# Waagenbox 1.2.41 – Kameravorschau

## Gewünschte Funktion

Kamerafotos erscheinen ausschließlich in der
Wiegungsübersicht in der Spalte Kamera.

Ein Klick auf die Miniatur öffnet die Großansicht
in einem Fenster mit dunklem Hintergrund.

Der Wiegeschein und der PDF-Ausdruck enthalten
keine Kameraaufnahme.

## Fehlerursache

Der JavaScript-Aufruf openCameraImage() wurde
nicht korrekt für ein HTML-Attribut kodiert.

## Korrektur

In weighings.php wird json_encode($photo)
nun zusätzlich über h() für HTML kodiert.

## Test

- JPEG über HTTP 200 erreichbar
- Thumbnail in der Übersicht angezeigt
- Großansicht per Klick geöffnet
- Schließen-Button sichtbar
- Browser-Test durch Betreiber bestätigt
- PHP-Syntax erfolgreich

Der Test wurde mit einem künstlichen JPEG für
Testwiegung 85 durchgeführt.

## Installation

Korrektur im Git-Entwicklungsverzeichnis und
in der Apache-Testinstanz vorgenommen.

Produktive Waagenbox unverändert.

## Freigabestatus

Funktion in der Testinstanz geprüft.
Produktivübernahme erst bei freigegebenem Update.
