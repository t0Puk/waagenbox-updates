# AJP Waagenbox – Release 1.2.41

Stand: 2026-10-11

## Ausgangsbasis

Produktive Version: 1.2.40

Entwicklungsbranch:
feature/1.2.41-field-validation

## Änderungen

### DINI 3590ETKR

- DINI-Wiegungs-ID dauerhaft speichern.
- Wiegescheinnummer aus DINI-ID und
  Waagenbox-Nummer zusammensetzen.
- Großanzeige erst nach bestätigtem
  KEYP37 und KEYR freigeben.
- Bereits produktiv getestete RALL-
  und Livegewichtserfassung erhalten.

### ELDAT RX09

- Verarbeitung der Funksignale verbessert.
- Seriellen Empfang während der
  Startverarbeitung aufrechterhalten.
- Doppelten Start des DINI-Workers verhindern.
- Alten 433-MHz-Dienst nicht mehr benötigen.
- Eldat verwaltet sein RuntimeDirectory selbst.

### Großanzeige

- Startfreigabe an DINI-Bestätigung koppeln.
- BRUTTO-Beschriftung im
  Verarbeitungszustand entfernen.

### Feldmanager

- Letzten begonnenen Schlag bis
  zum nächsten Schlag weiterverwenden.
- Eigenständige Telegram-
  Verbindungsüberwachung vorbereiten.

### Berichte

- Ertrag in t/ha je Schlag anzeigen.
- Gesamtauswertung aktiver Schläge.
- Druckansicht für aktive Schläge.

### Wiegungen

- Mehrere Wiegungen auswählen und löschen.
- Kamera-Vorschau verbessert.

## Datenbankmigration

migration_v1_2_41_dini_ticket_id.sql

Neue Spalte:
weighings.dini_id

## Produktivabgleich

Vor Freigabe wurden die Programmdateien
der laufenden Version 1.2.40 mit dem
Entwicklungsbranch verglichen.

Die bekannten produktiven DINI-Hotfixes
sind im Entwicklungsstand enthalten.

Zusätzliche lokale Produktivdateien
bleiben durch das Overlay-Deployment
erhalten.

## Freigabestatus

Release-Kandidat.

Produktive Installation und Praxistest
mit echter DINI- und ELDAT-Hardware
stehen noch aus.

Vor der Installation:
- Wartungsfenster ohne laufende Wiegung
- Vollständige Anwendungssicherung
- Frische Datenbanksicherung
- Signiertes Updatepaket
- Rollbackmöglichkeit prüfen
