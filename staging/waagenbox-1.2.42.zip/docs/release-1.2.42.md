# AJP Waagenbox 1.2.42

## Änderungen

- Eindeutige Job-Token für laufende Wiegeaufträge.
- Tokengebundene DINI- und Eldat-Abschlüsse.
- Schutz gegen verspätete und doppelte Abschlussmeldungen.
- Gemeinsame MariaDB-Wartungssperre für Wiegestarts.
- Wartungsschutz für manuelle, QR-, Eldat- und klassische Funkstarts.
- Prüfung laufender und offener Wiegungen vor Update/Rollback.
- Wartungsjournal blockiert Starts nach ungeklärten Updateabbrüchen.
- Anpassungen der Shutdown-/Recovery-Sperrbehandlung.
- Überarbeitete Regressionstests.

## Datenbank

Migration:

`migration_v1_2_42_job_token.sql`

Ergänzt in `weighing_state`:

- `job_token CHAR(32) NULL`
- Unique Index `uq_weighing_state_job_token`

Die Migration ist für wiederholte Ausführung vorgesehen.

## Tests

Bisher erfolgreich:

- PHP- und Python-Syntaxprüfungen
- DINI-Zwei-Pass-Prozesstest
- DINI-Startbestätigung und Timeout
- Eldat-RX09-Simulation und Entprellung
- QR- und Funkregressionen
- Update-Sicherungstest (76 Prüfungen)
- MariaDB-Wartungssperren
- Isolierte Journalprüfungen
- Simulierter Shutdown-Sperrtest

## Hinweise zum Produktivupdate

Der Wechsel von 1.2.41 auf 1.2.42 benötigt ein
kontrolliertes Wartungsfenster.

Vor der Installation:

1. Keine laufenden Wiegungen.
2. Keine offenen Fahrzeugwiegungen.
3. Vollständige Datenbanksicherung.
4. Vollständige Anwendungssicherung.
5. Bestehende DINI- und Eldat-Konfiguration erhalten.

Die Hardwaretests erfolgen anschließend an der echten Waage.

Der simulierte Shutdown-Test ersetzt keinen vollständigen
Update-/Rollback-End-to-End-Test mit realer Wiederherstellung.

## Ergänzende Shutdown-Absicherung

- Der Update- und Rollback-Shutdown-Handler hält die
  MariaDB-Verbindung während der Recovery ausdrücklich fest.
- Die Wartungssperre bleibt während einer unerwartet
  ausgelösten Wiederherstellung erhalten.
- Die Sperrlebensdauer wurde mit dem echten Shutdown-Handler
  und einer zweiten MariaDB-Verbindung dynamisch getestet.
- Ein vollständiger Restore-End-to-End-Test steht weiterhin aus.
