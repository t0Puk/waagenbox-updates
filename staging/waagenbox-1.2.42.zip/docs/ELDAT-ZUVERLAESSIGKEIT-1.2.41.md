# Waagenbox 1.2.41 – Eldat RX09 Zuverlässigkeit

## Ausgangsproblem

Ein erster Tastendruck am Eldat-Handsender führte
gelegentlich nicht zur erwarteten Wiegung.

Die Protokolle vom 09.10.2026 zeigten außerdem
mehrfach erkannte Funkereignisse und zusätzliche
DINI-Worker-Startversuche.

## Ursache 1 – Doppelter DINI-Worker-Start

Bei einer normalen Eldat-Wiegung startet
startVehiclePass() bereits den DINI-Worker.

cli/eldat_remote_trigger.php rief anschließend
startDiniPendingWorker() ein zweites Mal auf.

Dieser zusätzliche Aufruf wurde entfernt.

Die Erstgewichtserfassung behält ihren eigenen
Workerstart, da sie startVehiclePass() nicht verwendet.

## Ursache 2 – Blockierender RX09-Listener

Der Listener führte den PHP-Startauftrag bisher
synchron aus.

Währenddessen konnten Funktelegramme nicht
kontinuierlich verarbeitet werden.

Die Verarbeitung wurde in einen separaten Thread
verschoben.

Der serielle Empfang bleibt dadurch aktiv.

## Schutz vor Doppelstarts

- Pro Sender wird ein Tastendruck entprellt.
- Wiederholtelegramme werden unterdrückt.
- Während ein Startauftrag läuft, wird kein
  zusätzlicher Startauftrag angenommen.
- Es existiert keine Warteschlange für Startaufträge.
- Die Funkstille-Freigabe bleibt bei 1,0 Sekunden.
- Erstgewicht und Einlernmodus bleiben erhalten.

## Geänderte Dateien

- cli/eldat_remote_trigger.php
- hardware/eldat_rx09_listener.py

## Tests

- Eldat-Workerstart-Regression: bestanden
- Funk-Dry-Run: bestanden
- Virtueller serieller RX09: bestanden
- 7 RX09-Integrationstests: bestanden
- Langer Tastendruck: genau ein Auftrag
- Verzögerter PHP-Aufruf: Empfang bleibt aktiv
- Zusätzlicher Sender: kein gepufferter Auftrag
- Neuer Tastendruck nach Funkpause: erkannt

## Einschränkung

Der RX09 liefert kein ausdrückliches Release-Ereignis.
Deshalb bleibt die Abgrenzung physischer Tastendrücke
von ausreichend langer Funkstille abhängig.

Der Test mit den echten Handsendern am laufenden
DINI-System steht noch aus.

## Release-Status

Im Entwicklungsbranch umgesetzt und simuliert getestet.

Keine Änderung an der produktiven Waagenbox
oder am aktiven Eldat-systemd-Dienst vorgenommen.

## Ergänzung: abschließender Entprelltest

Der bisherige Timing-Simulationstest modellierte noch
einen blockierenden PHP-Aufruf.

Die aktuelle RX09-Implementierung verarbeitet Funktelegramme
währenddessen in einem separaten Ausführungspfad weiter.

Der Timing-Test wurde deshalb an die asynchrone Architektur
angepasst.

Ergebnisse:
- Kurzer Tastendruck: PASS
- Zwei getrennte Tastendrücke: PASS
- Langer Tastendruck bei langsamem PHP-Trigger: PASS
- Zwei Tastendrücke nach Worker-Ende: PASS

Zusätzlich bestand der PTY-Integrationstest mit dem
tatsächlichen Listener alle sieben Prüfungen.

Die produktive Eldat-Installation wurde nicht verändert.
Ein Praxistest am realen RX09 bleibt erforderlich.
