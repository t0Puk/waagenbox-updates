# Waagenbox 1.2.41 – Großanzeige

## Änderung 4: Bruttobezeichnung entfernen

Im Zustand "WIEGUNG WIRD VERARBEITET"
soll bei einer Bruttowiegung keine zusätzliche
Bezeichnung "BRUTTOGEWICHT" erscheinen.

## Umsetzung

Datei: api/grossanzeige_status.php

Im Processing-Zustand ohne offene
Fahrzeugwiegung werden:

- weight_label auf einen leeren String gesetzt
- weight_label_key auf einen leeren String gesetzt

Unverändert bleiben:

- Gewichtswerte
- Verarbeitungszustand
- Erstgewicht
- Zweitgewicht
- Nettogewicht
- alle anderen Großanzeigen-Zustände

Die eigenständige Großanzeigen-Software
wurde nicht verändert.

## Prüfung

- 6 Strukturprüfungen erfolgreich
- PHP-Syntax fehlerfrei
- git diff --check fehlerfrei

Ein vollständiger Praxistest während einer
realen DINI-Wiegung steht noch aus.

## Freigabestatus

Im Entwicklungsbranch umgesetzt und geprüft.
Noch nicht produktiv installiert.
