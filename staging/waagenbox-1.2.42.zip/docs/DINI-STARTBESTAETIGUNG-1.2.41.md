# Waagenbox 1.2.41 – DINI-Startbestätigung

## Ziel

Die Großanzeige darf erst dann zum Auffahren
auffordern, wenn der DINI die Startbefehle
KEYP37 und KEYR jeweils mit OK bestätigt hat.

## Ablauf

1. Fahrer startet eine Wiegung.
2. Alte DINI-Startfreigabe wird gelöscht.
3. Waagenbox sendet KEYP37.
4. DINI bestätigt mit OK.
5. Waagenbox sendet KEYR.
6. DINI bestätigt mit OK.
7. live.json erhält start_confirmed=true.
8. Großanzeigen-API erlaubt Zustand drive_on.
9. Bei erkannter Überfahrt folgt processing.

## Fehlerverhalten

Bei fehlender oder abgelehnter Bestätigung
wird keine Auffahrfreigabe erteilt.

Die Großanzeige bleibt zunächst im Zustand
processing, solange eine Wiegung aussteht.

## Dateien

- hardware/Dini3590.php
- api/grossanzeige_status.php

## Sicherheit

Die Startfreigabe wird vor jeder Überfahrt
entfernt, auch bei einer zweiten Überfahrt.

Live-Gewichtsmeldungen behalten das
Kennzeichen start_confirmed=true.

Der Demo-Modus bleibt unverändert.

## Tests

- 8 Großanzeigen-Startprüfungen bestanden
- 6 statische Großanzeigen-Prüfungen bestanden
- 15 DINI-Startbestätigungsprüfungen bestanden
- 14 DINI-Zwei-Pass-Prüfungen bestanden
- DINI-Live-Gewichtstest bestanden
- DINI-Timeout-Test bestanden

Alle 6 Testgruppen erfolgreich.

## Status

Im Entwicklungsbranch umgesetzt und getestet.

Noch nicht auf produktive Waagenbox übertragen.

Der vollständige Praxistest am echten
DINI-Terminal und der Großanzeige steht aus.
