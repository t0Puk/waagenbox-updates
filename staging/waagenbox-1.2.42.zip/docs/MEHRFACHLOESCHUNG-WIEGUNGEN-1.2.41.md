# Waagenbox 1.2.41 – Mehrfachlöschung von Wiegungen

## Ziel

Mehrere Wiegescheine können gemeinsam in der
Wiegungsübersicht ausgewählt und gelöscht werden.

## Umsetzung

Datei: weighings.php

- Checkbox vor jeder Wiegung
- Alle angezeigten Wiegungen auswählen
- Button mit Anzahl ausgewählter Wiegungen
- Sicherheitsabfrage vor endgültiger Löschung
- Vorhandene Einzellöschung bleibt bestehen
- Vorhandene Filter bleiben nach dem Löschen erhalten
- Automatische Aktualisierung pausiert bei aktiver Auswahl

## Serverseitige Sicherheit

- Löschung ausschließlich über POST
- CSRF-Token erforderlich
- Maximale Auswahl: 500 Wiegungen
- Ungültige IDs werden abgewiesen
- Doppelte IDs werden zusammengefasst
- Besitzerprüfung über owner_user_id
- Datenbanktransaktion für die Löschoperation
- Kamera-Snapshots werden nach erfolgreichem
  Commit der betroffenen Wiegungen entfernt

## Testinstanz

Git-Branch:
feature/1.2.41-field-validation

Webroot:
/var/www/waage-test

Datenbank:
waagebox_test

## Praxistest

Ausgangsbestand: 24 Testwiegungen

Zusätzliche Testdatensätze:

- ID 86: BULK_DELETE_TEST_1
- ID 87: BULK_DELETE_TEST_2
- ID 88: BULK_DELETE_TEST_KEEP

Die IDs 86 und 87 wurden über die Weboberfläche
gemeinsam ausgewählt und gelöscht.

Ergebnis der Datenbankkontrolle:

- ID 86 nicht mehr vorhanden
- ID 87 nicht mehr vorhanden
- ID 88 weiterhin vorhanden
- Gesamtbestand: 25 Wiegungen

Praxistest erfolgreich abgeschlossen.

## Noch offene Prüfungen

- Isolierter Test mit fremdem Benutzerkonto
- Abschließender Regressionstest vor Produktivrelease

## Release-Status

Auf Testinstanz umgesetzt und getestet.

Produktivinstallation und produktive Datenbank
wurden nicht verändert.

Noch kein Produktivrelease.
