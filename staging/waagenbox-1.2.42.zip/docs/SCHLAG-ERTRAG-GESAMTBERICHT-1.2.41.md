# Waagenbox 1.2.41 – Schlagübersicht und Hektarertrag

## Ziel

Die Schlagübersicht zeigt zusätzlich den Ertrag
in Tonnen pro Hektar.

Für alle aktiven Schläge gibt es einen gemeinsamen
druckbaren Gesamtbericht.

## Änderungen

### Schlagübersicht

Datei: fields.php

- Neue Spalte Ertrag (t/ha)
- Berechnung aus Netto-Gesamtgewicht und Fläche
- Bei fehlender oder ungültiger Fläche erscheint –
- Neuer Button: Aktive Schläge drucken

### Einzelschlagbericht

Datei: reports/field.php

- Neuer Wert Ertrag pro Hektar
- Berechnung identisch zur Schlagübersicht
- Vorhandene Druckfunktion bleibt erhalten

### Gesamtbericht

Neue Datei: reports/fields_active.php

- Nur aktive Schläge
- Schlagname, Kultur, Jahr
- Fläche in Hektar
- Anzahl Wiegungen
- Nettogewicht in Tonnen
- Ertrag pro Hektar
- Gesamtsumme
- Druckfunktion über Browser
- PDF-Speicherung über Browser-Druckdialog
- Drucklayout im Querformat A4

## Berechnung

Ertrag t/ha = Netto-Gesamtgewicht kg
              / 1000 / Fläche ha

Bei Schlägen ohne gültige Fläche erfolgt
keine Hektarertragsberechnung.

Die Nettogewichte dieser Schläge werden trotzdem
in die Gesamtmenge aufgenommen.

Der gesamte Hektarertrag wird nur aus Gewichten
von Schlägen mit gültiger Fläche berechnet.

Deaktivierte Schläge werden nicht berücksichtigt.

## Testdaten

9 aktive Schläge
40,36 ha Gesamtfläche
0 zugeordnete Wiegungen

Die Testoberfläche und der Sammelbericht wurden
am 11.10.2026 im Browser geprüft.

## Berechnungstests

3 aktive Schläge
8 ha gültige Fläche
370 t Gesamtgewicht
350 t davon mit gültiger Fläche
20 t ohne gültige Fläche

Ergebnis: 43,75 t/ha

8 von 8 Tests bestanden.

## Dateien

- fields.php
- reports/field.php
- reports/fields_active.php
- tests/field_yield_calculation_test.php

## Release-Status

Im Entwicklungsbranch umgesetzt und getestet.

Die Änderungen wurden ausschließlich in die
separate Test-Weboberfläche installiert.

Produktive Waagenbox und produktive Datenbank
wurden nicht verändert.

Noch kein Produktivrelease.
