<?php
declare(strict_types=1);

require_once __DIR__.'/../functions.php';
requireLogin();

$stmt = db()->prepare("
    SELECT
        f.id,
        f.name,
        f.crop,
        f.year,
        f.area,
        COALESCE(SUM(w.net_weight), 0) AS total_net_weight,
        COUNT(w.id) AS weighing_count
    FROM `fields` f
    LEFT JOIN weighings w
      ON w.field_id = f.id
     AND w.owner_user_id = f.owner_user_id
    WHERE f.owner_user_id = ?
      AND f.active = 1
    GROUP BY f.id
    ORDER BY f.name ASC, f.id ASC
");
$stmt->execute([currentOwnerId()]);
$rows = $stmt->fetchAll();

$totalKg = 0.0;
$totalArea = 0.0;
$totalWeighings = 0;
$knownAreaKg = 0.0;
$missingAreaKg = 0.0;
$missingAreaCount = 0;

foreach ($rows as $r) {
    $kg = (float)$r['total_net_weight'];
    $area = (float)($r['area'] ?? 0);

    $totalKg += $kg;
    $totalWeighings += (int)$r['weighing_count'];

    if ($area > 0) {
        $totalArea += $area;
        $knownAreaKg += $kg;
    } else {
        $missingAreaKg += $kg;
        $missingAreaCount++;
    }
}

$fmt = static fn(float $value, int $digits = 2): string =>
    number_format($value, $digits, ',', '.');

$overallYield = $totalArea > 0
    ? $knownAreaKg / 1000 / $totalArea
    : null;
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gesamtbericht aktive Schläge</title>
<style>
body {
    font-family: Arial, sans-serif;
    color: #14202c;
    margin: 32px auto;
    padding: 0 20px;
    max-width: 1100px;
}
h1 { margin-bottom: 5px; }
.subtitle { color: #617080; margin-top: 0; }
.toolbar { display: flex; gap: 10px; margin-bottom: 25px; }
.button {
    display: inline-block;
    padding: 10px 14px;
    background: #17212b;
    color: white;
    border: 0;
    border-radius: 7px;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
}
table { width: 100%; border-collapse: collapse; margin-top: 22px; }
th, td { padding: 10px 8px; border-bottom: 1px solid #ddd; }
th { text-align: left; background: #edf1f4; }
.number { text-align: right; white-space: nowrap; }
tfoot td { font-weight: bold; background: #edf1f4; }
.note { font-size: 13px; color: #52606d; margin-top: 20px; }
.summary { margin: 22px 0; font-size: 17px; }
@media print {
    @page { size: A4 landscape; margin: 12mm; }
    body { margin: 0; padding: 0; max-width: none; font-size: 11px; }
    .toolbar { display: none; }
    tr { break-inside: avoid; }
    thead { display: table-header-group; }
    tfoot { display: table-footer-group; }
    th, td { padding: 6px 5px; }
}
</style>
</head>
<body>

<div class="toolbar">
    <a class="button" href="../fields.php">← Zurück zu Schlägen</a>
    <button class="button" type="button" onclick="window.print()">
        Drucken / als PDF speichern
    </button>
</div>

<h1>Gesamtbericht – aktive Schläge</h1>
<p class="subtitle">
    Erstellt am <?=h(date('d.m.Y H:i'))?>
    · <?=count($rows)?> aktive Schläge
</p>

<table>
<thead>
<tr>
    <th>Schlag</th>
    <th>Kultur</th>
    <th>Jahr</th>
    <th class="number">Fläche (ha)</th>
    <th class="number">Wiegungen</th>
    <th class="number">Netto (t)</th>
    <th class="number">Ertrag (t/ha)</th>
</tr>
</thead>
<tbody>
<?php foreach ($rows as $r):
    $kg = (float)$r['total_net_weight'];
    $area = (float)($r['area'] ?? 0);
?>
<tr>
    <td><?=h($r['name'])?></td>
    <td><?=h($r['crop'] ?: '–')?></td>
    <td><?=h($r['year'] ?: '–')?></td>
    <td class="number"><?= $area > 0 ? $fmt($area) : '–' ?></td>
    <td class="number"><?=(int)$r['weighing_count']?></td>
    <td class="number"><?=$fmt($kg / 1000)?></td>
    <td class="number">
        <?= $area > 0 ? $fmt($kg / 1000 / $area) : '–' ?>
    </td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?>
<tr><td colspan="7">Keine aktiven Schläge vorhanden.</td></tr>
<?php endif; ?>
</tbody>
<tfoot>
<tr>
    <td>Gesamt</td>
    <td></td>
    <td></td>
    <td class="number"><?=$fmt($totalArea)?></td>
    <td class="number"><?=$totalWeighings?></td>
    <td class="number"><?=$fmt($totalKg / 1000)?></td>
    <td class="number">
        <?=$overallYield !== null ? $fmt($overallYield) : '–'?>
    </td>
</tr>
</tfoot>
</table>

<p class="note">
    Alle Gewichte sind Nettogewichte.
    Der Gesamtertrag in t/ha wird aus den Schlägen mit gültiger
    Fläche berechnet.
    <?php if ($missingAreaCount > 0): ?>
        <?=$missingAreaCount?> aktive Schläge ohne gültige Fläche
        mit zusammen <?=$fmt($missingAreaKg / 1000)?> t netto
        sind in der Gesamtmenge enthalten, aber nicht in
        der Hektarertragsberechnung.
    <?php endif; ?>
</p>

</body>
</html>
