-- Waagenbox 1.2.42
-- Eindeutige Kennung fuer laufende Wiegeauftraege.
-- Wiederholbar bei bereits vorhandener Spalte / vorhandenem Index.
-- Bestehende Daten und Wiegescheine bleiben unveraendert.

SET @wb_column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'weighing_state'
      AND COLUMN_NAME = 'job_token'
);

SET @wb_sql = IF(
    @wb_column_exists = 0,
    'ALTER TABLE weighing_state ADD COLUMN job_token CHAR(32) NULL AFTER started_at',
    'DO 0'
);

PREPARE wb_stmt FROM @wb_sql;
EXECUTE wb_stmt;
DEALLOCATE PREPARE wb_stmt;

SET @wb_index_exists = (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'weighing_state'
      AND INDEX_NAME = 'uq_weighing_state_job_token'
);

SET @wb_sql = IF(
    @wb_index_exists = 0,
    'CREATE UNIQUE INDEX uq_weighing_state_job_token ON weighing_state (job_token)',
    'DO 0'
);

PREPARE wb_stmt FROM @wb_sql;
EXECUTE wb_stmt;
DEALLOCATE PREPARE wb_stmt;
