<?php
declare(strict_types=1);

/**
 * Gemeinsame MariaDB-Sperre fuer Wiegestarts und Wartung.
 *
 * Die Sperre ist an die PDO-Verbindung gebunden.
 * Die aufrufende Funktion muss diese Verbindung
 * bis zur Freigabe am Leben halten.
 */

function waagenboxMaintenanceLockName(): string
{
    if (!defined('DB_NAME') || !is_string(DB_NAME)) {
        throw new RuntimeException('Datenbankname fehlt.');
    }

    return 'ajp_wb_maint_' . substr(
        hash('sha256', DB_NAME),
        0,
        32
    );
}

function waagenboxMaintenanceAcquire(
    PDO $pdo,
    int $timeoutSeconds = 0
): void {
    if ($timeoutSeconds < 0 || $timeoutSeconds > 30) {
        throw new InvalidArgumentException(
            'Ungueltige Wartezeit fuer Wartungssperre.'
        );
    }

    $stmt = $pdo->prepare(
        'SELECT GET_LOCK(?, ?)'
    );
    $stmt->execute([
        waagenboxMaintenanceLockName(),
        $timeoutSeconds
    ]);

    if ((int)$stmt->fetchColumn() !== 1) {
        throw new RuntimeException(
            'Die Waagenbox ist durch einen Wartungsvorgang belegt.'
        );
    }
}

function waagenboxMaintenanceRelease(PDO $pdo): void
{
    $stmt = $pdo->prepare(
        'SELECT RELEASE_LOCK(?)'
    );
    $stmt->execute([
        waagenboxMaintenanceLockName()
    ]);

    if ((int)$stmt->fetchColumn() !== 1) {
        throw new RuntimeException(
            'Wartungssperre konnte nicht freigegeben werden.'
        );
    }
}

/**
 * Verhindert Wiegestarts bei ungeklärten Update-/Rollbackvorgaengen.
 *
 * Muss bei gehaltener MariaDB-Wartungssperre ausgefuehrt werden.
 */
function waagenboxMaintenanceAssertJournalClear(): void
{
    if (!function_exists('rollbackBackupRoot')) {
        throw new RuntimeException(
            'Wartungsschutz nicht verfuegbar: Backup-Konfiguration fehlt.'
        );
    }

    $root = rollbackBackupRoot();
    $journal = dirname($root) . '/operation.json';

    if (!is_file($journal) && !is_link($journal)) {
        return;
    }

    if (is_link($journal) || !is_file($journal)) {
        throw new RuntimeException(
            'Wiegestart gesperrt: Wartungsjournal ist ungueltig.'
        );
    }

    $json = @file_get_contents($journal);

    if ($json === false) {
        throw new RuntimeException(
            'Wiegestart gesperrt: Wartungsjournal ist nicht lesbar.'
        );
    }

    try {
        $state = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        throw new RuntimeException(
            'Wiegestart gesperrt: Wartungsjournal ist beschaedigt.',
            0,
            $e
        );
    }

    if (
        !is_array($state) ||
        !in_array(
            $state['state'] ?? null,
            ['complete', 'recovered', 'aborted'],
            true
        )
    ) {
        throw new RuntimeException(
            'Wiegestart gesperrt: Ein Wartungsvorgang ist nicht abgeschlossen.'
        );
    }
}

/**
 * Fuehrt einen Wiegestart unter der gemeinsamen Wartungssperre aus.
 *
 * Der Callback muss den eigentlichen Start einschliesslich
 * des Datenbank-INSERTs durchfuehren.
 *
 * Die Sperre bleibt bis zum Verlassen des Callbacks bestehen.
 */
function waagenboxWithWeighingStartLock(
    PDO $pdo,
    callable $callback
): mixed {
    waagenboxMaintenanceAcquire($pdo);

    try {
        waagenboxMaintenanceAssertJournalClear();
        return $callback();
    } finally {
        waagenboxMaintenanceRelease($pdo);
    }
}

/**
 * Prueft alle Benutzer, nicht nur den angemeldeten.
 * Muss bei gehaltener Wartungssperre erfolgen.
 */
function waagenboxMaintenanceAssertIdle(PDO $pdo): void
{
    $active = (int)$pdo->query(
        'SELECT COUNT(*) FROM weighing_state'
    )->fetchColumn();

    if ($active > 0) {
        throw new RuntimeException(
            'Update gesperrt: Es laufen noch ' .
            $active . ' Wiegungen.'
        );
    }

    $open = (int)$pdo->query(
        'SELECT COUNT(*) FROM open_vehicle_weighings'
    )->fetchColumn();

    if ($open > 0) {
        throw new RuntimeException(
            'Update gesperrt: Es sind noch ' .
            $open . ' Fahrzeugwiegungen offen.'
        );
    }
}
