#!/usr/bin/env python3
"""Simulation der asynchronen RX09-Entprellung.

Keine Hardware, Datenbank oder echten Wiegungen.
Der Listener verarbeitet Telegramme weiter, während
ein separater Thread den PHP-Trigger ausführt.
"""

RELEASE_QUIET_SECONDS = 1.0


def simulate(events, processing_delay=0.0):
    pressed = False
    last_seen = None
    triggered = []
    busy_until = 0.0

    for timestamp in events:
        now = timestamp

        # Empfang läuft unabhängig vom PHP-Worker weiter.
        if (
            pressed
            and last_seen is not None
            and now - last_seen >= RELEASE_QUIET_SECONDS
        ):
            pressed = False

        if pressed:
            last_seen = now
            continue

        pressed = True
        last_seen = now

        # Während ein Trigger läuft, wird kein weiterer
        # Startauftrag ausgelöst.
        if now < busy_until:
            continue

        triggered.append(timestamp)
        busy_until = now + processing_delay

    return triggered


def check(name, events, expected, delay=0.0):
    actual = len(simulate(events, delay))
    ok = actual == expected

    print(
        ("PASS" if ok else "FAIL")
        + f": {name} – {actual} Ereignisse"
        + f" (erwartet {expected})"
    )

    return ok


def main():
    short_press = [0.0, 0.05, 0.10, 0.15, 0.20]

    two_presses = [
        0.0, 0.05, 0.10,
        2.0, 2.05, 2.10
    ]

    slow_processing = [
        0.0, 0.05, 0.10, 0.15,
        0.20, 0.25, 0.30, 0.35,
        0.40, 0.45
    ]

    checks = [
        check("Kurzer Tastendruck", short_press, 1),
        check("Zwei getrennte Tastendrücke", two_presses, 2),
        check(
            "Langer Tastendruck bei langsamem PHP-Trigger",
            slow_processing,
            1,
            delay=1.5
        ),
        check(
            "Zwei Tastendrücke nach Worker-Ende",
            two_presses,
            2,
            delay=1.5
        ),
    ]

    passed = sum(checks)
    total = len(checks)

    print()
    print(f"ERGEBNIS: {passed}/{total} Tests bestanden")

    return 0 if passed == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
