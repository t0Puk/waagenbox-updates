<?php
declare(strict_types=1);

/*
 * Isolierter Funktionstest.
 * Keine echten API-Aufrufe, Datenbankzugriffe
 * oder Telegram-Nachrichten.
 */

$source = file_get_contents(__DIR__.'/../feldmanager_link.php');

$start = strpos($source, 'function feldmanagerAssignmentStatus(');
$end = strpos($source, 'function feldmanagerAutomaticFieldId(');

if ($start === false || $end === false || $end <= $start) {
    throw new RuntimeException('Funktionen nicht gefunden.');
}

$code = substr($source, $start);

$replacements = [
    'feldmanagerAssignmentStatus' => 'testAssignmentStatus',
    'feldmanagerAutomaticFieldId' => 'testAutomaticFieldId',
    'feldmanagerEnabled' => 'mockEnabled',
    'feldmanagerTeamForRemote' => 'mockTeam',
    'feldmanagerActiveField' => 'mockApi',
    'feldmanagerResolveLocalField' => 'mockResolve',
    'saveAppSetting' => 'mockSave',
    'appSetting' => 'mockSetting',
    'db()' => 'mockDb()',
    'currentOwnerId()' => 'mockOwnerId()',
];

$code = str_replace(
    array_keys($replacements),
    array_values($replacements),
    $code
);

eval($code);

$GLOBALS['mock_api'] = [];
$GLOBALS['mock_settings'] = [];

function mockEnabled(): bool {
    return true;
}

function mockTeam(?int $remoteId): ?int {
    return match ($remoteId) {
        60 => 6,
        70 => 7,
        default => null,
    };
}

function mockApi(?int $team): array {
    return $GLOBALS['mock_api'][$team ?? 0] ?? [
        'ok'=>false,
        'error'=>'no_mock',
    ];
}

function mockResolve(array $field): ?int {
    return match ($field['name'] ?? '') {
        'Schlag A' => 101,
        'Schlag B' => 102,
        'Schlag C' => 201,
        default => null,
    };
}

function mockSave(string $key, string $value): void {
    $GLOBALS['mock_settings'][$key] = $value;
}

function mockSetting(string $key, string $default=''): string {
    return $GLOBALS['mock_settings'][$key] ?? $default;
}

function mockDb(): never {
    throw new RuntimeException('Unerwarteter Datenbankzugriff.');
}

function mockOwnerId(): int {
    return 1;
}

function remoteField(int $team, string $name): array {
    return [
        'team_number'=>$team,
        'field'=>['name'=>$name],
    ];
}

function assertTest(
    string $label,
    bool $condition
): void {
    static $count=0;
    $count++;

    echo ($condition ? 'PASS ' : 'FAIL '),
        $label, PHP_EOL;

    if (!$condition) {
        throw new RuntimeException(
            'Funktionstest fehlgeschlagen: '.$label
        );
    }
}

/* 1. Schlag A ist aktiv */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>1,
    'active'=>remoteField(6,'Schlag A'),
];

assertTest(
    'Aktiver Schlag A wird zugeordnet',
    testAutomaticFieldId(null,60)===101
);

assertTest(
    'Schlag A wird fuer Team 6 gespeichert',
    ($GLOBALS['mock_settings']['feldmanager_last_field_team_6']??null)==='101'
);

/* 2. Schlag A beendet, Nachlauf */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>0,
    'latest_started'=>remoteField(6,'Schlag A'),
];

assertTest(
    'Nachlauf bleibt bei Schlag A',
    testAutomaticFieldId(null,60)===101
);

/* 3. Schlag B beginnt */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>1,
    'active'=>remoteField(6,'Schlag B'),
];

assertTest(
    'Neue Arbeit wechselt auf Schlag B',
    testAutomaticFieldId(null,60)===102
);

/* 4. Schlag B beendet */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>0,
    'latest_started'=>remoteField(6,'Schlag B'),
];

assertTest(
    'Nachlauf bleibt jetzt bei Schlag B',
    testAutomaticFieldId(null,60)===102
);

/* 5. Anderes Team */
$GLOBALS['mock_api'][7] = [
    'ok'=>true,
    'active_count'=>1,
    'active'=>remoteField(7,'Schlag C'),
];

assertTest(
    'Team 7 bekommt eigenen Schlag C',
    testAutomaticFieldId(null,70)===201
);

assertTest(
    'Team 6 bleibt bei Schlag B',
    testAutomaticFieldId(null,60)===102
);

/* 6. Fehlerhafte API */
$GLOBALS['mock_api'][6] = [
    'ok'=>false,
    'error'=>'connection_failed',
];

assertTest(
    'API-Fehler uebernimmt keinen neuen Schlag',
    testAutomaticFieldId(null,60)===null
);

/* 7. Mehrere aktive Arbeiten */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>2,
    'active'=>null,
];

assertTest(
    'Mehrdeutigkeit wird nicht zugeordnet',
    testAutomaticFieldId(null,60)===null
);

/* 8. Falsches Team bei aktivem Schlag */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>1,
    'active'=>remoteField(7,'Schlag C'),
];

assertTest(
    'Falsches Team wird abgewiesen',
    testAutomaticFieldId(null,60)===null
);

/* 9. Kein jemals gestarteter Schlag */
$GLOBALS['mock_api'][6] = [
    'ok'=>true,
    'active_count'=>0,
    'latest_started'=>null,
];

assertTest(
    'Explizit leere Historie verwendet keinen alten Schlag',
    testAutomaticFieldId(null,60)===null
);

/* 10. Keine Fernbedienungs-Teamzuordnung */
assertTest(
    'Unbekannte Fernbedienung behaelt Fallback',
    testAutomaticFieldId(999,999)===999
);

echo PHP_EOL;
echo "OK: Funktionale Schlagzuordnung erfolgreich getestet.\n";
