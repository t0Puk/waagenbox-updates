<?php
declare(strict_types=1);

$testRuntime = sys_get_temp_dir()
    . '/waagenbox-dini-test-' . getmypid();

if (!is_dir($testRuntime) && !mkdir($testRuntime, 0700, true)) {
    throw new RuntimeException('Testverzeichnis konnte nicht erstellt werden.');
}

putenv('WAAGENBOX_DINI_RUNTIME_DIR=' . $testRuntime);

register_shutdown_function(static function () use ($testRuntime): void {
    foreach (glob($testRuntime . '/diagnostics/*') ?: [] as $file) {
        @unlink($file);
    }
    @rmdir($testRuntime . '/diagnostics');
    @unlink($testRuntime . '/live.json');
    @unlink($testRuntime . '/io.lock');
    @rmdir($testRuntime);
});

require_once __DIR__ . '/../hardware/Dini3590.php';

$port = random_int(20000, 45000);
$serverScript = tempnam(sys_get_temp_dir(), 'dini-sim-');

file_put_contents($serverScript, <<<'SIM'
<?php
$server = stream_socket_server(
    'tcp://127.0.0.1:' . $argv[1],
    $errno,
    $errstr
);
if (!$server) exit(2);

$conn = stream_socket_accept($server, 10);
if (!$conn) exit(3);

stream_set_timeout($conn, 5);
$rallCount = 0;
$sentFinal = false;

while (!feof($conn)) {
    $line = fgets($conn);
    if ($line === false) break;
    $cmd = trim($line);

    if ($cmd === 'KEYP37' || $cmd === 'KEYR') {
        fwrite($conn, "OK\r\n");
    } elseif ($cmd === 'RALL') {
        $rallCount++;
        $weight = match ($rallCount) {
            1 => 0,
            2 => 250,
            3 => 500,
            default => 505
        };
        fwrite($conn, "S1,ST,{$weight},kg\r\n");

        if ($weight >= 505) {
            usleep(500000);
            fwrite(
                $conn,
                "08/10/26;06:30;1;;;9610;;;;Wiegung;;0;0\r\n"
            );
            $sentFinal = true;
        }
    }
}

file_put_contents($argv[2], json_encode([
    'rall_count' => $rallCount,
    'final_sent' => $sentFinal
]));

fclose($conn);
fclose($server);
SIM
);

$resultFile = tempnam(sys_get_temp_dir(), 'dini-result-');

$cmd = [
    PHP_BINARY,
    $serverScript,
    (string)$port,
    $resultFile
];

$proc = proc_open(
    $cmd,
    [
        0 => ['file', '/dev/null', 'r'],
        1 => ['file', '/dev/null', 'w'],
        2 => ['file', '/dev/null', 'w']
    ],
    $pipes
);

try {
    usleep(300000);

    $dini = new Dini3590('127.0.0.1', $port, 2.0, 500.0);
    $result = $dini->runFirstWeighing(15.0);

    $data = $result['weight'] ?? null;
    echo "DINI-Ergebnis: ", var_export($result, true), PHP_EOL;

    proc_close($proc);
    $proc = null;

    $sim = json_decode(file_get_contents($resultFile), true);

    if (($sim['rall_count'] ?? 0) !== 4) {
        throw new RuntimeException(
            'RALL wurde nicht exakt viermal abgefragt.'
        );
    }

    if (empty($sim['final_sent'])) {
        throw new RuntimeException(
            'Offizielles DINI-Endergebnis wurde nicht gesendet.'
        );
    }

    echo "PASS: RALL bei 505 kg beendet.\n";
    echo "PASS: Kein weiteres RALL nach Abschaltschwelle.\n";
    echo "PASS: Offizieller DINI-Datensatz empfangen.\n";
} finally {
    if (is_resource($proc)) {
        proc_terminate($proc);
        proc_close($proc);
    }
    @unlink($serverScript);
    @unlink($resultFile);
}
