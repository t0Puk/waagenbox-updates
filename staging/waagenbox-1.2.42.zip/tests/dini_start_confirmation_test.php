<?php
declare(strict_types=1);

require_once __DIR__.'/../hardware/Dini3590.php';

$dir = sys_get_temp_dir().'/dini-start-'.getmypid();
if (!mkdir($dir, 0700, true)) {
    throw new RuntimeException('Testordner fehlt');
}
putenv('WAAGENBOX_DINI_RUNTIME_DIR='.$dir);

$failed = 0;
function checkStart(bool $ok, string $name): void {
    global $failed;
    echo ($ok ? 'PASS: ' : 'FAIL: ').$name.PHP_EOL;
    if (!$ok) $failed++;
}

foreach (['success', 'repeat', 'reject_press', 'reject_release'] as $mode) {
    $live = $dir.'/live.json';
    $observations = $dir.'/observations.json';

    @unlink($live);
    @unlink($observations);

    // Simuliert eine Freigabe einer vorherigen Überfahrt.
    file_put_contents($live, json_encode([
        'active'=>true,
        'phase'=>'drive_on',
        'start_confirmed'=>true
    ]));

    $server = stream_socket_server(
        'tcp://127.0.0.1:0', $errno, $errstr
    );
    if (!$server) throw new RuntimeException($errstr);

    $address = stream_socket_get_name($server, false);
    $port = (int)substr(strrchr($address, ':'), 1);
    $pid = pcntl_fork();

    if ($pid === -1) throw new RuntimeException('Fork fehlgeschlagen');

    if ($pid === 0) {
        $checks = [
            'before_press'=>false,
            'before_release'=>false,
            'after_release'=>false
        ];

        $conn = stream_socket_accept($server, 5);
        if (!$conn) exit(2);
        stream_set_timeout($conn, 5);

        while (($line = fgets($conn)) !== false) {
            $cmd = trim($line);

            if ($cmd === 'KEYP37') {
                usleep(200000);
                $checks['before_press'] = !is_file($live);

                if ($mode === 'reject_press') {
                    fwrite($conn, "ERROR\r\n");
                    break;
                }
                fwrite($conn, "OK\r\n");
            } elseif ($cmd === 'KEYR') {
                usleep(200000);
                $checks['before_release'] = !is_file($live);

                if ($mode === 'reject_release') {
                    fwrite($conn, "ERROR\r\n");
                    break;
                }
                fwrite($conn, "OK\r\n");
            } elseif ($cmd === 'RALL') {
                $data = is_file($live)
                    ? json_decode((string)file_get_contents($live), true)
                    : null;
                $checks['after_release'] =
                    is_array($data) &&
                    ($data['start_confirmed'] ?? false) === true &&
                    ($data['phase'] ?? '') === 'drive_on';

                fwrite(
                    $conn,
                    "05/10/26;21:00;101;;;1200;;;;Wiegung;;0;0\r\n"
                );
                break;
            }
        }

        file_put_contents($observations, json_encode($checks));
        fclose($conn);
        fclose($server);
        exit(0);
    }

    $threw = false;
    try {
        $dini = new Dini3590('127.0.0.1', $port, 2.0);
        $dini->runFirstWeighing(5.0);
    } catch (Throwable $e) {
        $threw = true;
        echo 'INFO '.$mode.': '.$e->getMessage().PHP_EOL;
    }

    pcntl_waitpid($pid, $status);
    fclose($server);

    $checks = is_file($observations)
        ? json_decode((string)file_get_contents($observations), true)
        : [];

    checkStart(
        ($checks['before_press'] ?? false) === true,
        $mode.': alte Freigabe vor KEYP37 entfernt'
    );

    if ($mode !== 'reject_press') {
        checkStart(
            ($checks['before_release'] ?? false) === true,
            $mode.': keine Freigabe vor KEYR-OK'
        );
    }

    if (in_array($mode, ['success', 'repeat'], true)) {
        checkStart(!$threw, $mode.': DINI-Start erfolgreich');
        checkStart(
            ($checks['after_release'] ?? false) === true,
            $mode.': Freigabe erst nach beiden OK'
        );
    } else {
        checkStart($threw, $mode.': DINI-Fehler erkannt');
        checkStart(
            !is_file($live),
            $mode.': keine Auffahrfreigabe nach Fehler'
        );
    }
}

foreach (glob($dir.'/*') ?: [] as $file) @unlink($file);
@rmdir($dir);

echo 'ERGEBNIS: '.($failed === 0 ? 'ALLE TESTS BESTANDEN' : $failed.' FEHLER').PHP_EOL;
exit($failed === 0 ? 0 : 1);
