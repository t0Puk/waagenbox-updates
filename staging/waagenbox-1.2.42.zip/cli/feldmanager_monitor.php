<?php
declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

$dryRun = in_array('--dry-run', $argv, true);

if (in_array('--simulate-connected', $argv, true)) {
    echo "SIMULATION: Feldmanager verbunden.\n";
    echo "Keine Telegram-Nachricht.\n";
    exit(0);
}

if (in_array('--simulate-error', $argv, true)) {
    echo "SIMULATION: Feldmanager nicht erreichbar.\n";
    echo "Keine Telegram-Nachricht.\n";
    exit(0);
}

if (!feldmanagerEnabled()) {
    echo "Feldmanager-Überwachung deaktiviert.\n";
    exit(0);
}

$lockPath = sys_get_temp_dir()
    . '/waagenbox-feldmanager-monitor-'
    . hash('sha256', __DIR__)
    . '.lock';

$lock = fopen($lockPath, 'c');
if ($lock === false) {
    fwrite(STDERR, "Monitor-Lock nicht verfügbar.\n");
    exit(1);
}

if (!flock($lock, LOCK_EX | LOCK_NB)) {
    echo "Andere Monitorprüfung läuft bereits.\n";
    exit(0);
}

try {
    $status = feldmanagerMonitor();

    $connected = false;

    if (!empty($status['ok'])) {
        $outbound = (array)(
            $status['directions']['waagenbox_to_feldmanager']
            ?? []
        );

        $connected =
            ($outbound['state'] ?? '') === 'connected';
    }

    echo $connected
        ? "Feldmanager: verbunden\n"
        : "Feldmanager: Verbindung gestört\n";

    if (!$dryRun) {
        feldmanagerTelegramHandleOutboundState($connected);
    } else {
        echo "Trockenlauf: keine Telegram-Meldung.\n";
    }
} catch (Throwable $e) {
    fwrite(
        STDERR,
        "Feldmanager-Monitor: Prüfung fehlgeschlagen.\n"
    );
    exit(1);
} finally {
    flock($lock, LOCK_UN);
    fclose($lock);
}
