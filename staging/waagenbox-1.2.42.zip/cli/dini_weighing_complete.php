<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/rf_remote_support.php';

$args = array_slice($argv, 1);

$checkOnly = false;

if (($args[0] ?? '') === '--check') {
    $checkOnly = true;
    array_shift($args);
}

if (
    (!in_array(count($args), [6, 7], true)) ||
    !preg_match('/^\d+$/', (string)$args[0]) ||
    !preg_match('/^\d+$/', (string)$args[1]) ||
    !is_numeric((string)$args[4]) ||
    !preg_match('/^[a-f0-9]{32}$/', (string)$args[5]) ||
    (isset($args[6]) && !preg_match('/^[1-9][0-9]*$/', (string)$args[6]))
) {
    fwrite(
        STDERR,
        "Verwendung: php cli/dini_weighing_complete.php " .
        "<owner_id> <vehicle_id> <trigger> <started_at> <weight>" .
        PHP_EOL
    );
    exit(64);
}

$ownerId = (int)$args[0];
$expectedVehicleId = (int)$args[1];
$expectedTrigger = trim((string)$args[2]);
$expectedStartedAt = trim((string)$args[3]);
$weight = (float)$args[4];
$expectedJobToken = (string)$args[5];
$diniId = isset($args[6]) ? (int)$args[6] : null;

if (
    $ownerId <= 0 ||
    $expectedVehicleId < 0 ||
    $expectedTrigger === '' ||
    !preg_match(
        '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
        $expectedStartedAt
    ) ||
    $weight <= 0
) {
    fwrite(STDERR, "Ungültiger DINI-Abschlussauftrag." . PHP_EOL);
    exit(64);
}

$pdo = db();

/*
 * Die vorhandenen Waagenfunktionen arbeiten im Owner-Kontext.
 * Wir verwenden dafür dieselbe bewährte Umschaltung wie ELDAT.
 */
rfRemoteUseOwnerContext($pdo, $ownerId);

$pending = pendingWeighing();

if (!$pending) {
    fwrite(STDOUT, "DINI Abschluss: keine laufende Wiegung." . PHP_EOL);
    exit(2);
}

$pendingVehicleId = (int)($pending['vehicle_id'] ?? 0);
$pendingTrigger = (string)($pending['trigger_type'] ?? '');
$pendingStartedAt = (string)($pending['started_at'] ?? '');
$pendingJobToken = (string)($pending['job_token'] ?? '');

if (
    $pendingVehicleId !== $expectedVehicleId ||
    $pendingTrigger !== $expectedTrigger ||
    $pendingStartedAt !== $expectedStartedAt ||
    !hash_equals($expectedJobToken, $pendingJobToken)
) {
    fwrite(
        STDOUT,
        "DINI Abschluss: Auftrag ist nicht mehr aktuell." . PHP_EOL
    );
    exit(2);
}

/*
 * --check ist ausschließlich ein Preflight.
 * Nach erfolgreicher Prüfung der exakten Auftragsidentität darf hier
 * ausdrücklich noch kein Gewicht gespeichert oder Auftrag abgeschlossen werden.
 */
if ($checkOnly) {
    fwrite(STDOUT, "DINI Preflight: Auftrag ist gültig." . PHP_EOL);
    exit(0);
}

try {
    if (str_ends_with($pendingTrigger, '_first_pass')) {
        $result = capturePendingFirstPass($weight, $expectedJobToken);

        fwrite(
            STDOUT,
            'DINI Abschluss erste Überfahrt: ' .
            json_encode(
                $result,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) .
            PHP_EOL
        );

        if (!empty($result['waiting_for_second'])) {
            $nextPending = pendingWeighing();

            if (
                !$nextPending ||
                (int)($nextPending['vehicle_id'] ?? 0) !== 0 ||
                (string)($nextPending['trigger_type'] ?? '') === '' ||
                (string)($nextPending['started_at'] ?? '') === '' ||
                !hash_equals(
                    $expectedJobToken,
                    (string)($nextPending['job_token'] ?? '')
                )
            ) {
                throw new RuntimeException(
                    'Folgeauftrag für die zweite Überfahrt konnte nicht eindeutig gelesen werden.'
                );
            }

            fwrite(
                STDOUT,
                'DINI_NEXT_PASS:' .
                json_encode(
                    [
                        'vehicle_id'=>0,
                        'trigger'=>(string)$nextPending['trigger_type'],
                        'started_at'=>(string)$nextPending['started_at'],
                        'job_token'=>(string)$nextPending['job_token'],
                    ],
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                ) .
                PHP_EOL
            );
        }

        exit(0);
    }

    if (in_array(
          $pendingTrigger,
          ['eldat_first_weight', 'mobile_first_weight'],
          true
      )) {
        if ($expectedVehicleId <= 0) {
            throw new RuntimeException(
                'Für die Erstgewichtserfassung fehlt das Fahrzeug.'
            );
        }

        $result = completeVehicleFirstWeight(
            $weight,
            $expectedVehicleId,
            $expectedJobToken
        );

        fwrite(
            STDOUT,
            'DINI Abschluss Erstgewicht: ' .
            json_encode(
                $result,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) .
            PHP_EOL
        );
        exit(0);
    }

    $weighingId = completePendingWeighing($weight, '', $diniId, $expectedJobToken);

    fwrite(
        STDOUT,
        "DINI Abschluss Wiegung: Wiegeschein-ID {$weighingId}." .
        PHP_EOL
    );

    exit(0);

} catch (Throwable $e) {
    fwrite(
        STDERR,
        "DINI Abschluss fehlgeschlagen: " .
        $e->getMessage() .
        PHP_EOL
    );
    exit(3);
}
