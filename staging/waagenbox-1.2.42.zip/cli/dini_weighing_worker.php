<?php
declare(strict_types=1);

require_once __DIR__ . '/../hardware/Dini3590.php';

function argValue(array $argv, string $name): ?string
{
    $index = array_search($name, $argv, true);

    if ($index === false || !isset($argv[$index + 1])) {
        return null;
    }

    return (string)$argv[$index + 1];
}

$host = trim((string)argValue($argv, '--host'));
$port = (int)argValue($argv, '--port');
$resultTimeout = (float)(argValue($argv, '--timeout') ?? '360');
$liveStopKg = (float)(argValue($argv, '--live-stop-kg') ?? '500');

if ($liveStopKg < 5.0 || $liveStopKg > 100000.0) {
    fwrite(STDERR, "DINI Worker: --live-stop-kg ist ungültig.\n");
    exit(2);
}

$ownerId = (int)(argValue($argv, '--owner-id') ?? '0');
$vehicleId = (int)(argValue($argv, '--vehicle-id') ?? '0');
$trigger = trim((string)(argValue($argv, '--trigger') ?? ''));
$startedAt = trim((string)(argValue($argv, '--started-at') ?? ''));
$jobToken = trim((string)(argValue($argv, '--job-token') ?? ''));
$completeScript = trim(
    (string)(
        argValue($argv, '--complete-script')
        ?? (__DIR__ . '/dini_weighing_complete.php')
    )
);

$hasJob = (
    $ownerId > 0 ||
    $vehicleId > 0 ||
    $trigger !== '' ||
    $startedAt !== '' ||
    $jobToken !== ''
);

if ($hasJob) {
    if (
        $ownerId <= 0 ||
        $vehicleId < 0 ||
        $trigger === '' ||
        !preg_match('/^[a-f0-9]{32}$/', $jobToken) ||
        !preg_match(
            '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
            $startedAt
        )
    ) {
        fwrite(STDERR, "DINI Worker: Auftragsidentität ist unvollständig.\n");
        exit(2);
    }
}

if ($host === '') {
    fwrite(STDERR, "DINI Worker: --host fehlt.\n");
    exit(2);
}

if ($port < 1 || $port > 65535) {
    fwrite(STDERR, "DINI Worker: --port ist ungültig.\n");
    exit(2);
}

if ($resultTimeout <= 0) {
    fwrite(STDERR, "DINI Worker: --timeout ist ungültig.\n");
    exit(2);
}

/*
 * Produktiv wird der feste DINI-Runtimepfad verwendet.
 * Tests können einen isolierten Runtimepfad vorgeben, damit sie weder
 * Berechtigungen noch State einer laufenden Waagenbox beeinflussen.
 */
$runtimeDir = trim((string)(getenv('WAAGENBOX_DINI_RUNTIME_DIR') ?: ''));

if ($runtimeDir === '') {
    $runtimeDir = '/var/lib/waagebox/dini';
}

$runtimeDir = rtrim($runtimeDir, '/');

$lockPath = $runtimeDir . '/worker.lock';
$lockHandle = @fopen($lockPath, 'c');

if ($lockHandle === false) {
    fwrite(
        STDERR,
        "DINI Worker: Sperrdatei konnte nicht geöffnet werden: {$lockPath}\n"
    );
    exit(2);
}

if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
    fwrite(
        STDERR,
        "DINI Worker: Eine dynamische DINI-Wiegung läuft bereits.\n"
    );
    fclose($lockHandle);
    exit(3);
}

$pidPath = $runtimeDir . '/worker.pid';
$livePath = $runtimeDir . '/live.json';
$pid = getmypid();

if ($pid === false || @file_put_contents($pidPath, (string)$pid . PHP_EOL, LOCK_EX) === false) {
    fwrite(
        STDERR,
        "DINI Worker: PID-Datei konnte nicht geschrieben werden: {$pidPath}\n"
    );
    @flock($lockHandle, LOCK_UN);
    @fclose($lockHandle);
    exit(2);
}

/*
 * Kein Livegewicht einer vorherigen Wiegung übernehmen.
 * Ab jetzt gehört live.json ausschließlich zu diesem Worker.
 */
@unlink($livePath);

register_shutdown_function(
    static function () use ($lockHandle, $pidPath, $livePath, $pid): void {
        /*
         * PID-Datei nur entfernen, wenn sie noch zu genau diesem
         * Worker gehört. So kann kein älterer Prozess die PID-Datei
         * eines inzwischen neu gestarteten Workers löschen.
         */
        $storedPid = @file_get_contents($pidPath);

        if (
            $storedPid !== false &&
            trim($storedPid) === (string)$pid
        ) {
            @unlink($pidPath);
        }

        /*
         * Livegewicht dieser Wiegung nicht im Standby stehen lassen.
         */
        @unlink($livePath);

        @flock($lockHandle, LOCK_UN);
        @fclose($lockHandle);
    }
);

if ($hasJob && !is_file($completeScript)) {
    fwrite(
        STDERR,
        "DINI Worker: Abschlussprogramm nicht gefunden: {$completeScript}\n"
    );
    exit(2);
}

function runCompletionProgram(
    string $completeScript,
    int $ownerId,
    int $vehicleId,
    string $trigger,
    string $startedAt,
    float $weight,
    string $jobToken,
    bool $checkOnly = false,
    ?int $diniId = null
): array {
    $command = [
        PHP_BINARY,
        $completeScript,
    ];

    if ($checkOnly) {
        $command[] = '--check';
    }

    array_push(
        $command,
        (string)$ownerId,
        (string)$vehicleId,
        $trigger,
        $startedAt,
        (string)$weight,
        $jobToken
    );

    if (!$checkOnly && $diniId !== null) {
        $command[] = (string)$diniId;
    }

    $descriptorSpec = [
        0 => ['file', '/dev/null', 'r'],
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];

    $process = proc_open(
        $command,
        $descriptorSpec,
        $pipes,
        dirname(__DIR__)
    );

    if (!is_resource($process)) {
        throw new RuntimeException(
            $checkOnly
                ? 'Preflight konnte nicht gestartet werden.'
                : 'Abschlussprogramm konnte nicht gestartet werden.'
        );
    }

    $out = stream_get_contents($pipes[1]);
    $err = stream_get_contents($pipes[2]);

    fclose($pipes[1]);
    fclose($pipes[2]);

    $rc = proc_close($process);

    if ($out !== '') {
        fwrite(STDOUT, $out);
    }

    if ($err !== '') {
        fwrite(STDERR, $err);
    }

    return [
        'rc'=>$rc,
        'out'=>$out,
        'err'=>$err,
    ];
}

try {
    $dini = new Dini3590(
        $host,
        $port,
        2.0,
        $liveStopKg
    );

    /*
     * Normalerweise gibt es genau einen Durchlauf.
     *
     * Nur die manuelle Wiegung ohne Fahrzeug benötigt zwei unmittelbar
     * aufeinanderfolgende dynamische Überfahrten. Beide bleiben absichtlich
     * im selben Worker und damit unter demselben exklusiven DINI-Lock.
     */
    $maxPasses = $hasJob ? 2 : 1;

    for ($pass = 1; $pass <= $maxPasses; $pass++) {
        if ($hasJob) {
            $preflight = runCompletionProgram(
                $completeScript,
                $ownerId,
                $vehicleId,
                $trigger,
                $startedAt,
                1.0,
                $jobToken,
                true
            );

            if ($preflight['rc'] !== 0) {
                throw new RuntimeException(
                    "Auftrag im Preflight abgelehnt (RC={$preflight['rc']})."
                );
            }
        }

        fwrite(
            STDOUT,
            "DINI Worker: starte dynamische Wiegung {$pass} auf {$host}:{$port}.\n"
        );

        $result = $dini->runFirstWeighing($resultTimeout);

        fwrite(
            STDOUT,
            'DINI_RESULT:' .
            json_encode(
                $result,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) .
            PHP_EOL
        );

        fwrite(
            STDOUT,
            sprintf(
                "DINI Worker: Wiegung %d abgeschlossen, Gesamtgewicht %.0f kg.\n",
                (int)$result['dini_id'],
                (float)$result['total_weight']
            )
        );

        if (!$hasJob) {
            break;
        }

        $completion = runCompletionProgram(
            $completeScript,
            $ownerId,
            $vehicleId,
            $trigger,
            $startedAt,
            (float)$result['total_weight'],
            $jobToken,
            false,
            (int)$result['dini_id']
        );

        if ($completion['rc'] !== 0) {
            throw new RuntimeException(
                "Abschlussprogramm fehlgeschlagen (RC={$completion['rc']})."
            );
        }

        $nextPass = null;

        foreach (preg_split('/\R/', (string)$completion['out']) as $line) {
            if (!str_starts_with($line, 'DINI_NEXT_PASS:')) {
                continue;
            }

            $decoded = json_decode(
                substr($line, strlen('DINI_NEXT_PASS:')),
                true
            );

            if (!is_array($decoded)) {
                throw new RuntimeException(
                    'DINI_NEXT_PASS enthält ungültiges JSON.'
                );
            }

            if ($nextPass !== null) {
                throw new RuntimeException(
                    'Mehr als ein DINI_NEXT_PASS-Signal empfangen.'
                );
            }

            $nextPass = $decoded;
        }

        if ($nextPass === null) {
            fwrite(
                STDOUT,
                "DINI Worker: Auftrag erfolgreich abgeschlossen.\n"
            );
            break;
        }

        if ($pass >= $maxPasses) {
            throw new RuntimeException(
                'Unerwarteter weiterer DINI-Folgedurchlauf angefordert.'
            );
        }

        $nextVehicleId = (int)($nextPass['vehicle_id'] ?? -1);
        $nextTrigger = trim((string)($nextPass['trigger'] ?? ''));
        $nextStartedAt = trim((string)($nextPass['started_at'] ?? ''));
        $nextJobToken = trim((string)($nextPass['job_token'] ?? ''));

        if (
            $nextVehicleId !== 0 ||
            $nextTrigger === '' ||
            !preg_match('/^[a-f0-9]{32}$/', $nextJobToken) ||
            !hash_equals($jobToken, $nextJobToken) ||
            !preg_match(
                '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
                $nextStartedAt
            )
        ) {
            throw new RuntimeException(
                'DINI-Folgeauftrag besitzt keine gültige Identität.'
            );
        }

        $vehicleId = $nextVehicleId;
        $trigger = $nextTrigger;
        $startedAt = $nextStartedAt;

        fwrite(
            STDOUT,
            "DINI Worker: erste Überfahrt gespeichert; warte auf zweite Überfahrt.\n"
        );
    }

    exit(0);

} catch (Throwable $e) {
    fwrite(
        STDERR,
        "DINI Worker: " . $e->getMessage() . PHP_EOL
    );

    /*
     * Sicherheits-Cleanup:
     * Wenn DINI eine fehlerhafte Überfahrt abbricht oder der Worker
     * in einen Timeout läuft, darf die Waagenbox nicht dauerhaft
     * im Zustand "Wiegung gestartet" hängen bleiben.
     *
     * Es wird ausschließlich der Auftrag gelöscht, dessen Identität
     * noch exakt zu diesem Worker gehört.
     */
    if ($hasJob) {
        try {
            require_once dirname(__DIR__) . '/rf_remote_support.php';

            $pdo = db();
            rfRemoteUseOwnerContext($pdo, $ownerId);

            if (clearPendingWeighingIfMatching($jobToken)) {

                fwrite(
                    STDERR,
                    "DINI Worker: fehlgeschlagenen Auftrag zurückgesetzt; Waagenbox wieder bereit." . PHP_EOL
                );
            } else {
                fwrite(
                    STDERR,
                    "DINI Worker: Cleanup übersprungen; Pending-Auftrag hat sich inzwischen geändert." . PHP_EOL
                );
            }
        } catch (Throwable $cleanupError) {
            fwrite(
                STDERR,
                "DINI Worker: Cleanup fehlgeschlagen: " .
                $cleanupError->getMessage() .
                PHP_EOL
            );
        }
    }

    exit(1);
}
