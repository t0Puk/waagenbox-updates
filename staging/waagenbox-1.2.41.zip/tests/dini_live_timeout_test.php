<?php
declare(strict_types=1);

$testRuntime = sys_get_temp_dir()
    . '/waagenbox-dini-test-' . getmypid();

if (!is_dir($testRuntime) && !mkdir($testRuntime, 0700, true)) {
    throw new RuntimeException('Testverzeichnis konnte nicht erstellt werden.');
}

putenv('WAAGENBOX_DINI_RUNTIME_DIR=' . $testRuntime);

register_shutdown_function(static function () use ($testRuntime): void {
    foreach (glob($testRuntime . '/diagnostics/*') ?: [] as $file) {
        @unlink($file);
    }
    @rmdir($testRuntime . '/diagnostics');
    @unlink($testRuntime . '/live.json');
    @unlink($testRuntime . '/io.lock');
    @rmdir($testRuntime);
});

require_once __DIR__ . '/../hardware/Dini3590.php';

$server = stream_socket_server(
    'tcp://127.0.0.1:0',
    $errno,
    $errstr
);

if (!$server) {
    throw new RuntimeException($errstr);
}

$address = stream_socket_get_name($server, false);
$port = (int)substr(strrchr($address, ':'), 1);

$pid = pcntl_fork();

if ($pid === -1) {
    throw new RuntimeException('Fork fehlgeschlagen.');
}

if ($pid === 0) {
    $conn = stream_socket_accept($server, 5);

    if (!$conn) {
        exit(2);
    }

    stream_set_timeout($conn, 5);

    while (!feof($conn)) {
        $line = fgets($conn);

        if ($line === false) {
            break;
        }

        $cmd = trim($line);

        if ($cmd === 'KEYP37' || $cmd === 'KEYR') {
            fwrite($conn, "OK\r\n");
        } elseif ($cmd === 'RALL') {
            fwrite($conn, "S1,ST,505,kg\r\n");
        }
    }

    fclose($conn);
    fclose($server);
    exit(0);
}

try {
    $dini = new Dini3590('127.0.0.1', $port, 2.0, 500.0);

    try {
        $dini->runFirstWeighing(3.0);
        throw new RuntimeException(
            'FEHLER: Wiegung ohne Endergebnis wurde akzeptiert.'
        );
    } catch (RuntimeException $e) {
        $message = $e->getMessage();

        if (
            !str_contains($message, 'Keine fertige DINI-Wiegung') &&
            !str_contains($message, 'Timeout beim Warten auf eine DINI-Antwort')
        ) {
            throw $e;
        }

        echo "PASS: Kein DINI-Endergebnis empfangen.\n";
        echo "PASS: Timeout korrekt ausgelöst.\n";
        echo "PASS: Kein falsches Wiegeergebnis zurückgegeben.\n";
    }
} finally {
    fclose($server);
    pcntl_waitpid($pid, $status);
}
