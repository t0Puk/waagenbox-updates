<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$trigger = file_get_contents(
    $root.'/cli/eldat_remote_trigger.php'
);
$functions = file_get_contents(
    $root.'/functions.php'
);

if ($trigger === false || $functions === false) {
    fwrite(STDERR, "Quelldateien fehlen.\n");
    exit(1);
}

$failed = 0;

function checkCondition(bool $ok, string $label): void {
    global $failed;
    echo ($ok ? 'PASS: ' : 'FAIL: ')
        .$label.PHP_EOL;
    if (!$ok) $failed++;
}

$normalStart = strpos(
    $trigger,
    'if ($button === $weighButton)'
);
$tareStart = strpos(
    $trigger,
    "if (\$tareButton !== '' && \$button === \$tareButton)"
);

checkCondition(
    $normalStart !== false &&
    $tareStart !== false &&
    $normalStart < $tareStart,
    'Normale Wiegung und Erstgewicht getrennt'
);

if ($normalStart !== false && $tareStart !== false &&
    $normalStart < $tareStart) {

    $normal = substr(
        $trigger,
        $normalStart,
        $tareStart - $normalStart
    );
    $tare = substr($trigger, $tareStart);

    // Kommentare werden bei der Funktionsaufrufprüfung
    // nicht als ausführbarer Code berücksichtigt.
    $normalWithoutComments = preg_replace(
        '~//[^\r\n]*|/\*.*?\*/~s',
        '',
        $normal
    );

    checkCondition(
        substr_count(
            $normalWithoutComments,
            'startVehiclePass('
        ) === 1,
        'Normale Wiegung verwendet startVehiclePass'
    );

    checkCondition(
        substr_count(
            $normalWithoutComments,
            'startDiniPendingWorker('
        ) === 0,
        'Kein zweiter Workerstart im normalen Eldat-Pfad'
    );

    checkCondition(
        substr_count($tare, 'startDiniPendingWorker(') === 1,
        'Erstgewicht behält eigenen Workerstart'
    );
}

checkCondition(
    preg_match(
        '/function\s+startVehiclePass\s*\(/',
        $functions
    ) === 1 &&
    str_contains(
        $functions,
        'startDiniPendingWorker();'
    ),
    'Zentrale Wägefunktion startet DINI-Worker'
);

echo "ERGEBNIS: "
    .($failed === 0 ? 'ALLE TESTS BESTANDEN'
                    : $failed.' FEHLER')
    .PHP_EOL;

exit($failed === 0 ? 0 : 1);
