<?php
declare(strict_types=1);

$src = file_get_contents(
    dirname(__DIR__).'/api/grossanzeige_status.php'
);

if ($src === false) {
    fwrite(STDERR, "API konnte nicht gelesen werden.\n");
    exit(1);
}

$checks = [
    'DINI-Betrieb wird erkannt' =>
        str_contains($src, '$diniActive = dini() !== null;'),

    'Startfreigabe beginnt mit false' =>
        str_contains($src, '$diniStartConfirmed = false;'),

    'Worker muss laufen' =>
        str_contains($src, 'diniWorkerBusy() && is_file($livePath)'),

    'Freigabe muss explizit true sein' =>
        str_contains($src,
            '($liveInfo[\'start_confirmed\'] ?? false) === true'),

    'Ohne Bestätigung keine Auffahrfreigabe' =>
        str_contains($src,
            'if ($diniActive && !$diniStartConfirmed)'),

    'Ohne Bestätigung bleibt Gewicht null' =>
        preg_match(
            '/if \(\$diniActive && !\$diniStartConfirmed\)\s*\{\s*\$state = \'processing\';\s*\$displayWeight = 0\.0;/',
            $src
        ) === 1,

    'Demo behält bisherigen Startzustand' =>
        str_contains($src, "$" . "livePhase = 'drive_on';"),

    'Bestätigte Überfahrt kann starten' =>
        str_contains($src, "$" . "state = 'drive_on';"),
];

$failed = 0;
foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS: ' : 'FAIL: '), $name, PHP_EOL;
    if (!$ok) $failed++;
}

echo 'ERGEBNIS: ', count($checks)-$failed,
     '/', count($checks), ' bestanden', PHP_EOL;

exit($failed === 0 ? 0 : 1);
