#!/usr/bin/env python3
"""RX09-Integrationstest mit PTY und simuliertem PHP-Trigger."""

import json
import os
import pty
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LISTENER = ROOT / "hardware/eldat_rx09_listener.py"


def read_events(path):
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text().splitlines()
        if line.strip()
    ]


def check(condition, message):
    print(("PASS: " if condition else "FAIL: ") + message)
    return bool(condition)


def send(master, sender="18d2c3", button="A"):
    os.write(master, f"REC,{sender},{button}\r".encode("ascii"))


def wait_count(path, count, timeout=4):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if len(read_events(path)) >= count:
            return True
        time.sleep(0.025)
    return False


def main():
    passed = True

    with tempfile.TemporaryDirectory(prefix="waagenbox-rx09-") as tmp:
        tmp = Path(tmp)
        events = tmp / "events.jsonl"
        output = tmp / "listener.log"
        fake = tmp / "fake_trigger.py"

        fake.write_text(
            "import json, os, sys, time\n"
            "with open(os.environ['RX09_TEST_LOG'], 'a') as f:\n"
            "    f.write(json.dumps({'sender': sys.argv[1], "
            "'button': sys.argv[2], 'at': time.monotonic()})+'\\n')\n"
            "    f.flush()\n"
            "time.sleep(1.5)\n"
            "print('ELDAT Simulation abgeschlossen', flush=True)\n"
        )

        master, slave = pty.openpty()
        device = os.ttyname(slave)

        env = os.environ.copy()
        env["RX09_TEST_LOG"] = str(events)
        env["PYTHONDONTWRITEBYTECODE"] = "1"

        command = [
            sys.executable,
            str(LISTENER),
            "--device", device,
            "--php", sys.executable,
            "--trigger-script", str(fake),
            "--learn-request", str(tmp / "learn-request.json"),
            "--learn-result", str(tmp / "learn-result.json"),
        ]

        proc = None

        try:
            with output.open("w") as log:
                proc = subprocess.Popen(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    env=env,
                    stdin=subprocess.DEVNULL,
                )

                time.sleep(0.5)
                passed &= check(
                    proc.poll() is None,
                    "RX09-Listener läuft am virtuellen Anschluss",
                )

                if proc.poll() is not None:
                    raise RuntimeError("Listener unerwartet beendet")

                # Ein langer Tastendruck: alle 50 ms ein Telegramm.
                start = time.monotonic()
                while time.monotonic() - start < 1.9:
                    send(master)
                    time.sleep(0.05)

                    # Ein anderer Sender während der PHP-Verarbeitung.
                    if 0.35 < time.monotonic() - start < 0.41:
                        send(master, "18ef67")

                passed &= check(
                    wait_count(events, 1),
                    "Erster Tastendruck wird verarbeitet",
                )

                time.sleep(0.35)
                first_events = read_events(events)

                passed &= check(
                    len(first_events) == 1,
                    "Langer Tastendruck erzeugt nur einen Auftrag",
                )

                passed &= check(
                    all(e["sender"] != "18ef67" for e in first_events),
                    "Kein zwischengespeicherter Auftrag "
                    "eines zweiten Senders",
                )

                # Ausreichend Funkstille vor dem nächsten Tastendruck.
                time.sleep(1.2)
                send(master)

                passed &= check(
                    wait_count(events, 2),
                    "Neuer Tastendruck nach Funkpause erkannt",
                )

                time.sleep(0.25)
                final_events = read_events(events)

                passed &= check(
                    len(final_events) == 2,
                    "Genau zwei gültige Aufträge insgesamt",
                )

                passed &= check(
                    all(e["sender"] == "18d2c3" for e in final_events),
                    "Nur erwarteter Handsender verarbeitet",
                )

        finally:
            if proc is not None:
                if proc.poll() is None:
                    proc.send_signal(signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
            os.close(master)
            os.close(slave)

        print()
        print("=== LISTENER-AUSGABE ===")
        if output.exists():
            print(output.read_text()[-5000:])

    print(
        "ERGEBNIS:",
        "ALLE PRÜFUNGEN BESTANDEN" if passed else "TEST FEHLGESCHLAGEN",
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
