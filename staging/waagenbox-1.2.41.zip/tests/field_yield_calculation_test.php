<?php
declare(strict_types=1);

$fields = [
    ['active'=>1, 'area'=>5.0, 'kg'=>200000.0],
    ['active'=>1, 'area'=>3.0, 'kg'=>150000.0],
    ['active'=>1, 'area'=>null, 'kg'=>20000.0],
    ['active'=>0, 'area'=>2.0, 'kg'=>100000.0],
];

$tests = 0;
$failed = 0;

function checkValue(string $name, float $actual, float $expected): void {
    global $tests, $failed;
    $tests++;
    $ok = abs($actual - $expected) < 0.000001;
    echo ($ok ? 'PASS: ' : 'FAIL: '), $name,
        ' = ', number_format($actual, 2, ',', '.'),
        PHP_EOL;
    if (!$ok) $failed++;
}

$totalKg = 0.0;
$totalArea = 0.0;
$knownAreaKg = 0.0;
$missingAreaKg = 0.0;
$activeCount = 0;

foreach ($fields as $field) {
    if (!$field['active']) continue;
    $activeCount++;

    $kg = $field['kg'];
    $area = (float)($field['area'] ?? 0);

    $totalKg += $kg;

    if ($area > 0) {
        $totalArea += $area;
        $knownAreaKg += $kg;
    } else {
        $missingAreaKg += $kg;
    }
}

checkValue('Aktive Schlaege', (float)$activeCount, 3);
checkValue('Gesamtflaeche', $totalArea, 8);
checkValue('Gesamtmenge Tonnen', $totalKg / 1000, 370);
checkValue('Menge mit Flaeche', $knownAreaKg / 1000, 350);
checkValue('Menge ohne Flaeche', $missingAreaKg / 1000, 20);
checkValue('Gesamtertrag t/ha', $knownAreaKg / 1000 / $totalArea, 43.75);
checkValue('Ertrag Schlag 1', 200000 / 1000 / 5, 40);
checkValue('Ertrag Schlag 2', 150000 / 1000 / 3, 50);

echo "ERGEBNIS: ", $tests-$failed, "/", $tests,
    " Tests bestanden", PHP_EOL;

exit($failed === 0 ? 0 : 1);
