<?php
declare(strict_types=1);

$source = file_get_contents(
    __DIR__ . '/../feldmanager_link.php'
);

$checks = [
    'Teambezogene Speicherung vorhanden' =>
        str_contains($source, 'feldmanager_last_field_team_'),

    'Neues API-Feld wird gelesen' =>
        str_contains($source, "\$status['latest_started']"),

    'Teamnummer wird geprüft' =>
        str_contains($source, '$latestTeam!==$team'),

    'Lokale Schlagzuordnung wird geprüft' =>
        str_contains($source, 'feldmanagerResolveLocalField($latestField)'),

    'Nachlaufstatus vorhanden' =>
        str_contains($source, "'last_active'"),

    'Aktiver Schlag hat eigene Behandlung' =>
        str_contains($source, "'state'=>'active'"),

    'API-Fehler werden erkannt' =>
        str_contains($source, "'state'=>'unavailable'"),

    'Mehrdeutige aktive Arbeiten werden erkannt' =>
        str_contains($source, "'state'=>'ambiguous'"),

    'Nachlaufstatus wird automatisch verwendet' =>
        str_contains($source, "['active','last_active']"),
];

$failed = 0;

foreach ($checks as $label => $passed) {
    echo ($passed ? 'PASS ' : 'FAIL ') . $label . PHP_EOL;
    if (!$passed) $failed++;
}

echo PHP_EOL;

if ($failed > 0) {
    echo "FEHLER: $failed Prüfungen fehlgeschlagen.\n";
} else {
    echo "OK: Alle " . count($checks)
       . " Strukturprüfungen erfolgreich.\n";
}
