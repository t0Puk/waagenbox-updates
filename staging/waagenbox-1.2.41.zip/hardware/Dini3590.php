<?php
/**
 * AJP Waagenbox – Dini 3590ET/3590EGT TCP command client
 *
 * Based on the supplied Dini 3590ET/3590EGT serial command documentation.
 * All commands are terminated with CR/LF.
 *
 * IMPORTANT:
 * The TCP port is intentionally configurable. The supplied documentation
 * confirms Ethernet/TCP support but does not specify the ETHKR-1 TCP port.
 */
class Dini3590
{
    private string $host;
    private int $port;
    private float $timeout;
    private float $liveStopKg;

    public function __construct(
        string $host,
        int $port,
        float $timeout = 2.0,
        float $liveStopKg = 500.0
    )
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
        $this->liveStopKg = (
            $liveStopKg >= 5.0 && $liveStopKg <= 100000.0
        ) ? $liveStopKg : 500.0;
    }

    public function command(string $command, bool $waitForAnswer = true): string
    {
        $lockPath = rtrim(
            (string)(getenv('WAAGENBOX_DINI_RUNTIME_DIR') ?: '/var/lib/waagebox/dini'),
            '/'
        ) . '/io.lock';
        $lock = @fopen($lockPath, 'c');

        if ($lock === false) {
            throw new RuntimeException('DINI I/O-Lock konnte nicht geöffnet werden.');
        }

        $lockDeadline = microtime(true) + 2.0;
        while (!flock($lock, LOCK_EX | LOCK_NB)) {
            if (microtime(true) >= $lockDeadline) {
                fclose($lock);
                throw new RuntimeException('DINI I/O ist belegt.');
            }
            usleep(10000);
        }

        try {
            $errno = 0;
            $errstr = '';
            $socket = @fsockopen(
                $this->host,
                $this->port,
                $errno,
                $errstr,
                $this->timeout
            );

            if (!$socket) {
                throw new RuntimeException(
                    "Dini nicht erreichbar ({$this->host}:{$this->port}): {$errstr} ({$errno})"
                );
            }

            stream_set_timeout($socket, (int)$this->timeout, (int)(($this->timeout - (int)$this->timeout) * 1000000));

            $wire = $command . "\r\n";
            $written = fwrite($socket, $wire);
            if ($written === false || $written < strlen($wire)) {
                fclose($socket);
                throw new RuntimeException("Befehl konnte nicht vollständig an die Dini gesendet werden.");
            }

            if (!$waitForAnswer) {
                fclose($socket);
                return '';
            }

            $answer = '';
            $started = microtime(true);

            while ((microtime(true) - $started) < $this->timeout) {
                $chunk = fgets($socket);
                if ($chunk !== false) {
                    $answer .= $chunk;
                    if (str_ends_with($answer, "\r\n") || str_ends_with($answer, "\n")) {
                        break;
                    }
                } else {
                    $meta = stream_get_meta_data($socket);
                    if (!empty($meta['timed_out'])) {
                        break;
                    }
                    usleep(10000);
                }
            }

            fclose($socket);

            if ($answer === '') {
                throw new RuntimeException("Keine Antwort von der Dini auf '{$command}'.");
            }

            return trim($answer, "\r\n");
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /** R – Gewicht lesen. Antwort kann Standard- oder Extended-Protokoll sein. */
    public function readWeight(): array
    {
        $raw = $this->command('R');
        return $this->parseWeightAnswer($raw);
    }

    /** REXT – erweiterten Gewichtsdatensatz lesen. */
    public function readExtendedWeight(): array
    {
        $raw = $this->command('REXT');
        $parts = explode(',', $raw);

        // Erwartete Struktur: c,ss,weight,pp,tare,pieces,avg,unit
        return [
            'raw' => $raw,
            'channel' => trim($parts[0] ?? ''),
            'status' => trim($parts[1] ?? ''),
            'weight' => $this->numberOrNull($parts[2] ?? null),
            'tare_type' => trim($parts[3] ?? ''),
            'tare' => $this->numberOrNull($parts[4] ?? null),
            'pieces' => $this->numberOrNull($parts[5] ?? null),
            'average_piece_weight' => $this->numberOrNull($parts[6] ?? null),
            'unit' => trim($parts[7] ?? ''),
        ];
    }

    /** RALL – kompletter Statusdatensatz inklusive Instrument state/key buffer. */
    public function readAll(): array
    {
        $raw = $this->command('RALL');
        $parts = explode(',', $raw);

        return [
            'raw' => $raw,
            'channel' => trim($parts[0] ?? ''),
            'status' => trim($parts[1] ?? ''),
            'gross' => $this->numberOrNull($parts[2] ?? null),
            'unit' => trim($parts[3] ?? ''),
            'tare_type' => trim($parts[4] ?? ''),
            'tare' => $this->numberOrNull($parts[5] ?? null),
            'last_totalization_scale' => trim($parts[6] ?? ''),
            'last_totalization_net' => $this->numberOrNull($parts[7] ?? null),
            'last_totalization_unit' => trim($parts[8] ?? ''),
            'last_totalization_gross' => $this->numberOrNull($parts[9] ?? null),
            'scale_state' => trim($parts[10] ?? ''),
            'pressed_keys_counter' => trim($parts[11] ?? ''),
            'pressed_key_code' => trim($parts[12] ?? ''),
            'totalizations' => trim($parts[13] ?? ''),
            'alibi_rewrite_id' => trim($parts[14] ?? ''),
            'alibi_id' => trim($parts[15] ?? ''),
        ];
    }

    /** STAT – Arbeitszustand des Instruments. */
    public function readState(): array
    {
        $raw = $this->command('STAT');
        $index = (int)preg_replace('/\D+/', '', $raw);
        $states = [
            0 => 'Instrument start-up',
            1 => 'Scale',
            3 => 'Menu',
            4 => 'Setup',
            10 => 'Scale switch',
            11 => 'Reception / transmission of setup',
            12 => 'Serial test',
            13 => 'Print test',
            33 => 'Dosage',
            34 => 'Stand-by',
            35 => 'User input',
            36 => 'Auto zero',
            37 => 'Diagnostic',
            38 => 'Digital output diagnostic',
        ];
        return ['raw' => $raw, 'index' => $index, 'name' => $states[$index] ?? 'Unbekannt'];
    }

    /**
     * KEYP – Tastendruck simulieren.
     * Laut supplied documentation: first weighing = 37, second weighing = 38.
     */
    public function pressKey(string $hexCode): string
    {
        $hexCode = strtoupper(trim($hexCode));
        if (!preg_match('/^[0-9A-F]{2}$/', $hexCode)) {
            throw new InvalidArgumentException("Ungültiger Dini-Key-Code: {$hexCode}");
        }
        return $this->command('KEYP' . $hexCode);
    }

    /** KEYR – Tastenfreigabe. Muss unmittelbar nach KEYP gesendet werden. */
    public function releaseKey(): string
    {
        return $this->command('KEYR');
    }

    public function startFirstWeighing(): array
    {
        $press = $this->pressKey('37');
        $release = $this->releaseKey();
        return ['key' => '37', 'press_answer' => $press, 'release_answer' => $release];
    }

    public function startSecondWeighing(): array
    {
        $press = $this->pressKey('38');
        $release = $this->releaseKey();
        return ['key' => '38', 'press_answer' => $press, 'release_answer' => $release];
    }

    /** OUTP – digitalen Ausgang setzen. 0000 = aktiv, 0001 = inaktiv. */
    public function setOutput(int $index, bool $active): string
    {
        if ($index < 0 || $index > 0x10) {
            throw new InvalidArgumentException('Ausgang muss zwischen 0 und 16 liegen.');
        }
        $hexIndex = strtoupper(dechex($index));
        $value = $active ? '0000' : '0001';
        return $this->command('OUTP' . $hexIndex . $value);
    }

    public function readDigitalInputs(): string
    {
        return $this->command('GETI');
    }

    public function identify(): string
    {
        return $this->command('VER');
    }

    /**
     * Startet eine dynamische Erstwiegung und wartet auf den vom DINI
     * selbst berechneten Abschlussdatensatz.
     *
     * Real am 3590ETKR getestet:
     *   KEYP37 -> OK
     *   KEYR   -> OK
     *
     * Beispiel Abschlussdatensatz:
     *   05/10/26;19:50;       6;;;     600;;;;Erstes Wiegung;;       0;       0
     *
     * Feld 3 ist die DINI-Wiegungs-ID, NICHT die Anzahl der Achsen.
     */
    public function runFirstWeighing(float $resultTimeout = 360.0): array
    {
        return $this->runDynamicWeighing('37', $resultTimeout);
    }

    private function runDynamicWeighing(
        string $keyCode,
        float $resultTimeout
    ): array {
        if ($resultTimeout <= 0) {
            throw new InvalidArgumentException(
                'DINI Ergebnis-Timeout muss größer als 0 sein.'
            );
        }

        $errno = 0;
        $errstr = '';

        $socket = @fsockopen(
            $this->host,
            $this->port,
            $errno,
            $errstr,
            $this->timeout
        );

        if (!$socket) {
            throw new RuntimeException(
                "Dini nicht erreichbar ({$this->host}:{$this->port}): " .
                "{$errstr} ({$errno})"
            );
        }

        try {
            // Alte Freigabe vor JEDEM neuen DINI-Start entfernen.
            // Das gilt auch vor der zweiten Überfahrt.
            $livePath = rtrim(
                (string)(getenv('WAAGENBOX_DINI_RUNTIME_DIR') ?: '/var/lib/waagebox/dini'),
                '/'
            ) . '/live.json';
            @unlink($livePath);

            $this->writeSocketCommand($socket, 'KEYP' . $keyCode);

            $pressAnswer = $this->readSocketLine(
                $socket,
                $this->timeout
            );

            if (strtoupper($pressAnswer) !== 'OK') {
                throw new RuntimeException(
                    "DINI hat KEYP{$keyCode} nicht bestätigt: {$pressAnswer}"
                );
            }

            $this->writeSocketCommand($socket, 'KEYR');

            $releaseAnswer = $this->readSocketLine(
                $socket,
                $this->timeout
            );

            if (strtoupper($releaseAnswer) !== 'OK') {
                throw new RuntimeException(
                    "DINI hat KEYR nicht bestätigt: {$releaseAnswer}"
                );
            }

            // Erst nach KEYP37=OK und KEYR=OK darf die
            // Großanzeige den Fahrer zum Auffahren auffordern.
            $confirmedLive = [
                'active' => true,
                'phase' => 'drive_on',
                'start_confirmed' => true,
                'weight_kg' => 0.0,
                'updated_at' => microtime(true),
            ];
            $confirmedJson = json_encode($confirmedLive);

            if ($confirmedJson === false) {
                throw new RuntimeException(
                    'DINI-Startfreigabe konnte nicht kodiert werden.'
                );
            }

            $confirmedTmp = $livePath . '.tmp.' . getmypid();

            if (@file_put_contents($confirmedTmp, $confirmedJson, LOCK_EX) === false ||
                !@rename($confirmedTmp, $livePath)) {
                @unlink($confirmedTmp);
                throw new RuntimeException(
                    'DINI-Startfreigabe konnte nicht gespeichert werden.'
                );
            }

            // Liveabfrage nur bis zur ersten erkannten Überfahrtlast.
            // Anschließend ausschließlich auf das DINI-Endergebnis warten.
            $deadline = microtime(true) + $resultTimeout;
            $liveWeightThreshold = $this->liveStopKg;
            $livePolling = true;

            while (microtime(true) < $deadline) {
                if (!$livePolling) {
                    $remaining = max(0.1, $deadline - microtime(true));
                    $line = $this->readSocketLine($socket, $remaining);

                    if ($line === '') {
                        continue;
                    }

                    $this->diagnosticLog(
                        'DYNAMIC_RX',
                        [
                            'key' => $keyCode,
                            'raw' => $line,
                        ]
                    );

                    $result = $this->parseDynamicWeighingResult($line);

                    if ($result !== null) {
                        $result['key'] = $keyCode;
                        $result['press_answer'] = $pressAnswer;
                        $result['release_answer'] = $releaseAnswer;
                        return $result;
                    }

                    continue;
                }

                $this->writeSocketCommand($socket, 'RALL');

                $line = $this->readSocketLine(
                    $socket,
                    min(2.0, max(0.1, $deadline - microtime(true)))
                );

                if ($line === '') {
                    continue;
                }

                // Das offizielle DINI-Endergebnis kann jederzeit eintreffen.
                $result = $this->parseDynamicWeighingResult($line);

                if ($result !== null) {
                    $this->diagnosticLog(
                        'DYNAMIC_RX',
                        [
                            'key' => $keyCode,
                            'raw' => $line,
                        ]
                    );

                    $result['key'] = $keyCode;
                    $result['press_answer'] = $pressAnswer;
                    $result['release_answer'] = $releaseAnswer;
                    return $result;
                }

                // Erwartete RALL-Antwort protokollieren.
                $parts = explode(',', $line);
                $grossRaw = trim($parts[2] ?? '');
                $gross = null;

                if (preg_match('/[-+]?\d+(?:\.\d+)?/', $grossRaw, $m)) {
                    $gross = (float)$m[0];
                }

                $this->diagnosticLog(
                    'DYNAMIC_RALL_LIVE',
                    [
                        'key' => $keyCode,
                        'gross' => $gross,
                        'raw' => $line,
                    ]
                );

                // Livegewicht fuer Waagenbox/Grossanzeige bereitstellen.
                // Die Datei wird atomar ersetzt, damit Leser niemals
                // einen teilweise geschriebenen JSON-Datensatz sehen.
                if ($gross !== null) {
                    $livePath = rtrim(
                (string)(getenv('WAAGENBOX_DINI_RUNTIME_DIR') ?: '/var/lib/waagebox/dini'),
                '/'
            ) . '/live.json';
                    $liveTmp = $livePath . '.tmp.' . getmypid();

                    $liveData = [
                        'active' => true,
                        'phase' => 'drive_on',
                        'start_confirmed' => true,
                        'weight_kg' => max(0.0, $gross),
                        'updated_at' => microtime(true),
                    ];

                    $liveJson = json_encode(
                        $liveData,
                        JSON_UNESCAPED_UNICODE |
                        JSON_UNESCAPED_SLASHES
                    );

                    if ($liveJson !== false) {
                        if (@file_put_contents($liveTmp, $liveJson, LOCK_EX) !== false) {
                            @rename($liveTmp, $livePath);
                        } else {
                            @unlink($liveTmp);
                        }
                    }
                }

                if ($gross !== null && $gross > $liveWeightThreshold) {
                    $livePolling = false;

                    $this->diagnosticLog(
                        'DYNAMIC_RALL_STOP',
                        [
                            'key' => $keyCode,
                            'threshold_kg' => $liveWeightThreshold,
                            'detected_kg' => $gross,
                        ]
                    );

                    // Zustand atomar veröffentlichen, damit die Großanzeige
                    // auch ohne weitere Livewerte auf processing bleibt.
                    $liveData['phase'] = 'processing';
                    $liveData['weight_kg'] = 0.0;
                    $liveData['updated_at'] = microtime(true);
                    $liveJson = json_encode($liveData);

                    if ($liveJson !== false) {
                        if (@file_put_contents($liveTmp, $liveJson, LOCK_EX) !== false) {
                            @rename($liveTmp, $livePath);
                        } else {
                            @unlink($liveTmp);
                        }
                    }

                    continue;
                }

                usleep(300000);
            }

            throw new RuntimeException(
                sprintf(
                    'Keine fertige DINI-Wiegung innerhalb von %.0f Sekunden.',
                    $resultTimeout
                )
            );
        } finally {
            fclose($socket);
        }
    }

    private function diagnosticLog(string $event, array $data = []): void
    {
        $dir = rtrim(
            (string)(getenv('WAAGENBOX_DINI_RUNTIME_DIR') ?: '/var/lib/waagebox/dini'),
            '/'
        ) . '/diagnostics';

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        if (!is_dir($dir) || !is_writable($dir)) {
            return;
        }

        $now = microtime(true);
        $seconds = (int)$now;
        $milliseconds = (int)(($now - $seconds) * 1000);

        $timestamp =
            date('Y-m-d H:i:s', $seconds) .
            sprintf('.%03d', $milliseconds);

        $record = [
            'ts' => $timestamp,
            'event' => $event,
        ] + $data;

        $file = $dir . '/dini-' . date('Ymd-H', $seconds) . '.jsonl';

        @file_put_contents(
            $file,
            json_encode(
                $record,
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES |
                JSON_INVALID_UTF8_SUBSTITUTE
            ) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    private function writeSocketCommand($socket, string $command): void
    {
        $wire = $command . "\r\n";
        $written = fwrite($socket, $wire);

        if ($written === false || $written < strlen($wire)) {
            throw new RuntimeException(
                "Befehl '{$command}' konnte nicht vollständig an die Dini " .
                "gesendet werden."
            );
        }
    }

    private function readSocketLine($socket, float $timeout): string
    {
        $seconds = (int)$timeout;
        $microseconds = (int)(($timeout - $seconds) * 1000000);

        stream_set_timeout($socket, $seconds, $microseconds);

        $line = fgets($socket);

        if ($line === false) {
            $meta = stream_get_meta_data($socket);

            if (!empty($meta['timed_out'])) {
                throw new RuntimeException(
                    'Timeout beim Warten auf eine DINI-Antwort.'
                );
            }

            if (!empty($meta['eof'])) {
                throw new RuntimeException(
                    'DINI hat die TCP-Verbindung unerwartet geschlossen.'
                );
            }

            return '';
        }

        return trim($line, "\r\n");
    }

    private function parseDynamicWeighingResult(string $raw): ?array
    {
        $parts = explode(';', $raw);

        if (count($parts) < 10) {
            return null;
        }

        $date = trim($parts[0] ?? '');
        $time = trim($parts[1] ?? '');
        $diniId = trim($parts[2] ?? '');
        $weight = trim($parts[5] ?? '');
        $weighingType = trim($parts[9] ?? '');

        if (
            !preg_match('/^\d{2}\/\d{2}\/\d{2}$/', $date) ||
            !preg_match('/^\d{2}:\d{2}$/', $time) ||
            !preg_match('/^\d+$/', $diniId) ||
            $weight === '' ||
            !is_numeric($weight)
        ) {
            return null;
        }

        return [
            'raw' => $raw,
            'date' => $date,
            'time' => $time,
            'dini_id' => (int)$diniId,
            'total_weight' => (float)$weight,
            'weighing_type' => $weighingType,
        ];
    }

    private function parseWeightAnswer(string $raw): array
    {
        $parts = explode(',', $raw);
        return [
            'raw' => $raw,
            'status' => trim($parts[0] ?? ''),
            'type' => trim($parts[1] ?? ''),
            'weight' => $this->numberOrNull($parts[2] ?? null),
            'unit' => trim($parts[3] ?? ''),
        ];
    }

    private function numberOrNull(?string $value): ?float
    {
        if ($value === null) return null;
        $value = trim($value);
        if ($value === '' || !is_numeric($value)) return null;
        return (float)$value;
    }
}
