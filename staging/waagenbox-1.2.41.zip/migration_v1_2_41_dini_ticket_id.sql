-- Waagenbox 1.2.41
-- DINI-Wiegungs-ID dauerhaft am Wiegeschein speichern.
-- Ausschließlich auf der freigegebenen Datenbank ausführen.

ALTER TABLE weighings
    ADD COLUMN dini_id BIGINT UNSIGNED NULL DEFAULT NULL
    AFTER id;
