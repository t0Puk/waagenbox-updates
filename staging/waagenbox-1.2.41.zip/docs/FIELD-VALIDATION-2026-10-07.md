# AJP Waagenbox – Feldvalidierung 07.10.2026

## Ausgangslage

Ausgangspunkt ist der veröffentlichte und signiert installierte Release 1.2.40.
Die produktive Anlage besteht unter anderem aus der Waagenbox, dem
DINI Argeo 3590ETKR, dem ELDAT RX09 und der separaten Großanzeige.

Die während der Inbetriebnahme vorgenommenen und real getesteten Korrekturen
werden für die nächste Version auf dem Branch
`feature/1.2.41-field-validation` festgeschrieben.

Der veröffentlichte Release 1.2.40 wird nicht nachträglich verändert.

## DINI – Livegewicht

Für die Anzeige eines Gewichts während der Überfahrt wird `RALL` verwendet.

Wesentliche Architekturentscheidung:

- keine zweite TCP-Verbindung zum DINI während einer dynamischen Wiegung;
- `RALL` läuft über dieselbe persistente TCP-Verbindung des DINI-Workers;
- der offizielle Abschluss einer Wiegung bleibt der abschließende
  Semikolon-Datensatz des DINI;
- RALL-Werte dienen nur als Liveanzeige und ersetzen niemals das offizielle
  Endgewicht.

Eine frühere parallele Verbindung führte zu fragmentierten bzw. beschädigten
Antworten und darf daher nicht wieder eingeführt werden.

Das Livegewicht wird atomar in

`/var/lib/waagebox/dini/live.json`

bereitgestellt und von `currentWeight()` nur bei aktivem Worker und ausreichend
aktuellem Datensatz verwendet. Damit erhalten Dashboard und Großanzeige das
aktuelle Gewicht während der Überfahrt.

## RALL-Nachlauf

Nach erkannter Belastung wird die Liveabfrage beendet, wenn das Gewicht wieder
unter dem Schwellwert liegt und die konfigurierte Ruhezeit abgelaufen ist.

Produktiv getestet:

- Lastschwellwert: 100 kg
- Ruhe-/Nachlaufzeit: 11 Sekunden
- Einstellung: `dini_live_quiet_seconds`
- gespeicherter Testwert: `11.0`

Danach wartet der Worker weiter auf den offiziellen DINI-Enddatensatz.

Ein realer Test mit Achsüberfahrten war erfolgreich. Livegewicht wurde angezeigt,
die RALL-Phase nach der Ruhezeit beendet und anschließend das offizielle
Gesamtgewicht verarbeitet und ein Wiegeschein erstellt.

## Worker-Lifecycle

Der DINI-Worker verwaltet:

- `/var/lib/waagebox/dini/worker.lock`
- `/var/lib/waagebox/dini/worker.pid`
- `/var/lib/waagebox/dini/live.json`

Die PID-Datei erlaubt eine zuverlässigere Unterscheidung zwischen einem wirklich
laufenden Worker und einer lediglich vorhandenen Lockdatei.

Beim Beenden des Workers werden PID- und Live-State nur passend zum eigenen
Worker bereinigt.

Für Regressionstests kann der Runtimepfad über

`WAAGENBOX_DINI_RUNTIME_DIR`

überschrieben werden. Ohne diese Umgebungsvariable bleibt der Produktivpfad
unverändert `/var/lib/waagebox/dini`.

## Pending-State und manueller Reset

Bei einem Worker-Fehler bzw. Timeout wird versucht, den zugehörigen Pending-State
zu bereinigen.

Zusätzlich steht unter Einstellungen eine administrative Reset-Funktion für eine
hängende Wiegung zur Verfügung. Dabei wird ein vorhandener Worker anhand seiner
PID und Kommandozeile geprüft, beendet und anschließend der passende Pending-State
kontrolliert entfernt.

Bekannter Restpunkt: Zwischen der Identitätsprüfung und dem anschließenden
Löschen besteht noch ein theoretisches Race. Eine spätere Version soll hierfür
einen exakt bedingten Löschvorgang verwenden.

## ELDAT RX09

Beim produktiven Einlernen wurde festgestellt, dass der gehärtete
ELDAT-systemd-Dienst wegen `ProtectSystem=strict` nicht nach
`/run/waagenbox-rf` schreiben konnte.

Produktiv erfolgreicher Schreibzugriff:

`ReadWritePaths=/var/lib/waagebox/dini /run/waagenbox-rf`

Diese Änderung wird in die 1.2.41-Quell-Unit übernommen.

ELDAT-Einlernen sowie A-/B-Tastenabläufe wurden danach erfolgreich geprüft.

## Großanzeige

Das Livegewicht der laufenden DINI-Wiegung wird über den vorhandenen
Großanzeigen-Status ausgegeben. Eine separate zweite DINI-Verbindung für die
Großanzeige ist nicht erforderlich und darf nicht eingerichtet werden.

Die Großanzeigen-Einstellungen dürfen außerdem bei echtem Loopback-Zugriff
(`127.0.0.1` bzw. `::1`) ohne Admin-Anmeldung bearbeitet werden.

Netzwerkzugriffe bleiben adminpflichtig. Die CSRF-Prüfung bleibt bestehen.

## Fahrzeug-Erstgewicht

Bei bestehenden Fahrzeugen kann das gespeicherte Erst-/Leergewicht jetzt manuell
korrigiert werden.

Regeln:

- Eingabe in 5-kg-Schritten;
- leeres Eingabefeld verändert ein vorhandenes Erstgewicht nicht;
- Löschen erfolgt weiterhin ausschließlich über die separate Löschfunktion;
- ein manuell gespeichertes Erstgewicht wird funktional genauso verwendet wie
  ein automatisch ermitteltes Erstgewicht.

Die Bearbeitung, Speicherung, Löschung und anschließend eine reale Wiegung mit
manuell eingetragenem Erstgewicht wurden erfolgreich getestet.

## Reale Abnahme

Nach Abschluss der Korrekturen wurden mehrere reale Tests durchgeführt.

Bestätigt wurden insbesondere:

- ELDAT RX09;
- DINI-Wiegungsstart;
- Livegewicht während der Überfahrt;
- RALL-Nachlauf;
- offizielles DINI-Endgewicht;
- Abschluss der Wiegung;
- Wiegescheinerstellung;
- gespeichertes/manuell korrigiertes Erstgewicht;
- Großanzeigen-Darstellung.

Die abschließenden Tests liefen ohne Probleme.

## Bewusst offene Punkte

1. Ein Abbruch direkt am DINI-Terminal wird von der Waagenbox noch nicht sicher
   als Abbruch erkannt. Untersuchung erst beim nächsten verfügbaren DINI-Testaufbau.
2. Pending-Cleanup soll später gegen das theoretische Check/Delete-Race gehärtet
   werden.
3. Eine vollständige DINI-Session-Lock-Strategie kann später geprüft werden.
   Bis dahin keine parallele DINI-Verbindung während dynamischer Wiegungen.
4. Die Erzeugung und Berechtigung von `/run/waagenbox-rf` nach einem vollständigen
   Neustart wird vor dem endgültigen 1.2.41-Release nochmals geprüft.
5. Erkenntnisse aus dem kommenden realen Tagesbetrieb werden vor dem endgültigen
   1.2.41-Release ausgewertet.

## Status

Dieser Stand ist kein nachträglich veränderter Release 1.2.40.

Er bildet den real getesteten Ausgangspunkt für die weitere Entwicklung von
AJP Waagenbox 1.2.41 auf:

`feature/1.2.41-field-validation`
