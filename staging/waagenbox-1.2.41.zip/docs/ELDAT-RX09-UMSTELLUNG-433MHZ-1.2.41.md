# AJP Waagenbox 1.2.41 – Umstellung auf Eldat RX09

## Ziel

Der bisherige 433-MHz-GPIO-Empfänger wird nicht
mehr verwendet.

Die Funkfernbedienung erfolgt ausschließlich
über den Eldat RX09 USB-Empfänger.

## Hardware

Eldat RX09 USB-Empfänger

Stabiler Gerätepfad:
/dev/serial/by-id/usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0

Serielle Schnittstelle:
/dev/ttyUSB0

## Produktivsystem

Alter Dienst:
waagenbox-rf-remote.service

Status:
inactive / disabled

Neuer Dienst:
waagenbox-eldat-rx09.service

Status:
active / enabled

## Gemeinsames Laufzeitverzeichnis

Pfad:
/run/waagenbox-rf

Eigentümer:
www-data:www-data

Berechtigungen:
0750

Das Verzeichnis wird künftig eigenständig
durch den Eldat-systemd-Dienst verwaltet.

Erforderliche Service-Einstellungen:

RuntimeDirectory=waagenbox-rf
RuntimeDirectoryMode=0750
RuntimeDirectoryPreserve=restart

Das Verzeichnis wird von der Einlernfunktion
für folgende Dateien verwendet:

learn-request.json
learn-result.json

## Durchgeführte Systemumstellung

1. Eldat-Override erweitert.
2. systemd-Konfiguration neu eingelesen.
3. Eldat-Dienst neu gestartet.
4. Alten 433-MHz-Dienst deaktiviert.
5. Laufzeitverzeichnis wiederhergestellt.
6. Eldat-Dienst erneut gestartet.
7. Schreibberechtigung geprüft.

Ergebnis:
- Eldat active / enabled
- Alter GPIO-Funkdienst inactive / disabled
- Laufzeitverzeichnis vorhanden
- Schreibzugriff für www-data erfolgreich
- Keine Warnungen im Eldat-Journal

## Änderungen am Repository

systemd/waagenbox-eldat-rx09.service:
- RuntimeDirectory ergänzt
- Berechtigungen ergänzt
- RuntimeDirectoryPreserve ergänzt

install_eldat_rx09_systemd.sh:
- Abhängigkeit vom alten RF-Dienst entfernt

tests/eldat_systemd_installer_test.py:
- Zusätzliche Prüfungen für eigenständigen Eldat-Betrieb

## Testergebnisse

24 von 24 Installationstests erfolgreich.

Shell-Syntax erfolgreich.

systemd-analyze verify erfolgreich.

## Noch offene Prüfungen

- Handsender-Einlernen am realen RX09
- Verhalten nach vollständigem Raspberry-Neustart
- Abschließender Hardwaretest vor Release 1.2.41

## Versionsstand

Produktive Waagenbox weiterhin 1.2.40.

Entwicklungsbranch:
feature/1.2.41-field-validation

Kein Produktivrelease durchgeführt.
