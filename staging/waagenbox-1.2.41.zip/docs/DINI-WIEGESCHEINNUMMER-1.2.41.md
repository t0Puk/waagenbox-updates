# Waagenbox 1.2.41 – DINI-Wiegescheinnummer

## Ziel

Neue DINI-Wiegungen erhalten eine kombinierte
Wiegeschein-Nummer:

DINI-ID_Waagenbox-Nummer

Beispiel: 102_000061

Die Waagenbox-Nummer bleibt sechsstellig und
berücksichtigt bestehende Nummernkreis-Resets.

## Speicherung

Die DINI-ID wird aus dem abschließenden
DINI-Datensatz übernommen.

Übertragungsweg:
- hardware/Dini3590.php
- cli/dini_weighing_worker.php
- cli/dini_weighing_complete.php
- functions.php
- weighings.dini_id

Bei zwei Überfahrten wird die DINI-ID der
abschließenden Überfahrt gespeichert.

## Datenbank

Neue optionale Spalte:
weighings.dini_id BIGINT UNSIGNED NULL

Migration:
migration_v1_2_41_dini_ticket_id.sql

Auch schema.sql wurde ergänzt.

## Bestehende Wiegescheine

Alte Datensätze haben dini_id=NULL.
Sie behalten ihre bisherige Nummer.

Manuelle Wiegungen benötigen keine DINI-ID.

## Anzeige

reports/weighing.php verwendet
formattedDiniTicketNumberForWeighing().

Der Wiegeschein enthält weiterhin kein Kamerafoto.

## Tests

- 6 DINI-Abschlussprüfungen erfolgreich
- 14 Zwei-Überfahrten-Tests erfolgreich
- DINI-IDs 101 und 102 korrekt übergeben
- Datenbankspalte auf waagebox_test angelegt
- SQL-Test mit anschließendem ROLLBACK
- Nummernformatierung geprüft
- PHP-Syntaxprüfungen erfolgreich

## Status

Auf Testdatenbank und Entwicklungsbranch vorbereitet.
Noch kein Praxistest mit echter DINI-Wiegung.
Produktive Waagenbox unverändert.

Vor Produktivübernahme:
- DB-Migration über Updateverfahren
- reale DINI-Wiegung kontrollieren
- Wiegeschein und Nummernkreis prüfen
