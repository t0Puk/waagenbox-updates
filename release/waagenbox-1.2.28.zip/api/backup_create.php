<?php
require_once __DIR__.'/../functions.php';
requireAdmin();

$pdo=db();
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
$tables=[];
foreach($pdo->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM) as $row){
    if(isset($row[1]) && strtoupper((string)$row[1])==='BASE TABLE') $tables[]=$row[0];
}

function backupSqlValue($value): string {
    if ($value === null) return 'NULL';
    // SQL-Standard-Quoting: Anführungszeichen werden verdoppelt.
    // Dadurch ist das Backup unabhängig von NO_BACKSLASH_ESCAPES.
    return "'" . str_replace("'", "''", (string)$value) . "'";
}
function backupIdentifier(string $name): string { return '`'.str_replace('`','``',$name).'`'; }

$out="-- AJP Waagenbox Datenbank-Backup\n-- Erstellt: ".date('Y-m-d H:i:s')."\n-- Datenbank: ".DB_NAME."\n\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSTART TRANSACTION;\n\n";
foreach($tables as $table){
    $q=backupIdentifier($table);
    $create=$pdo->query('SHOW CREATE TABLE '.$q)->fetch(PDO::FETCH_NUM);
    $cols=$pdo->query('SHOW COLUMNS FROM '.$q)->fetchAll(PDO::FETCH_NUM);
    $columnNames=[];
    foreach($cols as $col) $columnNames[]=backupIdentifier((string)$col[0]);
    $out.="DROP TABLE IF EXISTS {$q};\n".$create[1].";\n\n";
    $rows=$pdo->query('SELECT * FROM '.$q)->fetchAll(PDO::FETCH_NUM);
    if($rows){
        $out.='INSERT INTO '.$q.' ('.implode(',',$columnNames).") VALUES\n";
        $lines=[];
        foreach($rows as $row){
            $vals=[];
            foreach($row as $v) $vals[]=backupSqlValue($v);
            $lines[]='('.implode(',',$vals).')';
        }
        $out.=implode(",\n",$lines).";\n\n";
    }
}
$out.="COMMIT;\nSET FOREIGN_KEY_CHECKS=1;\n";

$filename='waagenbox_'.date('Y-m-d_H-i-s').'.sql';
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Content-Length: '.strlen($out));
echo $out;
