<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../hardware/Dini3590.php';

$config = require __DIR__ . '/../config/dini.php';

try {
    $dini = new Dini3590(
        $config['host'],
        (int)$config['port'],
        (float)$config['timeout']
    );

    $action = $_GET['action'] ?? 'weight';

    switch ($action) {
        case 'weight':
            $result = $dini->readWeight();
            break;
        case 'extended':
            $result = $dini->readExtendedWeight();
            break;
        case 'all':
            $result = $dini->readAll();
            break;
        case 'state':
            $result = $dini->readState();
            break;
        case 'identify':
            $result = ['raw' => $dini->identify()];
            break;
        case 'first':
            $result = $dini->startFirstWeighing();
            break;
        case 'second':
            $result = $dini->startSecondWeighing();
            break;
        default:
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Unbekannte action.']);
            exit;
    }

    echo json_encode(['ok' => true, 'action' => $action, 'result' => $result], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
