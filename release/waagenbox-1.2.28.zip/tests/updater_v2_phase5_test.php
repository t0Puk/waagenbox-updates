<?php
declare(strict_types=1);

$checks=0;

function p5(bool $ok,string $message): void
{
    global $checks;

    if (!$ok) {
        fwrite(STDERR,"FAIL {$message}\n");
        exit(1);
    }

    $checks++;
    echo "PASS {$message}\n";
}

$script=file_get_contents(
    __DIR__.'/../install_updater_bootstrap.sh'
);

p5(
    str_contains(
        $script,
        'BOOTSTRAP_SNAPSHOT_OK'
    ),
    'bootstrap creates verified full snapshot'
);

p5(
    str_contains(
        $script,
        'updateSafetyLegacyConfig'
    ),
    'bootstrap uses safe legacy config migration'
);

p5(
    str_contains(
        $script,
        'operation_before_bootstrap.json'
    ),
    'old operation journal is archived'
);

p5(
    str_contains(
        $script,
        "recovery_failed"
    ),
    'known recovery_failed journal is explicitly reconciled'
);

p5(
    str_contains(
        $script,
        'chown root:www-data "$APP_ROOT/config.php"'
    ),
    'config remains root:www-data'
);

p5(
    str_contains(
        $script,
        'chown -R www-data:www-data "$APP_ROOT/uploads"'
    ),
    'runtime uploads remain writable by web user'
);

p5(
    str_contains(
        $script,
        'install_deploy_helper.sh'
    ),
    'bootstrap integrates deployment helper installer'
);

p5(
    !str_contains(
        $script,
        'chmod 777'
    ),
    'bootstrap never uses chmod 777'
);

p5(
    !str_contains(
        $script,
        'chown -R www-data:www-data "$APP_ROOT"'
    ),
    'bootstrap never makes whole application web-owned'
);

p5(
    str_contains(
        $script,
        'FINAL_VERSION'
    ),
    'bootstrap verifies final application version'
);

p5(
    str_contains(
        $script,
        'require_once $argv[2]'
    ),
    'bootstrap final version check does not reload version.php'
);

echo "RESULT {$checks} phase-5 checks passed\n";
