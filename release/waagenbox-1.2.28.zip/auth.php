<?php
// AJP Waage – Authentifizierung der Raspberry-Produktionsinstallation
if (PHP_SAPI !== 'cli' && session_status() !== PHP_SESSION_ACTIVE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function currentUser(): ?array {
    static $loaded = false;
    static $user = null;
    if ($loaded) return $user;
    $loaded = true;
    $id = (int)($_SESSION['user_id'] ?? 0);
    if ($id <= 0) return null;
    try {
        $s = db()->prepare('SELECT id,username,display_name,role,active,expires_at,force_password_change,last_login_at FROM users WHERE id=? LIMIT 1');
        $s->execute([$id]);
        $user = $s->fetch() ?: null;
    } catch (Throwable $e) {
        $user = null;
    }
    return $user;
}

function isLocalAccess(): bool {
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return in_array($remote, ['127.0.0.1', '::1'], true);
}

function passwordProtectionRequired(): bool {
    return !(defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) && !isLocalAccess();
}

function accessPasswordHash(): string {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT && !empty($_SESSION['web_test_access_password_hash'])) {
        return trim((string)$_SESSION['web_test_access_password_hash']);
    }
    return trim(appSetting('access_password_hash', ''));
}

function accessPasswordConfigured(): bool {
    return accessPasswordHash() !== '';
}

function saveAccessPasswordHash(string $hash): void {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) {
        $_SESSION['web_test_access_password_hash'] = $hash;
        return;
    }
    saveAppSetting('access_password_hash', $hash);
}

function isAccessAuthenticated(): bool {
    return !empty($_SESSION['waage_access_authenticated']);
}

function isLoggedIn(): bool { return currentUser() !== null || isAccessAuthenticated(); }
function isAdmin(): bool { $u=currentUser(); return ($u && $u['role']==='admin') || isAccessAuthenticated(); }

function csrfToken(): string {
    if (empty($_SESSION['waage_csrf_token'])) {
        $_SESSION['waage_csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['waage_csrf_token'];
}

function requireCsrfToken(): void {
    $provided = (string)($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string)($_SESSION['waage_csrf_token'] ?? '');
    if (!isValidCsrfToken($provided)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false, 'message'=>'Ungültiger CSRF-Token.']);
        exit;
    }
}

function isValidCsrfToken(string $provided): bool {
    $expected = (string)($_SESSION['waage_csrf_token'] ?? '');
    return $expected !== '' && $provided !== '' && hash_equals($expected, $provided);
}

function logoutUser(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}

function requireLogin(bool $allowPasswordChange=false): void {
    // Entwicklungs-Webversion bleibt ohne Login erreichbar.
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) return;
    // Direkter lokaler Zugriff am Raspberry (localhost / 127.0.0.1) bleibt ohne Passwort erreichbar.
    if (isLocalAccess()) return;
    if (isAccessAuthenticated()) return;
    if (!accessPasswordConfigured()) redirect('setup_access_password.php');
    redirect('login.php');
}

function requireAdmin(): void {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) return;
    requireLogin();
    if (!isAdmin()) {
        http_response_code(403);
        exit('Zugriff verweigert.');
    }
}
