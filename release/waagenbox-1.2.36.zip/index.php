<?php
require_once __DIR__.'/functions.php';
require_once __DIR__.'/system_control_support.php';
requireLogin();

$localDashboard = isLocalAccess();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['action'] ?? '') === 'kiosk_exit') {
    try {
        requireCsrfToken();
        if (!$localDashboard) throw new RuntimeException('Der Kiosk-Modus kann nur direkt am Raspberry-Bildschirm beendet werden.');
        $result = systemControlRequest('kiosk_exit');
        if (empty($result['ok'])) throw new RuntimeException((string)($result['message'] ?? 'Kiosk-Modus konnte nicht beendet werden.'));
        flash((string)$result['message']);
    } catch (Throwable $e) {
        flash('Kiosk-Modus konnte nicht beendet werden: '.$e->getMessage());
    }
    redirect('index.php');
}

if(isset($_GET['update']) && $_GET['update']==='success'){
    $v=trim((string)($_GET['v']??''));
    flash($v!=='' ? 'Update erfolgreich installiert. Neue Version: v'.$v.'.' : 'Update erfolgreich installiert.');
}
$dashboardSystemStatus = $localDashboard ? systemControlStatus() : null;
layoutStart('Dashboard','dashboard');
$activeFields = activeFields();
$activeVehicleCount = (int)db()->query('SELECT COUNT(*) FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1')->fetchColumn();
$activeFieldCount = (int)db()->query('SELECT COUNT(*) FROM `fields` WHERE owner_user_id='.(int)currentOwnerId().' AND active=1')->fetchColumn();
?>
<div class="dashboard-top-grid">
  <section class="card weight-card">
    <div class="eyebrow">AKTUELLES GEWICHT</div>
    <div id="weight" class="weight"><?=formatScaleWeight(currentWeight())?> <span>kg</span></div>
    <div id="weightStatus" class="status"><?=h(weightStatus())?></div>
    <div class="actions">
      <a class="button primary" href="weighing.php">Manuelle Wiegung</a><a class="button" href="vehicles.php">Fahrzeug wählen</a>
      <?php if($localDashboard && !empty($dashboardSystemStatus['installed']) && !empty($dashboardSystemStatus['kiosk_running'])): ?>
        <form method="post" style="display:inline" onsubmit="return confirm('Kiosk-Modus wirklich beenden und zum Raspberry-Desktop zurückkehren?');">
          <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
          <button class="button" name="action" value="kiosk_exit">Kiosk beenden</button>
        </form>
      <?php endif; ?>
    </div>
  </section>

  <section class="card scale-light-card" aria-live="polite">
    <div class="eyebrow">WAAGENSTATUS</div>
    <div id="scaleLight" class="scale-light dashboard-scale-light <?=h(scaleStatusKey())?>" data-status="<?=h(scaleStatusKey())?>">
      <span class="scale-bulb red"></span>
      <span class="scale-bulb yellow"></span>
      <span class="scale-bulb green"></span>
    </div>
    <div id="scaleLightLabel" class="scale-light-label"><?=h(scaleStatusLabel())?></div>
  </section>

  <section class="card camera camera-full">
    <div class="eyebrow">IP-KAMERA</div>
    <?php $cameraStream=cameraStreamUrl(); $cameraSnapshot=cameraSnapshotUrl(); ?>
    <?php if(cameraEnabled() && $cameraStream!==''): ?>
      <div class="camera-image"><img src="<?=h($cameraStream)?>" alt="IP-Kamera"></div>
    <?php elseif(cameraEnabled() && $cameraSnapshot!==''): ?>
      <div class="camera-image"><img src="api/camera_mjpeg.php?interval=1000" alt="IP-Kamera"></div>
    <?php else: ?>
      <div class="camera-placeholder">IP-Kamera noch nicht konfiguriert</div>
    <?php endif; ?>
  </section>
</div>
<div class="grid2">
  <section class="card"><h3>Aktive Schläge</h3><div id="activeFieldCount" class="bigtext"><?=$activeFieldCount?></div><p>aktiv</p><small id="activeFieldNames"><?=h(implode(' · ', array_map(fn($f)=>(string)$f['name'],$activeFields)))?></small><br><a class="text-link" href="fields.php">Schläge verwalten →</a></section>
  <section class="card"><h3>Aktive Fahrzeuge</h3><div id="activeVehicleCount" class="bigtext"><?=$activeVehicleCount?></div><p>aktiv</p><a class="text-link" href="vehicles.php">Fahrzeuge verwalten →</a></section>
</div>
<?php if (demoMode()): ?>
<section class="card test-weight-card">
  <h2>Testgewicht</h2>
  <p class="muted">Testbetrieb ohne aktiven Waagencomputer: Dieses Gewicht wird als aktuelles Waagenggewicht verwendet.</p>
  <form method="post" action="api/demo_weight.php" class="test-weight-form">
    <div><label>Testgewicht (kg)</label><input type="number" name="weight" min="0" step="0.1" value="<?=h(testWeight())?>"></div>
    <button class="button primary">Testgewicht setzen</button>
  </form>
  <p class="muted">Aktuell simuliert: <strong><?=formatScaleWeight(testWeight())?> kg</strong></p>
</section>
<?php endif; ?>
<script src="assets/app.js"></script>
<script>
async function refreshDashboardData(){
  try{
    const r=await fetch('api/dashboard_status.php',{cache:'no-store'});
    const d=await r.json();
    if(!d.ok) return;
    const vehicles=document.getElementById('activeVehicleCount');
    const fields=document.getElementById('activeFieldCount');
    const fieldNames=document.getElementById('activeFieldNames');
    if(vehicles) vehicles.textContent=String(d.active_vehicle_count ?? 0);
    if(fields) fields.textContent=String(d.active_field_count ?? 0);
    if(fieldNames) fieldNames.textContent=Array.isArray(d.active_field_names) ? d.active_field_names.join(' · ') : '';
  }catch(e){}
}
refreshDashboardData();
setInterval(refreshDashboardData,3000);
</script>

<?php if (demoMode()): ?><script src="assets/demo_auto_complete.js"></script><?php endif; ?>
<?php layoutEnd(true); ?>