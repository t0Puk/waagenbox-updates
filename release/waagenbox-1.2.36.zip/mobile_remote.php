<?php
require_once __DIR__.'/functions.php';
$token=trim((string)($_GET['t']??''));
if($token===''){http_response_code(404);exit('Ungültiger QR-Code.');}
if(useMobileContextByToken($token)===null){http_response_code(404);exit('Ungültiger QR-Code.');}
$s=db()->prepare('SELECT r.*,v.plate,v.name AS vehicle_name,v.first_weight,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id WHERE r.owner_user_id=? AND r.mobile_token=? LIMIT 1');
$s->execute([currentOwnerId(),$token]); $remote=$s->fetch();
if(!$remote || (int)$remote['active']!==1 || (int)($remote['vehicle_active']??0)!==1){http_response_code(403);exit('Diese mobile Fernbedienung ist nicht aktiv.');}
$gpsEnabledServer = appSetting('gps_enabled','0') === '1';
$hasFirstWeight = (float)($remote['first_weight'] ?? 0) > 0;
$vehicleLabel=trim(($remote['plate']??'').' – '.($remote['vehicle_name']??''),' –');
?>
<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#17212b"><title>AJP Waage – <?=h($remote['name'])?></title><link rel="stylesheet" href="assets/style.css"></head><body class="mobile-remote-page">
<div class="mobile-remote"><div class="mobile-brand">AJPnaturenergie<br><span>Mobile Waage</span></div><div class="mobile-card"><div class="eyebrow">FERNBEDIENUNG</div><h1><?=h($remote['name'])?></h1><div class="mobile-vehicle">🚜 <?=h($vehicleLabel ?: 'Kein Fahrzeug')?></div><div id="gpsBox" class="gps-box"><?= $gpsEnabledServer ? "📍 Standort wird geprüft …" : "🟢 GPS-Prüfung ist deaktiviert." ?></div>
<div class="mobile-weight"><div class="eyebrow">AKTUELLES WAAGENGEWICHT</div><div id="currentWeight">– <span>kg</span></div><div id="firstWeight" class="mobile-first">1. Gewicht: –</div></div>
<button id="startButton" class="mobile-start" <?= ($gpsEnabledServer || !$hasFirstWeight) ? "disabled" : "" ?>>WIEGUNG<br>STARTEN</button>
<button id="firstWeightButton" class="mobile-start" style="<?= $hasFirstWeight ? 'display:none;' : 'margin-top:12px;' ?>" <?= $gpsEnabledServer ? "disabled" : "" ?>>1. GEWICHT<br>(LEERGEWICHT) ERFASSEN</button>
<div id="mobileStatus" class="mobile-status"><?= $gpsEnabledServer ? "Bitte Standortzugriff erlauben." : ($hasFirstWeight ? "Bereit zum Wiegen." : "Bitte zuerst das Leergewicht erfassen.") ?></div><div id="successBox" class="mobile-success" style="display:none"><div class="mobile-success-icon">✓</div><div class="mobile-success-title">Wiegung erfolgreich übermittelt</div><div id="successDetails" class="mobile-success-details"></div><div class="mobile-success-countdown">Die Wiegeoberfläche wird in <span id="successCountdown">5</span> Sekunden wieder geöffnet.</div></div></div><div id="mobileNote" class="mobile-note">Die Wiegung kann nur in der Nähe der hinterlegten Waage gestartet und abgeschlossen werden.</div></div>
<script>
const token=<?=json_encode($token)?>;
const startButton=document.getElementById('startButton');
const firstWeightButton=document.getElementById('firstWeightButton');
const gpsBox=document.getElementById('gpsBox');
const statusBox=document.getElementById('mobileStatus');
const weightBox=document.getElementById('currentWeight');
const firstBox=document.getElementById('firstWeight');
const successBox=document.getElementById('successBox');
const successDetails=document.getElementById('successDetails');
const successCountdown=document.getElementById('successCountdown');
const mobileNote=document.getElementById('mobileNote');
let locationData=<?= $gpsEnabledServer ? "null" : "{gpsDisabled:true}" ?>,locationAllowed=<?= $gpsEnabledServer ? "false" : "true" ?>,running=false,firstWeightRunning=false,successShown=false,finishTimer=null,lastWeight=0,gpsEnabled=<?= $gpsEnabledServer ? "true" : "false" ?>,gpsInitialized=true,hasFirstWeight=<?= $hasFirstWeight ? "true" : "false" ?>;


function showWeight(v){
  weightBox.innerHTML=(Math.round((Number(v)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' <span>kg</span>';
}

async function refreshStatus(){
  if(successShown)return false;
  try{
    const r=await fetch('api/mobile_status.php?t='+encodeURIComponent(token),{cache:'no-store'});
    const d=await r.json();
    if(!d.ok)return false;
    const w=Number(d.current_weight)||0;
    showWeight(w);
    if(!gpsInitialized){
      gpsInitialized=true;
      gpsEnabled=d.gps_enabled!==false;
      if(!gpsEnabled){
        locationData={gpsDisabled:true};
        gpsBox.textContent='🟢 GPS-Prüfung ist deaktiviert.';
        if(mobileNote)mobileNote.textContent='Die Wiegung kann ohne Standortfreigabe gestartet werden.';
        if(!running){statusBox.textContent=hasFirstWeight?'Bereit zum Wiegen.':'Bitte zuerst das Leergewicht erfassen.';startButton.disabled=!hasFirstWeight;firstWeightButton.disabled=hasFirstWeight;}
      }
    }

    if(d.pending){
      running=true;
      firstWeightRunning=d.pending_mode==='first_weight';
      startButton.style.display='none';
      firstWeightButton.style.display='none';

      if(firstWeightRunning){
        firstBox.textContent='1. Gewicht: noch nicht erfasst';
        if(w>0 && lastWeight<=0 && !finishTimer){
          statusBox.textContent='🟡 Leergewicht erkannt. Gewicht wird gespeichert …';
          finishTimer=setTimeout(()=>completeFirstWeight(),1000);
        }else if(w<=0 && !finishTimer){
          statusBox.textContent='🟢 Leergewichtserfassung aktiv. Bitte jetzt mit dem Fahrzeug über die Waage fahren …';
        }
        lastWeight=w;
        if(w<=0 && finishTimer){
          clearTimeout(finishTimer);
          finishTimer=null;
          statusBox.textContent='🟢 Leergewichtserfassung aktiv. Bitte jetzt mit dem Fahrzeug über die Waage fahren …';
        }
      }else{
        firstBox.textContent='1. Gewicht: '+(Math.round((Number(d.first_weight)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' kg';

        // Nach dem Start wird das Zweitgewicht automatisch übernommen,
        // sobald ein neues positives Gewicht erkannt wird.
        if(w>0 && lastWeight<=0 && !finishTimer){
          statusBox.textContent='🟡 Gewicht erkannt. Wiegung wird beendet …';
          finishTimer=setTimeout(()=>completeWeighing(),1000);
        }
        lastWeight=w;
        if(w<=0 && finishTimer){clearTimeout(finishTimer);finishTimer=null;statusBox.textContent='🟢 Wiegung gestartet. Warte auf das aktuelle Gewicht …';}
      }
    }else if(!running){
      hasFirstWeight=(Number(d.vehicle_first_weight)||0)>0;
      firstBox.textContent='1. Gewicht: '+(Math.round((Number(d.vehicle_first_weight)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' kg';
      firstWeightButton.style.display=hasFirstWeight?'none':'block';
      if(!hasFirstWeight) firstWeightButton.style.marginTop='12px';
      startButton.style.display='block';
      if(locationAllowed){startButton.disabled=!hasFirstWeight;firstWeightButton.disabled=hasFirstWeight;}
      lastWeight=w;
    }
    return true;
  }catch(e){return false;}
}

function checkLocation(){
  if(!gpsEnabled){locationData={gpsDisabled:true};locationAllowed=true;gpsBox.textContent='🟢 GPS-Prüfung ist deaktiviert.';statusBox.textContent=hasFirstWeight?'Bereit zum Wiegen.':'Bitte zuerst das Leergewicht erfassen.';if(mobileNote)mobileNote.textContent='Die Wiegung kann ohne Standortfreigabe gestartet werden.';startButton.disabled=!hasFirstWeight;firstWeightButton.disabled=hasFirstWeight;return;}
  if(!navigator.geolocation){
    gpsBox.textContent='🔴 Dieses Smartphone unterstützt keine Standortabfrage.';
    statusBox.textContent='Wiegung nicht möglich.';return;
  }
  gpsBox.textContent='📍 Standort wird geprüft …';
  startButton.disabled=true;
  firstWeightButton.disabled=true;
  navigator.geolocation.getCurrentPosition(async p=>{
    locationData={lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy};
    try{
      const r=await fetch('api/mobile_location.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(locationData && locationData.gpsDisabled ? {token} : {token,latitude:locationData.lat,longitude:locationData.lon,accuracy:locationData.accuracy})});
      const d=await r.json();
      if(d.ok){
        locationAllowed=true;
        gpsBox.textContent='🟢 Standort bestätigt · '+Math.round(d.distance_m)+' m von der Waage';
        if(!running){statusBox.textContent=hasFirstWeight?'Bereit zum Wiegen.':'Bitte zuerst das Leergewicht erfassen.';startButton.disabled=!hasFirstWeight;firstWeightButton.disabled=hasFirstWeight;}
      }else{
        gpsBox.textContent='🔴 '+d.message;
        locationAllowed=false;
        if(!running){statusBox.textContent='Wiegung nicht möglich.';startButton.disabled=true;firstWeightButton.disabled=true;}
      }
    }catch(e){locationAllowed=false;gpsBox.textContent='🔴 Standortprüfung fehlgeschlagen.';if(!running){startButton.disabled=true;firstWeightButton.disabled=true;}}
  },e=>{
    gpsBox.textContent='🔴 Standort konnte nicht ermittelt werden: '+e.message;
    locationAllowed=false;
    if(!running){statusBox.textContent='Bitte Standortzugriff erlauben.';startButton.disabled=true;firstWeightButton.disabled=true;}
  },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}

firstWeightButton.addEventListener('click',async()=>{
  if(!locationAllowed||!locationData){statusBox.textContent='🔴 Standortprüfung ist noch nicht abgeschlossen.';return;}
  firstWeightButton.disabled=true;
  statusBox.textContent='Leergewichtserfassung wird gestartet …';
  try{
    const payload=locationData && locationData.gpsDisabled
      ? {token,action:'start'}
      : {token,action:'start',latitude:locationData.lat,longitude:locationData.lon,accuracy:locationData.accuracy};
    const r=await fetch('api/mobile_first_weight.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const d=await r.json();
    if(!d.ok)throw new Error(d.message||'Leergewichtserfassung konnte nicht gestartet werden.');
    running=true;
    firstWeightRunning=true;
    lastWeight=0;
    firstBox.textContent='1. Gewicht: noch nicht erfasst';
    startButton.style.display='none';
    firstWeightButton.style.display='none';
    statusBox.textContent='🟢 Leergewichtserfassung aktiv. Bitte jetzt mit dem Fahrzeug über die Waage fahren …';
    await refreshStatus();
  }catch(e){
    running=false;
    firstWeightRunning=false;
    statusBox.textContent='🔴 '+(e.message||'Leergewichtserfassung konnte nicht gestartet werden.');
    if(locationAllowed) firstWeightButton.disabled=false;
  }
});

async function completeFirstWeight(){
  finishTimer=null;
  if(successShown||!running||!firstWeightRunning)return;
  statusBox.textContent='Leergewicht wird gespeichert …';
  try{
    const r=await fetch('api/mobile_first_weight.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,action:'complete'})});
    const d=await r.json();
    if(!d.ok)throw new Error(d.message||'Leergewicht konnte nicht gespeichert werden.');
    hasFirstWeight=true;
    running=false;
    firstWeightRunning=false;
    firstBox.textContent='1. Gewicht: '+(Math.round((Number(d.first_weight)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' kg';
    firstWeightButton.style.display='none';
    startButton.style.display='block';
    startButton.disabled=!locationAllowed;
    statusBox.textContent='🟢 Leergewicht gespeichert. Bereit zum Wiegen.';
    lastWeight=Number(d.first_weight)||0;
    await refreshStatus();
  }catch(e){
    statusBox.textContent='🔴 '+(e.message||'Leergewicht konnte nicht gespeichert werden.');
    lastWeight=0;
  }
}

startButton.addEventListener('click',async()=>{
  if(!locationAllowed||!locationData){statusBox.textContent='🔴 Standortprüfung ist noch nicht abgeschlossen.';return;}
  if(!hasFirstWeight){statusBox.textContent='🔴 Bitte zuerst das Leergewicht erfassen.';return;}
  startButton.disabled=true;
  statusBox.textContent='Wiegung wird gestartet …';
  try{
    const r=await fetch('api/mobile_trigger.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(locationData && locationData.gpsDisabled ? {token} : {token,latitude:locationData.lat,longitude:locationData.lon,accuracy:locationData.accuracy})});
    const d=await r.json();
    if(!d.ok)throw new Error(d.message||'Wiegung konnte nicht gestartet werden.');
    running=true;lastWeight=0;
    statusBox.textContent='🟢 Wiegung gestartet. Warte auf das Wiegeergebnis …';
    startButton.style.display='none';
    firstWeightButton.style.display='none';
    await refreshStatus();
  }catch(e){statusBox.textContent='🔴 '+(e.message||'Wiegung konnte nicht gestartet werden.');if(gpsEnabled)checkLocation();else startButton.disabled=false;}
});

async function completeWeighing(){
  finishTimer=null;
  if(successShown||!running)return;
  statusBox.textContent='Wiegung wird abgeschlossen …';
  try{
    const r=await fetch('api/mobile_complete.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token})});
    const d=await r.json();
    if(!d.ok)throw new Error(d.message||'Wiegung konnte nicht abgeschlossen werden.');
    successShown=true;running=false;
    successDetails.textContent='Netto: '+(Math.round((Number(d.net_weight)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' kg';
    statusBox.style.display='none';
    gpsBox.textContent='🟢 Wiegung erfolgreich gespeichert.';
    successBox.style.display='block';
    let remaining=5;successCountdown.textContent=remaining;
    const timer=setInterval(()=>{
      remaining--;successCountdown.textContent=remaining;
      if(remaining<=0){clearInterval(timer);window.location.reload();}
    },1000);
  }catch(e){
    statusBox.textContent='🔴 '+e.message;
    // Bei einem kurzen/ungültigen Gewichtsimpuls erneut auf ein positives Gewicht warten.
    lastWeight=0;
  }
}

refreshStatus().then(()=>{if(gpsEnabled)checkLocation();else {locationData={gpsDisabled:true};locationAllowed=true;startButton.disabled=!hasFirstWeight;firstWeightButton.disabled=hasFirstWeight;}});setInterval(refreshStatus,500);
</script></body></html>
