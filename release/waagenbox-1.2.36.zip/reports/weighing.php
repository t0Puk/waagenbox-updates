<?php
require_once __DIR__.'/../functions.php';
requireLogin();
$id=(int)($_GET['id']??0);
$s=db()->prepare('SELECT w.*,v.plate,v.name AS vehicle_name,f.name AS field_name,c.name AS customer_name,p.name AS product_name FROM weighings w LEFT JOIN vehicles v ON v.id=w.vehicle_id AND v.owner_user_id=w.owner_user_id LEFT JOIN `fields` f ON f.id=w.field_id AND f.owner_user_id=w.owner_user_id LEFT JOIN customers c ON c.id=w.customer_id AND c.owner_user_id=w.owner_user_id LEFT JOIN products p ON p.id=w.product_id AND p.owner_user_id=w.owner_user_id WHERE w.owner_user_id=? AND w.id=?');
$s->execute([currentOwnerId(),$id]); $r=$s->fetch();
if(!$r){http_response_code(404);exit('Wiegung nicht gefunden');}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><title>Wiegung <?=$id?></title><style>
body{font-family:Arial,sans-serif;margin:40px;max-width:800px;color:#14202c}h1{margin-bottom:4px}.box{border:1px solid #ccc;padding:20px;margin:20px 0}table{width:100%;border-collapse:collapse}td{padding:9px;border-bottom:1px solid #ddd}.netto{font-size:30px;font-weight:bold}.no-print{margin-bottom:20px}.weighing-meta{display:flex;align-items:baseline;gap:48px;flex-wrap:wrap}.ticket-number{font-weight:700}.report-note{margin-top:28px;font-size:10px;color:#6f7780}.button{display:inline-block;border:0;background:#17212b;color:#fff;padding:10px 14px;border-radius:7px;font-weight:700;cursor:pointer;text-decoration:none;margin-right:8px}@media print{.no-print{display:none}}
</style></head><body><div class="no-print"><a class="button" href="../weighings.php">← Zur Wiegescheinübersicht</a><button class="button" type="button" onclick="window.print()">Drucken / als PDF speichern</button></div>
<h1>Wiegung</h1><p class="weighing-meta"><span><?=h($r['created_at'])?></span><span class="ticket-number">Wiegeschein-Nr. <?=h(formattedTicketNumberForWeighing((int)$r['id']))?></span></p><div class="box"><table>
<tr><td>Fahrzeug</td><td><?php if($r['vehicle_id']): ?><b><?=h($r['plate'])?></b><?php if($r['vehicle_name']): ?> – <?=h($r['vehicle_name'])?><?php endif; ?><?php else: ?><em>Kein Fahrzeug hinterlegt</em><?php endif; ?></td></tr>
<tr><td>Kunde</td><td><?php if(!empty($r['customer_id']) && !empty($r['customer_name'])): ?><b><?=h($r['customer_name'])?></b><?php else: ?><em>Kein Kunde hinterlegt</em><?php endif; ?></td></tr>
<tr><td>Produkt</td><td><?php if(!empty($r['product_id']) && !empty($r['product_name'])): ?><b><?=h($r['product_name'])?></b><?php else: ?><em>Kein Produkt hinterlegt</em><?php endif; ?></td></tr>
<tr><td>Schlag</td><td><?=h($r['field_name'] ?: 'Kein Schlag ausgewählt')?></td></tr>
<tr><td>1. Gewicht</td><td><?=formatWeight((float)$r['first_weight'])?> kg</td></tr><tr><td>2. Gewicht</td><td><?=formatWeight((float)$r['second_weight'])?> kg</td></tr>
<tr><td>Netto</td><td class="netto"><?=formatWeight((float)$r['net_weight'])?> kg</td></tr><tr><td>Auslösung</td><td><?=h($r['trigger_type'])?></td></tr>
<?php if(!empty($r['notes'])): ?><tr><td>Notizen</td><td><?=nl2br(h($r['notes']))?></td></tr><?php endif; ?>
</table></div><div class="report-note">Messwerte aus frei programmierbarer Zusatzeinrichtung. Die geeichten Messwerte können eingesehen werden.</div></body></html>
