<?php
require_once __DIR__.'/../functions.php';
if (!isLocalAccess()) requireAdmin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

const RF_LEARN_DIR = '/run/waagenbox-rf';
const RF_LEARN_REQUEST = RF_LEARN_DIR.'/learn-request.json';
const RF_LEARN_RESULT = RF_LEARN_DIR.'/learn-result.json';
const RF_LEARN_SECONDS = 20;

function rfLearnJson(int $status, array $payload): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function rfLearnRead(string $path): ?array {
    if (!is_file($path)) return null;
    $raw = @file_get_contents($path);
    if ($raw === false) return null;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function rfLearnRemoveIfToken(string $path, string $token, int $ownerId): void {
    $data = rfLearnRead($path);
    if (!$data) return;
    if ((string)($data['token'] ?? '') !== $token) return;
    if ((int)($data['owner_id'] ?? 0) !== $ownerId) return;
    @unlink($path);
}

function rfLearnWriteRequest(array $data): bool {
    if (!is_dir(RF_LEARN_DIR) || !is_writable(RF_LEARN_DIR)) return false;
    $tmp = RF_LEARN_DIR.'/learn-request.'.bin2hex(random_bytes(6)).'.tmp';
    $json = json_encode($data, JSON_UNESCAPED_SLASHES);
    if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, RF_LEARN_REQUEST)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

$ownerId = currentOwnerId();
if ($ownerId <= 0) rfLearnJson(403, ['ok'=>false, 'message'=>'Kein gültiger Benutzerkontext.']);

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'status');

if ($action === 'start') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') rfLearnJson(405, ['ok'=>false, 'message'=>'POST erforderlich.']);
    requireCsrfToken();

    if (!is_dir(RF_LEARN_DIR) || !is_writable(RF_LEARN_DIR)) {
        rfLearnJson(503, ['ok'=>false, 'message'=>'Funkempfänger-Dienst ist nicht aktiv.']);
    }

    $existing = rfLearnRead(RF_LEARN_REQUEST);
    if ($existing && (float)($existing['expires_at'] ?? 0) > time()) {
        rfLearnJson(409, ['ok'=>false, 'message'=>'Es läuft bereits ein Einlernvorgang.']);
    }

    @unlink(RF_LEARN_REQUEST);
    @unlink(RF_LEARN_RESULT);

    $token = bin2hex(random_bytes(16));
    $expiresAt = time() + RF_LEARN_SECONDS;
    if (!rfLearnWriteRequest([
        'token'=>$token,
        'owner_id'=>$ownerId,
        'expires_at'=>$expiresAt,
    ])) {
        rfLearnJson(500, ['ok'=>false, 'message'=>'Einlernmodus konnte nicht gestartet werden.']);
    }

    rfLearnJson(200, [
        'ok'=>true,
        'state'=>'waiting',
        'token'=>$token,
        'expires_at'=>$expiresAt,
        'timeout_seconds'=>RF_LEARN_SECONDS,
        'message'=>'Einlernmodus aktiv. Bitte jetzt die gewünschte Taste am Handsender drücken.',
    ]);
}

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
if (!preg_match('/^[0-9a-f]{32}$/', $token)) {
    rfLearnJson(400, ['ok'=>false, 'message'=>'Ungültiger Einlern-Token.']);
}

if ($action === 'cancel') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') rfLearnJson(405, ['ok'=>false, 'message'=>'POST erforderlich.']);
    requireCsrfToken();
    rfLearnRemoveIfToken(RF_LEARN_REQUEST, $token, $ownerId);
    rfLearnRemoveIfToken(RF_LEARN_RESULT, $token, $ownerId);
    rfLearnJson(200, ['ok'=>true, 'state'=>'cancelled', 'message'=>'Einlernmodus beendet.']);
}

if ($action !== 'status') {
    rfLearnJson(400, ['ok'=>false, 'message'=>'Unbekannte Aktion.']);
}

$result = rfLearnRead(RF_LEARN_RESULT);
if ($result && (string)($result['token'] ?? '') === $token && (int)($result['owner_id'] ?? 0) === $ownerId) {
    $code = (int)($result['code'] ?? -1);
    if ($code < 0 || $code > 0xFFFFFF) {
        rfLearnJson(500, ['ok'=>false, 'message'=>'Ungültiges Lernergebnis.']);
    }

    $q = db()->prepare('SELECT id,name FROM remotes WHERE owner_user_id=? AND code=? ORDER BY id LIMIT 2');
    $q->execute([$ownerId, (string)$code]);
    $duplicates = $q->fetchAll(PDO::FETCH_ASSOC);

    @unlink(RF_LEARN_RESULT);
    rfLearnJson(200, [
        'ok'=>true,
        'state'=>'captured',
        'code'=>(string)$code,
        'hex'=>(string)($result['hex'] ?? sprintf('0x%06X', $code)),
        'duplicate'=>count($duplicates) > 0,
        'duplicate_remote'=>$duplicates[0] ?? null,
        'message'=>'Handsender-Code wurde erkannt.',
    ]);
}

$request = rfLearnRead(RF_LEARN_REQUEST);
if ($request && (string)($request['token'] ?? '') === $token && (int)($request['owner_id'] ?? 0) === $ownerId) {
    $expiresAt = (int)($request['expires_at'] ?? 0);
    if ($expiresAt > time()) {
        rfLearnJson(200, [
            'ok'=>true,
            'state'=>'waiting',
            'expires_at'=>$expiresAt,
            'seconds_left'=>max(0, $expiresAt-time()),
            'message'=>'Warte auf Handsender …',
        ]);
    }
    @unlink(RF_LEARN_REQUEST);
}

rfLearnJson(200, ['ok'=>true, 'state'=>'expired', 'message'=>'Kein Funksignal erkannt. Bitte Einlernen erneut starten.']);
