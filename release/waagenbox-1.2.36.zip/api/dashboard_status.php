<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$pdo=db();
$ownerId=currentOwnerId();

$vehicleStmt=$pdo->prepare('SELECT id,plate,name,active FROM vehicles WHERE owner_user_id=? ORDER BY id');
$vehicleStmt->execute([$ownerId]);
$vehicles=$vehicleStmt->fetchAll();

$fieldStmt=$pdo->prepare('SELECT id,name,crop,year,active FROM `fields` WHERE owner_user_id=? ORDER BY id');
$fieldStmt->execute([$ownerId]);
$fields=$fieldStmt->fetchAll();

$activeFields=array_values(array_filter($fields,static fn($f)=>(int)$f['active']===1));
$activeVehicleCount=count(array_filter($vehicles,static fn($v)=>(int)$v['active']===1));

$latestStmt=$pdo->prepare('SELECT COALESCE(MAX(id),0) FROM weighings WHERE owner_user_id=?');
$latestStmt->execute([$ownerId]);
$latestWeighingId=(int)$latestStmt->fetchColumn();

echo json_encode([
    'ok'=>true,
    'active_vehicle_count'=>$activeVehicleCount,
    'active_field_count'=>count($activeFields),
    'active_field_names'=>array_map(static fn($f)=>(string)$f['name'],$activeFields),
    'latest_weighing_id'=>$latestWeighingId,
    'revision'=>hash('sha256',json_encode([$vehicles,$fields,$latestWeighingId],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
