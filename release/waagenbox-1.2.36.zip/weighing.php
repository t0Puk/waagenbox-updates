<?php
require_once __DIR__.'/functions.php';
requireLogin();
$error = null;
$pdo = db();
$testWeightValue = testWeight();
$selected = (int)($_GET['vehicle_id'] ?? $_POST['vehicle_id'] ?? 0);
$selectedField = (int)($_GET['field_id'] ?? $_POST['field_id'] ?? 0);
$selectedCustomer = (int)($_GET['customer_id'] ?? $_POST['customer_id'] ?? 0);
$selectedProduct = (int)($_GET['product_id'] ?? $_POST['product_id'] ?? 0);
$vehicle = null;
if ($selected > 0) {
    $q=$pdo->prepare('SELECT id,plate,name,first_weight,max_weight FROM vehicles WHERE owner_user_id=? AND id=? AND active=1');
    $q->execute([currentOwnerId(),$selected]); $vehicle=$q->fetch() ?: null;
}
$fields = $pdo->query('SELECT id,name,crop,year,active FROM `fields` WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY active DESC, name ASC')->fetchAll();
$customers = $pdo->query('SELECT id,name FROM customers WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY name')->fetchAll();
$products = $pdo->query('SELECT id,name FROM products WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY name')->fetchAll();

function validateOptionalRefs(PDO $pdo, int $fieldId, int $customerId, int $productId): void {
    if ($fieldId > 0) { $s=$pdo->prepare('SELECT id FROM `fields` WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$fieldId]); if(!$s->fetchColumn()) throw new RuntimeException('Der ausgewählte Schlag wurde nicht gefunden.'); }
    if ($customerId > 0) { $s=$pdo->prepare('SELECT id FROM customers WHERE owner_user_id=? AND id=? AND active=1'); $s->execute([currentOwnerId(),$customerId]); if(!$s->fetchColumn()) throw new RuntimeException('Der ausgewählte Kunde ist nicht aktiv oder wurde nicht gefunden.'); }
    if ($productId > 0) { $s=$pdo->prepare('SELECT id FROM products WHERE owner_user_id=? AND id=? AND active=1'); $s->execute([currentOwnerId(),$productId]); if(!$s->fetchColumn()) throw new RuntimeException('Das ausgewählte Produkt ist nicht aktiv oder wurde nicht gefunden.'); }
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $action = $_POST['action'] ?? '';
        if ($action === 'set_test_weight') {
            setTestWeight(max(0.0,(float)str_replace(',', '.', (string)($_POST['test_weight'] ?? '0'))));
            flash('Testgewicht wurde gesetzt.');
            redirect('weighing.php');
        }
        if ($action === 'clear_test_weight') {
            setTestWeight(0.0);
            flash('Testgewicht wurde gelöscht.');
            redirect('weighing.php');
        }
        $vid = (int)($_POST['vehicle_id'] ?? 0);
        $fid = (int)($_POST['field_id'] ?? 0);
        $cid = (int)($_POST['customer_id'] ?? 0);
        $pid = (int)($_POST['product_id'] ?? 0);
        if ($vid > 0) {
            $q=$pdo->prepare('SELECT id,plate,name,first_weight,max_weight FROM vehicles WHERE owner_user_id=? AND id=? AND active=1'); $q->execute([currentOwnerId(),$vid]); $vehicle=$q->fetch() ?: null;
            if (!$vehicle) throw new RuntimeException('Fahrzeug nicht gefunden.');
        }
        if ($action === 'use_saved') {
            if (!$vehicle) throw new RuntimeException('Bitte ein Fahrzeug auswählen.');
            if ((float)$vehicle['first_weight'] <= 0) throw new RuntimeException('Für dieses Fahrzeug ist noch kein Erstgewicht hinterlegt.');
            validateOptionalRefs($pdo,$fid,$cid,$pid);
            setPendingWeighing((float)$vehicle['first_weight'],(int)$vehicle['id'],null,'manual',$fid?:null,$cid?:null,$pid?:null);
            startSecondScaleWeighing();
            flash('Gespeichertes 1. Gewicht verwendet. Die Waage wartet jetzt auf das Zweitgewicht.');
            redirect('weighing.php?vehicle_id='.(int)$vehicle['id']);
        }
        if ($action === 'first') {
            if (!$vehicle) throw new RuntimeException('Für ein gespeichertes Erstgewicht muss ein Fahrzeug ausgewählt sein.');
            validateOptionalRefs($pdo,$fid,$cid,$pid);
            startFirstScaleWeighing();
            $weight=currentWeight(); if($weight<=0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
            $u=$pdo->prepare('UPDATE vehicles SET first_weight=? WHERE owner_user_id=? AND id=?'); $u->execute([$weight,currentOwnerId(),$vehicle['id']]);
            clearPendingWeighing();
            flash('1. Gewicht für '.$vehicle['plate'].' gespeichert: '.formatWeight($weight).' kg. Die Waage ist wieder bereit.');
            redirect('weighing.php?vehicle_id='.(int)$vehicle['id']);
        }
        if ($action === 'start_unassigned') {
            validateOptionalRefs($pdo,$fid,$cid,$pid);
            startFirstScaleWeighing();
            $weight=currentWeight(); if($weight<=0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
            setPendingWeighing($weight,null,null,'manual',$fid?:null,$cid?:null,$pid?:null);
            flash('1. Gewicht gespeichert: '.number_format($weight,1,',','.').' kg. Die Waage wartet jetzt auf das Zweitgewicht.');
            redirect('weighing.php');
        }
        if ($action === 'second') {
            $pending=pendingWeighing(); if(!$pending) throw new RuntimeException('Es ist keine laufende Wiegung vorhanden.');
            $weight=currentWeight(); if($weight<=0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
            $id = completePendingWeighing($weight, trim($_POST['notes'] ?? ''));
            // Nach dem Abschluss bleibt die Wiegeseite noch 5 Sekunden aktiv,
            // damit die rote Verarbeitungsanzeige sichtbar bleibt.
            redirect('weighing.php?completed=1&id='.(int)$id);
        }
    } catch(Throwable $e) { $error=$e->getMessage(); }
}
$vehicles=$pdo->query('SELECT id,plate,name,first_weight FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY plate')->fetchAll();
$pending=pendingWeighing();
$autoDemoFinish = $pending && demoMode() && (($pending['trigger_type'] ?? '') === 'manual');
layoutStart('Wiegung','weighings');
if($error) echo '<div class="flash error"><strong>Wiegung konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$completed = isset($_GET['completed']) && $_GET['completed'] === '1';
?>
<?php if($completed): ?>
<div class="card" id="weighingProcessingNotice" style="text-align:center;margin-bottom:20px">
  <div class="eyebrow">WIEGUNG ERFOLGREICH ABGESCHLOSSEN</div>
  <h2>Daten werden verarbeitet …</h2>
  <p class="muted">Die Waage bleibt noch <strong id="processingCountdown">5</strong> Sekunden auf Rot. Anschließend werden die Wiegungen angezeigt.</p>
</div>
<script>
(function(){
  let remaining=5;
  const el=document.getElementById('processingCountdown');
  const timer=setInterval(function(){
    remaining--;
    if(el) el.textContent=remaining;
    if(remaining<=0){clearInterval(timer);window.location.href='weighings.php';}
  },1000);
})();
</script>
<?php endif; ?>
<div class="toolbar"><h1>Wiegung</h1><a class="button" href="weighings.php">Wiegungen anzeigen</a></div>
<div class="weighing-layout">
<section class="card live-scale-card">
  <div class="eyebrow">AKTUELLES WAAGENGEWICHT</div>
  <div id="weight" class="weight"><?=formatScaleWeight(currentWeight())?> <span>kg</span></div>
  <div id="weightStatus" class="status"><?=h(weightStatus())?></div>
  <div class="scale-status-panel">
    <div id="scaleLight" class="scale-light <?=h(scaleStatusKey())?>" data-status="<?=h(scaleStatusKey())?>"><span class="scale-bulb red"></span><span class="scale-bulb yellow"></span><span class="scale-bulb green"></span></div>
    <div><div class="eyebrow">WAAGENSTATUS</div><div id="scaleLightLabel" class="scale-light-label"><?=h(scaleStatusLabel())?></div></div>
  </div>
</section>
<section class="card weighing-form-card">
<?php if($pending): ?>
  <div class="eyebrow">LAUFENDE WIEGUNG</div>
  <h2>Zweitgewicht erfassen</h2>
  <div class="weighing-summary"><div><span>1. Gewicht</span><strong><?=formatWeight((float)$pending['first_weight'])?> kg</strong></div><?php if(!empty($pending['vehicle_id'])):?><div><span>Fahrzeug</span><strong><?=h(vehicleLabel((int)$pending['vehicle_id']))?></strong></div><?php endif; ?><?php if(!empty($pending['field_id'])):?><div><span>Schlag</span><strong><?=h(fieldName((int)$pending['field_id']))?></strong></div><?php endif; ?><?php if(!empty($pending['customer_id'])):?><div><span>Kunde</span><strong><?=h(customerName((int)$pending['customer_id']))?></strong></div><?php endif; ?><?php if(!empty($pending['product_id'])):?><div><span>Produkt</span><strong><?=h(productName((int)$pending['product_id']))?></strong></div><?php endif; ?></div>
  <p class="muted">Sobald das Fahrzeug vollständig auf der Waage steht und das Gewicht stabil ist, kann das Zweitgewicht übernommen werden.</p>
  <form method="post"><input type="hidden" name="action" value="second"><label>Notizen (optional)</label><textarea name="notes" placeholder="z. B. Besonderheiten zur Wiegung"></textarea><p><button class="button primary large-button">Zweitgewicht übernehmen &amp; Wiegeschein erzeugen</button></p></form>
<?php else: ?>
  <div class="eyebrow">NEUE WIEGUNG</div><h2>Wiegung starten</h2>
  <p class="muted">Wähle bei Bedarf ein Fahrzeug. Kunde, Produkt und Schlag können optional ergänzt werden.</p>
  <form method="get" class="select-row"><div class="full"><label>Fahrzeug</label><select name="vehicle_id"><option value="">Kein Fahrzeug</option><?php foreach($vehicles as $v): ?><option value="<?=$v['id']?>" <?=$selected===(int)$v['id']?'selected':''?>><?=h($v['plate'].' – '.$v['name'].' · Erstgewicht: '.formatWeight((float)$v['first_weight']).' kg')?></option><?php endforeach; ?></select></div><button class="button">Fahrzeug auswählen</button></form>
  <form method="post"><input type="hidden" name="vehicle_id" value="<?=$vehicle?(int)$vehicle['id']:0?>"><div class="form-grid"><div><label>Kunde (optional)</label><select name="customer_id"><option value="0">Kein Kunde</option><?php foreach($customers as $c): ?><option value="<?=$c['id']?>" <?=$selectedCustomer===(int)$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach; ?></select></div><div><label>Produkt (optional)</label><select name="product_id"><option value="0">Kein Produkt</option><?php foreach($products as $pr): ?><option value="<?=$pr['id']?>" <?=$selectedProduct===(int)$pr['id']?'selected':''?>><?=h($pr['name'])?></option><?php endforeach; ?></select></div><div class="full"><label>Schlag (optional)</label><select name="field_id"><option value="0">Kein Schlag</option><?php foreach($fields as $f): ?><option value="<?=$f['id']?>" <?=$selectedField===(int)$f['id']?'selected':''?>><?=h($f['name'].(!empty($f['crop'])?' – '.$f['crop']:'').(!empty($f['year'])?' ('.$f['year'].')':''))?></option><?php endforeach; ?></select></div></div><div class="button-row weighing-actions">
  <?php if($vehicle): ?><button class="button primary large-button" name="action" value="first">1. Gewicht wiegen &amp; speichern</button><?php if((float)$vehicle['first_weight']>0): ?><button class="button large-button" name="action" value="use_saved">Gespeichertes 1. Gewicht verwenden</button><?php endif; ?><?php else: ?><button class="button primary large-button" name="action" value="start_unassigned">1. Gewicht speichern</button><?php endif; ?>
  </div></form>
<?php endif; ?>
</section></div>
<?php if (demoMode()): ?>
<div class="card test-weight-card">
  <div class="eyebrow">TESTBETRIEB OHNE WAAGENCOMPUTER</div>
  <h2>Testgewicht setzen</h2>
  <p class="muted">Nur solange die Dini-Waage nicht aktiviert ist. Das Testgewicht wird wie ein echtes Waagengewicht verwendet, damit Wiegungen vorab geprüft werden können.</p>
  <form method="post" class="test-weight-form">
    <input type="hidden" name="action" value="set_test_weight">
    <div><label>Testgewicht (kg)</label><input type="number" name="test_weight" step="0.1" min="0" value="<?=h(number_format($testWeightValue,0,'.',''))?>" placeholder="z. B. 12500"></div>
    <button class="button primary">Testgewicht setzen</button>
  </form>
  <div class="actions"><form method="post"><input type="hidden" name="action" value="clear_test_weight"><button class="button">Testgewicht löschen</button></form></div>
  <p class="muted">Aktuell simuliert: <strong><?=formatScaleWeight($testWeightValue)?> kg</strong></p>
</div>
<?php endif; ?>
<script src="assets/app.js"></script>
<script>
window.pendingKey=<?=json_encode($pending ? ($pending['started_at'].'|'.($pending['remote_id']??0).'|'.($pending['vehicle_id']??0)) : null)?>;
window.pendingFirstWeight=<?=json_encode($pending ? (float)$pending['first_weight'] : 0)?>;
let autoFinishTimer=null;
let autoFinishing=false;

async function pollPendingState(){
  try{
    const r=await fetch('api/pending.php',{cache:'no-store'});
    const d=await r.json();
    if(d.key!==window.pendingKey && !autoFinishing) location.reload();
  }catch(e){}
}

async function pollTestWeight(){
  if(!window.pendingKey || autoFinishing) return;
  try{
    const r=await fetch('api/status.php',{cache:'no-store'});
    const d=await r.json();
    const w=Number(d.weight)||0;
    // Im Testbetrieb simuliert ein neues, vom 1. Gewicht abweichendes
    // Testgewicht das fertige Gesamtgewicht der dynamischen Waage.
    if(w>0 && Math.abs(w-Number(window.pendingFirstWeight))>0.05 && !autoFinishTimer){
      autoFinishTimer=setTimeout(()=>{
        autoFinishTimer=null;
        finishTestWeighing();
      },1000);
    }
    if((w<=0 || Math.abs(w-Number(window.pendingFirstWeight))<=0.05) && autoFinishTimer){
      clearTimeout(autoFinishTimer);
      autoFinishTimer=null;
    }
  }catch(e){}
}

function finishTestWeighing(){
  if(autoFinishing) return;
  autoFinishing=true;
  const form=document.getElementById('autoFinishForm');
  if(form) form.submit();
}

<?php if($autoDemoFinish): ?>
setInterval(pollTestWeight,500);
<?php endif; ?>
setInterval(pollPendingState,3000);
</script>
<?php if($autoDemoFinish): ?>
<form id="autoFinishForm" method="post" style="display:none"><input type="hidden" name="action" value="second"></form>
<?php endif; ?>
<?php layoutEnd(); ?>
