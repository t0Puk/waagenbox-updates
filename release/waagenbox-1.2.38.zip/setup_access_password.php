<?php
require_once __DIR__.'/functions.php';
if (accessPasswordConfigured()) redirect('login.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $password=(string)($_POST['password']??'');
    $confirm=(string)($_POST['confirm_password']??'');
    try {
        if (strlen($password)<4) throw new RuntimeException('Das Passwort muss mindestens 4 Zeichen lang sein.');
        if ($password!==$confirm) throw new RuntimeException('Die Passwörter stimmen nicht überein.');
        saveAccessPasswordHash(password_hash($password,PASSWORD_DEFAULT));
        $_SESSION['waage_access_authenticated']=1;
        $_SESSION['waage_last_activity']=time();
        session_regenerate_id(true);
        redirect('index.php');
    } catch(Throwable $e) { $error=$e->getMessage(); }
}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Zugang einrichten – AJP Waage</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page">
<div class="login-card card"><div class="brand">AJPnaturenergie</div><div class="sub">AJP Waagensteuerung</div><h1>Zugang schützen</h1>
<p>Für den Zugriff über das Netzwerk muss einmalig ein Passwort festgelegt werden. Der direkte Zugriff über localhost bleibt ohne Passwort möglich.</p>
<?php if($error): ?><div class="flash error"><?=h($error)?></div><?php endif; ?>
<form method="post"><label>Neues Passwort</label><input type="password" name="password" minlength="4" autocomplete="new-password" autofocus required><label style="margin-top:14px">Passwort wiederholen</label><input type="password" name="confirm_password" minlength="4" autocomplete="new-password" required><p><button class="button primary" style="width:100%">Passwort festlegen</button></p></form></div></body></html>
