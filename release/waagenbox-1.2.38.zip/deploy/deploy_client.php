<?php
declare(strict_types=1);

/*
 * Unprivilegierte Brücke zwischen Waagenbox-Webanwendung und
 * privilegiertem Deployment-Helfer.
 *
 * Diese Datei führt selbst keinerlei Dateioperationen unter /var/www/waage
 * mit Root-Rechten aus.
 */

function waagenboxDeployStorageRoot(): string
{
    $test = getenv('WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE');

    if (
        is_string($test) &&
        $test !== '' &&
        preg_match(
            '~^/tmp/waagenbox_deploy_bridge_test_[A-Za-z0-9._-]+(?:/.*)?$~',
            $test
        ) === 1
    ) {
        return rtrim($test, '/');
    }

    return '/var/lib/waagebox/deploy';
}

function waagenboxDeployHelperCommand(): array
{
    $test = getenv('WAAGEBOX_DEPLOY_CLIENT_TEST_HELPER');

    if (
        is_string($test) &&
        $test !== '' &&
        preg_match(
            '~^/tmp/waagenbox_deploy_bridge_test_[A-Za-z0-9._/-]+$~',
            $test
        ) === 1
    ) {
        return [
            '/usr/bin/sudo',
            '-n',
            $test,
        ];
    }

    return [
        '/usr/bin/sudo',
        '-n',
        '/usr/local/sbin/waagenbox-deploy-helper',
    ];
}

function waagenboxDeployEnsureDirectory(
    string $path,
    int $mode = 0750
): void {
    if (is_link($path)) {
        throw new RuntimeException(
            'Deployment-Verzeichnis darf kein Symlink sein: '.$path
        );
    }

    if (!is_dir($path) && !mkdir($path, $mode, true)) {
        throw new RuntimeException(
            'Deployment-Verzeichnis konnte nicht angelegt werden: '.$path
        );
    }

    if (!is_dir($path) || !is_writable($path)) {
        throw new RuntimeException(
            'Deployment-Verzeichnis ist nicht beschreibbar: '.$path
        );
    }
}

function waagenboxDeployAtomicWrite(
    string $file,
    string $contents,
    int $mode = 0640
): void {
    $directory = dirname($file);

    waagenboxDeployEnsureDirectory($directory);

    if (is_link($file)) {
        throw new RuntimeException(
            'Deployment-Datei darf kein Symlink sein: '.$file
        );
    }

    $tmp = $directory.'/.'.basename($file).
        '.new.'.bin2hex(random_bytes(8));

    $handle = fopen($tmp, 'xb');

    if (!is_resource($handle)) {
        throw new RuntimeException(
            'Temporäre Deployment-Datei konnte nicht angelegt werden.'
        );
    }

    try {
        $written = fwrite($handle, $contents);

        if ($written !== strlen($contents)) {
            throw new RuntimeException(
                'Deployment-Datei konnte nicht vollständig geschrieben werden.'
            );
        }

        if (
            function_exists('fsync') &&
            !fsync($handle)
        ) {
            throw new RuntimeException(
                'Deployment-Datei konnte nicht synchronisiert werden.'
            );
        }
    } finally {
        fclose($handle);
    }

    chmod($tmp, $mode);

    if (!rename($tmp, $file)) {
        @unlink($tmp);

        throw new RuntimeException(
            'Deployment-Datei konnte nicht atomar aktiviert werden.'
        );
    }
}

function waagenboxDeployCopyRegularFile(
    string $source,
    string $target,
    int $mode = 0640
): void {
    if (!is_file($source) || is_link($source)) {
        throw new RuntimeException(
            'Ungültige Deployment-Quelldatei: '.$source
        );
    }

    $input = fopen($source, 'rb');

    if (!is_resource($input)) {
        throw new RuntimeException(
            'Deployment-Quelldatei konnte nicht gelesen werden.'
        );
    }

    $directory = dirname($target);

    waagenboxDeployEnsureDirectory($directory);

    $tmp = $directory.'/.'.basename($target).
        '.new.'.bin2hex(random_bytes(8));

    $output = fopen($tmp, 'xb');

    if (!is_resource($output)) {
        fclose($input);

        throw new RuntimeException(
            'Deployment-Zieldatei konnte nicht angelegt werden.'
        );
    }

    try {
        while (!feof($input)) {
            $data = fread($input, 1024 * 1024);

            if ($data === false) {
                throw new RuntimeException(
                    'Deployment-Quelldatei konnte nicht vollständig gelesen werden.'
                );
            }

            if (
                $data !== '' &&
                fwrite($output, $data) !== strlen($data)
            ) {
                throw new RuntimeException(
                    'Deployment-Zieldatei konnte nicht vollständig geschrieben werden.'
                );
            }
        }

        if (
            function_exists('fsync') &&
            !fsync($output)
        ) {
            throw new RuntimeException(
                'Deployment-Zieldatei konnte nicht synchronisiert werden.'
            );
        }
    } finally {
        fclose($input);
        fclose($output);
    }

    chmod($tmp, $mode);

    if (!rename($tmp, $target)) {
        @unlink($tmp);

        throw new RuntimeException(
            'Deployment-Zieldatei konnte nicht atomar aktiviert werden.'
        );
    }
}

function waagenboxDeployRunHelper(): array
{
    $command = waagenboxDeployHelperCommand();

    $process = proc_open(
        $command,
        [
            0 => ['file', '/dev/null', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ],
        $pipes,
        null,
        null,
        ['bypass_shell' => true]
    );

    if (!is_resource($process)) {
        throw new RuntimeException(
            'Deployment-Helfer konnte nicht gestartet werden.'
        );
    }

    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);

    fclose($pipes[1]);
    fclose($pipes[2]);

    $code = proc_close($process);

    if ($code !== 0) {
        $detail = trim((string)$stderr);

        if ($detail === '') {
            $detail = trim((string)$stdout);
        }

        throw new RuntimeException(
            'Privilegiertes Deployment fehlgeschlagen'.
            ($detail !== '' ? ': '.$detail : '.')
        );
    }

    try {
        $result = json_decode(
            (string)$stdout,
            true,
            32,
            JSON_THROW_ON_ERROR
        );
    } catch (Throwable $e) {
        throw new RuntimeException(
            'Deployment-Helfer lieferte keine gültige Antwort.'
        );
    }

    if (
        !is_array($result) ||
        ($result['ok'] ?? false) !== true
    ) {
        throw new RuntimeException(
            'Deployment-Helfer meldete keinen erfolgreichen Abschluss.'
        );
    }

    return $result;
}

function waagenboxDeployPrepareInstall(
    string $package,
    string $version,
    string $sha256,
    string $signature
): void {
    if (
        preg_match('/^\d+\.\d+\.\d+$/', $version) !== 1
    ) {
        throw new RuntimeException(
            'Ungültige Deployment-Version.'
        );
    }

    if (
        preg_match('/^[a-f0-9]{64}$/i', $sha256) !== 1
    ) {
        throw new RuntimeException(
            'Ungültige Deployment-Prüfsumme.'
        );
    }

    if ($signature === '') {
        throw new RuntimeException(
            'Deployment-Signatur fehlt.'
        );
    }

    $actual = hash_file('sha256', $package);

    if (
        !is_string($actual) ||
        !hash_equals(strtolower($sha256), strtolower($actual))
    ) {
        throw new RuntimeException(
            'Updatepaket stimmt nicht mit der erwarteten Prüfsumme überein.'
        );
    }

    $root = waagenboxDeployStorageRoot();
    $pending = $root.'/pending';

    waagenboxDeployEnsureDirectory($root);
    waagenboxDeployEnsureDirectory($pending);

    waagenboxDeployCopyRegularFile(
        $package,
        $pending.'/package.zip',
        0640
    );

    /*
     * Dieses exakte Format wird vom Release-Server signiert.
     * Keine zusätzlichen Felder und keine Neuordnung.
     */
    $signedManifest = json_encode(
        [
            'version' => $version,
            'package_sha256' => strtolower($sha256),
        ],
        JSON_UNESCAPED_SLASHES |
        JSON_THROW_ON_ERROR
    )."\n";

    waagenboxDeployAtomicWrite(
        $pending.'/manifest.json',
        $signedManifest,
        0640
    );

    waagenboxDeployAtomicWrite(
        $pending.'/manifest.sig',
        $signature,
        0640
    );

    waagenboxDeployAtomicWrite(
        $root.'/request.json',
        json_encode(
            ['action' => 'install'],
            JSON_UNESCAPED_SLASHES |
            JSON_THROW_ON_ERROR
        )."\n",
        0640
    );
}

function waagenboxDeployInstall(
    string $package,
    string $version,
    string $sha256,
    string $signature
): array {
    waagenboxDeployPrepareInstall(
        $package,
        $version,
        $sha256,
        $signature
    );

    $result = waagenboxDeployRunHelper();

    if (
        ($result['action'] ?? null) !== 'install' ||
        ($result['version'] ?? null) !== $version ||
        !is_string($result['snapshot_id'] ?? null) ||
        preg_match(
            '/^[a-f0-9]{32}$/',
            $result['snapshot_id']
        ) !== 1
    ) {
        throw new RuntimeException(
            'Deployment-Helfer lieferte eine ungültige Installationsantwort.'
        );
    }

    return $result;
}

function waagenboxDeploySnapshot(): array
{
    $root = waagenboxDeployStorageRoot();

    waagenboxDeployEnsureDirectory($root);

    waagenboxDeployAtomicWrite(
        $root.'/request.json',
        json_encode(
            ['action' => 'snapshot'],
            JSON_UNESCAPED_SLASHES |
            JSON_THROW_ON_ERROR
        )."\n",
        0640
    );

    $result = waagenboxDeployRunHelper();

    if (
        ($result['action'] ?? null) !== 'snapshot' ||
        !is_string($result['snapshot_id'] ?? null) ||
        preg_match(
            '/^[a-f0-9]{32}$/',
            $result['snapshot_id']
        ) !== 1
    ) {
        throw new RuntimeException(
            'Deployment-Helfer lieferte eine ungültige Snapshot-Antwort.'
        );
    }

    return $result;
}

function waagenboxDeployRestore(
    string $snapshotId
): array {
    if (
        preg_match('/^[a-f0-9]{32}$/', $snapshotId) !== 1
    ) {
        throw new RuntimeException(
            'Ungültige Deployment-Snapshot-ID.'
        );
    }

    $root = waagenboxDeployStorageRoot();

    waagenboxDeployEnsureDirectory($root);

    waagenboxDeployAtomicWrite(
        $root.'/request.json',
        json_encode(
            [
                'action' => 'restore',
                'snapshot_id' => $snapshotId,
            ],
            JSON_UNESCAPED_SLASHES |
            JSON_THROW_ON_ERROR
        )."\n",
        0640
    );

    $result = waagenboxDeployRunHelper();

    if (
        ($result['action'] ?? null) !== 'restore' ||
        ($result['snapshot_id'] ?? null) !== $snapshotId
    ) {
        throw new RuntimeException(
            'Deployment-Helfer lieferte eine ungültige Rollback-Antwort.'
        );
    }

    return $result;
}
