<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false]);exit;}
requireCsrfToken();
$v=trim((string)($_POST['version']??''));
if($v===''||!preg_match('/^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$/',$v)){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültige Versionsnummer.']);exit;}
setUpdateIgnoredVersion($v); echo json_encode(['ok'=>true]);
