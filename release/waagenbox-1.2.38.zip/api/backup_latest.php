<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
require_once __DIR__.'/../backup_download.php';
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
try {
    $backup = openLatestAutomaticBackup('/var/backups/waagenbox');
} catch (Throwable $e) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Kein lesbares automatisches Waagenbox-Backup vorhanden. Bitte Sicherung und Leserechte prüfen.');
}
header('Content-Type: application/gzip');
header('Content-Disposition: attachment; filename="'.$backup['name'].'"');
header('Content-Length: '.$backup['size']);
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
fpassthru($backup['stream']);
fclose($backup['stream']);
