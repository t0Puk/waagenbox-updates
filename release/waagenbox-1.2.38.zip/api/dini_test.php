<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
require_once __DIR__.'/../hardware/dini_diagnostics.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$action = (string)($_GET['action'] ?? 'weight');
if (!array_key_exists($action, diniDiagnosticActions())) {
    http_response_code(400);
    exit(json_encode(['ok'=>false, 'error'=>'Unzulässige Diagnoseaktion.']));
}

try {
    $dini = dini();
    if ($dini === null) {
        echo json_encode(['ok'=>false, 'state'=>'disabled', 'error'=>'Dini ist deaktiviert oder im Demo-Modus.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $result = diniDiagnosticRead($dini, $action);
    echo json_encode(['ok' => true, 'action' => $action, 'result' => $result], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => 'Dini nicht erreichbar oder keine gültige Antwort. Bitte Verbindung und Einstellungen prüfen.',
    ], JSON_UNESCAPED_UNICODE);
}
