<?php
require_once __DIR__.'/../functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
if (passwordProtectionRequired() && !isAccessAuthenticated()) { http_response_code(401); exit; }
requireCsrfToken();
if (passwordProtectionRequired() && ($_POST['active'] ?? '') === '1') $_SESSION['waage_last_activity'] = time();
http_response_code(204);
