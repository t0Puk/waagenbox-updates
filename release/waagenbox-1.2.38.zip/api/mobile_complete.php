<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
function mi2():array{$d=json_decode(file_get_contents('php://input'),true);return is_array($d)?$d:$_POST;}
$d=mi2();
$token=trim((string)($d['token']??''));
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger QR-Code.']);exit;}
if(useMobileContextByToken($token)===null){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Ungültiger QR-Code.']);exit;}
$pdo=db();
$s=$pdo->prepare('SELECT r.id,r.active,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.mobile_token=? LIMIT 1');
$s->execute([currentOwnerId(),$token]);$r=$s->fetch();
if(!$r||(int)$r['active']!==1||(int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Fernbedienung oder Fahrzeug ist nicht aktiv.']);exit;}
$p=pendingWeighing();
if(!$p||(int)($p['remote_id']??0)!==(int)$r['id']){http_response_code(409);echo json_encode(['ok'=>false,'message'=>'Für diese Fernbedienung läuft keine Wiegung.']);exit;}
$weight=currentWeight();
if($weight<=0){http_response_code(409);echo json_encode(['ok'=>false,'message'=>'Es wurde noch kein aktuelles Gewicht erkannt.']);exit;}
try{
  $id=completePendingWeighing($weight);
  echo json_encode(['ok'=>true,'id'=>$id,'second_weight'=>$weight,'net_weight'=>$weight-(float)$p['first_weight'],'message'=>'Wiegung abgeschlossen.']);
}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);}
