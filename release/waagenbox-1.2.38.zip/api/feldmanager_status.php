<?php
declare(strict_types=1);
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');

$expected=trim(appSetting('feldmanager_api_token',''));
$provided=trim((string)($_SERVER['HTTP_X_AJP_FELDMANAGER_TOKEN']??''));

if($expected===''||strlen($expected)<24){
    http_response_code(503);
    echo json_encode(['ok'=>false,'error'=>'integration_not_configured'],JSON_UNESCAPED_UNICODE);
    exit;
}
if($provided===''||!hash_equals($expected,$provided)){
    http_response_code(401);
    echo json_encode(['ok'=>false,'error'=>'unauthorized'],JSON_UNESCAPED_UNICODE);
    exit;
}

$requestedTeam=max(0,(int)($_GET['team_number']??0));
$teamMap=feldmanagerRemoteTeamMap();
$configuredTeams=array_values(array_unique(array_map('intval',array_values($teamMap))));
sort($configuredTeams,SORT_NUMERIC);

echo json_encode([
    'ok'=>true,
    'integration_enabled'=>feldmanagerEnabled(),
    'team_numbers'=>$configuredTeams,
    'team_source'=>'remotes',
    'requested_team_number'=>$requestedTeam?:null,
    'team_matches'=>$requestedTeam<=0||in_array($requestedTeam,$configuredTeams,true),
    'version'=>APP_VERSION,
    'server_time'=>date(DATE_ATOM),
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
