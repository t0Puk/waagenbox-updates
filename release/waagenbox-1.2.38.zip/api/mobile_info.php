<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
$token=trim((string)($_GET['t']??''));
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
if(useMobileContextByToken($token)===null){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
$s=db()->prepare('SELECT r.id,r.active,r.vehicle_id,v.plate,v.name AS vehicle_name,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.mobile_token=? LIMIT 1');$s->execute([currentOwnerId(),$token]);$r=$s->fetch();
if(!$r || (int)$r['active']!==1 || (int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Diese mobile Fernbedienung ist nicht aktiv.']);exit;}
$html='';
if(!empty($r['vehicle_id'])) $html.='<div><strong>Fahrzeug:</strong> '.h(trim(($r['plate']??'').' – '.($r['vehicle_name']??''),' –')).'</div>';
foreach([['remote_fields','field_id','Schlag','fields'],['remote_customers','customer_id','Kunde','customers'],['remote_products','product_id','Produkt','products']] as [$table,$col,$label,$lookup]){
 $q=db()->prepare("SELECT x.$col, x.is_default, t.name FROM $table x JOIN `$lookup` t ON t.id=x.$col AND t.owner_user_id=x.owner_user_id WHERE x.owner_user_id=? AND x.remote_id=? AND x.active=1 ORDER BY x.is_default DESC,t.name");$q->execute([currentOwnerId(),(int)$r['id']]);$items=$q->fetchAll();
 if($items){$chosen=$items[0];$names=[];foreach($items as $it)$names[]=$it['name'];$html.='<div><strong>'.h($label).':</strong> '.h($chosen['name']);if(count($items)>1)$html.=' <span class="muted">('.count($items).' zugeordnet)</span>'; $html.='</div>';}
}
if($html==='')$html='<div>Keine zusätzlichen Zuordnungen hinterlegt.</div>';
echo json_encode(['ok'=>true,'html'=>$html],JSON_UNESCAPED_UNICODE);
