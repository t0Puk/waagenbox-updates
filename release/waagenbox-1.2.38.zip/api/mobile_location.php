<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
function jsonInput(): array { $raw=file_get_contents('php://input'); $d=json_decode($raw,true); return is_array($d)?$d:$_POST; }
function getSettingForOwner(PDO $pdo,int $ownerId,string $key,string $default=''): string { $s=$pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');$s->execute([$ownerId,$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v; }
function distanceMeters(float $lat1,float $lon1,float $lat2,float $lon2): float { $r=6371000.0;$p1=deg2rad($lat1);$p2=deg2rad($lat2);$dp=deg2rad($lat2-$lat1);$dl=deg2rad($lon2-$lon1);$a=sin($dp/2)**2+cos($p1)*cos($p2)*sin($dl/2)**2;return 2*$r*asin(min(1,sqrt($a))); }
$d=jsonInput();$token=trim((string)($d['token']??''));$lat=(float)($d['latitude']??0);$lon=(float)($d['longitude']??0);$accuracy=(float)($d['accuracy']??99999);
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
$pdo=db();$s=$pdo->prepare('SELECT r.id,r.owner_user_id,r.active,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id WHERE r.mobile_token=? LIMIT 1');$s->execute([$token]);$r=$s->fetch();
if(!$r || (int)$r['active']!==1 || (int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Fernbedienung oder Fahrzeug ist nicht aktiv.']);exit;}
$ownerId=(int)$r['owner_user_id'];
if(getSettingForOwner($pdo,$ownerId,'gps_enabled','0')!=='1'){echo json_encode(['ok'=>true,'distance_m'=>0,'message'=>'GPS-Prüfung ist deaktiviert.']);exit;}
if($lat<-90||$lat>90||$lon<-180||$lon>180){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültige Standortdaten.']);exit;}
$waageLat=(float)getSettingForOwner($pdo,$ownerId,'gps_lat','0');$waageLon=(float)getSettingForOwner($pdo,$ownerId,'gps_lon','0');$radius=max(1,(float)getSettingForOwner($pdo,$ownerId,'gps_radius_m','50'));$maxAcc=max(1,(float)getSettingForOwner($pdo,$ownerId,'gps_accuracy_m','50'));
if(getSettingForOwner($pdo,$ownerId,'gps_lat','')===''||getSettingForOwner($pdo,$ownerId,'gps_lon','')===''){http_response_code(503);echo json_encode(['ok'=>false,'message'=>'Der Standort der Waage ist noch nicht konfiguriert.']);exit;}
$dist=distanceMeters($lat,$lon,$waageLat,$waageLon);
if($accuracy>$maxAcc){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'GPS-Genauigkeit zu schlecht (ca. '.round($accuracy).' m). Bitte freien Himmel/Standortzugriff prüfen.','distance_m'=>$dist]);exit;}
if($dist>$radius){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Du bist zu weit von der Waage entfernt (ca. '.round($dist).' m).','distance_m'=>$dist]);exit;}
echo json_encode(['ok'=>true,'distance_m'=>$dist,'message'=>'Standort bestätigt.']);
