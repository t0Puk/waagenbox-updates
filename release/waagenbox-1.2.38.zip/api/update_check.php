<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');

$force = isset($_GET['force']) && $_GET['force'] === '1';
$last = appSetting('update_last_check','');
$snoozedUntil = updateSnoozedUntil();
$cached = appSetting('update_manifest_cache','');
$now = time();
$lastTs = $last !== '' ? strtotime($last) : 0;

if (!$force && $lastTs > 0 && ($now - $lastTs) < 21600 && $cached !== '') {
    $data = json_decode($cached, true);
    if (is_array($data)) { echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
}

$url = updateCheckUrl();
$body = false;
$err = '';
$code = 0;

// Primär per cURL. Falls cURL auf dem Hosting eingeschränkt ist,
// wird auf HTTPS über PHP-Streams zurückgefallen.
if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
        CURLOPT_USERAGENT => 'AJP-Waagenbox/'.APP_VERSION,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
}

if ($body === false && function_exists('file_get_contents')) {
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 12,
            'header' => "Accept: application/json\r\nUser-Agent: AJP-Waagenbox/".APP_VERSION."\r\n",
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    if ($body !== false) {
        if (!empty($http_response_header[0]) && preg_match('~\s(\d{3})\s~', $http_response_header[0], $m)) $code = (int)$m[1];
        $err = '';
    }
}

$checkedAt=date('Y-m-d H:i:s');
$result = ['ok'=>false,'current_version'=>APP_VERSION,'update_available'=>false,'ignored'=>false,'checked_at'=>$checkedAt,'message'=>'Update-Prüfung konnte nicht durchgeführt werden.'];
if ($body === false || $code < 200 || $code >= 300) {
    $result['message'] = 'Update-Server nicht erreichbar.'.($err !== '' ? ' '.$err : '').($code ? ' HTTP '.$code : '');
    saveAppSetting('update_last_check', date('Y-m-d H:i:s'));
    echo json_encode($result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
$manifest = json_decode($body, true);
if (!is_array($manifest) || empty($manifest['version']) || empty($manifest['download_url']) || empty($manifest['sha256'])) {
    $result['message'] = 'Das Update-Manifest ist ungültig.';
    saveAppSetting('update_last_check', date('Y-m-d H:i:s'));
    echo json_encode($result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}

$result = [
    'ok'=>true,
    'current_version'=>APP_VERSION,
    'update_available'=>compareAppVersions((string)$manifest['version'], APP_VERSION) > 0,
    'ignored'=>((string)$manifest['version'] === updateIgnoredVersion() && empty($manifest['mandatory'])),
    'snoozed'=>($snoozedUntil!=='' && strtotime($snoozedUntil)>time()),
    'version'=>(string)$manifest['version'],
    'download_url'=>(string)$manifest['download_url'],
    'sha256'=>strtolower((string)$manifest['sha256']),
    'mandatory'=>!empty($manifest['mandatory']),
    'release_date'=>(string)($manifest['release_date'] ?? ''),
    'message'=>(string)($manifest['message'] ?? 'Neue Version verfügbar.'),
    'checked_at'=>$checkedAt,
];
saveAppSetting('update_last_check', date('Y-m-d H:i:s'));
saveAppSetting('update_manifest_cache', json_encode($result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
echo json_encode($result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
