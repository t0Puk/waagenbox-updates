<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');

if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false,'message'=>'Nur POST ist erlaubt.']);exit;}
if(empty($_POST['confirm_restore']) || $_POST['confirm_restore']!=='1'){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Bitte die Wiederherstellung ausdrücklich bestätigen.']);exit;}
if(empty($_FILES['backup_file']) || $_FILES['backup_file']['error']!==UPLOAD_ERR_OK){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Bitte eine gültige SQL- oder SQL.GZ-Backupdatei auswählen.']);exit;}
$f=$_FILES['backup_file'];
$name=(string)$f['name'];
if(!preg_match('/\.(sql|sql\.gz)$/i',$name)){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Erlaubt sind nur .sql und .sql.gz Dateien.']);exit;}
$data=file_get_contents($f['tmp_name']);
if($data===false || $data===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Die Backupdatei ist leer oder konnte nicht gelesen werden.']);exit;}
if(preg_match('/\.gz$/i',$name)){
    $decoded=@gzdecode($data);
    if($decoded===false){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Die GZIP-Datei konnte nicht entpackt werden.']);exit;}
    $data=$decoded;
}
if(strlen($data)>50*1024*1024){http_response_code(413);echo json_encode(['ok'=>false,'message'=>'Die Backupdatei ist für die Web-Wiederherstellung zu groß (max. 50 MB).']);exit;}

function splitSqlStatements(string $sql): array {
    $sql=preg_replace('/^\xEF\xBB\xBF/','',$sql);
    $statements=[];$buf='';$len=strlen($sql);$quote=null;$lineComment=false;$blockComment=false;
    for($i=0;$i<$len;$i++){
        $c=$sql[$i];$n=$i+1<$len?$sql[$i+1]:'';
        if($lineComment){$buf.=$c;if($c==="\n")$lineComment=false;continue;}
        if($blockComment){$buf.=$c;if($c==='*'&&$n==='/'){$buf.=$n;$i++;$blockComment=false;}continue;}
        if($quote!==null){
            $buf.=$c;
            if($c==='\\'&&$i+1<$len){$buf.=$sql[++$i];continue;}
            if($c===$quote){
                if($i+1<$len&&$sql[$i+1]===$quote){$buf.=$sql[++$i];}
                else{$quote=null;}
            }
            continue;
        }
        if($c==='\''||$c==='"'||$c==='`'){$quote=$c;$buf.=$c;continue;}
        if($c==='#'){$lineComment=true;$buf.=$c;continue;}
        if($c==='-'&&$n==='-'&&($i+2>=$len||ctype_space($sql[$i+2]))){$lineComment=true;$buf.=$c.$n;$i++;continue;}
        if($c==='/'&&$n==='*'){$blockComment=true;$buf.=$c.$n;$i++;continue;}
        if($c===';'){$s=trim($buf);if($s!=='')$statements[]=$s;$buf='';continue;}
        $buf.=$c;
    }
    $s=trim($buf);if($s!=='')$statements[]=$s;return $statements;
}

$statements=splitSqlStatements($data);
if(!$statements){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Keine SQL-Anweisungen gefunden.']);exit;}
$pdo=db();
try{
    // Backups der Webanwendung können unter unterschiedlichen SQL_MODE-Einstellungen
    // entstehen. Für die Wiederherstellung verwenden wir Standard-Stringquoting.
    $pdo->exec("SET SESSION sql_mode = REPLACE(@@sql_mode, 'NO_BACKSLASH_ESCAPES', '')");
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    foreach($statements as $sql){
        $trim=ltrim($sql);
        if($trim==='') continue;
        // Transaktionsbefehle aus dem Backup nicht separat ausführen: DROP TABLE verursacht
        // ohnehin implizite Commits. Die Wiederherstellung wird deshalb als SQL-Skript ausgeführt.
        if(preg_match('/^(START\s+TRANSACTION|BEGIN|COMMIT|ROLLBACK)\b/i',$trim)) continue;
        $pdo->exec($sql);
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    echo json_encode(['ok'=>true,'message'=>'Backup wurde erfolgreich wiederhergestellt. Die Seite wird neu geladen.']);
}catch(Throwable $e){
    try{$pdo->exec('SET FOREIGN_KEY_CHECKS=1');}catch(Throwable $ignore){}
    http_response_code(500);echo json_encode(['ok'=>false,'message'=>'Wiederherstellung fehlgeschlagen: '.$e->getMessage()]);
}
