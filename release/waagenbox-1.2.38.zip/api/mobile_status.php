<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
$token=trim((string)($_GET['t']??''));
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
if(useMobileContextByToken($token)===null){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
$pdo=db();
function getMobileSetting(PDO $pdo,int $ownerId,string $key,string $default=''): string { $q=$pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1'); $q->execute([$ownerId,$key]); $v=$q->fetchColumn(); return $v===false?$default:(string)$v; }
$s=$pdo->prepare('SELECT r.id,r.active,r.vehicle_id,v.first_weight,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.mobile_token=? LIMIT 1');
$s->execute([currentOwnerId(),$token]);$r=$s->fetch();
if(!$r||(int)$r['active']!==1||(int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Diese mobile Fernbedienung ist nicht aktiv.']);exit;}
$p=pendingWeighing();
$pendingForThis=$p && (int)($p['remote_id']??0)===(int)$r['id'];
echo json_encode(['ok'=>true,'current_weight'=>currentWeight(),'pending'=>$pendingForThis,'pending_mode'=>$pendingForThis && (($p['trigger_type']??'')==='mobile_first_weight')?'first_weight':'weighing','gps_enabled'=>getMobileSetting($pdo,(int)$r['owner_user_id'],'gps_enabled','0')==='1','first_weight'=>$pendingForThis?(float)$p['first_weight']:(float)$r['first_weight'],'vehicle_first_weight'=>(float)$r['first_weight']],JSON_UNESCAPED_UNICODE);
