<?php
require_once __DIR__.'/../functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Nur POST ist erlaubt.'); }
$weight=max(0.0,(float)str_replace(',','.',(string)($_POST['weight']??'0')));
try {
    setTestWeight($weight);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Testgewicht konnte nicht gespeichert werden.');
}
$return=(string)($_POST['return']??'../index.php');
// Nur lokale PHP-Ziele zulassen; Standardziel ist das Dashboard und nicht /api/index.php.
if($return==='' || str_contains($return,'..') || preg_match('/^(?:[a-zA-Z0-9_\/-]+\.php)(?:\?[^#]*)?$/',$return)!==1){
    $return='../index.php';
}
redirect($return);
