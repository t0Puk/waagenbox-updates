-- AJP Waagenbox WEB-Entwicklungsstand v1.2.3
-- Migriert die bestehende Web-Demo-Datenbank auf das owner_user_id-Schema der aktuellen Pi-Version.
-- Vorhandene Daten werden dem automatisch angelegten Administrator zugeordnet.
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL,
  display_name VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','demo') NOT NULL DEFAULT 'demo',
  active TINYINT(1) NOT NULL DEFAULT 1,
  expires_at DATETIME NULL,
  force_password_change TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  KEY idx_users_role (role),
  KEY idx_users_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users (username,display_name,password_hash,role,active,expires_at,force_password_change)
SELECT 'admin','AJP Administrator','$2y$12$/3DTsNxXqyxy2Bj5tIrhROW5OF80i/GKudy6LtpoVNn1.foaTetZG','admin',1,NULL,1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='admin');

ALTER TABLE settings ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE fields ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remotes ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE products ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE weighings ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE weighing_state ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_fields ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_customers ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_products ADD COLUMN IF NOT EXISTS owner_user_id INT UNSIGNED NULL FIRST;

SET @admin_id := (SELECT id FROM users WHERE username='admin' LIMIT 1);

UPDATE settings SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE vehicles SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE fields SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remotes SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE customers SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE products SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE weighings SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE weighing_state SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_fields SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_customers SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_products SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;

ALTER TABLE settings MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE vehicles MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE fields MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remotes MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE customers MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE products MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE weighings MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE weighing_state MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_fields MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_customers MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_products MODIFY owner_user_id INT UNSIGNED NOT NULL;

ALTER TABLE settings DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,`key`), ADD KEY idx_settings_key(`key`);
ALTER TABLE vehicles DROP INDEX uq_vehicle_plate, ADD UNIQUE KEY uq_vehicle_owner_plate(owner_user_id,plate);
ALTER TABLE remotes DROP INDEX uq_remote_code, ADD UNIQUE KEY uq_remote_owner_code(owner_user_id,code);
ALTER TABLE remote_fields DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,field_id), ADD KEY idx_rf_owner_active(owner_user_id,remote_id,active);
ALTER TABLE remote_customers DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,customer_id), ADD KEY idx_rc_owner_active(owner_user_id,remote_id,active);
ALTER TABLE remote_products DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,product_id), ADD KEY idx_rp_owner_active(owner_user_id,remote_id,active);
ALTER TABLE weighing_state DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,id);

INSERT INTO settings (owner_user_id,`key`,`value`)
VALUES (@admin_id,'test_weight','0')
ON DUPLICATE KEY UPDATE `value`=VALUES(`value`);

SET FOREIGN_KEY_CHECKS=1;
