#!/usr/bin/python3
"""Explizit freizugebende Installation der Waagenbox-Systemsteuerung."""
import argparse
import json
import os
from pathlib import Path
import pwd
import stat
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
FILES = {
    'deploy/waagenbox-system-control.py': ('/usr/local/sbin/waagenbox-system-control', 0o755),
    'deploy/waagenbox-kiosk': ('/usr/local/bin/waagenbox-kiosk', 0o755),
}
SUDOERS = '/etc/sudoers.d/waagenbox-system-control'
RULE = b'www-data ALL=(root) NOPASSWD: /usr/local/sbin/waagenbox-system-control ""\n'
BINARIES = ['/usr/bin/systemctl', '/usr/bin/chromium', '/usr/bin/curl', '/usr/bin/flock', '/usr/sbin/visudo']


def run(*args):
    return subprocess.run(
        args,
        check=True,
        capture_output=True,
        text=True,
        env={**os.environ, 'LC_ALL': 'C', 'PATH': '/usr/sbin:/usr/bin:/sbin:/bin'},
    ).stdout.strip()


def safe_path(path):
    path = Path(path)
    for item in [path, *path.parents]:
        if item.is_symlink():
            raise ValueError('Unsafe symlink: ' + str(item))
        if item.exists():
            info = item.stat()
            if info.st_uid != 0 or info.st_mode & 0o022:
                raise ValueError('Root ownership/write protection required: ' + str(item))


def put(path, data, mode):
    path = Path(path)
    safe_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.waagenbox-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as target:
            os.fchmod(target.fileno(), mode)
            target.write(data)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def expected_files():
    items = [(dst, (ROOT / src).read_bytes(), mode) for src, (dst, mode) in FILES.items()]
    items.append((SUDOERS, RULE, 0o440))
    return items


def check():
    missing = []
    try:
        pwd.getpwnam('pi')
    except KeyError:
        missing.append('Benutzer pi fehlt')
    for binary in BINARIES:
        if not os.access(binary, os.X_OK):
            missing.append(binary)
    for dst, data, mode in expected_files():
        try:
            safe_path(dst)
            path = Path(dst)
            if path.read_bytes() != data or stat.S_IMODE(path.stat().st_mode) != mode:
                missing.append(dst)
        except (OSError, ValueError):
            missing.append(dst)
    try:
        run('/usr/sbin/visudo', '-cf', SUDOERS)
    except (OSError, subprocess.CalledProcessError):
        if SUDOERS not in missing:
            missing.append(SUDOERS)
    print(json.dumps({
        'ok': not missing,
        'required_step': 'sudo /usr/bin/python3 install_system_controls.py --install',
        'missing': missing,
    }))
    return 1 if missing else 0


def install():
    if os.geteuid() != 0:
        raise ValueError('Run the explicitly approved installation as root.')
    pwd.getpwnam('pi')
    for binary in BINARIES:
        if not os.access(binary, os.X_OK):
            raise ValueError('Missing prerequisite: ' + binary)
    for dst, _, _ in expected_files():
        safe_path(dst)
    with tempfile.NamedTemporaryFile() as candidate:
        candidate.write(RULE)
        candidate.flush()
        run('/usr/sbin/visudo', '-cf', candidate.name)
    for dst, data, mode in expected_files():
        put(dst, data, mode)
    return check()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true')
    group.add_argument('--install', action='store_true')
    args = parser.parse_args()
    try:
        if args.check:
            raise SystemExit(check())
        raise SystemExit(install())
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print(json.dumps({'ok': False, 'error': str(error) if isinstance(error, ValueError) else 'Systeminstallation fehlgeschlagen.'}))
        raise SystemExit(1)
