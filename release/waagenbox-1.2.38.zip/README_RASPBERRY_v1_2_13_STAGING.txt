AJP Waagenbox Raspberry v1.2.13 – STAGING

Dieses Paket ist ein vollständiges Update-Paket für den Raspberry-Updater.

Enthalten ist der getestete Web-Funktionsstand mit:
- Kamera-Einstellungen und Kamera-Snapshot pro Wiegung
- manuellem Datenbank-Backup und Backup-Wiederherstellung
- 5-kg-Gewichtsdarstellung
- mobile QR-Fernbedienung/GPS
- automatischem Abschluss im Testbetrieb
- 5 Sekunden rote Verarbeitungsphase nach erfolgreicher Wiegung
- Rücksprung zu Wiegungen nach der Verarbeitungsphase
- Update-Erfolgsmeldung und anschließender Dashboard-Neuladung
- Testgewicht auf dem Raspberry, solange kein Dini-Waagencomputer aktiviert ist

WICHTIG:
- Die lokale config.php des Raspberry wird vom Update-Mechanismus nicht aus dem Paket übernommen.
- APP_VERSION wird nach erfolgreicher Installation automatisch auf die Manifest-Version gesetzt.
- Es ist keine Datenbankmigration enthalten.
