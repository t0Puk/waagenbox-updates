<?php
require_once __DIR__.'/functions.php';
logoutUser();
if ((defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) || isLocalAccess()) redirect('index.php');
redirect('login.php');
