<?php
/** AJP Waagenbox – automatische Datenbanksicherung.
 *  Wird als CLI-Prozess über einen systemd-Timer regelmäßig aufgerufen.
 */
require_once __DIR__.'/functions.php';
require_once __DIR__.'/update_safety.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit('Nur CLI.');}
$force=in_array('--force',$argv??[],true);
if(!$force && appSetting('backup_enabled','0')!=='1') exit(0);

function backupDue(): bool {
    $last=appSetting('backup_last',''); $freq=appSetting('backup_frequency','daily'); $time=appSetting('backup_time','03:00'); $weekday=(int)appSetting('backup_weekday','1');
    $now=new DateTimeImmutable('now',new DateTimeZone(APP_TIMEZONE));
    if($last!==''){
        try{$lastDt=new DateTimeImmutable($last,new DateTimeZone(APP_TIMEZONE));}catch(Throwable $e){$lastDt=null;}
    }else{$lastDt=null;}
    if($freq==='hourly') return !$lastDt || ($now->getTimestamp()-$lastDt->getTimestamp()>=3600);
    [$hh,$mm]=array_map('intval',explode(':',$time));
    if((int)$now->format('H')<$hh || ((int)$now->format('H')===$hh && (int)$now->format('i')<$mm)) return false;
    if($freq==='weekly'){
        if((int)$now->format('N')!==$weekday)return false;
        return !$lastDt || $lastDt->format('o-W')!==$now->format('o-W');
    }
    return !$lastDt || $lastDt->format('Y-m-d')!==$now->format('Y-m-d');
}
$dir='/var/backups/waagenbox';
if(!is_dir($dir) && !mkdir($dir,0750,true)) throw new RuntimeException('Backup-Verzeichnis konnte nicht angelegt werden.');

$lockFile=$dir.'/.backup.lock';
$lockHandle=fopen($lockFile,'c');
if($lockHandle===false) {
    throw new RuntimeException('Backup-Sperrdatei konnte nicht geöffnet werden.');
}
@chmod($lockFile,0600);

if(!flock($lockHandle,LOCK_EX|LOCK_NB)) {
    fclose($lockHandle);
    echo "Backup läuft bereits; weiterer Aufruf wurde übersprungen.\n";
    exit(0);
}

register_shutdown_function(static function() use ($lockHandle): void {
    if(is_resource($lockHandle)) {
        @flock($lockHandle,LOCK_UN);
        @fclose($lockHandle);
    }
});

if(!$force && !backupDue()) exit(0);

$stamp=(new DateTimeImmutable('now',new DateTimeZone(APP_TIMEZONE)))->format('Y-m-d_H-i-s');
$token=bin2hex(random_bytes(6));
$file=$dir.'/waagenbox_'.$stamp.'_'.$token.'.sql.gz';
$sqlTmp=$dir.'/.waagenbox_'.$stamp.'.'.$token.'.sql.tmp';
$gzTmp=$file.'.'.$token.'.tmp';
$defaultsTmp=$dir.'/.mariadb_'.$stamp.'.'.$token.'.cnf.tmp';

function backupMariaDbOption(string $value): string {
    return '"' . str_replace(
        ["\\", '"', "\n", "\r", "\t"],
        ["\\\\", '\\"', "\\n", "\\r", "\\t"],
        $value
    ) . '"';
}

try {
    $defaultsContent="[client]\n"
        ."host=".backupMariaDbOption(DB_HOST)."\n"
        ."port=".(int)DB_PORT."\n"
        ."user=".backupMariaDbOption(DB_USER)."\n"
        ."password=".backupMariaDbOption(DB_PASS)."\n"
        ."protocol=tcp\n";

    $oldUmask=umask(0077);
    try {
        $written=file_put_contents($defaultsTmp,$defaultsContent,LOCK_EX);
    } finally {
        umask($oldUmask);
    }

    if($written===false) {
        throw new RuntimeException('Temporäre MariaDB-Konfiguration konnte nicht erstellt werden.');
    }

    if(!chmod($defaultsTmp,0600)) {
        throw new RuntimeException('Dateirechte der temporären MariaDB-Konfiguration konnten nicht gesetzt werden.');
    }

    $cmd='mariadb-dump --defaults-extra-file='.escapeshellarg($defaultsTmp)
        .' --single-transaction --routines --triggers --events --no-tablespaces --hex-blob'
        .' '.escapeshellarg(DB_NAME)
        .' > '.escapeshellarg($sqlTmp);

    $out=[];
    $rc=0;
    exec('/bin/bash -c '.escapeshellarg('umask 077; '.$cmd),$out,$rc);

    if($rc!==0 || !is_file($sqlTmp) || filesize($sqlTmp)<100) {
        throw new RuntimeException('Datenbank-Dump fehlgeschlagen (Exit-Code '.$rc.').');
    }

    // DEFINER-Klauseln entfernen, damit das Backup auch mit dem
    // eingeschränkten Datenbankbenutzer wiederhergestellt werden kann.
    updateSafetyNormalizeDump($sqlTmp);
    updateSafetyDumpCheck($sqlTmp);

    $gzipCmd='gzip -c -- '.escapeshellarg($sqlTmp).' > '.escapeshellarg($gzTmp);
    $out=[];
    $rc=0;
    exec('/bin/bash -c '.escapeshellarg('umask 077; '.$gzipCmd),$out,$rc);

    if($rc!==0 || !is_file($gzTmp) || filesize($gzTmp)<100) {
        throw new RuntimeException('Komprimierung des Datenbank-Backups fehlgeschlagen (Exit-Code '.$rc.').');
    }

    $out=[];
    $rc=0;
    exec('gzip -t -- '.escapeshellarg($gzTmp),$out,$rc);
    if($rc!==0) {
        throw new RuntimeException('Integritätsprüfung des komprimierten Datenbank-Backups fehlgeschlagen.');
    }

    if(!chmod($gzTmp,0600)) {
        throw new RuntimeException('Dateirechte des Datenbank-Backups konnten nicht gesetzt werden.');
    }

    if(!rename($gzTmp,$file)) {
        throw new RuntimeException('Datenbank-Backup konnte nicht atomar aktiviert werden.');
    }
} catch(Throwable $e) {
    @unlink($sqlTmp);
    @unlink($gzTmp);
    @unlink($defaultsTmp);
    throw $e;
}

@unlink($sqlTmp);
@unlink($defaultsTmp);

$ret=max(1,min(90,(int)appSetting('backup_retention','14')));
$files=glob($dir.'/waagenbox_*.sql.gz')?:[]; rsort($files,SORT_STRING);
foreach(array_slice($files,$ret) as $old) @unlink($old);

$gdrive=appSetting('gdrive_enabled','0')==='1';
if($gdrive){
    $remote=trim(appSetting('gdrive_remote','')); $path=trim(appSetting('gdrive_path','Waagenbox-Backups'));
    if($remote==='') throw new RuntimeException('Google Drive ist aktiviert, aber kein rclone-Remote eingetragen.');
    $which=trim((string)shell_exec('command -v rclone 2>/dev/null'));
    if($which==='') throw new RuntimeException('Google Drive ist aktiviert, aber rclone ist nicht installiert.');
    $target=$remote.':'.ltrim($path,'/');
    $cmd='rclone copy '.escapeshellarg($file).' '.escapeshellarg($target).' --create-empty-src-dirs';
    exec('/bin/bash -c '.escapeshellarg($cmd),$out,$rc);
    if($rc!==0) throw new RuntimeException('Upload zu Google Drive fehlgeschlagen (Exit-Code '.$rc.').');
}

$now=(new DateTimeImmutable('now',new DateTimeZone(APP_TIMEZONE)))->format('Y-m-d H:i:s');
saveAppSetting('backup_last',$now); saveAppSetting('backup_last_file',$file);
echo "Backup erfolgreich: {$file}\n";
