<?php
require_once __DIR__.'/functions.php';
$ownerId = currentOwnerId();

// Wiegung löschen – nur per POST und mit Sicherheitsabfrage im Browser.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = (int)$_POST['delete_id'];
    if ($deleteId > 0) {
        $stmt = db()->prepare('DELETE FROM weighings WHERE id=? AND owner_user_id=?');
        $stmt->execute([$deleteId, $ownerId]);
        if ($stmt->rowCount()) deleteCameraSnapshot($deleteId);
        flash($stmt->rowCount() ? 'Wiegung wurde gelöscht.' : 'Wiegung wurde nicht gefunden.');
    }
    $query = $_POST['return_query'] ?? '';
    redirect('weighings.php' . ($query !== '' ? '?' . $query : ''));
}

$fieldRowsStmt = db()->prepare('SELECT id,name,crop,year FROM `fields` WHERE owner_user_id=? ORDER BY name');
$fieldRowsStmt->execute([$ownerId]);
$fieldRows = $fieldRowsStmt->fetchAll();
$vehicleRowsStmt = db()->prepare('SELECT id,plate,name FROM vehicles WHERE owner_user_id=? ORDER BY plate');
$vehicleRowsStmt->execute([$ownerId]);
$vehicleRows = $vehicleRowsStmt->fetchAll();
$customerRowsStmt = db()->prepare('SELECT id,name FROM customers WHERE owner_user_id=? ORDER BY name');
$customerRowsStmt->execute([$ownerId]);
$customerRows = $customerRowsStmt->fetchAll();
$productRowsStmt = db()->prepare('SELECT id,name FROM products WHERE owner_user_id=? ORDER BY name');
$productRowsStmt->execute([$ownerId]);
$productRows = $productRowsStmt->fetchAll();

$fieldId = (int)($_GET['field_id'] ?? 0);
$vehicleId = (int)($_GET['vehicle_id'] ?? 0);
$customerId = (int)($_GET['customer_id'] ?? 0);
$productId = (int)($_GET['product_id'] ?? 0);
$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo = trim((string)($_GET['date_to'] ?? ''));

$sql = 'SELECT w.*, v.plate, v.name AS vehicle_name, f.name AS field_name, c.name AS customer_name, p.name AS product_name
        FROM weighings w
        LEFT JOIN vehicles v ON v.id=w.vehicle_id
        LEFT JOIN `fields` f ON f.id=w.field_id
        LEFT JOIN customers c ON c.id=w.customer_id
        LEFT JOIN products p ON p.id=w.product_id
        WHERE w.owner_user_id=?';
$params = [$ownerId];

if ($fieldId > 0) {
    $sql .= ' AND w.field_id=?';
    $params[] = $fieldId;
}
if ($vehicleId > 0) {
    $sql .= ' AND w.vehicle_id=?';
    $params[] = $vehicleId;
}
if ($customerId > 0) {
    $sql .= ' AND w.customer_id=?';
    $params[] = $customerId;
}
if ($productId > 0) {
    $sql .= ' AND w.product_id=?';
    $params[] = $productId;
}
if ($dateFrom !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom)) {
    $sql .= ' AND w.created_at >= ?';
    $params[] = $dateFrom . ' 00:00:00';
}
if ($dateTo !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo)) {
    $sql .= ' AND w.created_at < DATE_ADD(?, INTERVAL 1 DAY)';
    $params[] = $dateTo . ' 00:00:00';
}

$sql .= ' ORDER BY w.created_at DESC, w.id DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$returnQuery = http_build_query(array_filter([
    'field_id' => $fieldId ?: null,
    'vehicle_id' => $vehicleId ?: null,
    'customer_id' => $customerId ?: null,
    'product_id' => $productId ?: null,
    'date_from' => $dateFrom !== '' ? $dateFrom : null,
    'date_to' => $dateTo !== '' ? $dateTo : null,
], static fn($v) => $v !== null && $v !== ''));

layoutStart('Wiegungen','weighings');
?>
<div class="toolbar"><h1>Wiegungen</h1></div>

<div class="card">
    <h3>Wiegungen filtern</h3>
    <form method="get" class="form-grid">
        <div>
            <label for="field_id">Schlag</label>
            <select id="field_id" name="field_id">
                <option value="0">Alle Schläge</option>
                <?php foreach ($fieldRows as $f): ?>
                    <option value="<?=h($f['id'])?>" <?=$fieldId===(int)$f['id']?'selected':''?>>
                        <?=h($f['name'])?><?php if($f['crop']): ?> – <?=h($f['crop'])?><?php endif; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="vehicle_id">Fahrzeug</label>
            <select id="vehicle_id" name="vehicle_id">
                <option value="0">Alle Fahrzeuge</option>
                <?php foreach ($vehicleRows as $v): ?>
                    <option value="<?=h($v['id'])?>" <?=$vehicleId===(int)$v['id']?'selected':''?>>
                        <?=h($v['plate'])?><?= $v['name'] ? ' – '.h($v['name']) : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="customer_id">Kunde</label>
            <select id="customer_id" name="customer_id"><option value="0">Alle Kunden</option><?php foreach($customerRows as $c): ?><option value="<?=h($c['id'])?>" <?=$customerId===(int)$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach; ?></select>
        </div>
        <div>
            <label for="product_id">Produkt</label>
            <select id="product_id" name="product_id"><option value="0">Alle Produkte</option><?php foreach($productRows as $pr): ?><option value="<?=h($pr['id'])?>" <?=$productId===(int)$pr['id']?'selected':''?>><?=h($pr['name'])?></option><?php endforeach; ?></select>
        </div>
        <div>
            <label for="date_from">Datum von</label>
            <input type="date" id="date_from" name="date_from" value="<?=h($dateFrom)?>">
        </div>
        <div>
            <label for="date_to">Datum bis</label>
            <input type="date" id="date_to" name="date_to" value="<?=h($dateTo)?>">
        </div>
        <div class="full actions">
            <button type="submit">Filter anwenden</button>
            <a class="button" href="weighings.php">Filter zurücksetzen</a>
        </div>
    </form>
</div>

<div class="card table-wrap weighings-table-card">
    <div class="table-heading"><strong><?=count($rows)?> Wiegung<?=count($rows)===1?'':'en'?></strong></div>
    <table>
        <tr>
            <th>Datum</th><th>Fahrzeug</th><th>Kunde</th><th>Produkt</th><th>Schlag</th><th>1. Gewicht</th><th>2. Gewicht</th><th>Netto</th><th>Trigger</th><th>Kamera</th><th>Aktionen</th>
        </tr>
        <?php if (!$rows): ?>
            <tr><td colspan="11"><em>Keine Wiegungen für die gewählten Filter gefunden.</em></td></tr>
        <?php else: ?>
            <?php foreach($rows as $r): ?>
            <tr>
                <td><?=h($r['created_at'])?></td>
                <td><?php if($r['vehicle_id']): ?><?=h($r['plate'])?><?= $r['vehicle_name'] ? ' – '.h($r['vehicle_name']) : '' ?><?php else: ?><em>Kein Fahrzeug</em><?php endif; ?></td>
                <td><?=h($r['customer_name'] ?: 'Kein Kunde')?></td>
                <td><?=h($r['product_name'] ?: 'Kein Produkt')?></td>
                <td><?=h($r['field_name'] ?: 'Kein Schlag')?></td>
                <td><?=formatWeight((float)$r['first_weight'])?> kg</td>
                <td><?=formatWeight((float)$r['second_weight'])?> kg</td>
                <td><strong><?=formatWeight((float)$r['net_weight'])?> kg</strong></td>
                <td><?=h($r['trigger_type'])?></td>
                <td class="weighing-photo-cell"><?php $photo=cameraSnapshotRelativePath((int)$r['id']); $photoAbs=cameraSnapshotAbsolutePath((int)$r['id']); if(is_file($photoAbs)): ?><button type="button" class="camera-thumb-button" onclick="openCameraImage(<?=json_encode($photo)?>)"><img src="<?=h($photo)?>?v=<?=filemtime($photoAbs)?>" alt="Kamerabild zur Wiegung"></button><?php else: ?><span class="muted">–</span><?php endif; ?></td>
                <td class="row-actions">
                    <a class="button" href="edit_weighing.php?id=<?=$r['id']?>">Bearbeiten</a>
                    <a class="button" href="reports/weighing.php?id=<?=$r['id']?>" target="_blank">Drucken/PDF</a>
                    <form method="post" class="delete-form" onsubmit="return confirm('Wiegung vom <?=h($r['created_at'])?> wirklich endgültig löschen?\n\nDieser Vorgang kann nicht rückgängig gemacht werden.');">
                        <input type="hidden" name="delete_id" value="<?=h($r['id'])?>">
                        <input type="hidden" name="return_query" value="<?=h($returnQuery)?>">
                        <button type="submit" class="button-danger">Löschen</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</div>
<div id="cameraImageModal" class="camera-image-modal" hidden onclick="closeCameraImage()"><div class="camera-image-modal-inner" onclick="event.stopPropagation()"><button type="button" class="camera-image-close" onclick="closeCameraImage()">×</button><img id="cameraImageLarge" src="" alt="Kamerabild Großansicht"></div></div>
<script>
function openCameraImage(src){const m=document.getElementById("cameraImageModal"),i=document.getElementById("cameraImageLarge");i.src=src;m.hidden=false;}function closeCameraImage(){const m=document.getElementById("cameraImageModal"),i=document.getElementById("cameraImageLarge");m.hidden=true;i.src="";}
let lastWeighingId = <?= !empty($rows) ? (int)$rows[0]['id'] : 0 ?>;
async function pollWeighings(){try{const r=await fetch('api/weighings_latest.php',{cache:'no-store'});const d=await r.json();if(d.latest_id>lastWeighingId){location.reload();}}catch(e){}}
setInterval(pollWeighings,5000);
</script>
<?php layoutEnd(); ?>
