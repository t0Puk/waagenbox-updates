<?php
require_once __DIR__.'/functions.php';
if (!passwordProtectionRequired()) redirect('index.php');
if (isAccessAuthenticated()) redirect('index.php');
if (!accessPasswordConfigured()) redirect('setup_access_password.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $password=(string)($_POST['password']??'');
    if ($password==='' || !password_verify($password, accessPasswordHash())) {
        $error='Das Passwort ist nicht korrekt.';
        usleep(450000);
    } else {
        session_regenerate_id(true);
        $_SESSION['waage_access_authenticated']=1;
        $_SESSION['waage_last_activity']=time();
        redirect('index.php');
    }
}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Anmeldung – AJP Waage</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page">
<div class="login-card card"><div class="brand">AJPnaturenergie</div><div class="sub">AJP Waagensteuerung</div><h1>Anmelden</h1>
<?php if($error): ?><div class="flash error"><?=h($error)?></div><?php endif; ?>
<form method="post"><label>Passwort</label><input type="password" name="password" autocomplete="current-password" autofocus required><p><button class="button primary" style="width:100%">Anmelden</button></p></form>
<p class="muted login-hint">Der lokale Zugriff über localhost benötigt kein Passwort. Die mobile QR-Fernbedienung verwendet weiterhin ausschließlich ihren QR-Token.</p></div></body></html>
