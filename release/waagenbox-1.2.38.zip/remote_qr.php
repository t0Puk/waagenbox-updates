<?php
require_once __DIR__.'/functions.php';
requireLogin();
$id=(int)($_GET['id']??0);
$s=db()->prepare('SELECT r.*,v.plate,v.name AS vehicle_name FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.id=?');$s->execute([currentOwnerId(),$id]);$remote=$s->fetch();
if(!$remote){http_response_code(404);exit('Fernbedienung nicht gefunden');}
if(empty($remote['mobile_token'])){ $token=bin2hex(random_bytes(32)); $u=db()->prepare('UPDATE remotes SET mobile_token=? WHERE owner_user_id=? AND id=?'); $u->execute([$token,currentOwnerId(),$id]); $remote['mobile_token']=$token; }
$url=mobileRemoteUrl($remote['mobile_token']);
$label=trim(($remote['plate']??'').' – '.($remote['vehicle_name']??''),' –');
?>
<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QR-Code – <?=h($remote['name'])?></title><link rel="stylesheet" href="assets/style.css"><script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script></head><body>
<div class="container qr-page"><div class="card qr-card"><div class="brand qr-brand">AJPnaturenergie</div><div class="sub qr-sub">Mobile Waage</div><h1><?=h($remote['name'])?></h1><h2><?=h($label ?: 'Kein Fahrzeug')?></h2><div id="qrcode" class="qr-code"></div><p class="qr-instruction">QR-Code mit dem Smartphone scannen und anschließend die Wiegung direkt an der Waage starten.</p><p class="muted">Dieser QR-Code bleibt aktiv, bis unter „Fernbedienungen“ erneut auf „QR-Code“ gedrückt wird. Dann wird ein neuer Code erzeugt und der bisherige Code sofort ungültig.</p><p class="qr-url"><?=h($url)?></p><div class="button-row no-print"><button class="button primary" onclick="window.print()">🖨️ Drucken</button><a class="button" href="remotes.php">← Zurück</a></div></div></div>
<script>new QRCode(document.getElementById('qrcode'),{text:<?=json_encode($url)?>,width:300,height:300,correctLevel:QRCode.CorrectLevel.M});</script>
</body></html>
