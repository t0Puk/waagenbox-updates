<?php
/** Gemeinsame, ausschließlich von den Update-Endpunkten verwendete Sicherungslogik.
 * Keine Konfiguration laden: Datei kann mit temporären Testverzeichnissen geprüft werden.
 * Fehler-/Rettungsdaten werden niemals automatisch bereinigt. Nur explizit
 * erfolgreiche Arbeitsdaten und verifizierte Generationen sind bereinigbar.
 */
function updateSafetyWriteJson(string $file, array $data): void {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n";
    $tmp = $file.'.new';
    if (file_put_contents($tmp, $json, LOCK_EX) !== strlen($json) || !rename($tmp, $file)) {
        throw new RuntimeException('Statusdatei konnte nicht sicher geschrieben werden: '.$file);
    }
    @chmod($file, 0600);
}

function updateSafetyReadJson(string $file): array {
    $data = json_decode((string)file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($data)) throw new RuntimeException('Ungültige Sicherungsmetadaten: '.$file);
    return $data;
}

function updateSafetyDirectory(string $dir): void {
    if (is_link($dir) || (!is_dir($dir) && !mkdir($dir, 0700, true)) || !is_writable($dir)) {
        throw new RuntimeException('Sicherungsverzeichnis nicht verfügbar: '.$dir);
    }
}

function updateSafetyLock(string $root) {
    updateSafetyDirectory($root);
    $lock = fopen($root.'/operation.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
        throw new RuntimeException('Ein Update oder Rollback läuft bereits.');
    }
    $journal = $root.'/operation.json';
    if (is_file($journal)) {
        $state = updateSafetyReadJson($journal);
        if (!in_array($state['state'] ?? '', ['complete', 'recovered', 'aborted'], true)) {
            throw new RuntimeException('Ein vorheriger Wartungsvorgang ist ungeklärt. Rettungsdateien und '.$journal.' müssen vor einem neuen Versuch geprüft werden.');
        }
    }
    return $lock;
}

function updateSafetyBinary(array $names): string {
    foreach ($names as $name) {
        foreach (explode(PATH_SEPARATOR, getenv('PATH') ?: '/usr/bin:/bin') as $dir) {
            $path = rtrim($dir, '/\\').DIRECTORY_SEPARATOR.$name.(PHP_OS_FAMILY === 'Windows' ? '.exe' : '');
            if (is_file($path) && is_executable($path)) return $path;
        }
    }
    throw new RuntimeException('Erforderliches Programm fehlt: '.implode(' / ', $names));
}

/** Kein Shell-String und keine Zugangsdaten in argv oder HTTP-Fehlern. */
function updateSafetyRun(array $args, string $log, ?string $input = null, ?string $output = null, ?array $env = null): void {
    $descriptors = [
        0 => ['file', $input ?? (PHP_OS_FAMILY === 'Windows' ? 'NUL' : '/dev/null'), 'r'],
        1 => ['file', $output ?? $log, $output === null ? 'ab' : 'wb'],
        2 => ['file', $log, 'ab'],
    ];
    $process = proc_open($args, $descriptors, $pipes, null, $env, ['bypass_shell' => true]);
    if (!is_resource($process)) throw new RuntimeException('Prozess konnte nicht gestartet werden. Protokoll: '.$log);
    $code = proc_close($process);
    if ($code !== 0) throw new RuntimeException('Prozess '.basename($args[0]).' fehlgeschlagen (Exit-Code '.$code.'). Protokoll: '.$log);
}

/** Vollständiges Dateiinventar; Symlinks/Sonderdateien werden bewusst abgewiesen. */
function updateSafetyInventory(string $root): array {
    if (!is_dir($root) || is_link($root)) throw new RuntimeException('Kein reguläres Anwendungsverzeichnis: '.$root);
    $result = [];
    $walk = function (string $dir, string $prefix) use (&$walk, &$result): void {
        $entries = scandir($dir);
        if ($entries === false) throw new RuntimeException('Verzeichnis nicht lesbar: '.$dir);
        foreach ($entries as $name) {
            if ($name === '.' || $name === '..') continue;
            $path = $dir.'/'.$name;
            $relative = $prefix.$name;
            if (is_link($path)) throw new RuntimeException('Symlink ist im Sicherungs-/Updatepfad nicht erlaubt: '.$relative);
            if (is_dir($path)) {
                $result[$relative] = ['type' => 'directory'];
                $walk($path, $relative.'/');
            } elseif (is_file($path)) {
                $hash = hash_file('sha256', $path);
                if ($hash === false) throw new RuntimeException('Datei nicht prüfbar: '.$relative);
                $result[$relative] = ['type' => 'file', 'sha256' => $hash];
            } else {
                throw new RuntimeException('Nicht unterstützter Dateityp: '.$relative);
            }
        }
    };
    $walk($root, '');
    ksort($result);
    return $result;
}

function updateSafetyRequireFiles(string $root, array $files): void {
    foreach ($files as $file) {
        if (!is_file($root.'/'.$file) || is_link($root.'/'.$file) || filesize($root.'/'.$file) === 0) {
            throw new RuntimeException('Erforderliche Datei fehlt oder ist leer: '.$file);
        }
    }
}

function updateSafetyCopy(string $source, string $target, string $log): void {
    updateSafetyRun([updateSafetyBinary(['cp']), '-a', '--', $source, $target], $log);
}

function updateSafetyRequireWritableApplication(string $app, array $files): void {
    if (!is_dir($app) || !is_writable($app)) throw new RuntimeException('Anwendungsverzeichnis ist für den Update-Benutzer nicht beschreibbar; Update abgebrochen.');
    foreach ($files as $relative => $entry) {
        $target = $app.'/'.$relative;
        if (($entry['type'] ?? '') === 'file' && is_file($target) && !is_writable($target)) {
            throw new RuntimeException('Vorhandene Anwendungsdatei ist nicht beschreibbar: '.$relative.'; Deployment mit passenden Dateirechten erforderlich.');
        }
        $parent = dirname($target);
        if (is_dir($parent) && !is_writable($parent)) throw new RuntimeException('Anwendungsverzeichnis ist nicht beschreibbar: '.$parent.'; Update abgebrochen.');
    }
}

function updateSafetyDumpCheck(string $file): string {
    if (!is_file($file) || is_link($file) || filesize($file) < 100) {
        throw new RuntimeException('Datenbanksicherung fehlt oder ist unplausibel: '.$file);
    }
    $stream = fopen($file, 'rb');
    if (!$stream) throw new RuntimeException('Datenbanksicherung nicht lesbar: '.$file);
    $hasTable = false;
    $tail = '';
    while (($line = fgets($stream)) !== false) {
        if (str_starts_with($line, 'CREATE TABLE ')) $hasTable = true;
        $tail = substr($tail.$line, -4096);
    }
    $readComplete = feof($stream);
    fclose($stream);
    if (!$readComplete || !$hasTable || !str_contains($tail, '-- Dump completed')) {
        throw new RuntimeException('Datenbanksicherung ist unvollständig (Tabellen oder Abschlussmarkierung fehlen): '.$file);
    }
    $hash = hash_file('sha256', $file);
    if ($hash === false) throw new RuntimeException('Datenbanksicherung konnte nicht geprüft werden: '.$file);
    return $hash;
}

function updateSafetyDbArgs(string $binary): array {
    return [$binary, '--protocol=TCP', '-h', DB_HOST, '-P', (string)DB_PORT, '-u', DB_USER];
}

function updateSafetyDbEnv(): array {
    $env = getenv();
    $env['MYSQL_PWD'] = DB_PASS;
    return $env;
}

/** Auch nach einem Import eine neue Verbindung verwenden. */
function updateSafetyDb(): PDO {
    return new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}

function updateSafetyObjects(PDO $pdo): array {
    $objects = ['tables' => [], 'views' => [], 'procedures' => [], 'functions' => [], 'events' => [], 'triggers' => []];
    foreach ($pdo->query('SHOW FULL TABLES')->fetchAll(PDO::FETCH_NUM) as $row) {
        $objects[$row[1] === 'VIEW' ? 'views' : 'tables'][] = $row[0];
    }
    foreach (['routines' => 'ROUTINE_NAME, ROUTINE_TYPE', 'events' => 'EVENT_NAME', 'triggers' => 'TRIGGER_NAME'] as $table => $columns) {
        $schemaColumn = ['routines' => 'ROUTINE_SCHEMA', 'events' => 'EVENT_SCHEMA', 'triggers' => 'TRIGGER_SCHEMA'][$table];
        $stmt = $pdo->prepare('SELECT '.$columns.' FROM information_schema.'.$table.' WHERE '.$schemaColumn.'=?');
        $stmt->execute([DB_NAME]);
        foreach ($stmt->fetchAll(PDO::FETCH_NUM) as $row) {
            $kind = $table === 'routines' ? (strtoupper($row[1]) === 'PROCEDURE' ? 'procedures' : 'functions') : $table;
            $objects[$kind][] = $row[0];
        }
    }
    foreach ($objects as &$names) sort($names, SORT_STRING);
    return $objects;
}

function updateSafetySnapshot(string $app, string $destination, array $metadata): array {
    updateSafetyDirectory($destination);
    $appReal = realpath($app);
    $destinationReal = realpath($destination);
    if ($appReal === false || $destinationReal === false || $appReal === $destinationReal ||
        str_starts_with($destinationReal, $appReal.DIRECTORY_SEPARATOR) || str_starts_with($appReal, $destinationReal.DIRECTORY_SEPARATOR)) {
        throw new RuntimeException('Sicherung und Anwendung dürfen nicht ineinander liegen.');
    }
    updateSafetyRequireFiles($app, ['config.php', 'functions.php', 'version.php', 'db.php']);
    $before = updateSafetyInventory($app);
    updateSafetyCopy($app, $destination.'/app', $destination.'/copy.log');
    if ($before !== updateSafetyInventory($destination.'/app') || $before !== updateSafetyInventory($app)) {
        throw new RuntimeException('Anwendungssicherung stimmt nicht mit dem Ausgangsbestand überein. Sicherung: '.$destination);
    }
    $objects = updateSafetyObjects(updateSafetyDb());
    $args = array_merge(updateSafetyDbArgs(updateSafetyBinary(['mariadb-dump', 'mysqldump'])), [
        '--single-transaction', '--routines', '--triggers', '--events', '--no-tablespaces', '--hex-blob', DB_NAME,
    ]);
    updateSafetyRun($args, $destination.'/database_error.log', null, $destination.'/database.sql', updateSafetyDbEnv());
    // Der gespeicherte Snapshot wird bewusst zuerst normalisiert und erst danach gehasht.
    updateSafetyNormalizeDump($destination.'/database.sql');
    if ($objects !== updateSafetyObjects(updateSafetyDb())) throw new RuntimeException('Datenbankschema wurde während der Sicherung verändert.');
    $metadata['database_file'] = 'database.sql';
    $metadata['database_sha256'] = updateSafetyDumpCheck($destination.'/database.sql');
    $metadata['application_files'] = $before;
    $metadata['database_objects'] = $objects;
    $metadata['created_at'] = date('Y-m-d H:i:s');
    $metadata['format'] = 1;
    $metadata['snapshot_id'] = bin2hex(random_bytes(16));
    updateSafetyWriteJson($destination.'/metadata.json', $metadata);
    return updateSafetyValidateSnapshot($destination);
}

/** Entfernt ausschließlich die von mariadb-dump erzeugten DEFINER-Klauseln.
 * Der Parser betrachtet nur versionierte SQL-Kommentare; beliebige SQL-Strings
 * und Dateninhalte bleiben unverändert.
 */
function updateSafetyNormalizeDump(string $file): void {
    $input = fopen($file, 'rb');
    if (!$input) throw new RuntimeException('Datenbanksicherung konnte nicht gelesen werden: '.$file);
    $tmp = $file.'.normalize.'.bin2hex(random_bytes(8));
    $output = fopen($tmp, 'wb');
    if (!$output) { fclose($input); throw new RuntimeException('Temporäre Normalisierungsdatei konnte nicht angelegt werden.'); }
    try {
        while (($line = fgets($input)) !== false) {
            $normalized = preg_replace_callback('/\/\*![0-9]{5}([^*]*)\*\//', static function (array $match): string {
                $body = preg_replace('/(\s)DEFINER\s*=\s*(?:`[^`\r\n]+`|[A-Za-z0-9_$.-]+)\s*@\s*(?:`[^`\r\n]+`|[A-Za-z0-9_$.-]+)/i', '$1', $match[1]);
                if ($body === null || preg_match('/\bDEFINER\b/i', $body)) throw new RuntimeException('Nicht unterstützte DEFINER-Klausel in versioniertem MariaDB-Dump-Kommentar.');
                return '/*!'.substr($match[0], 3, 5).$body.'*/';
            }, $line);
            if ($normalized === null || fwrite($output, $normalized) !== strlen($normalized)) throw new RuntimeException('Normalisierte Datenbanksicherung konnte nicht vollständig geschrieben werden.');
        }
        if (!feof($input)) throw new RuntimeException('Datenbanksicherung konnte nicht vollständig gelesen werden.');
        if (function_exists('fsync') && !fsync($output)) throw new RuntimeException('Normalisierte Datenbanksicherung konnte nicht synchronisiert werden.');

        fclose($input);
        $input = null;

        fclose($output);
        $output = null;

        if (!rename($tmp, $file)) throw new RuntimeException('Normalisierte Datenbanksicherung konnte nicht atomar aktiviert werden.');
    } catch (Throwable $e) {
        if (is_resource($input)) fclose($input);
        if (is_resource($output)) fclose($output);
        @unlink($tmp);
        throw $e;
    }
}

/** Nur einfache, eindeutig erkennbare globale Legacy-Deklarationen ersetzen.
 * Tokenisierung vermeidet Änderungen in Kommentaren, Strings oder DB-Passwörtern.
 * Der restliche Quelltext bleibt bytegenau erhalten; niemals config.php ausführen.
 */
function updateSafetyLegacyConfig(string $source): string {
    $tokens = [];
    $offset = 0;
    foreach (token_get_all($source, TOKEN_PARSE) as $token) {
        $text = is_array($token) ? $token[1] : $token;
        $id = is_array($token) ? $token[0] : null;
        if (!in_array($id, [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
            $tokens[] = ['id'=>$id, 'text'=>$text, 'start'=>$offset, 'end'=>$offset+strlen($text)];
        }
        $offset += strlen($text);
    }
    $ranges = [];
    $depth = 0;
    foreach ($tokens as $i => $token) {
        if ($token['text'] === '{') $depth++;
        if ($token['text'] === '}') $depth--;
        if ($token['id'] === T_CONST && ($tokens[$i+1]['text'] ?? '') !== 'APP_VERSION') {
            for ($j=$i+1; isset($tokens[$j]) && $tokens[$j]['text'] !== ';'; $j++) {
                if ($tokens[$j]['id'] === T_STRING && $tokens[$j]['text'] === 'APP_VERSION') {
                    throw new RuntimeException('Zusammengesetzte Legacy-Konstantendeklaration muss separat geprüft werden.');
                }
            }
        }
        $const = $token['id'] === T_CONST && ($tokens[$i+1]['text'] ?? '') === 'APP_VERSION';
        $define = in_array($token['id'], [T_STRING, T_NAME_FULLY_QUALIFIED], true) &&
            strtolower(ltrim($token['text'], '\\')) === 'define' && ($tokens[$i+1]['text'] ?? '') === '(' &&
            in_array($tokens[$i+2]['text'] ?? '', ["'APP_VERSION'", '"APP_VERSION"'], true);
        if (!$const && !$define) continue;
        if ($const) {
            $end = $i+4;
            $valid = $depth === 0 && ($tokens[$i+2]['text'] ?? '') === '=' && ($tokens[$end]['text'] ?? '') === ';';
            $literal = $tokens[$i+3]['text'] ?? '';
        } else {
            $end = $i+6;
            $previous = $tokens[$i-1] ?? [];
            $valid = (($previous['id'] ?? null) === T_OPEN_TAG || in_array($previous['text'] ?? '', [';', '{', '}'], true)) &&
                ($tokens[$i+3]['text'] ?? '') === ',' && ($tokens[$i+5]['text'] ?? '') === ')' && ($tokens[$end]['text'] ?? '') === ';';
            $literal = $tokens[$i+4]['text'] ?? '';
        }
        // Ungewöhnliche PHP-Ausdrücke, Klassen-/Namespace-Konstanten und mehrere
        // Deklarationen werden nicht erraten, sondern ohne Dateimutationen abgewiesen.
        if (!$valid || !preg_match('~^[\'"]\d+(?:\.\d+){1,3}(?:[-+][A-Za-z0-9.-]+)?[\'"]$~D', $literal)) {
            throw new RuntimeException('Legacy-APP_VERSION ist nicht als einfache Deklaration migrierbar. Lokale Konfiguration bleibt unverändert.');
        }
        $ranges[] = [$token['start'], $tokens[$end]['end']];
    }
    if (!$ranges) return $source;
    if (count($ranges) !== 1 || in_array(T_NAMESPACE, array_column($tokens, 'id'), true)) {
        throw new RuntimeException('Mehrdeutige Legacy-Versionsdefinition. Lokale Konfiguration bleibt unverändert.');
    }
    [$start, $end] = $ranges[0];
    // Auch nachfolgende lokale Einstellungen dürfen APP_VERSION weiter lesen.
    $result = substr($source, 0, $start)."require_once __DIR__ . '/version.php';".substr($source, $end);
    token_get_all($result, TOKEN_PARSE);
    return $result;
}

function updateSafetyMigrateConfig(string $snapshot, string $app, string $work, string $php): string {
    $meta = updateSafetyValidateSnapshot($snapshot);
    $file = $app.'/config.php';
    if (is_link($file)) throw new RuntimeException('Lokale Konfiguration darf kein Symlink sein.');
    $source = file_get_contents($file);
    if ($source === false || !hash_equals($meta['application_files']['config.php']['sha256'], hash('sha256', $source))) {
        throw new RuntimeException('Lokale Konfiguration weicht von der geprüften Sicherung ab.');
    }
    $result = updateSafetyLegacyConfig($source);
    $expectedHash = hash('sha256', $result);
    if ($result === $source) return $expectedHash;
    // Erst im geschützten Arbeitsverzeichnis prüfen. Keine Inhalte in Fehlermeldungen.
    $draft = $work.'/config_migration.php';
    if (file_put_contents($draft, $result, LOCK_EX) !== strlen($result) || !chmod($draft, 0600)) {
        throw new RuntimeException('Konfigurationsmigration konnte nicht vorbereitet werden.');
    }
    updateSafetyRun([$php, '-n', '-l', $draft], $work.'/config_migration.log');
    // Gleicher Ordner/Dateisystem für atomisches rename; PHP-Endung verhindert
    // Auslieferung als Klartext durch die reguläre PHP-Webserverkonfiguration.
    $tmp = $app.'/.config-migration-'.bin2hex(random_bytes(8)).'.php';
    $stream = fopen($tmp, 'xb');
    if (!$stream) throw new RuntimeException('Temporäre Konfigurationsdatei konnte nicht angelegt werden.');
    try {
        if (!chmod($tmp, 0600) || fwrite($stream, $result) !== strlen($result) || !fflush($stream) || !fsync($stream)) {
            throw new RuntimeException('Temporäre Konfiguration konnte nicht vollständig gespeichert werden.');
        }
    } finally { fclose($stream); }
    $permissions = fileperms($file);
    if ($permissions === false || !chmod($tmp, $permissions & 0777)) throw new RuntimeException('Konfigurationsrechte konnten nicht übernommen werden.');
    if (!hash_equals($expectedHash, (string)hash_file('sha256', $tmp)) ||
        !hash_equals(hash('sha256', $source), (string)hash_file('sha256', $file))) {
        throw new RuntimeException('Konfiguration wurde während der Migration verändert.');
    }
    if (!rename($tmp, $file) || !hash_equals($expectedHash, (string)hash_file('sha256', $file))) {
        throw new RuntimeException('Atomischer Austausch der lokalen Konfiguration fehlgeschlagen.');
    }
    return $expectedHash;
}

/** Nur nach vollständig erfolgreichem Abschluss aufrufen. Altbestände bleiben
 * ohne diese gebundene Erfolgsmarkierung von jeder automatischen Löschung ausgenommen.
 */
function updateSafetyMarkSuccessfulSnapshot(string $snapshot): void {
    updateSafetyValidateSnapshot($snapshot);
    updateSafetyWriteJson($snapshot.'/retention.json', [
        'metadata_sha256'=>hash_file('sha256', $snapshot.'/metadata.json'),
        'completed_at'=>microtime(true),
    ]);
}

/** Vor einem Rollback Quelle an den Versuch binden. Ein Fehler/Abbruch lässt
 * die Markierung dauerhaft stehen; alte Fehler-Markierungen niemals entfernen.
 */
function updateSafetyPinSnapshot(string $snapshot): ?string {
    $file = $snapshot.'/rescue-pin.json';
    if (file_exists($file)) return null;
    $id = bin2hex(random_bytes(16));
    updateSafetyWriteJson($file, ['attempt'=>$id]);
    return $id;
}

function updateSafetyUnpinSuccessfulSnapshot(string $snapshot, ?string $attempt): void {
    if ($attempt === null) return;
    $file = $snapshot.'/rescue-pin.json';
    if ((updateSafetyReadJson($file)['attempt'] ?? '') !== $attempt || !unlink($file)) {
        throw new RuntimeException('Schutzmarkierung bleibt bestehen; manuelle Prüfung erforderlich.');
    }
}

/** Explizit begrenztes Löschen; keine Symlinks verfolgen, niemals den Elternpfad. */
function updateSafetyRemoveTree(string $path, string $parent): void {
    $parentReal = realpath($parent);
    $pathReal = realpath($path);
    if ($parentReal === false || $pathReal === false || is_link($path) || dirname($pathReal) !== $parentReal) {
        throw new RuntimeException('Bereinigung verweigert: Ziel liegt nicht unmittelbar im erlaubten Verzeichnis.');
    }
    if (is_file($pathReal)) {
        if (!unlink($pathReal)) throw new RuntimeException('Temporäre Datei konnte nicht entfernt werden.');
        return;
    }
    $files = updateSafetyInventory($pathReal);
    uksort($files, fn($a,$b)=>strlen($b)<=>strlen($a));
    foreach ($files as $name=>$entry) {
        $ok = $entry['type'] === 'directory' ? rmdir($pathReal.'/'.$name) : unlink($pathReal.'/'.$name);
        if (!$ok) throw new RuntimeException('Bereinigung konnte nicht abgeschlossen werden.');
    }
    if (!rmdir($pathReal)) throw new RuntimeException('Bereinigungsverzeichnis konnte nicht entfernt werden.');
}

/** Aktuelle Sicherung plus eine weitere erfolgreiche Generation behalten.
 * Geschützte, unbekannte und beschädigte Generationen werden nicht gelöscht.
 * Auch erfolgreiche manuelle Rollback-Versuche fallen unter diese Begrenzung.
 */
function updateSafetyPruneSuccessfulSnapshots(string $root): void {
    updateSafetyValidateSnapshot($root);
    $storage = dirname($root);
    $candidates = glob($root.'_previous_*', GLOB_ONLYDIR) ?: [];
    foreach (glob($storage.'/rollback_attempt_*', GLOB_ONLYDIR) ?: [] as $attempt) {
        if (!is_link($attempt) && is_dir($attempt.'/snapshot')) $candidates[] = $attempt.'/snapshot';
    }
    $eligible = [];
    foreach ($candidates as $candidate) {
        if (is_link($candidate) || file_exists($candidate.'/rescue-pin.json') || !is_file($candidate.'/retention.json')) continue;
        try {
            $marker = updateSafetyReadJson($candidate.'/retention.json');
            if (!is_numeric($marker['completed_at'] ?? null) ||
                !hash_equals((string)($marker['metadata_sha256'] ?? ''), (string)hash_file('sha256', $candidate.'/metadata.json'))) continue;
            updateSafetyValidateSnapshot($candidate);
            $eligible[$candidate] = (float)$marker['completed_at'];
        } catch (Throwable $e) { continue; }
    }
    arsort($eligible, SORT_NUMERIC);
    foreach (array_slice(array_keys($eligible), 1) as $candidate) {
        // Zweite Prüfung unmittelbar vor dem Löschen, unter dem Wartungs-Lock.
        updateSafetyValidateSnapshot($root);
        updateSafetyValidateSnapshot($candidate);
        if (file_exists($candidate.'/rescue-pin.json')) continue;
        updateSafetyRemoveTree($candidate, dirname($candidate));
    }
}

function updateSafetyCleanupSuccess(array $state, string $root): array {
    $warnings = [];
    if (($state['state'] ?? '') !== 'complete' || !empty($state['mutating'])) {
        return ['Keine Bereinigung: Wartungsvorgang ist nicht erfolgreich abgeschlossen.'];
    }
    // Nur dieser erfolgreiche Arbeitsordner, niemals Fehler-/Fremdordner.
    foreach (['package.zip','stage','config_migration.php'] as $name) {
        try {
            if (file_exists($state['work'].'/'.$name)) updateSafetyRemoveTree($state['work'].'/'.$name, $state['work']);
        } catch (Throwable $e) { $warnings[] = $name.' konnte nicht bereinigt werden.'; }
    }
    try { updateSafetyPruneSuccessfulSnapshots($root); }
    catch (Throwable $e) { $warnings[] = 'Alte Sicherungen bleiben erhalten: '.$e->getMessage(); }
    return $warnings;
}

function updateSafetyValidateSnapshot(string $root): array {
    $meta = updateSafetyReadJson($root.'/metadata.json');
    if (($meta['format'] ?? null) !== 1 || empty($meta['application_files']) || empty($meta['database_objects']['tables'])) {
        throw new RuntimeException('Sicherung besitzt keinen vollständigen Prüfnachweis. Sie bleibt unverändert erhalten: '.$root);
    }
    foreach (['tables','views','procedures','functions','events','triggers'] as $kind) {
        if (!isset($meta['database_objects'][$kind]) || !is_array($meta['database_objects'][$kind])) {
            throw new RuntimeException('Objektinventar der Datenbanksicherung ist unvollständig: '.$root);
        }
        foreach ($meta['database_objects'][$kind] as $name) {
            if (!is_string($name) || $name === '') throw new RuntimeException('Ungültiger Objektname in der Datenbanksicherung.');
        }
    }
    updateSafetyRequireFiles($root.'/app', ['config.php', 'functions.php', 'version.php', 'db.php']);
    if ($meta['application_files'] !== updateSafetyInventory($root.'/app') ||
        !hash_equals((string)($meta['database_sha256'] ?? ''), updateSafetyDumpCheck($root.'/database.sql'))) {
        throw new RuntimeException('Prüfsummen der Sicherung stimmen nicht überein: '.$root);
    }
    return $meta;
}

/** Alte Generation bleibt erhalten; fehlgeschlagene Aktivierung wird zurückgenommen. */
function updateSafetyActivate(string $candidate, string $root): void {
    updateSafetyValidateSnapshot($candidate);
    $old = $root.'_previous_'.bin2hex(random_bytes(8));
    if (file_exists($root) && !@rename($root, $old)) throw new RuntimeException('Bisherige Rollback-Sicherung konnte nicht archiviert werden.');
    if (!@rename($candidate, $root)) {
        $restored = !is_dir($old) || @rename($old, $root);
        throw new RuntimeException('Neue Rollback-Sicherung konnte nicht aktiviert werden. '.($restored ? 'Bisherige Sicherung bleibt verfügbar.' : 'Bisherige Sicherung liegt unter '.$old));
    }
}

function updateSafetyRestoreDatabase(string $snapshot, string $log): void {
    $meta = updateSafetyValidateSnapshot($snapshot);
    $normalized = $log.'.normalized.sql';
    if (!copy($snapshot.'/database.sql', $normalized)) throw new RuntimeException('Datenbanksicherung konnte für den Restore nicht vorbereitet werden.');
    try {
        updateSafetyNormalizeDump($normalized);
        updateSafetyDumpCheck($normalized);
    } catch (Throwable $e) { @unlink($normalized); throw $e; }
    // Der Dump löscht/erstellt enthaltene Tabellen. Neu hinzugekommene Objekte
    // werden separat entfernt, damit kein Mischschema zurückbleibt.
    $pdo = updateSafetyDb();
    $current = updateSafetyObjects($pdo);
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try {
        foreach (['views' => 'VIEW', 'triggers' => 'TRIGGER', 'events' => 'EVENT', 'procedures' => 'PROCEDURE', 'functions' => 'FUNCTION', 'tables' => 'TABLE'] as $kind => $sqlType) {
            foreach (array_diff($current[$kind], $meta['database_objects'][$kind]) as $name) {
                $pdo->exec('DROP '.$sqlType.' `'.str_replace('`', '``', $name).'`');
            }
        }
    } finally {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    }
    try {
        updateSafetyRun(array_merge(updateSafetyDbArgs(updateSafetyBinary(['mariadb', 'mysql'])), [DB_NAME]), $log, $normalized, null, updateSafetyDbEnv());
    } finally {
        @unlink($normalized);
    }
    if (updateSafetyObjects(updateSafetyDb()) !== $meta['database_objects']) {
        throw new RuntimeException('Datenbank-Restore wurde ausgeführt, aber das Objektinventar stimmt nicht mit der Sicherung überein.');
    }
}

function updateSafetyRestoreApplication(string $snapshot, string $app, string $log): void {
    $meta = updateSafetyValidateSnapshot($snapshot);
    $appReal = realpath($app);
    $snapshotReal = realpath($snapshot);
    if ($appReal === false || $snapshotReal === false || $appReal === DIRECTORY_SEPARATOR ||
        $appReal === $snapshotReal || str_starts_with($snapshotReal, $appReal.DIRECTORY_SEPARATOR) ||
        str_starts_with($appReal, $snapshotReal.DIRECTORY_SEPARATOR)) {
        throw new RuntimeException('Anwendung und Rettungskopie müssen in getrennten Verzeichnissen liegen.');
    }
    $actual = updateSafetyInventory($app);
    updateSafetyRequireWritableApplication($app, $actual);
    // Nur zusätzliche Einträge im Ziel löschen, niemals die Rettungskopie.
    $extra = array_diff_key($actual, $meta['application_files']);
    uksort($extra, fn($a, $b) => strlen($b) <=> strlen($a));
    foreach ($extra as $name => $entry) {
        $ok = $entry['type'] === 'directory' ? rmdir($app.'/'.$name) : unlink($app.'/'.$name);
        if (!$ok) throw new RuntimeException('Zusätzliche Update-Datei konnte nicht entfernt werden: '.$name);
    }
    updateSafetyCopy($snapshot.'/app/.', $app, $log);
    if (updateSafetyInventory($app) !== $meta['application_files']) throw new RuntimeException('Anwendungs-Restore stimmt nicht mit der Sicherung überein.');
    if (function_exists('opcache_reset')) opcache_reset();
}

/** Beide Teile versuchen, auch wenn einer scheitert. Nie Erfolg vortäuschen. */
function updateSafetyRecover(string $snapshot, string $app, string $work, ?callable $restoreDatabase = null, ?callable $restoreApplication = null): array {
    updateSafetyDirectory($work);
    // Optionale Adapter ermöglichen Fehlerfalltests ohne Datenbank oder Produktivpfade.
    $restoreDatabase ??= fn() => updateSafetyRestoreDatabase($snapshot, $work.'/restore_database.log');
    $restoreApplication ??= fn() => updateSafetyRestoreApplication($snapshot, $app, $work.'/restore_application.log');
    $errors = [];
    try { $restoreDatabase(); }
    catch (Throwable $e) { $errors[] = 'Datenbank: '.$e->getMessage(); }
    try { $restoreApplication(); }
    catch (Throwable $e) { $errors[] = 'Anwendung: '.$e->getMessage(); }
    return $errors;
}

function updateSafetyPackage(string $stage, string $expectedVersion, string $php, string $log): array {
    updateSafetyRequireFiles($stage, ['functions.php', 'version.php', 'db.php', 'index.php', 'api/update_install.php', 'api/update_rollback.php', 'update_safety.php']);
    $files = updateSafetyInventory($stage);
    foreach ($files as $name => $entry) {
        if (preg_match('~^(config\.php|\.env(?:\..*)?|\.git|tmp|temp|cache)(/|$)~', $name) ||
            (str_starts_with($name, 'uploads/') && $entry['type'] === 'file' && basename($name) !== '.htaccess')) {
            throw new RuntimeException('Updatepaket enthält lokale Konfiguration oder Laufzeitdaten: '.$name);
        }
        if ($entry['type'] === 'file' && str_ends_with($name, '.php')) updateSafetyRun([$php, '-n', '-l', $stage.'/'.$name], $log);
    }
    $version = (string)file_get_contents($stage.'/version.php');
    if (!preg_match('~(?:define\s*\(\s*[\'"]APP_VERSION[\'"]\s*,\s*|const\s+APP_VERSION\s*=\s*)[\'"]([^\'"]+)[\'"]~', $version, $match) || $match[1] !== $expectedVersion) {
        throw new RuntimeException('version.php stimmt nicht mit der Manifest-Version überein.');
    }
    return $files;
}

function updateSafetyUnpack(string $archive, string $stage): string {
    if (!class_exists('ZipArchive')) throw new RuntimeException('Die PHP-ZIP-Erweiterung fehlt.');
    $zip = new ZipArchive();
    if ($zip->open($archive) !== true) throw new RuntimeException('Updatepaket ist kein lesbares ZIP-Archiv.');
    try {
        $total = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = $stat['name'];
            $total += $stat['size'];
            $opsys = $attributes = 0;
            $zip->getExternalAttributesIndex($i, $opsys, $attributes);
            $type = ($attributes >> 16) & 0170000;
            if ($name === '' || str_contains($name, '\\') || str_contains($name, ':') || str_starts_with($name, '/') ||
                preg_match('~(^|/)\.{1,2}(/|$)|[\x00-\x1f]~', $name) ||
                ($opsys === 3 && !in_array($type, [0, 0100000, 0040000], true))) {
                throw new RuntimeException('Unsicherer Pfad oder Dateityp im Updatepaket.');
            }
            if ($total > 512 * 1024 * 1024 || $zip->numFiles > 20000) throw new RuntimeException('Updatepaket überschreitet die zulässige Größe.');
        }
        updateSafetyDirectory($stage);
        if (!$zip->extractTo($stage)) throw new RuntimeException('Updatepaket konnte nicht vollständig entpackt werden.');
    } finally { $zip->close(); }
    $entries = array_values(array_diff(scandir($stage), ['.', '..']));
    return count($entries) === 1 && is_dir($stage.'/'.$entries[0]) ? $stage.'/'.$entries[0] : $stage;
}

/** Gemeinsamer Fehler-/Shutdownpfad; Journal bleibt bei Rettungsfehlern gesperrt. */
function updateSafetyFailure(array &$state, string $journal, string $message): string {
    if (!empty($state['mutating'])) {
        $errors = updateSafetyRecover($state['snapshot'], $state['app'], $state['work']);
        $state['state'] = $errors ? 'recovery_failed' : 'recovered';
        $message .= $errors ? ' Automatische Wiederherstellung unvollständig: '.implode(' | ', $errors) : ' Anwendung und Datenbank wurden auf den gesicherten Zustand zurückgesetzt.';
    } else {
        $state['state'] = 'aborted';
        $message .= ' Die Installation hat Anwendung und Datenbank noch nicht verändert.';
    }
    $state['mutating'] = false;
    $state['error'] = $message;
    try { updateSafetyWriteJson($journal, $state); }
    catch (Throwable $e) { $message .= ' Ablaufstatus konnte nicht gespeichert werden; manuelle Prüfung erforderlich.'; }
    return $message.' Rettungsdateien bleiben erhalten: '.$state['work'].(!empty($state['snapshot']) ? ' ; '.$state['snapshot'] : '');
}

function updateSafetyShutdown(array &$state, string $journal): void {
    // Speicherreserve für eine bestmögliche Rettung bei PHP-Fatalfehlern.
    $reserve = str_repeat('x', 262144);
    register_shutdown_function(function () use (&$state, $journal, &$reserve): void {
        $reserve = null;
        if (!empty($state['mutating'])) {
            $message = updateSafetyFailure($state, $journal, 'Wartungsvorgang wurde unerwartet abgebrochen.');
            error_log($message);
            if (!headers_sent()) { http_response_code(500); header('Content-Type: application/json; charset=utf-8'); }
            echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
        }
    });
}
