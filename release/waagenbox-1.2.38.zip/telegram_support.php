<?php
declare(strict_types=1);

function telegramEnabled(): bool {
    return appSetting('telegram_enabled','0')==='1';
}

function telegramBotToken(): string {
    return trim(appSetting('telegram_bot_token',''));
}

function telegramChatId(): string {
    return trim(appSetting('telegram_chat_id',''));
}

function telegramConfigured(): bool {
    return telegramBotToken()!=='' && telegramChatId()!=='';
}

function telegramSendMessage(string $message): array {
    $token=telegramBotToken();
    $chatId=telegramChatId();
    if($token===''||$chatId==='') return ['ok'=>false,'error'=>'not_configured','message'=>'Telegram ist noch nicht vollständig konfiguriert.'];

    $url='https://api.telegram.org/bot'.$token.'/sendMessage';
    $payload=http_build_query([
        'chat_id'=>$chatId,
        'text'=>$message,
        'disable_web_page_preview'=>'true',
    ]);

    $body=false;
    $code=0;
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>$payload,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>4,
            CURLOPT_TIMEOUT=>8,
            CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_USERAGENT=>'AJP-Waagenbox/'.APP_VERSION,
        ]);
        $body=curl_exec($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $err=(string)curl_error($ch);
        curl_close($ch);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Telegram nicht erreichbar: '.$err];
    }else{
        $ctx=stream_context_create([
            'http'=>[
                'method'=>'POST',
                'header'=>"Content-Type: application/x-www-form-urlencoded\r\n",
                'content'=>$payload,
                'timeout'=>8,
                'ignore_errors'=>true,
            ],
            'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true],
        ]);
        $body=@file_get_contents($url,false,$ctx);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Telegram nicht erreichbar.'];
        foreach($http_response_header??[] as $line){
            if(preg_match('~^HTTP/\S+\s+(\d+)~',$line,$m)){ $code=(int)$m[1]; break; }
        }
    }

    $data=json_decode((string)$body,true);
    if($code<200||$code>=300||!is_array($data)||empty($data['ok'])){
        return ['ok'=>false,'error'=>'telegram_error','message'=>'Telegram hat die Nachricht nicht bestätigt.','http_status'=>$code];
    }
    return ['ok'=>true];
}

function feldmanagerTelegramHandleOutboundState(bool $connected): void {
    if(!telegramEnabled() || !telegramConfigured() || !feldmanagerEnabled()) return;

    $state=$connected?'connected':'error';
    $previous=appSetting('feldmanager_outbound_notify_state','');

    if($previous===''){
        saveAppSetting('feldmanager_outbound_notify_state',$state);
        return;
    }
    if($previous===$state) return;

    $brand=appSetting('brand_name','AJP WAAGE');
    $message=$connected
        ? "✅ Verbindung wiederhergestellt\n".$brand."\nWaagenbox → Feldmanager ist wieder verbunden."
        : "🚨 Verbindungsstörung\n".$brand."\nWaagenbox → Feldmanager ist nicht erreichbar.\nBitte Schlagzuordnung prüfen und bei Bedarf manuell reagieren.";

    $sent=telegramSendMessage($message);
    if(!empty($sent['ok'])){
        saveAppSetting('feldmanager_outbound_notify_state',$state);
    }else{
        error_log('Waagenbox Telegram: '.(string)($sent['message']??'Nachricht konnte nicht gesendet werden.'));
    }
}
