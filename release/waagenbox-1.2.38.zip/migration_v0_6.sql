-- WägeSoftware v0.6 – Mobile QR-Remote + GPS-Standortprüfung
SET NAMES utf8mb4;

ALTER TABLE remotes
  ADD COLUMN mobile_token CHAR(64) NULL AFTER code;

UPDATE remotes
SET mobile_token = SHA2(CONCAT(UUID(), '-', RAND(), '-', id), 256)
WHERE mobile_token IS NULL OR mobile_token = '';

ALTER TABLE remotes
  ADD UNIQUE KEY uq_remote_mobile_token (mobile_token);

-- Globale Standort-/GPS-Einstellungen werden in der vorhandenen settings-Tabelle gespeichert.
INSERT INTO settings (`key`,`value`) VALUES
 ('gps_enabled','1'),
 ('gps_lat',''),
 ('gps_lon',''),
 ('gps_radius_m','50'),
 ('gps_accuracy_m','50'),
 ('gps_check_second','0')
ON DUPLICATE KEY UPDATE `key`=`key`;
