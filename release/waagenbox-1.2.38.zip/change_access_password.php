<?php
require_once __DIR__.'/functions.php';
requireLogin();
$error=null;
$configured=accessPasswordConfigured();
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    $old=(string)($_POST['old_password']??'');$new=(string)($_POST['new_password']??'');$confirm=(string)($_POST['confirm_password']??'');
    if($configured && !password_verify($old,accessPasswordHash())) throw new RuntimeException('Das bisherige Passwort ist nicht korrekt.');
    if(strlen($new)<4) throw new RuntimeException('Das neue Passwort muss mindestens 4 Zeichen lang sein.');
    if($new!==$confirm) throw new RuntimeException('Die neuen Passwörter stimmen nicht überein.');
    saveAccessPasswordHash(password_hash($new,PASSWORD_DEFAULT));
    flash('Passwort wurde geändert.');redirect('settings.php?tab=zugang');
  }catch(Throwable $e){$error=$e->getMessage();}
}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Passwort ändern – AJP Waage</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page"><div class="login-card card"><div class="brand">AJPnaturenergie</div><h1><?= $configured ? 'Passwort ändern' : 'Zugangspasswort festlegen' ?></h1><?php if($error): ?><div class="flash error"><?=h($error)?></div><?php endif; ?><form method="post"><?php if($configured): ?><?php if($configured): ?><label>Bisheriges Passwort</label><input type="password" name="old_password" required autocomplete="current-password"><?php endif; ?><?php endif; ?><label style="margin-top:14px">Neues Passwort</label><input type="password" name="new_password" minlength="4" required autocomplete="new-password"><label style="margin-top:14px">Neues Passwort wiederholen</label><input type="password" name="confirm_password" minlength="4" required autocomplete="new-password"><p><button class="button primary">Passwort speichern</button> <a class="button" href="settings.php?tab=zugang">Abbrechen</a></p></form></div></body></html>
