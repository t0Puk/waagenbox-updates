<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/rf_remote_support.php';

$args = array_slice($argv, 1);
$dryRun = in_array('--dry-run', $args, true);
$args = array_values(array_filter($args, static fn(string $arg): bool => $arg !== '--dry-run'));

if (count($args) !== 1) {
    fwrite(STDERR, "Verwendung: php cli/rf_remote_trigger.php <code> [--dry-run]" . PHP_EOL);
    exit(64);
}

$code = (string)$args[0];
$result = triggerRfRemoteCode($code, $dryRun);

$message = $result['message'] ?? 'Unbekanntes Ergebnis.';
$status = $result['status'] ?? 'error';

if (!empty($result['ok'])) {
    $prefix = $dryRun ? 'RF DRY-RUN ' : 'RF ';
    fwrite(STDOUT, $prefix . $code . ': ' . $message . PHP_EOL);

    if ($dryRun) {
        $details = [
            'remote_id'=>$result['remote_id'] ?? null,
            'vehicle_id'=>$result['vehicle_id'] ?? null,
            'field_id'=>$result['field_id'] ?? null,
            'customer_id'=>$result['customer_id'] ?? null,
            'product_id'=>$result['product_id'] ?? null,
        ];
        fwrite(STDOUT, 'Details: ' . json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL);
    }

    exit(0);
}

// Unknown 433 MHz traffic is expected and remains a quiet rejection.
if ($status === 'unknown') {
    fwrite(STDOUT, 'RF ' . $code . ': ignoriert (unknown)' . PHP_EOL);
    exit(2);
}

fwrite(STDERR, 'RF ' . $code . ': ' . $message . ' (' . $status . ')' . PHP_EOL);
exit(3);
