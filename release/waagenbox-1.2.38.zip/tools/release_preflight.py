#!/usr/bin/python3
"""Check paths that would actually be exported into a release archive."""
import io
import json
from pathlib import PurePosixPath
import re
import subprocess
import tarfile


def allowed(name):
    if not name or "\\" in name or ":" in name or name.startswith("/"):
        return False

    parts = PurePosixPath(name).parts

    if any(part in (".", "..") for part in name.split("/")):
        return False

    lower = name.lower()
    base = parts[-1].lower()

    if any(
        part.lower()
        in (
            ".git",
            ".ssh",
            "__pycache__",
            "backups",
            "rollback",
            "tmp",
            "temp",
            "cache",
        )
        for part in parts
    ):
        return False

    if parts[0].lower() == "uploads":
        return False

    if (
        base == "config.php"
        or base.startswith(".env")
        or re.fullmatch(r"id_(rsa|dsa|ecdsa|ed25519)", base)
    ):
        return False

    if lower.endswith(
        (
            ".key",
            ".pem",
            ".ppk",
            ".p12",
            ".pfx",
            ".sql.gz",
            ".bak",
            ".backup",
            ".dump",
            ".old",
            ".orig",
            ".pyc",
        )
    ):
        return False

    if lower.endswith(".sql") and not (
        name == "schema.sql"
        or re.fullmatch(r"migration_[A-Za-z0-9_]+\.sql", name)
    ):
        return False

    return True


def exported_names():
    archive = subprocess.check_output(
        ["git", "archive", "--format=tar", "HEAD"]
    )

    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as tar:
        return [
            member.name.rstrip("/")
            for member in tar.getmembers()
            if member.name.rstrip("/")
        ]


if __name__ == "__main__":
    names = exported_names()

    rejected = [
        name
        for name in names
        if not allowed(name)
    ]

    print(
        json.dumps(
            {
                "ok": not rejected,
                "rejected": rejected,
                "checked_exported_paths": len(names),
                "zip_created": False,
            }
        )
    )

    raise SystemExit(1 if rejected else 0)
