"""Installer preflight tests with no root, package manager or system writes."""
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('installer', ROOT / 'install_service_components.py')
installer = importlib.util.module_from_spec(spec)
with patch.dict(sys.modules, {'pwd': SimpleNamespace(getpwnam=lambda name: SimpleNamespace(pw_dir='/home/pi'))}):
    spec.loader.exec_module(installer)


class InstallerTest(unittest.TestCase):
    def scenario(self, connection='', unmanaged='', link='', info='', active='inactive'):
        calls = []

        def run(*args):
            calls.append(args)
            if 'GENERAL.CON-UUID' in args:
                return connection
            if '--print-config' in args:
                return '[keyfile]\nunmanaged-devices=' + unmanaged
            if args[-1] == 'link':
                return link
            if args[-1] == 'info':
                return info
            if 'show' in args:
                return active
            if 'is-active' in args:
                return active
            return ''

        with patch.object(installer.os, 'geteuid', return_value=0, create=True), \
             patch.object(installer.os, 'access', return_value=True), \
             patch.object(installer.os.path, 'isfile', return_value=True), \
             patch.object(installer, 'safe_path'), patch.object(installer, 'run', side_effect=run), \
             patch.object(installer, 'put') as put, patch.object(installer, 'check', return_value=0), \
             patch.object(installer.Path, 'mkdir'), patch.object(installer.Path, 'chmod'):
            try:
                result = installer.install()
            except ValueError as error:
                result = str(error)
        return result, calls, put

    def test_busy_nm_aborts_before_writes(self):
        result, calls, put = self.scenario(connection='synthetic-existing-uuid')
        self.assertIn('active NetworkManager', result)
        put.assert_not_called()
        self.assertEqual(len(calls), 1)

    def test_existing_unmanaged_devices_not_overwritten(self):
        result, _, put = self.scenario(unmanaged='interface-name:eth1')
        self.assertIn('manual integration', result)
        put.assert_not_called()

    def test_foreign_connections_rejected(self):
        for values in ({'link': 'Connected to test'}, {'info': 'type AP'}):
            result, _, put = self.scenario(**values)
            self.assertIn('another connection', result)
            put.assert_not_called()

    def test_reinstallation_preserves_enabled_state(self):
        for active, info in (('inactive', ''), ('active', 'type AP')):
            result, calls, put = self.scenario(unmanaged='interface-name:wlan0', active=active, info=info)
            self.assertEqual(result, 0)
            self.assertEqual(put.call_count, len(installer.FILES) + 1)
            self.assertIn(('/usr/bin/systemctl', 'daemon-reload'), calls)
            self.assertIn(('/usr/bin/nmcli', 'general', 'reload', 'conf'), calls)
            for call in calls:
                self.assertFalse(any(action in call for action in ('enable', 'disable', 'start', 'stop', 'restart')))
            self.assertNotIn('/etc/waagenbox/service-wlan/hostapd.conf', [call.args[0] for call in put.call_args_list])

    def test_sources_have_linux_line_endings(self):
        for source in installer.FILES:
            self.assertNotIn(b'\r', (ROOT / source).read_bytes(), source)


if __name__ == '__main__':
    unittest.main()
