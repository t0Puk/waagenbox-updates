<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$installer = file_get_contents($root.'/api/update_install.php');

if ($installer === false) {
    fwrite(STDERR, "FAIL Installer konnte nicht gelesen werden.\n");
    exit(1);
}

$checks = 0;

function ok(bool $condition, string $message): void
{
    global $checks;

    if (!$condition) {
        fwrite(STDERR, "FAIL {$message}\n");
        exit(1);
    }

    $checks++;
    echo "PASS {$message}\n";
}

ok(
    str_contains(
        $installer,
        "if (!function_exists('requireCsrfToken'))"
    ),
    'bootstrap rejects missing CSRF helper cleanly'
);

ok(
    str_contains(
        $installer,
        "Update-Bootstrap ist unvollständig"
    ),
    'bootstrap provides clear compatibility error'
);

ok(
    str_contains(
        $installer,
        "/^migration_v(\\d+(?:_\\d+){1,2})(?:_[A-Za-z][A-Za-z0-9_-]*)?\\.sql$/"
    ),
    'migration matcher accepts two- and three-component versions'
);

$pattern = '/^migration_v(\d+(?:_\d+){1,2})(?:_[A-Za-z][A-Za-z0-9_-]*)?\.sql$/';

$valid = [
    'migration_v0_5.sql' => '0_5',
    'migration_v1_0_production.sql' => '1_0',
    'migration_v1_2_3_web.sql' => '1_2_3',
    'migration_v1_2_27.sql' => '1_2_27',
    'migration_v1_2_27_hotfix_1.sql' => '1_2_27',
];

foreach ($valid as $name => $expected) {
    $matched = preg_match($pattern, $name, $m) === 1;
    ok($matched, "migration accepted: {$name}");
    ok(($m[1] ?? null) === $expected, "migration version parsed: {$name}");
}

$invalid = [
    'migration.sql',
    'migration_v1.sql',
    'migration_v1_2_3_4.sql',
    'migration_v1_2_3_99.sql',
    'migration_v1_2_3_4_web.sql',
    'migration_v1_2!.sql',
    'migration_vx_y.sql',
];

foreach ($invalid as $name) {
    ok(
        preg_match($pattern, basename($name), $m) !== 1,
        "invalid migration rejected: {$name}"
    );
}

function normalizedVersion(string $captured): string
{
    $parts = explode('_', $captured);
    while (count($parts) < 3) $parts[] = '0';
    return implode('.', $parts);
}

ok(normalizedVersion('1_0') === '1.0.0', 'legacy two-part migration normalizes to 1.0.0');
ok(normalizedVersion('1_2_3') === '1.2.3', 'three-part migration remains unchanged');

echo "RESULT {$checks} updater-v2 checks passed\n";
