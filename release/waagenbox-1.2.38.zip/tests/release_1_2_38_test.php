<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$checks=0;
function ok138(bool $condition,string $label):void{
    global $checks;
    if(!$condition){fwrite(STDERR,"FAIL $label\n");exit(1);}
    $checks++;
    echo "PASS $label\n";
}
function read138(string $path):string{
    $v=file_get_contents($path);
    if($v===false){fwrite(STDERR,"FAIL Datei nicht lesbar: $path\n");exit(1);}
    return $v;
}

$version=read138($root.'/version.php');
$functions=read138($root.'/functions.php');
$link=read138($root.'/feldmanager_link.php');
$settings=read138($root.'/settings.php');
$remoteEdit=read138($root.'/remote_edit.php');
$remotes=read138($root.'/remotes.php');
$dashboard=read138($root.'/index.php');
$dashboardStatus=read138($root.'/api/dashboard_status.php');
$style=read138($root.'/assets/style.css');
$telegram=read138($root.'/telegram_support.php');
$reportWeighing=read138($root.'/reports/weighing.php');
$mobileRemote=read138($root.'/mobile_remote.php');

ok138(str_contains($version,"APP_VERSION = '1.2.38'"),'Version ist 1.2.38');
ok138(str_contains($functions,"require_once __DIR__.'/feldmanager_link.php';"),'Feldmanager-Client wird zentral geladen');
ok138(str_contains($functions,'$fieldId=feldmanagerAutomaticFieldId($fieldId,$remoteId);'),'Neue Wiegungen übergeben Fernbedienungskontext an Feldmanager-Zuordnung');
ok138(str_contains($link,"appSetting('feldmanager_enabled','0')==='1'"),'Automatik ist per Einstellung schaltbar');
ok138(str_contains($link,"X-AJP-Waagenbox-Token"),'API-Zugriff verwendet separaten Token');
ok138(str_contains($link,"preg_match('~^https://~i"),'Feldmanager-Verbindung verlangt HTTPS');
ok138(str_contains($link,"waagenbox_active_field.php"),'Aktiver Feldmanager-Schlag wird abgefragt');
ok138(str_contains($link,"waagenbox_teams.php"),'Aktive Feldmanager-Teams werden abgefragt');
ok138(str_contains($link,"feldmanager_remote_team_map"),'Fernbedienungsbezogene Team-Zuordnung ist vorhanden');
ok138(!str_contains($link,"feldmanagerFieldMap()"),'Manuelle Schlag-ID-Zuordnung wird nicht mehr verwendet');
ok138(str_contains($link,"LOWER(TRIM(name))=LOWER(TRIM(?))"),'Fallback kann eindeutig nach Schlagname zuordnen');
ok138(str_contains($link,"state'=>'ambiguous'"),'Mehrere aktive Schläge werden nicht blind übernommen');
ok138(str_contains($link,'return $fallbackFieldId;'),'Bei nicht eindeutiger Automatik bleibt bestehende Zuordnung erhalten');
ok138(str_contains($link,'!$remoteId || $remoteId<=0'),'Wiegungen ohne Fernbedienung bleiben außerhalb der Team-Automatik');
ok138(str_contains($settings,"tab=feldmanager"),'Einstellungen enthalten Feldmanager-Reiter');
ok138(str_contains($settings,"Automatische Schlagzuordnung über Feldmanager aktiv"),'Automatik lässt sich in der Oberfläche aktivieren');
ok138(!str_contains($settings,"vehicle_team["),'Fahrzeug-Team-Zuordnung wurde aus Einstellungen entfernt');
ok138(!str_contains($settings,"field_map["),'Manuelle Schlag-Zuordnung wurde aus Einstellungen entfernt');
ok138(str_contains($settings,'requireCsrfToken();'),'Feldmanager-Einstellungen sind CSRF-geschützt');
ok138(str_contains($settings,"requireAdmin();"),'Feldmanager-Einstellungen sind admin-geschützt');
ok138(str_contains($settings,"Token gespeichert – leer lassen zum Beibehalten"),'Gespeicherter API-Token wird nicht im Formular ausgegeben');
ok138(str_contains($remoteEdit,"feldmanager_team"),'Feldmanager-Team kann in Fernbedienungs-Zuordnungen gewählt werden');
ok138(str_contains($remoteEdit,"feldmanagerTeams()"),'Fernbedienungs-Zuordnung lädt nur Teams aus Feldmanager');
ok138(str_contains($remotes,"<th>Feldmanager-Team</th>"),'Fernbedienungsübersicht zeigt Feldmanager-Team');
ok138(str_contains($remotes,"feldmanagerRemoteTeamMap()"),'Fernbedienungsübersicht verwendet gespeicherte Team-Zuordnung');
ok138(str_contains($link,"waagenbox_monitor.php"),'Waagenbox besitzt Feldmanager-Zwei-Richtungs-Monitor');
ok138(str_contains($dashboard,"id=\"feldmanagerOutboundLed\""),'Dashboard zeigt Waagenbox-zu-Feldmanager-LED');
ok138(str_contains($dashboard,"id=\"feldmanagerInboundLed\""),'Dashboard zeigt Feldmanager-zu-Waagenbox-LED');
ok138(str_contains($dashboardStatus,"'feldmanager_outbound_state'=>\$feldmanagerOutboundState"),'Dashboard-API meldet Waagenbox-zu-Feldmanager-Status');
ok138(str_contains($dashboardStatus,"'feldmanager_inbound_state'=>\$feldmanagerInboundState"),'Dashboard-API meldet Feldmanager-zu-Waagenbox-Status');
ok138(str_contains($dashboardStatus,"feldmanagerMonitor()"),'Dashboard nutzt Zwei-Richtungs-Monitor nur bei aktiver Automatik');
ok138(str_contains($style,".feldmanager-led.connected"),'Feldmanager-LED hat grünen Verbindungsstatus');
ok138(str_contains($style,".feldmanager-led.error"),'Feldmanager-LED hat roten Fehlerstatus');
ok138(str_contains($style,".feldmanager-led.off"),'Feldmanager-LED hat ausgeschalteten Status');
ok138(str_contains($style,".feldmanager-led.unknown"),'Feldmanager-LED hat unbekannten Prüfstatus');
ok138(str_contains($functions,"require_once __DIR__.'/telegram_support.php';"),'Telegram-Unterstützung wird zentral geladen');
ok138(str_contains($settings,"tab=telegram"),'Einstellungen enthalten Telegram-Reiter');
ok138(str_contains($settings,"Telegram-Benachrichtigungen aktiv"),'Telegram lässt sich in der Oberfläche aktivieren');
ok138(str_contains($settings,"Testnachricht senden"),'Telegram-Testnachricht ist in der Oberfläche verfügbar');
ok138(str_contains($settings,"Token gespeichert – leer lassen zum Beibehalten"),'Telegram-Bot-Token wird nicht im Formular ausgegeben');
ok138(str_contains($telegram,"api.telegram.org/bot"),'Telegram-Nachrichten verwenden die offizielle HTTPS-Bot-API');
ok138(str_contains($telegram,"feldmanager_outbound_notify_state"),'Telegram speichert den letzten Waagenbox-zu-Feldmanager-Zustand');
ok138(str_contains($telegram,'$previous===$state'),'Telegram verhindert wiederholte Meldungen ohne Zustandswechsel');
ok138(str_contains($dashboardStatus,"feldmanagerTelegramHandleOutboundState"),'Dashboard löst Telegram-Prüfung für Waagenbox-zu-Feldmanager aus');
ok138(str_contains($reportWeighing,'onclick="window.close()"'),'Wiegeschein besitzt Schließen-Button für das neue Fenster');
ok138(!str_contains($reportWeighing,'Zur Wiegescheinübersicht'),'Wiegeschein öffnet nicht erneut die Wiegescheinübersicht');
ok138(str_contains($settings,"contact_phone"),'Allgemeine Einstellungen enthalten Kontakt-Telefonnummer');
ok138(str_contains($settings,"contact_enabled"),'Kontakt-Link für QR-Fernbedienungen ist schaltbar');
ok138(!str_contains($mobileRemote,'Mobile Waage'),'QR-Fernbedienung zeigt den Untertitel Mobile Waage nicht mehr');
ok138(str_contains($mobileRemote,'href="tel:'),'QR-Fernbedienung besitzt anklickbaren Telefonkontakt');
ok138(str_contains($mobileRemote,'$showContact'),'QR-Kontakt wird nur bei aktivierter Einstellung angezeigt');
ok138(str_contains($mobileRemote,"appSetting('brand_name','AJP WAAGE')"),'QR-Fernbedienung verwendet den konfigurierten Namen der Waage');
ok138(str_contains($style,'.mobile-contact{display:flex;justify-content:center'),'QR-Kontakt wird mittig ausgerichtet');
ok138(str_contains($mobileRemote,"filemtime(__DIR__.'/assets/style.css')"),'QR-Fernbedienung lädt Stylesheet mit Cache-Busting');


$status=read138($root.'/api/feldmanager_status.php');
ok138(str_contains($status,'X_AJP_FELDMANAGER_TOKEN'),'Feldmanager kann Waagenbox-Status token-geschützt prüfen');
ok138(str_contains($status,"'integration_enabled'=>feldmanagerEnabled()"),'Waagenbox meldet, ob Feldmanager-Automatik tatsächlich aktiv ist');
ok138(str_contains($status,"'team_numbers'=>\$configuredTeams"),'Waagenbox meldet konfigurierte Fernbedienungs-Teams');

echo "RESULT $checks checks passed\n";
