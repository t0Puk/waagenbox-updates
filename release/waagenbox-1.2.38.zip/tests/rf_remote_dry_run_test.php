<?php
declare(strict_types=1);

$pendingCalls = 0;
$lastPendingArgs = null;

// Prevent rf_remote_support.php from loading the real application bootstrap.
function db() {
    throw new RuntimeException('db() must not be called by this isolated unit test.');
}

function setPendingWeighing(
    float $first,
    ?int $vehicleId = null,
    ?int $remoteId = null,
    string $trigger = 'manual',
    ?int $fieldId = null,
    ?int $customerId = null,
    ?int $productId = null
): void {
    global $pendingCalls, $lastPendingArgs;
    $pendingCalls++;
    $lastPendingArgs = [$first, $vehicleId, $remoteId, $trigger, $fieldId, $customerId, $productId];
}

require_once dirname(__DIR__) . '/rf_remote_support.php';

final class FakeRfPdo extends PDO {
    public array $execStatements = [];

    public function __construct() {}

    public function exec(string $statement): int|false {
        $this->execStatements[] = $statement;
        return 0;
    }
}

function assertSameValue(mixed $expected, mixed $actual, string $message): void {
    if ($expected !== $actual) {
        fwrite(STDERR, "FAIL: {$message}\nExpected: " . var_export($expected, true) . "\nActual: " . var_export($actual, true) . "\n");
        exit(1);
    }
}

function assertTrueValue(bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
}

$pdo = new FakeRfPdo();
$plan = [
    'owner_id'=>1,
    'remote_id'=>7,
    'vehicle_id'=>11,
    'first_weight'=>12345.0,
    'field_id'=>21,
    'customer_id'=>31,
    'product_id'=>41,
];

$dry = rfRemoteExecutePlan($pdo, $plan, true);

assertTrueValue($dry['ok'] === true, 'Dry-run must succeed for a validated plan.');
assertSameValue('dry_run', $dry['status'], 'Dry-run status must be dry_run.');
assertSameValue(7, $dry['remote_id'], 'Remote ID must be reported.');
assertSameValue(11, $dry['vehicle_id'], 'Vehicle ID must be reported.');
assertSameValue(21, $dry['field_id'], 'Field ID must be reported.');
assertSameValue(31, $dry['customer_id'], 'Customer ID must be reported.');
assertSameValue(41, $dry['product_id'], 'Product ID must be reported.');
assertSameValue(0, $pendingCalls, 'Dry-run must never call setPendingWeighing().');
assertSameValue([], $pdo->execStatements, 'Dry-run must not change the DB owner context.');

$live = rfRemoteExecutePlan($pdo, $plan, false);

assertTrueValue($live['ok'] === true, 'Live execution must succeed for a validated plan.');
assertSameValue('started', $live['status'], 'Live status must be started.');
assertSameValue(1, $pendingCalls, 'Live execution must call setPendingWeighing exactly once.');
assertSameValue(
    [12345.0, 11, 7, 'radio', 21, 31, 41],
    $lastPendingArgs,
    'Live execution must pass the complete RF weighing plan.'
);
assertSameValue(['SET @ajp_user_id = 1'], $pdo->execStatements, 'Live execution must set owner context once.');

echo "RF dry-run tests: OK\n";
