"""Portable tests: no real browser or desktop changes."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('kiosk', ROOT / 'deploy/install-kiosk-autostart.py')
kiosk = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kiosk)


class KioskTest(unittest.TestCase):
    def test_preserves_existing_autostart_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            path = home / '.config/labwc/autostart'
            path.parent.mkdir(parents=True)
            existing = '#!/bin/sh\ncustom-panel &\n# keep this'
            path.write_text(existing)
            kiosk.install(home)
            first = path.read_bytes()
            kiosk.install(home)
            self.assertEqual(first, path.read_bytes())
            self.assertTrue(path.read_text().startswith(existing))
            self.assertEqual(path.read_text().count(kiosk.LINE), 1)

    def test_fresh_install_does_not_duplicate_rpd_system_autostart(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            kiosk.install(home)
            text = (home / '.config/labwc/autostart').read_text()
            self.assertNotIn('. /etc/xdg/labwc/autostart', text)
            self.assertIn('rpd-labwc', text)
            self.assertIn(kiosk.LINE, text)

    def test_launcher(self):
        text = (ROOT / 'deploy/waagenbox-kiosk').read_text()
        for value in ('[ "$(id -un)" = pi ]', 'WAYLAND_DISPLAY', 'flock -n 9', 'while :; do',
                      'until /usr/bin/curl', '--noproxy', '--max-time 5', '/usr/bin/chromium',
                      '--ozone-platform=wayland', '--kiosk', '--no-first-run', '--password-store=basic',
                      '--disable-session-crashed-bubble', 'http://127.0.0.1/'):
            self.assertIn(value, text)
        self.assertNotIn('--no-sandbox', text)
        self.assertNotIn('https://', text)
        self.assertLess(text.index('until /usr/bin/curl'), text.index('/usr/bin/chromium'))

    def test_installer_scoped_and_separate(self):
        text = (ROOT / 'install_service_components.py').read_text()
        self.assertIn('NOPASSWD: /usr/local/sbin/waagenbox-service-wlan ""', text)
        self.assertIn("'/usr/sbin/visudo', '-cf'", text)
        self.assertIn("'/usr/sbin/runuser', '-u', 'pi'", text)
        self.assertIn("'daemon-reload'", text)
        self.assertIn("'general', 'reload', 'conf'", text)
        self.assertNotIn('/var/www/waage', text)
        self.assertNotIn('lightdm.conf', text)
        self.assertNotIn("'restart'", text)
        self.assertNotIn("'enable'", text)
        self.assertIn("'--check'", text)


if __name__ == '__main__':
    unittest.main()
