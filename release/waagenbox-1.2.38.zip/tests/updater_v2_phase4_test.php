<?php
declare(strict_types=1);

$checks = 0;

function p4(bool $ok, string $message): void
{
    global $checks;

    if (!$ok) {
        fwrite(STDERR, "FAIL {$message}\n");
        exit(1);
    }

    $checks++;
    echo "PASS {$message}\n";
}

$install = file_get_contents(
    __DIR__.'/../api/update_install.php'
);

$rollback = file_get_contents(
    __DIR__.'/../api/update_rollback.php'
);

$client = file_get_contents(
    __DIR__.'/../deploy/deploy_client.php'
);

$helper = file_get_contents(
    __DIR__.'/../deploy/waagenbox-deploy-helper.php'
);

$transaction = file_get_contents(
    __DIR__.'/../deploy/update_transaction.php'
);

p4(
    str_contains(
        $install,
        "deploy/update_transaction.php"
    ),
    'installer loads transaction bridge'
);

p4(
    str_contains(
        $rollback,
        "deploy/update_transaction.php"
    ),
    'rollback loads transaction bridge'
);

p4(
    str_contains(
        $install,
        "waagenboxDeploySnapshot()"
    ),
    'installer creates root snapshot before mutation'
);

p4(
    str_contains(
        $install,
        "waagenboxDeployInstall("
    ),
    'installer delegates application mutation to root helper'
);

p4(
    !str_contains(
        $install,
        "updateSafetyRequireWritableApplication("
    ),
    'installer no longer requires web-writable application'
);

p4(
    !str_contains(
        $install,
        "updateSafetyMigrateConfig("
    ),
    'installer no longer mutates config as web user'
);

p4(
    !str_contains(
        $install,
        'updateSafetyCopy($stage'
    ),
    'installer no longer copies stage directly into application'
);

p4(
    str_contains(
        $install,
        "'signature_url'"
    ),
    'installer requires detached signature URL'
);

p4(
    str_contains(
        $install,
        "waagenboxUpdateFailure("
    ),
    'installer uses combined recovery'
);

p4(
    str_contains(
        $rollback,
        "waagenboxDeployRestore("
    ),
    'manual rollback delegates application restore to root helper'
);

p4(
    !str_contains(
        $rollback,
        "updateSafetyRestoreApplication("
    ),
    'manual rollback no longer restores app as web user'
);

p4(
    str_contains(
        $rollback,
        "waagenboxUpdateFailure("
    ),
    'manual rollback uses combined recovery'
);

p4(
    str_contains(
        $client,
        "function waagenboxDeploySnapshot"
    ),
    'deploy client exposes snapshot action'
);

p4(
    str_contains(
        $helper,
        "\$action === 'snapshot'"
    ),
    'root helper supports snapshot action'
);

p4(
    str_contains(
        $transaction,
        "function waagenboxUpdateRecover"
    ),
    'combined recovery function exists'
);

p4(
    str_contains(
        $transaction,
        "updateSafetyRestoreDatabase("
    ) &&
    str_contains(
        $transaction,
        "waagenboxDeployRestore("
    ),
    'combined recovery restores DB and app independently'
);

p4(
    str_contains(
        $transaction,
        "function waagenboxUpdateShutdown"
    ),
    'helper-aware shutdown recovery exists'
);

echo "RESULT {$checks} phase-4 static checks passed\n";
