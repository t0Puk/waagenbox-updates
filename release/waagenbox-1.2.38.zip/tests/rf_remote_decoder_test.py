#!/usr/bin/env python3
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "hardware" / "rf_remote_listener.py"

spec = importlib.util.spec_from_file_location("rf_remote_listener", MODULE_PATH)
rf = importlib.util.module_from_spec(spec)
assert spec.loader is not None
sys.modules[spec.name] = rf
spec.loader.exec_module(rf)


class RfRemoteDecoderTest(unittest.TestCase):
    def setUp(self):
        # Real clean capture from the first tested AJP 433 MHz handset.
        # 48 data pulses + short closing pulse before the sync gap.
        self.frame = [
            410,1095,1183,345,412,1080,402,1112,1169,352,404,1095,
            412,1093,407,1087,416,1082,414,1094,398,1103,396,1095,
            412,1087,415,1084,1179,360,395,1097,1172,357,389,1104,
            1167,363,391,1108,401,1109,377,1110,411,1103,1152,373,
            385,
        ]

    def test_real_handset_code(self):
        self.assertEqual(rf.decode_frame(self.frame), 4719265)

    def test_shifted_frame_is_rejected(self):
        shifted = self.frame[1:] + [400]
        self.assertIsNone(rf.decode_frame(shifted))

    def test_wrong_frame_length_is_rejected(self):
        self.assertIsNone(rf.decode_frame(self.frame[:-1]))
        self.assertIsNone(rf.decode_frame(self.frame + [400]))

    def test_invalid_pulse_is_rejected(self):
        damaged = self.frame.copy()
        damaged[10] = 2200
        self.assertIsNone(rf.decode_frame(damaged))

    def test_two_confirmations_trigger_once_until_release(self):
        state = rf.ConfirmState()
        self.assertIsNone(state.observe(4719265, 10.0))
        self.assertEqual(state.observe(4719265, 10.2), 4719265)
        self.assertIsNone(state.observe(4719265, 10.3))
        self.assertIsNone(state.observe(4719265, 10.4))

        state.tick(11.3)
        self.assertIsNone(state.observe(4719265, 11.4))
        self.assertEqual(state.observe(4719265, 11.5), 4719265)

    def test_mixed_codes_do_not_confirm(self):
        state = rf.ConfirmState()
        self.assertIsNone(state.observe(4719265, 20.0))
        self.assertIsNone(state.observe(123456, 20.1))
        self.assertIsNone(state.observe(4719265, 20.2))

    def test_learn_request_captures_code_and_removes_request(self):
        with tempfile.TemporaryDirectory() as tmp:
            request = Path(tmp) / "learn-request.json"
            result = Path(tmp) / "learn-result.json"
            request.write_text(json.dumps({
                "token": "0123456789abcdef0123456789abcdef",
                "owner_id": 1,
                "expires_at": 2000,
            }), encoding="utf-8")

            self.assertTrue(rf.capture_learn_code(4719265, str(request), str(result), now=1000))
            self.assertFalse(request.exists())
            data = json.loads(result.read_text(encoding="utf-8"))
            self.assertEqual(data["code"], 4719265)
            self.assertEqual(data["hex"], "0x4802A1")
            self.assertEqual(data["owner_id"], 1)

    def test_expired_learn_request_does_not_capture(self):
        with tempfile.TemporaryDirectory() as tmp:
            request = Path(tmp) / "learn-request.json"
            result = Path(tmp) / "learn-result.json"
            request.write_text(json.dumps({
                "token": "0123456789abcdef0123456789abcdef",
                "owner_id": 1,
                "expires_at": 999,
            }), encoding="utf-8")

            self.assertFalse(rf.capture_learn_code(4719265, str(request), str(result), now=1000))
            self.assertFalse(request.exists())
            self.assertFalse(result.exists())


if __name__ == "__main__":
    unittest.main()
