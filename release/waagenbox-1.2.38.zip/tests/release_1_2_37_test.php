<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$checks=0;
function ok137(bool $condition,string $label): void {
    global $checks;
    if(!$condition){fwrite(STDERR,"FAIL $label\n");exit(1);}
    $checks++;
    echo "PASS $label\n";
}
function read137(string $path): string {
    $v=file_get_contents($path);
    if($v===false){fwrite(STDERR,"FAIL Datei nicht lesbar: $path\n");exit(1);}
    return $v;
}
$version=read137($root.'/version.php');
$fields=read137($root.'/fields.php');
$fieldEdit=read137($root.'/field_edit.php');
$fieldImport=read137($root.'/fields_import.php');
$remotes=read137($root.'/remotes.php');
$rfSupport=read137($root.'/rf_remote_support.php');
$rfLearn=read137($root.'/api/rf_learn.php');

ok137(str_contains($version,"APP_VERSION = '1.2.37'"),'Version ist 1.2.37');
ok137(str_contains($fields,'inputmode="decimal" name="area"') && !str_contains($fields,'type="number" step="0.01" name="area"'),'Schlagfläche akzeptiert Dezimalkomma');
ok137(str_contains($fields,"number_format((float)\$r['area'],2,',','.')"),'Schlagfläche wird mit deutschem Komma angezeigt');
ok137(str_contains($fields,'href="field_edit.php?id='),'Schlagliste bietet Bearbeiten');
ok137(str_contains($fields,'href="fields_import.php"'),'Schlagliste bietet GeoJSON-Import');
ok137(str_contains($fieldEdit,'UPDATE `fields` SET name=?,crop=?,year=?,area=?,notes=?'),'Schlagbearbeitung ändert Stammdaten ohne ID-Wechsel');
ok137(str_contains($fieldEdit,'requireCsrfToken()'),'Schlagbearbeitung ist CSRF-geschützt');
ok137(str_contains($fieldEdit,'numOrNull($areaRaw)'),'Schlagbearbeitung akzeptiert Dezimalkomma serverseitig');
ok137(str_contains($fieldImport,"'FeatureCollection'"),'GeoJSON-Import verlangt FeatureCollection');
ok137(str_contains($fieldImport,'5*1024*1024'),'GeoJSON-Upload ist größenbegrenzt');
ok137(str_contains($fieldImport,'maximal 1000 Schläge'),'GeoJSON-Import ist mengenbegrenzt');
ok137(str_contains($fieldImport,"'map_name'") && str_contains($fieldImport,"'map_area'") && str_contains($fieldImport,"'map_crop'"),'GeoJSON-Eigenschaften Name Fläche Frucht sind zuordenbar');
ok137(str_contains($fieldImport,'rows[]'),'Einzelne Schläge sind auswählbar');
ok137(str_contains($fieldImport,'Bereits vorhanden – wird übersprungen'),'Vorschau kennzeichnet bestehende Schläge');
ok137(str_contains($fieldImport,'SELECT id FROM `fields` WHERE owner_user_id=? AND name=? LIMIT 1'),'Import prüft vorhandene Schlag-Namen');
ok137(str_contains($fieldImport,'INSERT INTO `fields`') && !str_contains($fieldImport,'UPDATE `fields`'),'Import überschreibt keine bestehenden Schläge');
ok137(str_contains($fieldImport,'requireCsrfToken()'),'GeoJSON-Import ist CSRF-geschützt');
ok137(str_contains($fieldImport,'function fieldImportGeometryAreaHa'),'GeoJSON-Fläche kann aus Polygon-Geometrie berechnet werden');
ok137(str_contains($fieldImport,"'Berechnete Fläche aus GeoJSON-Geometrie (ha)'"),'Berechnete Polygonfläche wird für die Zuordnung angeboten');
ok137(str_contains($fieldImport,"['name','schlagname','schlag','field_name','field','bezeichnung']"),'GeoJSON-Name wird automatisch erkannt');
ok137(str_contains($fieldImport,"['crop','frucht','fruchtart','kultur','crop_name']"),'GeoJSON-Frucht wird automatisch erkannt');
ok137(str_contains($fieldImport,'Die Geometrie selbst wird nicht gespeichert'),'GeoJSON-Geometrie wird bewusst nicht dauerhaft importiert');
ok137(str_contains($remotes,"\$s->execute([currentOwnerId(),\$code,\$token,\$name,\$vehicleId]);"),'Remote-Code wird mit führenden Nullen gespeichert');
ok137(str_contains($remotes,'CAST(code AS UNSIGNED)=?'),'Remote-Duplikatprüfung vergleicht numerisch');
ok137(str_contains($rfSupport,'CAST(r.code AS UNSIGNED)=?'),'RF-Auslösung findet Codes trotz führender Nullen');
ok137(str_contains($rfLearn,'CAST(code AS UNSIGNED)=?'),'RF-Einlernen erkennt numerisch gleiche Codes als Duplikat');
echo "RESULT {$checks} checks passed\n";
