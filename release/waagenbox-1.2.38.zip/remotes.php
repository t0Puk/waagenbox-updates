<?php
require_once __DIR__.'/functions.php';
requireLogin();
if($_SERVER['REQUEST_METHOD']==='POST'){
    try {
        if (isset($_POST['toggle_id'])) {
            $id=(int)$_POST['toggle_id'];
            if ($id<=0) throw new RuntimeException('Ungültige Fernbedienung.');
            $pdo=db();
            $q=$pdo->prepare('SELECT active FROM remotes WHERE owner_user_id=? AND id=?');
            $q->execute([currentOwnerId(),$id]);
            $remote=$q->fetch();
            if (!$remote) throw new RuntimeException('Fernbedienung wurde nicht gefunden.');
            $newActive=((int)$remote['active']===1)?0:1;
            $s=$pdo->prepare('UPDATE remotes SET active=? WHERE owner_user_id=? AND id=?');
            $s->execute([$newActive,currentOwnerId(),$id]);
            flash('Fernbedienung '.($newActive?'wurde aktiviert.':'wurde deaktiviert.'));
            redirect('remotes.php');
        }
        if (isset($_POST['regenerate_token_id'])) {
            $id=(int)$_POST['regenerate_token_id'];
            if($id<=0) throw new RuntimeException('Ungültige Fernbedienung.');
            $token=bin2hex(random_bytes(32));
            $q=db()->prepare('UPDATE remotes SET mobile_token=? WHERE owner_user_id=? AND id=?');
            $q->execute([$token,currentOwnerId(),$id]);
            redirect('remote_qr.php?id='.$id);
        }
        if (isset($_POST['delete_id'])) {
            $id=(int)$_POST['delete_id'];
            $s=db()->prepare('DELETE FROM remotes WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$id]);
            flash($s->rowCount() ? 'Fernbedienung wurde gelöscht.' : 'Fernbedienung wurde nicht gefunden.');
            redirect('remotes.php');
        }
        $code=trim((string)($_POST['code'] ?? ''));
        $name=trim((string)($_POST['name'] ?? ''));
        $vehicleId=(int)($_POST['vehicle_id'] ?? 0);
        if($code==='' || !ctype_digit($code) || (int)$code<0 || (int)$code>0xFFFFFF) throw new RuntimeException('Bitte einen gültigen 24-Bit-Remote-Code eingeben.');
        if($name==='') throw new RuntimeException('Bitte eine Bezeichnung eingeben.');
        if($vehicleId<=0) throw new RuntimeException('Bitte ein Fahrzeug auswählen.');
        $q=db()->prepare('SELECT id FROM vehicles WHERE owner_user_id=? AND id=? AND active=1');
        $q->execute([currentOwnerId(),$vehicleId]);
        if(!$q->fetchColumn()) throw new RuntimeException('Das ausgewählte Fahrzeug ist nicht aktiv oder wurde nicht gefunden.');
        $q=db()->prepare('SELECT id,name FROM remotes WHERE owner_user_id=? AND CAST(code AS UNSIGNED)=? LIMIT 1');
        $q->execute([currentOwnerId(),(int)$code]);
        if($existing=$q->fetch()) throw new RuntimeException('Dieser Remote-Code ist bereits der Fernbedienung „'.($existing['name'] ?: '#'.$existing['id']).'“ zugeordnet.');
        $token=bin2hex(random_bytes(32));
        $s=db()->prepare('INSERT INTO remotes (owner_user_id,code,mobile_token,name,vehicle_id,active,created_at) VALUES (?,?,?, ?,?,1,NOW())');
        $s->execute([currentOwnerId(),$code,$token,$name,$vehicleId]);
        flash('Fernbedienung wurde angelegt.');
        redirect('remotes.php');
    } catch(Throwable $e){ $error=$e->getMessage(); }
}
layoutStart('Fernbedienungen','remotes');
if(!empty($error)) echo '<div class="flash error"><strong>Fernbedienung konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$rows=db()->query('SELECT r.*,v.plate,v.name AS vehicle_name FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id='.(int)currentOwnerId().' ORDER BY r.name')->fetchAll();
$vehicles=db()->query('SELECT id,plate,name FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY plate')->fetchAll();

$feldmanagerRemoteTeams=feldmanagerRemoteTeamMap();
$feldmanagerTeamNames=[];
if(feldmanagerEnabled() && feldmanagerBaseUrl()!=='' && trim(appSetting('feldmanager_api_token',''))!==''){
    $teamResponse=feldmanagerTeams();
    if(!empty($teamResponse['ok'])){
        foreach((array)($teamResponse['teams']??[]) as $team){
            $tid=(int)($team['id']??0);
            if($tid>0) $feldmanagerTeamNames[$tid]=(string)($team['name']??('Team #'.$tid));
        }
    }
}
?>
<div class="toolbar"><h1>Fernbedienungen</h1></div>
<div class="card table-wrap"><table><tr><th>Status</th><th>Code</th><th>Name</th><th>Fahrzeug</th><th>Feldmanager-Team</th><th></th></tr>
<?php foreach($rows as $r): ?><tr>
<td><?=(int)$r['active']===1?'<strong>Aktiv</strong>':'<span class="muted">Deaktiviert</span>'?></td>
<td><?=h($r['code'])?></td>
<td><?=h($r['name'])?></td>
<td><?=h(trim(($r['plate'] ?? '').' – '.($r['vehicle_name'] ?? ''), ' –'))?></td>
<?php $teamId=(int)($feldmanagerRemoteTeams[(int)$r['id']]??0); ?>
<td><?=$teamId>0?h($feldmanagerTeamNames[$teamId]??('Team #'.$teamId)):'–'?></td>
<td class="row-actions">
<form method="post" style="display:inline"><input type="hidden" name="regenerate_token_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button">📱 QR-Code</button></form>
<a class="button" href="remote_edit.php?id=<?= (int)$r['id'] ?>">Zuordnungen</a>
<form method="post" style="display:inline"><input type="hidden" name="toggle_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button"><?=(int)$r['active']===1?'Deaktivieren':'Aktivieren'?></button></form>
<form method="post" class="delete-form" onsubmit="return confirm(<?=json_encode('Fernbedienung '.($r['name'] ?? '').' wirklich endgültig löschen?\n\nDieser Vorgang kann nicht rückgängig gemacht werden.', JSON_UNESCAPED_UNICODE)?>);"><input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button-danger">Löschen</button></form>
</td></tr><?php endforeach; ?></table></div>
<div class="card"><h2>Fernbedienung anlegen</h2><form method="post"><div class="form-grid">
<div><label>Remote-Code</label><div style="display:flex;gap:.5rem;align-items:center"><input id="remoteCode" name="code" inputmode="numeric" pattern="[0-9]+" required style="flex:1"><button type="button" class="button" id="rfLearnButton">📡 Handsender einlernen</button></div><div id="rfLearnStatus" class="muted" style="margin-top:.45rem">Code kann manuell eingegeben oder direkt vom 433-MHz-Handsender eingelesen werden.</div></div><div><label>Bezeichnung</label><input name="name" required></div>
<div class="full"><label>Fahrzeug</label><select name="vehicle_id" required><option value="">Bitte wählen</option><?php foreach($vehicles as $v): ?><option value="<?=$v['id']?>"><?=h($v['plate'].' – '.$v['name'])?></option><?php endforeach; ?></select></div>
</div><p><button>Fernbedienung speichern</button></p></form></div>
<script>
(() => {
  const button = document.getElementById('rfLearnButton');
  const status = document.getElementById('rfLearnStatus');
  const codeInput = document.getElementById('remoteCode');
  let token = null;
  let timer = null;

  function csrf() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }
  function stopPolling() {
    if (timer) clearTimeout(timer);
    timer = null;
  }
  function setIdle(text) {
    stopPolling();
    token = null;
    button.disabled = false;
    button.textContent = '📡 Handsender einlernen';
    if (text) status.textContent = text;
  }
  async function poll() {
    if (!token) return;
    try {
      const r = await fetch('api/rf_learn.php?action=status&token=' + encodeURIComponent(token), {cache:'no-store'});
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Status konnte nicht gelesen werden.');
      if (d.state === 'captured') {
        codeInput.value = d.code;
        let text = 'Erkannt: ' + d.code + ' (' + d.hex + '). Code wurde übernommen.';
        if (d.duplicate && d.duplicate_remote) text += ' Achtung: bereits zugeordnet zu „' + (d.duplicate_remote.name || ('#' + d.duplicate_remote.id)) + '“.';
        setIdle(text);
        codeInput.focus();
        return;
      }
      if (d.state === 'expired') {
        setIdle('Kein Funksignal erkannt. Bitte Einlernen erneut starten.');
        return;
      }
      status.textContent = 'Warte auf Handsender … noch ' + (d.seconds_left ?? '') + ' s. Bitte Taste kurz drücken.';
      timer = setTimeout(poll, 500);
    } catch (e) {
      setIdle('Einlernen fehlgeschlagen: ' + e.message);
    }
  }
  button.addEventListener('click', async () => {
    if (token) return;
    button.disabled = true;
    button.textContent = 'Warte auf Signal …';
    status.textContent = 'Einlernmodus wird gestartet …';
    try {
      const r = await fetch('api/rf_learn.php?action=start', {
        method:'POST',
        headers:{'X-CSRF-Token':csrf()},
        cache:'no-store'
      });
      const d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.message || 'Einlernmodus konnte nicht gestartet werden.');
      token = d.token;
      status.textContent = d.message;
      timer = setTimeout(poll, 250);
    } catch (e) {
      setIdle('Einlernen nicht möglich: ' + e.message);
    }
  });
  window.addEventListener('beforeunload', () => {
    if (!token) return;
    const data = new FormData();
    data.append('action','cancel');
    data.append('token',token);
    data.append('csrf_token',csrf());
    navigator.sendBeacon('api/rf_learn.php', data);
  });
})();
</script>
<?php layoutEnd(); ?>
