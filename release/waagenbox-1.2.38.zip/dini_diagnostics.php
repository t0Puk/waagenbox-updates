<?php
require_once __DIR__.'/functions.php';
requireAdmin();
require_once __DIR__.'/hardware/dini_diagnostics.php';
layoutStart('Dini-Diagnose', 'settings');
?>
<div class="card"><h1>Dini-Herstellerdiagnose</h1>
<p>Nur lesende Abfragen. Jede Abfrage wird einzeln ausgelöst.</p>
<div class="button-row"><?php foreach (diniDiagnosticActions() as $action=>$label): ?>
<button type="button" class="button" data-action="<?=h($action)?>"><?=h($label)?></button>
<?php endforeach; ?></div><h2>Antwort und aufbereitete Daten</h2>
<pre id="diagnosticResult" style="white-space:pre-wrap">Noch keine Abfrage ausgeführt.</pre>
<a class="button" href="settings.php?tab=waagencomputer">Zurück</a></div>
<script>
document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', async () => {
    const buttons = document.querySelectorAll('[data-action]');
    buttons.forEach(b => b.disabled = true);
    const result = document.getElementById('diagnosticResult');
    result.textContent = 'Abfrage läuft …';
    try {
        const response = await fetch('api/dini_test.php?action=' + encodeURIComponent(button.dataset.action), {cache:'no-store'});
        if (response.redirected) { location.assign('login.php'); return; }
        const data = await response.json();
        result.textContent = data.ok ? JSON.stringify(data.result, null, 2) : data.error;
    } catch (_) { result.textContent = 'Diagnose derzeit nicht verfügbar.'; }
    finally { buttons.forEach(b => b.disabled = false); }
}));
</script>
<?php layoutEnd(); ?>
