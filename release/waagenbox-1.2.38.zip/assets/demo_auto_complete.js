(function(){
  let finishTimer=null;
  let finishing=false;
  let lastPendingKey=null;

  function clearFinishTimer(){
    if(finishTimer){
      clearTimeout(finishTimer);
      finishTimer=null;
    }
  }

  async function finishDemoWeighing(){
    if(finishing) return;
    finishing=true;
    clearFinishTimer();
    try{
      const response=await fetch('api/demo_auto_complete.php',{
        method:'POST',
        headers:csrfHeaders(),
        cache:'no-store'
      });
      const data=await response.json();
      if(data.ok && data.status==='completed'){
        document.dispatchEvent(new CustomEvent('waagenbox-demo-weighing-completed',{detail:data}));
        if(location.pathname.endsWith('/weighing.php') || location.pathname.endsWith('weighing.php')){
          location.href='weighing.php?completed=1&id='+encodeURIComponent(data.weighing_id||'');
          return;
        }
      }
    }catch(e){}
    finishing=false;
  }

  async function pollDemoAutoComplete(){
    if(finishing) return;
    try{
      const pendingResponse=await fetch('api/pending.php',{cache:'no-store'});
      const pending=await pendingResponse.json();
      if(!pending.demo_mode || !pending.pending || pending.trigger_type!=='radio'){
        lastPendingKey=null;
        clearFinishTimer();
        return;
      }

      lastPendingKey=pending.key||null;
      const firstWeight=Number(pending.first_weight)||0;
      const statusResponse=await fetch('api/status.php',{cache:'no-store'});
      const status=await statusResponse.json();
      const weight=Number(status.weight)||0;
      const validSecondWeight=weight>0 && Math.abs(weight-firstWeight)>0.05;

      if(validSecondWeight && !finishTimer){
        const keyAtStart=lastPendingKey;
        finishTimer=setTimeout(async()=>{
          finishTimer=null;
          if(keyAtStart!==lastPendingKey || finishing) return;
          await finishDemoWeighing();
        },1000);
      }else if(!validSecondWeight){
        clearFinishTimer();
      }
    }catch(e){}
  }

  pollDemoAutoComplete();
  setInterval(pollDemoAutoComplete,500);
})();
