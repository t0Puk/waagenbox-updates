async function updateWeight(){
  try{
    const r=await fetch('api/status.php',{cache:'no-store'});
    const d=await r.json();
    const w=document.getElementById('weight');
    const s=document.getElementById('weightStatus');
    const light=document.getElementById('scaleLight');
    const label=document.getElementById('scaleLightLabel');
    if(w) w.innerHTML=(Math.round((Number(d.weight)||0)/5)*5).toLocaleString('de-DE',{maximumFractionDigits:0})+' <span>kg</span>';
    if(s) s.textContent=d.status||'Bereit';
    if(light){
      const state=d.scale_status||'ready';
      light.classList.remove('ready','waiting','processing');
      light.classList.add(state);
      light.dataset.status=state;
    }
    if(label) label.textContent=d.scale_label||'Bereit für nächste Wiegung';
  }catch(e){}
}
function csrfHeaders(){return {'X-CSRF-Token':document.querySelector('meta[name="csrf-token"]')?.content||''};}
updateWeight();
setInterval(updateWeight,1000);

// Auf der Wiegungsübersicht werden neue Wiegungen im Hintergrund erkannt.
async function pollNewWeighing(){try{const r=await fetch('api/weighings_latest.php',{cache:'no-store'});const d=await r.json();if(window.lastWeighingId!==undefined && Number(d.latest_id)>Number(window.lastWeighingId)){location.reload();}else if(window.lastWeighingId===undefined){window.lastWeighingId=Number(d.latest_id)||0;}}catch(e){}}
setInterval(pollNewWeighing,5000);

async function checkForSoftwareUpdate(){
  try{
    const r=await fetch('api/update_check.php',{cache:'no-store'});
    const d=await r.json();
    if(!d.ok || !d.update_available || d.ignored || d.snoozed) return;
    if(document.getElementById('softwareUpdateBanner')) return;
    const hideButton=d.mandatory?'':'<button type="button" class="button" id="ignoreSoftwareUpdate">Diese Version ausblenden</button>';
    const box=document.createElement('div');
    box.id='softwareUpdateBanner';
    box.className='software-update-banner';
    box.innerHTML='<strong>Update verfügbar: v'+escapeHtml(d.version)+'</strong><span>'+escapeHtml(d.message||'Eine neue Version der Waagenbox ist verfügbar.')+'</span><div class="software-update-actions"><button type="button" class="button primary" id="installSoftwareUpdate">Update installieren</button><button type="button" class="button" id="laterSoftwareUpdate">Später</button>'+hideButton+'</div>';
    document.body.prepend(box);
    document.getElementById('installSoftwareUpdate').onclick=installSoftwareUpdate;
    document.getElementById('laterSoftwareUpdate').onclick=async()=>{try{await fetch('api/update_snooze.php',{method:'POST',headers:csrfHeaders()});}catch(e){}box.remove();};
    const ignore=document.getElementById('ignoreSoftwareUpdate');
    if(ignore) ignore.onclick=async()=>{try{await fetch('api/update_ignore.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',...csrfHeaders()},body:'version='+encodeURIComponent(d.version)});}catch(e){}box.remove();};
  }catch(e){}
}
function escapeHtml(v){const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML;}
async function installSoftwareUpdate(){
  const b=document.getElementById('softwareUpdateBanner');
  if(b) b.innerHTML='<strong>Update wird installiert …</strong><span>Bitte die Waagenbox währenddessen nicht ausschalten.</span>';
  try{
    const r=await fetch('api/update_install.php',{method:'POST',headers:csrfHeaders(),cache:'no-store'});
    const d=await r.json();
    if(!d.ok){if(b)b.innerHTML='<strong>Update fehlgeschlagen</strong><span>'+escapeHtml(d.message||'Unbekannter Fehler')+'</span><div class="software-update-actions"><button class="button" onclick="location.reload()">Neu laden</button></div>';return;}
    if(b)b.innerHTML='<strong>Update erfolgreich installiert.</strong><span>Die neue Version wird jetzt geladen.</span>';
    setTimeout(()=>location.reload(),1500);
  }catch(e){if(b)b.innerHTML='<strong>Update fehlgeschlagen</strong><span>Keine Antwort vom Update-Prozess.</span>';}
}
if(!document.body.classList.contains('page-mobile')) checkForSoftwareUpdate();
