<?php
require_once __DIR__.'/functions.php';
requireLogin();

$pdo = db();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if ($id <= 0) {
    http_response_code(404);
    exit('Schlag nicht gefunden');
}

$q = $pdo->prepare('SELECT * FROM `fields` WHERE owner_user_id=? AND id=?');
$q->execute([currentOwnerId(), $id]);
$field = $q->fetch();
if (!$field) {
    http_response_code(404);
    exit('Schlag nicht gefunden');
}

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        requireCsrfToken();

        $name = trim((string)($_POST['name'] ?? ''));
        $crop = trim((string)($_POST['crop'] ?? ''));
        $yearRaw = trim((string)($_POST['year'] ?? ''));
        $areaRaw = trim((string)($_POST['area'] ?? ''));
        $notes = trim((string)($_POST['notes'] ?? ''));

        if ($name === '') throw new RuntimeException('Bitte einen Namen eingeben.');
        $year = $yearRaw === '' ? null : (int)$yearRaw;
        $area = numOrNull($areaRaw);
        if ($area !== null && $area < 0) throw new RuntimeException('Die Flächengröße darf nicht negativ sein.');

        $dup = $pdo->prepare('SELECT id FROM `fields` WHERE owner_user_id=? AND name=? AND id<>? LIMIT 1');
        $dup->execute([currentOwnerId(), $name, $id]);
        if ($dup->fetchColumn()) throw new RuntimeException('Ein anderer Schlag mit diesem Namen ist bereits vorhanden.');

        $s = $pdo->prepare('UPDATE `fields` SET name=?,crop=?,year=?,area=?,notes=? WHERE owner_user_id=? AND id=?');
        $s->execute([$name, $crop, $year, $area, $notes, currentOwnerId(), $id]);

        flash('Schlag wurde gespeichert.');
        redirect('fields.php');
    } catch (Throwable $e) {
        $error = $e->getMessage();
        $field['name'] = $_POST['name'] ?? $field['name'];
        $field['crop'] = $_POST['crop'] ?? $field['crop'];
        $field['year'] = $_POST['year'] ?? $field['year'];
        $field['area'] = $_POST['area'] ?? $field['area'];
        $field['notes'] = $_POST['notes'] ?? $field['notes'];
    }
}

$areaValue = (string)($field['area'] ?? '');
if ($areaValue !== '') $areaValue = str_replace('.', ',', $areaValue);

layoutStart('Schlag bearbeiten', 'fields');
if ($error !== null) {
    echo '<div class="flash error"><strong>Schlag konnte nicht gespeichert werden.</strong><br>'.h($error).'</div>';
}
?>
<div class="toolbar">
  <h1>Schlag bearbeiten</h1>
  <a class="button" href="fields.php">← Zurück zu den Schlägen</a>
</div>

<div class="card">
<form method="post">
  <input type="hidden" name="id" value="<?= (int)$id ?>">
  <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
  <div class="form-grid">
    <div><label>Name</label><input name="name" required value="<?=h($field['name'])?>"></div>
    <div><label>Frucht / Kultur</label><input name="crop" value="<?=h($field['crop'])?>"></div>
    <div><label>Jahr</label><input type="number" name="year" value="<?=h($field['year'])?>"></div>
    <div><label>Fläche (ha)</label><input type="text" inputmode="decimal" name="area" placeholder="z. B. 1,00" value="<?=h($areaValue)?>"></div>
    <div class="full"><label>Notizen</label><textarea name="notes"><?=h($field['notes'])?></textarea></div>
  </div>
  <p><button class="button primary">Änderungen speichern</button></p>
</form>
</div>
<?php layoutEnd(); ?>
