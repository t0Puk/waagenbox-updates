# Kamera-Livebild aus vorhandener Schnappschuss-URL

Stand: 2026-09-16
Branch: `feature/1.2.35-camera-snapshot-live`
Basis: `release/1.2.34` / `e431b76261f3c1875ce213737564f86c9c342ace`

## Ziel

Die Kamera-Anbindung soll flexibel bleiben:

- Kameras mit einem direkt browserfaehigen HTTP-MJPEG-Stream koennen ihre echte Stream-URL weiterhin direkt im vorhandenen Feld `Stream-URL` verwenden.
- Kameras wie die aktuell getestete Foscam, bei denen die vorhandene Schnappschuss-URL funktioniert, koennen ueber eine interne Waagenbox-Bridge einen MJPEG-kompatiblen Stream erhalten.
- Die bestehende Kamera-Einstellungsseite soll dafuer nicht grundsaetzlich umgebaut werden.
- Die bereits gespeicherte `camera_snapshot_url` bleibt die einzige Quelle fuer die Kamera-Zugangsdaten und Kamera-IP der Snapshot-Bridge.
- Keine Kamera-Zugangsdaten werden in GitHub hinterlegt.

## Gewaehlte Architektur

Die vorbereitete Hauptloesung ist `api/camera_mjpeg.php`.

Ablauf:

```text
Kamera-Snapshot-URL aus Waagenbox-Einstellungen
        |
        v
api/camera_mjpeg.php
        |
        | holt standardmaessig etwa alle 1000 ms genau einen Snapshot
        v
multipart/x-mixed-replace (MJPEG)
        |
        v
vorhandenes Feld "Stream-URL" / Dashboard
```

Die Bridge ist damit kameraunabhaengig, solange die Kamera eine per HTTP/HTTPS erreichbare Bild-URL liefert.

## Vorbereitete Dateien

- `api/camera_mjpeg.php`: Snapshot-zu-MJPEG-Bridge; bevorzugte Variante fuer den Foscam-Test.
- `tests/camera_snapshot_live_test.py`: statische Schutz-, Scope- und Bridge-Checks.

Die bestehende `settings.php` ist auf diesem Branch absichtlich nicht geaendert worden.

## Stream-URL fuer den Test

Die Bridge akzeptiert einen optionalen Aktualisierungsabstand in Millisekunden:

```text
/api/camera_mjpeg.php?interval=1000
```

Zulaessiger Bereich im Endpoint:

- Minimum: 500 ms
- Standard: 1000 ms
- Maximum: 5000 ms

Fuer den Raspberry Pi 3 wird zuerst 1000 ms getestet. Erst wenn CPU, Apache und Kamera damit stabil bleiben, kann 750 oder 500 ms ausprobiert werden.

Wichtig: `127.0.0.1` darf nur verwendet werden, wenn das Dashboard direkt im Raspberry-Kiosk laeuft. Fuer Zugriffe von anderen Rechnern muss die URL auf den Host/die IP der Waagenbox zeigen; ansonsten wuerde `127.0.0.1` auf den jeweiligen Client zeigen. Welche konkrete URL spaeter im Feld `Stream-URL` verwendet wird, wird erst beim realen Test festgelegt.

## Betriebs- und Sicherheitsverhalten

`api/camera_mjpeg.php`:

- verwendet `requireLogin()` und damit das bestehende Waagenbox-Zugriffsmodell;
- liest ausschliesslich die vorhandene `camera_snapshot_url`;
- gibt Benutzername/Passwort der Kamera nicht im MJPEG-Stream aus;
- schliesst den PHP-Session-Lock vor der dauerhaften Stream-Schleife;
- setzt No-Cache-Header und deaktiviert PHP-Ausgabekompression;
- verwendet begrenzte Connect-/Gesamt-Timeouts pro Kamerabild;
- validiert jedes Kamerabild ueber `getimagesizefromstring()`;
- reicht bereits vorhandene JPEG-Bilder ohne erneutes Re-Encoding weiter, um CPU-Last zu sparen;
- konvertiert andere von GD lesbare Bildformate nur bei Bedarf nach JPEG;
- schreibt die Livebilder nicht auf die SD-Karte;
- veraendert keine Wiegungs- oder Produktivdaten.

## Besonderheit Apache/PHP

Die Produktivinstallation verwendet Apache mit mod_php. Eine dauerhafte MJPEG-Verbindung belegt waehrend der Anzeige einen Apache-Worker. Deshalb gilt fuer den realen Test:

1. zuerst nur ein Dashboard/Kiosk-Client;
2. CPU-, RAM- und Apache-Prozessanzahl beobachten;
3. Kamera-Antwortzeit beobachten;
4. bei mehreren parallelen Clients nicht ungeprueft weiter skalieren.

Falls sich eine dauerhafte PHP-Verbindung im Produktivtest als unguenstig herausstellt, bleibt der bereits vorbereitete Einzelbild-Proxy mit sequenziellem JavaScript-Refresh als Fallback erhalten. Ein neuer Systemdienst wird nicht eingefuehrt, solange die einfachere App-Loesung stabil funktioniert.

## Foscam-Testplan

Beim naechsten Test wird nichts direkt in `/var/www/waage` veraendert. Vorgehen:

1. Branch `feature/1.2.35-camera-snapshot-live` in `/home/pi/Waagenbox-test` verwenden.
2. PHP-Syntax aller neuen PHP-Dateien pruefen.
3. `python3 tests/camera_snapshot_live_test.py` ausfuehren.
4. Bestehende, funktionierende Foscam-Schnappschuss-URL unveraendert lassen.
5. Bridge im Test-Worktree mit einem lokalen HTTP-Test aufrufen.
6. Pruefen, ob `multipart/x-mixed-replace` geliefert wird und fortlaufend JPEG-Frames eintreffen.
7. Danach Browser-Test mit genau einem Client.
8. CPU/RAM/Apache beobachten.
9. Erst nach erfolgreichem Test entscheiden, welche Stream-URL in der bestehenden Einstellungsseite eingetragen wird.
10. Produktive Installation erst nach ausdruecklicher Freigabe.

## Flexibilitaet fuer spaetere Kameras

Eine spaetere Kamera mit echtem HTTP-MJPEG benoetigt die Bridge nicht. Dann wird einfach die native Stream-URL der Kamera eingetragen.

Eine spaetere Kamera mit funktionierender Snapshot-URL kann die gleiche Bridge weiterverwenden. Kamera-IP, Benutzername und Passwort bleiben damit konfigurierbar ueber die bereits vorhandenen Kamera-Einstellungen und muessen nicht in Programmcode oder GitHub eingebaut werden.

## Release-Regeln aus 1.2.34, die fuer diese Arbeit verbindlich bleiben

Vor einem spaeteren 1.2.35-Release:

- `release/1.2.34` bleibt unveraendert.
- Entwicklung nur auf dem Feature-Branch bzw. spaeter einem bewusst eingefrorenen Release-Branch.
- `/var/www/waage` niemals ungefragt veraendern.
- Keine produktiven Daten, Backups oder Secrets ins Repository aufnehmen.
- PHP- und Python-Syntax komplett pruefen.
- vorhandene Regression vollstaendig ausfuehren.
- Release-Preflight ausfuehren.
- beim Windows-Release-Bau native `$LASTEXITCODE` sofort pruefen.
- nach `git archive` Existenz, Mindestgroesse und SHA256 des ZIPs pruefen; leeres ZIP explizit ablehnen.
- Release-Ref explizit gegen den erwarteten Source-Commit vergleichen.
- Signed Manifest UTF-8 ohne BOM und mit abschliessendem LF erzeugen.
- OpenSSL-Verifikation vor Veroeffentlichung durchfuehren.
- Paket/Manifest/Signatur erst nach gemeinsamer Pruefung und ausdruecklicher Freigabe veroeffentlichen.
- Produktivinstallation erst nach ausdruecklicher Freigabe.

Diese Regeln stammen aus dem dokumentierten und praktisch abgenommenen 1.2.34-Stand und sollen verhindern, dass die beim letzten Release bereits gefundenen Fehler wieder auftreten.

## Noch offen

Noch nicht durchgefuehrt sind insbesondere:

- realer Foscam-Test der MJPEG-Bridge;
- Lasttest am Raspberry Pi 3;
- Entscheidung ueber die konkrete `Stream-URL` fuer lokalen Kiosk und Netzwerkzugriff;
- vollstaendige Regression dieses Feature-Branches;
- Versionsanhebung;
- Release-Freeze;
- Paketbau/Signatur/Veroeffentlichung;
- produktive Installation.

Bis dahin ist der Branch reine Vorbereitung. `/var/www/waage` wurde durch diese GitHub-Arbeiten nicht veraendert.
