# Produktionsabnahme AJP Waagenbox 1.2.31

Datum: 2026-09-14

## Referenzen

- Source-Commit: `8b749cad33803c6156265ee3aeb2c87afe6adbc9`
- Release-Branch: `release/1.2.31`
- Update-Repository-Commit: `dcee03c4d944a3754771ef976043872007a22462`
- ZIP SHA256: `25929a3fb60bdb4efcfaddb0e2e65c23d82164aeb629f6dce948d9c983b463ba`

## Produktiv erfolgreich geprüft

- Update von 1.2.30 auf 1.2.31 über die normale Updatefunktion
- Fahrzeuge anlegen
- Kunden anlegen
- Produkte anlegen
- Schläge anlegen
- Fernbedienungen anlegen
- alte QR-Fernbedienung weiterhin funktionsfähig
- neu erzeugte QR-Fernbedienung funktionsfähig
- QR-Wiegungen erfolgreich
- manuelle Wiegungen erfolgreich
- automatische Sitzungsabmeldung/Inaktivitäts-Logout erfolgreich
- Standort/GPS erfolgreich
- automatisches Backup herunterladen erfolgreich
- manuelles Backup erstellen erfolgreich
- manuelles Backup herunterladen erfolgreich
- Dini-Diagnose verhält sich bei nicht angeschlossenem Wiegecomputer kontrolliert und ohne Systemfehler
- Service-WLAN nach Reboot automatisch aktiv
- `http://10.42.0.1` per Smartphone erreichbar
- normale Raspberry-IP parallel erreichbar
- Chromium startet automatisch
- Dashboard startet automatisch im Vollbild/Kioskmodus
- keine manuelle Desktopbedienung nötig
- kein Desktop-Loginfenster vor dem Kiosk
- normaler Weblogin erfolgreich

## Noch hardwareabhängig offen

Die tatsächliche Kommunikation mit dem Dini-Wiegeterminal wird bei angeschlossener Waagenhardware vor Ort abschließend geprüft. Der aktuelle Zustand bei nicht angeschlossener Hardware ist erwartungsgemäß: Wagencomputer wird als nicht erreichbar angezeigt; Diagnose liefert eine kontrollierte Meldung statt eines Anwendungsfehlers.

## Ergebnis

Version 1.2.31 gilt als produktiv abgenommen und als bekannter guter Referenzstand für zukünftige Entwicklung.
