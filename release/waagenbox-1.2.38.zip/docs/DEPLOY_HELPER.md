# Privilegierter Deployment-Helfer

Der Waagenbox-Webserver soll langfristig keine Schreibrechte auf den
Anwendungscode unter `/var/www/waage` benötigen.

Der privilegierte Deployment-Helfer trennt deshalb:

- Webanwendung / Updateprüfung
- signiertes Release-Paket
- Root-Dateideployment
- Datenbankmigration und DB-Rollback

## Sicherheitsmodell

Der Helfer:

- läuft ausschließlich über CLI,
- muss als root laufen,
- akzeptiert keine Kommandozeilenargumente,
- verwendet in Produktion feste Pfade,
- prüft einen root-eigenen öffentlichen Schlüssel,
- installiert nur ein kryptografisch signiertes Manifest,
- prüft zusätzlich SHA-256 des ZIP-Pakets,
- lehnt `config.php` im Paket ab,
- lehnt Laufzeitdaten wie `uploads` im Paket ab,
- extrahiert ZIP-Dateien ohne Traversal/Symlinks,
- prüft alle PHP-Dateien vor Aktivierung,
- erstellt vor jeder Installation einen root-eigenen Anwendungssnapshot,
- kann ausschließlich solche root-eigenen Snapshots wiederherstellen.

Produktionspfade:

- Anwendung: `/var/www/waage`
- Deployment-Speicher: `/var/lib/waagebox/deploy`
- Public Key: `/etc/waagenbox/deploy-public.pem`

Der Testmodus akzeptiert ausschließlich Pfade unter
`/tmp/waagenbox_deploy_test_*` und `/tmp/waagenbox_deploy_bridge_test_*`.

## Noch nicht produktiv aktiviert

Der Helfer wird in Phase 2 zunächst nur isoliert getestet.

Insbesondere werden in diesem Schritt noch NICHT:

- `/usr/local/sbin` verändert,
- sudoers-Regeln installiert,
- `/var/www/waage` verändert,
- der Web-Updater auf den Helfer umgestellt,
- produktive Signaturschlüssel installiert.

Die spätere Webintegration darf ausschließlich den exakt festgelegten
Helfer ohne freie Argumente starten.

## Phase 3 – unprivilegierte Web-Brücke

`deploy/deploy_client.php` ist die einzige vorgesehene Schnittstelle der
PHP-Webanwendung zum privilegierten Helfer.

Die Webanwendung darf:

1. ein bereits heruntergeladenes Paket nach `pending/package.zip` kopieren,
2. das vom Release-Server signierte Minimalmanifest erzeugen,
3. die zugehörige Signatur ablegen,
4. atomar `request.json` erzeugen,
5. exakt `/usr/local/sbin/waagenbox-deploy-helper` über `sudo -n` starten.

Die sudoers-Regel erlaubt keine Argumente und keinen allgemeinen Shell-,
PHP-, cp-, mv-, rm- oder sonstigen Root-Befehl.

Das signierte Minimalmanifest besitzt bytegenau dieses Format:

`{"version":"X.Y.Z","package_sha256":"<64-hex>"}\n`

Der Release-Prozess muss genau diese Bytes signieren.

Phase 3 testet diese Brücke isoliert. Eine produktive Installation des
Helpers oder eine Umschaltung der Update-Endpunkte erfolgt dabei noch nicht.
