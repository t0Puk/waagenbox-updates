# 433-MHz-Funkfernbedienung – Entwicklungsstand 1.2.32

## Status

Die 433-MHz-Funkfernbedienung ist auf dem Entwicklungsbranch `feature/1.2.32-rf-remote` implementiert und am 15.09.2026 auf dem produktiven Raspberry erfolgreich praktisch geprüft worden.

Ausgangsbasis ist der vollständig abgenommene Referenzstand 1.2.31 auf `release/1.2.31` / `8b749cad33803c6156265ee3aeb2c87afe6adbc9`.

Die für 1.2.32 neuen Funkkomponenten wurden mit ausdrücklicher Freigabe des Benutzers kontrolliert nach `/var/www/waage` übernommen und der systemd-Dienst anschließend produktiv aktiviert. Die Anwendungsversion in `version.php` bleibt bis zum Abschluss der vollständigen Release-Regressionstests noch auf 1.2.31.

## Getestete Hardware

Raspberry Pi 3 Model B Rev 1.2, Debian 13, Kernel 6.18.39+rpt-rpi-v8.

Vorhandene GPIO-Werkzeuge beim Test:

- `gpioinfo`
- `gpiomon` aus libgpiod 2.2.1
- `pinctrl`

Empfänger: 433-MHz-RF-5V-Modul mit `GND / DATA / DATA / VCC`.

GPIO:

- DATA an GPIO17 / physischer Pin 11
- Empfänger-VCC an 5 V
- gemeinsames GND
- DATA wegen möglichem 5-V-Ausgang nicht direkt an den Raspberry-GPIO; beim Test wurde ein Spannungsteiler 10 kOhm / 20 kOhm vorgesehen.

## Real gemessener Handsender

Die getestete Taste wurde reproduzierbar erkannt als:

- Dezimal: `4719265`
- Hex: `0x4802A1`
- Bits: `010010000000001010100001`

Typische gemessene Pulszeiten:

- kurzer Puls ungefähr 0,4 ms
- langer Puls ungefähr 1,1 ms
- Synchronpause ungefähr 11,5 ms
- 24 Datenbits = 48 Datenpulse plus kurzer Abschlussimpuls

Mehrere Live-Tastendrücke ergaben stabil denselben Code.

## Sicherheits- und Plausibilitätsregeln

Der Listener akzeptiert nicht einfach irgendeine 433-MHz-Flanke. Für eine Auslösung gelten:

1. exakt ausgerichtetes Telegramm mit 48 Datenpulsen plus kurzem Abschlussimpuls,
2. zulässige Kurz-/Lang-Pulsfenster,
3. derselbe Code muss zweimal innerhalb eines kurzen Zeitfensters bestätigt werden,
4. ein gehaltenes Telegramm wird verriegelt und löst nur einmal aus,
5. unbekannte Funkcodes starten keine Wiegung,
6. eine bereits laufende oder noch verarbeitete Wiegung darf nicht überschrieben werden,
7. Fernbedienung und Fahrzeug müssen aktiv sein,
8. das Fahrzeug muss ein gespeichertes Erstgewicht besitzen.

Bei Funkrauschen gilt: lieber ein beschädigtes Telegramm verwerfen als einen unsicheren Code akzeptieren.

Wichtig: Die verwendeten 433-MHz-Handsender senden feste Codes. Das Verfahren ist daher eine komfortable Auslösung und keine kryptographische Authentifizierung; ein empfangener Code kann prinzipbedingt aufgezeichnet und nachgebildet werden.

## Softwarearchitektur

`hardware/rf_remote_listener.py`

- liest GPIO17 über `/usr/bin/gpiomon`,
- dekodiert ausschließlich passende 24-Bit-Telegramme,
- bestätigt den Code mehrfach,
- führt selbst keine Datenbankoperation aus,
- ruft nach erfolgreicher Erkennung den PHP-CLI-Bridge auf,
- fängt bei aktivem Einlernmodus den nächsten bestätigten Code ab und unterdrückt dabei ausdrücklich die Wägeauslösung.

`cli/rf_remote_trigger.php`

- ist nur über PHP-CLI ausführbar,
- übergibt den numerischen Code an `rf_remote_support.php`,
- unterstützt `--dry-run`,
- unbekannte Funkcodes werden kontrolliert verworfen.

`rf_remote_support.php`

- sucht den vorhandenen Eintrag über `remotes.code`,
- verwendet die bestehende Fahrzeugzuordnung,
- übernimmt die vorhandenen Standardzuordnungen für Schlag/Kunde/Produkt analog zur mobilen Fernbedienung,
- startet über die bestehende `setPendingWeighing()`-Logik,
- verwendet `trigger_type = 'radio'`,
- überschreibt keine laufende Wiegung,
- kann im Dry-Run die komplette Lookup-/Readiness-Prüfung durchführen, ohne einen `weighing_state` anzulegen oder den DB-Besitzerkontext zu verändern.

`api/rf_learn.php`

- ist admin-geschützt,
- nutzt CSRF-Schutz für Start/Abbruch,
- legt eine kurzlebige Lernanforderung unter `/run/waagenbox-rf` an,
- prüft Token und Benutzerkontext,
- meldet den erkannten Dezimal-/Hex-Code an die Oberfläche zurück,
- erkennt bereits vorhandene Remote-Codes,
- läuft ohne Datenbankmigration.

`remotes.php`

- bietet beim Anlegen einer Fernbedienung den Button `Handsender einlernen`,
- wartet maximal 20 Sekunden auf einen Code,
- übernimmt den erkannten Code in das Formular,
- weist bei bereits vorhandener Zuordnung auf die betreffende Fernbedienung hin.

Es ist für 1.2.32 **keine Datenbankmigration** erforderlich. Das bestehende Feld `remotes.code` wird verwendet.

## Raspberry-Testworktree und Testdatenbank

Der Entwicklungsbranch wurde im Raspberry-Testworktree `/home/pi/Waagenbox-test` getestet. Die Testkonfiguration verwendet die isolierte Datenbank `waagebox_test`.

Für den RF-End-to-End-Test wurden eindeutig markierte Testdaten verwendet:

- Fahrzeug `RF-TEST-FAHRZEUG`
- Kennzeichen `RF-TEST`
- Erstgewicht `10000.000`
- Fernbedienung `RF-TEST-FERNBEDIENUNG`
- Funkcode `4719265`

Die Testumgebung wurde vor der Live-Auslösung geprüft:

- Datenbank: `waagebox_test`
- Owner: `1`
- Dini: deaktiviert
- `weighing_state`: leer

## Erfolgreich ausgeführte RF-Tests am 15.09.2026

Folgende Prüfungen wurden erfolgreich durchgeführt:

1. PHP-Syntaxprüfung von `rf_remote_support.php`, `cli/rf_remote_trigger.php`, `api/rf_learn.php` und `remotes.php`.
2. Python-Syntaxprüfung von `hardware/rf_remote_listener.py`.
3. Python-Decoder-/Learn-Test: 8/8 Tests erfolgreich, einschließlich gültiger/ungültiger Frames, Bestätigung, Latch, abgelaufener Lernanforderung und erfolgreicher Lerncode-Erfassung.
4. Isolierter PHP-Dry-Run-Regressionstest erfolgreich; `setPendingWeighing()` wurde im Dry-Run nicht aufgerufen und der DB-Besitzerkontext nicht verändert.
5. CLI-Dry-Run gegen leere Testdatenbank: unbekannter Funkcode kontrolliert verworfen.
6. CLI-Dry-Run nach Anlage der RF-Testdaten: Code `4719265` korrekt Fernbedienung und Fahrzeug zugeordnet.
7. Physischer End-to-End-Dry-Run: mehrere einzelne Tastendrücke stabil als `4719265 / 0x4802A1` erkannt; `weighing_state` blieb leer.
8. Kontrollierter echter RF-Trigger per CLI in `waagebox_test`: `weighing_state` korrekt mit `trigger_type=radio` angelegt und anschließend entfernt.
9. Kontrollierter echter physischer RF-End-to-End-Trigger in `waagebox_test`: realer Tastendruck über GPIO17, Python-Listener und PHP-Bridge korrekt bis `weighing_state` verarbeitet und anschließend entfernt.
10. systemd-Testbetrieb mit GPIO-Zugriff erfolgreich.
11. Realer Hardware-Einlernmodus mit separatem Testdienst: Code `4719265 / 0x4802A1` erfasst, Ergebnisdatei erzeugt, Wägeauslösung unterdrückt (`weighing_state=0`).
12. Produktive UI-Prüfung: Button `Handsender einlernen` erkannte `4719265`, übernahm den Code und meldete die bereits vorhandene Fernbedienung `FB3`; zugleich blieb `weighing_state=0`.
13. Produktiver Dry-Run für `FB3`: erfolgreich; Zuordnung zu Fahrzeug `EL-TJ 26 / JohnDeere`, Kunde 1, Erstgewicht `11500.000` validiert.
14. Produktiver echter Funk-End-to-End-Test: ein einzelner Tastendruck erzeugte korrekt `weighing_state` mit `first_weight=11500.000`, `vehicle_id=1`, `remote_id=3`, `customer_id=1` und `trigger_type=radio`.
15. Der produktive RF-Testzustand wurde anschließend kontrolliert entfernt; `weighing_state=0`.
16. Der produktive Dienst `waagenbox-rf-remote.service` wurde mit ausdrücklicher Freigabe dauerhaft aktiviert und lief danach `enabled` und `active`.

## systemd-Dienst

Versionierte Vorlage: `systemd/waagenbox-rf-remote.service`.

Produktiver Dienst:

- Benutzer/Gruppe `www-data`
- Zusatzgruppe `gpio`
- `RuntimeDirectory=waagenbox-rf`
- Laufzeitdateien unter `/run/waagenbox-rf`
- `NoNewPrivileges=true`
- `ProtectSystem=strict`
- `ProtectHome=true`
- produktiver Webroot nur lesbar für den Dienst
- automatischer Neustart bei Fehlern
- Start über `multi-user.target`

Der Dienst wurde produktiv mit `systemctl enable --now waagenbox-rf-remote.service` aktiviert und praktisch geprüft.

## Noch offen vor Release 1.2.32

Vor Erstellung und Veröffentlichung des signierten Updatepakets sind noch erforderlich:

- vollständige bestehende Regression-/Update-/Sicherheitstests auf dem finalen Release-Kandidaten,
- Release-Preflight und Syntaxprüfungen,
- anschließend Versionsanhebung in der alleinigen Versionsquelle `version.php` auf 1.2.32,
- erneuter Kurztest nach Versionsanhebung,
- Release-Dokumentation finalisieren,
- signiertes Updatepaket mit POSIX-ZIP-Pfaden erstellen und prüfen,
- Veröffentlichung/Installation erst nach ausdrücklicher Freigabe.
