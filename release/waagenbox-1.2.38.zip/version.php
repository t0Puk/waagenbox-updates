<?php
// Alleinige Versionsquelle. Legacy-config.php wird vor dem Austausch migriert.
const APP_VERSION = '1.2.38';
if (!defined('WEB_DEVELOPMENT')) { define('WEB_DEVELOPMENT', false); }
