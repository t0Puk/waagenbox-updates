AJP Waagenbox Web – Patch v1.2.6
================================

Nur diese beiden Dateien nach /waage/software/ hochladen und vorhandene Dateien ersetzen:
- version.php
- functions.php

NICHT config.php überschreiben.

Änderungen:
- APP_VERSION wird unabhängig von config.php intern auf 1.2.6 definiert.
- Dadurch funktionieren Versionsanzeige und Update-Prüfung wieder.
- Die bereits vorhandene dauerhafte Uhrzeit im Kopfbereich bleibt erhalten.
- Datenbank und Demo-Benutzer werden nicht verändert.

Nach dem Test bitte die zuvor angelegte debug.php wieder löschen.
