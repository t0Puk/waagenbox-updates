#!/usr/bin/env python3
"""Decode 24-bit 433 MHz OOK remotes from a libgpiod gpiomon line.

The listener never touches the database itself. After a code has been decoded
twice consecutively it invokes the configured PHP CLI bridge. A held button is
latched and triggers only once until the valid RF stream has been quiet long
enough to count as a release.

When a valid learn request is present, the next confirmed code is written to a
runtime result file and is NOT passed to the weighing trigger.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Optional

SHORT_MIN_US = 250
SHORT_MAX_US = 750
LONG_MIN_US = 800
LONG_MAX_US = 1700
SYNC_MIN_US = 7000
DATA_PULSES = 48
FRAME_PULSES = 49
CONFIRMATIONS_REQUIRED = 2
CONFIRMATION_WINDOW_S = 0.6
RELEASE_QUIET_S = 0.8

EVENT_RE = re.compile(r"\s*([0-9]+\.[0-9]+)\s+(rising|falling)\b")


def pulse_kind(duration_us: int) -> Optional[str]:
    if SHORT_MIN_US <= duration_us <= SHORT_MAX_US:
        return "S"
    if LONG_MIN_US <= duration_us <= LONG_MAX_US:
        return "L"
    return None


def decode_frame(frame: list[int]) -> Optional[int]:
    """Return a 24-bit integer only for an exactly aligned, valid frame."""
    if len(frame) != FRAME_PULSES or pulse_kind(frame[-1]) != "S":
        return None

    bits: list[str] = []
    for pos in range(0, DATA_PULSES, 2):
        first = pulse_kind(frame[pos])
        second = pulse_kind(frame[pos + 1])
        if first == "S" and second == "L":
            bits.append("0")
        elif first == "L" and second == "S":
            bits.append("1")
        else:
            return None

    return int("".join(bits), 2)


@dataclass
class ConfirmState:
    candidate: Optional[int] = None
    count: int = 0
    last_valid_at: float = 0.0
    latched: Optional[int] = None

    def observe(self, code: int, now: float) -> Optional[int]:
        if self.latched is not None and now - self.last_valid_at >= RELEASE_QUIET_S:
            self.latched = None

        if self.candidate == code and now - self.last_valid_at <= CONFIRMATION_WINDOW_S:
            self.count += 1
        else:
            self.candidate = code
            self.count = 1

        self.last_valid_at = now

        if self.count >= CONFIRMATIONS_REQUIRED and self.latched != code:
            self.latched = code
            return code

        return None

    def tick(self, now: float) -> None:
        if self.latched is not None and now - self.last_valid_at >= RELEASE_QUIET_S:
            self.latched = None
        if self.candidate is not None and now - self.last_valid_at > CONFIRMATION_WINDOW_S:
            self.candidate = None
            self.count = 0


def _safe_unlink(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError as exc:
        print(f"RF learn cleanup failed for {path}: {exc}", file=sys.stderr, flush=True)


def capture_learn_code(code: int, request_file: str, result_file: str, now: Optional[float] = None) -> bool:
    """Capture a confirmed code for an active learn request.

    Returns True only when the code was consumed by learn mode. In that case the
    normal weighing trigger must be suppressed.
    """
    request_path = Path(request_file)
    result_path = Path(result_file)
    if not request_path.is_file():
        return False

    try:
        request = json.loads(request_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        _safe_unlink(request_path)
        return False

    token = str(request.get("token", ""))
    owner_id = int(request.get("owner_id", 0) or 0)
    expires_at = float(request.get("expires_at", 0) or 0)
    wall_now = time.time() if now is None else now

    if not re.fullmatch(r"[0-9a-f]{32}", token) or owner_id <= 0 or expires_at <= wall_now:
        _safe_unlink(request_path)
        return False

    result = {
        "token": token,
        "owner_id": owner_id,
        "code": code,
        "hex": f"0x{code:06X}",
        "captured_at": int(wall_now),
    }

    try:
        result_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = result_path.with_name(result_path.name + f".{os.getpid()}.tmp")
        tmp_path.write_text(json.dumps(result, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp_path, result_path)
        _safe_unlink(request_path)
    except OSError as exc:
        print(f"RF learn result write failed: {exc}", file=sys.stderr, flush=True)
        return False

    print(f"RF learn captured: {code} (0x{code:06X})", flush=True)
    return True


def trigger_code(php: str, script: str, code: int, timeout: float) -> bool:
    try:
        result = subprocess.run(
            [php, script, str(code)],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"RF trigger failed for {code}: {exc}", file=sys.stderr, flush=True)
        return False

    stdout = result.stdout.strip()
    stderr = result.stderr.strip()
    if stdout:
        print(stdout, flush=True)
    if result.returncode != 0:
        detail = stderr or f"exit={result.returncode}"
        print(f"RF trigger rejected for {code}: {detail}", file=sys.stderr, flush=True)
        return False
    return True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AJP Waagenbox 433 MHz remote listener")
    parser.add_argument("--line", default="GPIO17", help="libgpiod line name (default: GPIO17)")
    parser.add_argument("--gpiomon", default="/usr/bin/gpiomon", help="path to gpiomon")
    parser.add_argument("--php", default="/usr/bin/php", help="path to PHP CLI")
    parser.add_argument(
        "--trigger-script",
        default="/var/www/waage/cli/rf_remote_trigger.php",
        help="PHP CLI bridge",
    )
    parser.add_argument("--trigger-timeout", type=float, default=5.0)
    parser.add_argument("--learn-request", default="/run/waagenbox-rf/learn-request.json")
    parser.add_argument("--learn-result", default="/run/waagenbox-rf/learn-result.json")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        proc = subprocess.Popen(
            [args.gpiomon, "--edges=both", args.line],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
    except OSError as exc:
        print(f"Cannot start gpiomon: {exc}", file=sys.stderr)
        return 1

    if proc.stdout is None:
        print("gpiomon stdout unavailable", file=sys.stderr)
        proc.terminate()
        return 1

    last_timestamp: Optional[float] = None
    frame: list[int] = []
    confirm = ConfirmState()

    print(f"AJP RF listener active on {args.line}", flush=True)

    try:
        for line in proc.stdout:
            match = EVENT_RE.match(line)
            now_wall = time.monotonic()
            confirm.tick(now_wall)

            if not match:
                continue

            timestamp = float(match.group(1))
            if last_timestamp is None:
                last_timestamp = timestamp
                continue

            duration_us = round((timestamp - last_timestamp) * 1_000_000)
            last_timestamp = timestamp

            if duration_us >= SYNC_MIN_US:
                code = decode_frame(frame)
                frame = []

                if code is not None:
                    triggered = confirm.observe(code, now_wall)
                    if triggered is not None:
                        print(
                            f"RF code confirmed: {triggered} (0x{triggered:06X})",
                            flush=True,
                        )
                        if capture_learn_code(triggered, args.learn_request, args.learn_result):
                            continue
                        trigger_code(
                            args.php,
                            args.trigger_script,
                            triggered,
                            args.trigger_timeout,
                        )
                continue

            if SHORT_MIN_US <= duration_us <= LONG_MAX_US:
                frame.append(duration_us)
                if len(frame) > 60:
                    frame = []

    except KeyboardInterrupt:
        return 0
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            proc.kill()

    if proc.returncode not in (0, -15):
        stderr = proc.stderr.read().strip() if proc.stderr else ""
        if stderr:
            print(stderr, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
