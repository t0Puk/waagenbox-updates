<?php
/**
 * AJP Waagenbox – Dini 3590ET/3590EGT TCP command client
 *
 * Based on the supplied Dini 3590ET/3590EGT serial command documentation.
 * All commands are terminated with CR/LF.
 *
 * IMPORTANT:
 * The TCP port is intentionally configurable. The supplied documentation
 * confirms Ethernet/TCP support but does not specify the ETHKR-1 TCP port.
 */
class Dini3590
{
    private string $host;
    private int $port;
    private float $timeout;

    public function __construct(string $host, int $port, float $timeout = 2.0)
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
    }

    public function command(string $command, bool $waitForAnswer = true): string
    {
        $errno = 0;
        $errstr = '';
        $socket = @fsockopen(
            $this->host,
            $this->port,
            $errno,
            $errstr,
            $this->timeout
        );

        if (!$socket) {
            throw new RuntimeException(
                "Dini nicht erreichbar ({$this->host}:{$this->port}): {$errstr} ({$errno})"
            );
        }

        stream_set_timeout($socket, (int)$this->timeout, (int)(($this->timeout - (int)$this->timeout) * 1000000));

        $wire = $command . "\r\n";
        $written = fwrite($socket, $wire);
        if ($written === false || $written < strlen($wire)) {
            fclose($socket);
            throw new RuntimeException("Befehl konnte nicht vollständig an die Dini gesendet werden.");
        }

        if (!$waitForAnswer) {
            fclose($socket);
            return '';
        }

        $answer = '';
        $started = microtime(true);

        while ((microtime(true) - $started) < $this->timeout) {
            $chunk = fgets($socket);
            if ($chunk !== false) {
                $answer .= $chunk;
                if (str_ends_with($answer, "\r\n") || str_ends_with($answer, "\n")) {
                    break;
                }
            } else {
                $meta = stream_get_meta_data($socket);
                if (!empty($meta['timed_out'])) {
                    break;
                }
                usleep(10000);
            }
        }

        fclose($socket);

        if ($answer === '') {
            throw new RuntimeException("Keine Antwort von der Dini auf '{$command}'.");
        }

        return trim($answer, "\r\n");
    }

    /** R – Gewicht lesen. Antwort kann Standard- oder Extended-Protokoll sein. */
    public function readWeight(): array
    {
        $raw = $this->command('R');
        return $this->parseWeightAnswer($raw);
    }

    /** REXT – erweiterten Gewichtsdatensatz lesen. */
    public function readExtendedWeight(): array
    {
        $raw = $this->command('REXT');
        $parts = explode(',', $raw);

        // Erwartete Struktur: c,ss,weight,pp,tare,pieces,avg,unit
        return [
            'raw' => $raw,
            'channel' => trim($parts[0] ?? ''),
            'status' => trim($parts[1] ?? ''),
            'weight' => $this->numberOrNull($parts[2] ?? null),
            'tare_type' => trim($parts[3] ?? ''),
            'tare' => $this->numberOrNull($parts[4] ?? null),
            'pieces' => $this->numberOrNull($parts[5] ?? null),
            'average_piece_weight' => $this->numberOrNull($parts[6] ?? null),
            'unit' => trim($parts[7] ?? ''),
        ];
    }

    /** RALL – kompletter Statusdatensatz inklusive Instrument state/key buffer. */
    public function readAll(): array
    {
        $raw = $this->command('RALL');
        $parts = explode(',', $raw);

        return [
            'raw' => $raw,
            'channel' => trim($parts[0] ?? ''),
            'status' => trim($parts[1] ?? ''),
            'gross' => $this->numberOrNull($parts[2] ?? null),
            'unit' => trim($parts[3] ?? ''),
            'tare_type' => trim($parts[4] ?? ''),
            'tare' => $this->numberOrNull($parts[5] ?? null),
            'last_totalization_scale' => trim($parts[6] ?? ''),
            'last_totalization_net' => $this->numberOrNull($parts[7] ?? null),
            'last_totalization_unit' => trim($parts[8] ?? ''),
            'last_totalization_gross' => $this->numberOrNull($parts[9] ?? null),
            'scale_state' => trim($parts[10] ?? ''),
            'pressed_keys_counter' => trim($parts[11] ?? ''),
            'pressed_key_code' => trim($parts[12] ?? ''),
            'totalizations' => trim($parts[13] ?? ''),
            'alibi_rewrite_id' => trim($parts[14] ?? ''),
            'alibi_id' => trim($parts[15] ?? ''),
        ];
    }

    /** STAT – Arbeitszustand des Instruments. */
    public function readState(): array
    {
        $raw = $this->command('STAT');
        $index = (int)preg_replace('/\D+/', '', $raw);
        $states = [
            0 => 'Instrument start-up',
            1 => 'Scale',
            3 => 'Menu',
            4 => 'Setup',
            10 => 'Scale switch',
            11 => 'Reception / transmission of setup',
            12 => 'Serial test',
            13 => 'Print test',
            33 => 'Dosage',
            34 => 'Stand-by',
            35 => 'User input',
            36 => 'Auto zero',
            37 => 'Diagnostic',
            38 => 'Digital output diagnostic',
        ];
        return ['raw' => $raw, 'index' => $index, 'name' => $states[$index] ?? 'Unbekannt'];
    }

    /**
     * KEYP – Tastendruck simulieren.
     * Laut supplied documentation: first weighing = 37, second weighing = 38.
     */
    public function pressKey(string $hexCode): string
    {
        $hexCode = strtoupper(trim($hexCode));
        if (!preg_match('/^[0-9A-F]{2}$/', $hexCode)) {
            throw new InvalidArgumentException("Ungültiger Dini-Key-Code: {$hexCode}");
        }
        return $this->command('KEYP' . $hexCode);
    }

    /** KEYR – Tastenfreigabe. Muss unmittelbar nach KEYP gesendet werden. */
    public function releaseKey(): string
    {
        return $this->command('KEYR');
    }

    public function startFirstWeighing(): array
    {
        $press = $this->pressKey('37');
        $release = $this->releaseKey();
        return ['key' => '37', 'press_answer' => $press, 'release_answer' => $release];
    }

    public function startSecondWeighing(): array
    {
        $press = $this->pressKey('38');
        $release = $this->releaseKey();
        return ['key' => '38', 'press_answer' => $press, 'release_answer' => $release];
    }

    /** OUTP – digitalen Ausgang setzen. 0000 = aktiv, 0001 = inaktiv. */
    public function setOutput(int $index, bool $active): string
    {
        if ($index < 0 || $index > 0x10) {
            throw new InvalidArgumentException('Ausgang muss zwischen 0 und 16 liegen.');
        }
        $hexIndex = strtoupper(dechex($index));
        $value = $active ? '0000' : '0001';
        return $this->command('OUTP' . $hexIndex . $value);
    }

    public function readDigitalInputs(): string
    {
        return $this->command('GETI');
    }

    public function identify(): string
    {
        return $this->command('VER');
    }

    private function parseWeightAnswer(string $raw): array
    {
        $parts = explode(',', $raw);
        return [
            'raw' => $raw,
            'status' => trim($parts[0] ?? ''),
            'type' => trim($parts[1] ?? ''),
            'weight' => $this->numberOrNull($parts[2] ?? null),
            'unit' => trim($parts[3] ?? ''),
        ];
    }

    private function numberOrNull(?string $value): ?float
    {
        if ($value === null) return null;
        $value = trim($value);
        if ($value === '' || !is_numeric($value)) return null;
        return (float)$value;
    }
}
