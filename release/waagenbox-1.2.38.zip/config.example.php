<?php
// AJP Waagenbox – lokale Produktionsinstallation
const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'waagebox';
const DB_USER = 'waageapp';
const DB_PASS = 'CHANGE_ME';

// Die Programmversion wird ausschließlich in version.php definiert.
const APP_TIMEZONE = 'Europe/Berlin';
date_default_timezone_set(APP_TIMEZONE);
