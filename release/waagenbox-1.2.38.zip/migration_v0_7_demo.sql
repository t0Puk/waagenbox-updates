-- AJP Waagensteuerung v0.7 – Demo-Login / Benutzerverwaltung
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username VARCHAR(80) NOT NULL,
  display_name VARCHAR(150) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','demo') NOT NULL DEFAULT 'demo',
  active TINYINT(1) NOT NULL DEFAULT 1,
  expires_at DATETIME NULL,
  force_password_change TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  KEY idx_users_role (role),
  KEY idx_users_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Erster Administrator. Das mitgelieferte temporäre Passwort muss beim ersten Login geändert werden.
INSERT INTO users (username,display_name,password_hash,role,active,expires_at,force_password_change)
SELECT 'admin','AJP Administrator','$2y$12$/3DTsNxXqyxy2Bj5tIrhROW5OF80i/GKudy6LtpoVNn1.foaTetZG','admin',1,NULL,1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='admin');
-- AJP Waagensteuerung v0.7.1 – getrennte Demo-Daten je Benutzer
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- Vorbedingung: migration_v0_7_auth.sql wurde bereits ausgeführt.

ALTER TABLE settings ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE vehicles ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE fields ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remotes ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE customers ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE products ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE weighings ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE weighing_state ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_fields ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_customers ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;
ALTER TABLE remote_products ADD COLUMN owner_user_id INT UNSIGNED NULL FIRST;

SET @admin_id := (SELECT id FROM users WHERE username='admin' LIMIT 1);
UPDATE settings SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE vehicles SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE fields SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remotes SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE customers SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE products SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE weighings SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE weighing_state SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_fields SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_customers SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;
UPDATE remote_products SET owner_user_id=@admin_id WHERE owner_user_id IS NULL;

ALTER TABLE settings MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE vehicles MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE fields MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remotes MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE customers MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE products MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE weighings MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE weighing_state MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_fields MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_customers MODIFY owner_user_id INT UNSIGNED NOT NULL;
ALTER TABLE remote_products MODIFY owner_user_id INT UNSIGNED NOT NULL;

ALTER TABLE settings DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,`key`), ADD KEY idx_settings_key(`key`);
ALTER TABLE vehicles DROP INDEX uq_vehicle_plate, ADD UNIQUE KEY uq_vehicle_owner_plate(owner_user_id,plate);
ALTER TABLE remotes DROP INDEX uq_remote_code, ADD UNIQUE KEY uq_remote_owner_code(owner_user_id,code);
ALTER TABLE remote_fields DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,field_id), ADD KEY idx_rf_owner_active(owner_user_id,remote_id,active);
ALTER TABLE remote_customers DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,customer_id), ADD KEY idx_rc_owner_active(owner_user_id,remote_id,active);
ALTER TABLE remote_products DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,remote_id,product_id), ADD KEY idx_rp_owner_active(owner_user_id,remote_id,active);
ALTER TABLE weighing_state DROP PRIMARY KEY, ADD PRIMARY KEY(owner_user_id,id);

-- Trigger setzen den Mandanten automatisch bei INSERT. Direkte INSERTs ohne eingeloggten
-- Benutzer werden bewusst abgewiesen.
DROP TRIGGER IF EXISTS trg_settings_owner;
DROP TRIGGER IF EXISTS trg_vehicles_owner;
DROP TRIGGER IF EXISTS trg_fields_owner;
DROP TRIGGER IF EXISTS trg_remotes_owner;
DROP TRIGGER IF EXISTS trg_customers_owner;
DROP TRIGGER IF EXISTS trg_products_owner;
DROP TRIGGER IF EXISTS trg_weighings_owner;
DROP TRIGGER IF EXISTS trg_weighing_state_owner;
DROP TRIGGER IF EXISTS trg_remote_fields_owner;
DROP TRIGGER IF EXISTS trg_remote_customers_owner;
DROP TRIGGER IF EXISTS trg_remote_products_owner;

DELIMITER $$
CREATE TRIGGER trg_settings_owner BEFORE INSERT ON settings FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_vehicles_owner BEFORE INSERT ON vehicles FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_fields_owner BEFORE INSERT ON fields FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remotes_owner BEFORE INSERT ON remotes FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_customers_owner BEFORE INSERT ON customers FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_products_owner BEFORE INSERT ON products FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_weighings_owner BEFORE INSERT ON weighings FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_weighing_state_owner BEFORE INSERT ON weighing_state FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_fields_owner BEFORE INSERT ON remote_fields FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_customers_owner BEFORE INSERT ON remote_customers FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_products_owner BEFORE INSERT ON remote_products FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_demo_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Demo-Benutzerkontext'; END IF; END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=1;
