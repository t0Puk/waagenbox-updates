-- WägeSoftware v0.5 – Mehrfach-Zuordnungen für Fernbedienungen + globaler Wiegungsstatus
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS remote_fields (
  remote_id INT UNSIGNED NOT NULL,
  field_id INT UNSIGNED NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (remote_id, field_id),
  KEY idx_rf_active (remote_id, active),
  CONSTRAINT fk_rf_remote FOREIGN KEY (remote_id) REFERENCES remotes(id) ON DELETE CASCADE,
  CONSTRAINT fk_rf_field FOREIGN KEY (field_id) REFERENCES fields(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS remote_customers (
  remote_id INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (remote_id, customer_id),
  KEY idx_rc_active (remote_id, active),
  CONSTRAINT fk_rc_remote FOREIGN KEY (remote_id) REFERENCES remotes(id) ON DELETE CASCADE,
  CONSTRAINT fk_rc_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS remote_products (
  remote_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (remote_id, product_id),
  KEY idx_rp_active (remote_id, active),
  CONSTRAINT fk_rp_remote FOREIGN KEY (remote_id) REFERENCES remotes(id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS weighing_state (
  id TINYINT UNSIGNED NOT NULL,
  first_weight DECIMAL(12,3) NOT NULL,
  vehicle_id INT UNSIGNED NULL,
  remote_id INT UNSIGNED NULL,
  field_id INT UNSIGNED NULL,
  customer_id INT UNSIGNED NULL,
  product_id INT UNSIGNED NULL,
  trigger_type VARCHAR(30) NOT NULL DEFAULT 'manual',
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_ws_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
  CONSTRAINT fk_ws_remote FOREIGN KEY (remote_id) REFERENCES remotes(id) ON DELETE SET NULL,
  CONSTRAINT fk_ws_field FOREIGN KEY (field_id) REFERENCES fields(id) ON DELETE SET NULL,
  CONSTRAINT fk_ws_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_ws_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
