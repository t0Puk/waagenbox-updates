<?php
require_once __DIR__.'/../functions.php';
requireLogin();
$id=(int)($_GET['id']??0);
$s=db()->prepare("SELECT f.*, COALESCE(SUM(w.net_weight),0) AS total_net_weight, COUNT(w.id) AS weighing_count
                  FROM `fields` f LEFT JOIN weighings w ON w.field_id=f.id AND w.owner_user_id=f.owner_user_id WHERE f.owner_user_id=? AND f.id=? GROUP BY f.id");
$s->execute([currentOwnerId(),$id]);
$r=$s->fetch();
if(!$r){http_response_code(404);exit('Schlag nicht gefunden');}
?><!doctype html><html lang="de"><head><meta charset="utf-8"><title>Schlagbericht – <?=h($r['name'])?></title><style>
body{font-family:Arial,sans-serif;margin:40px;max-width:850px;color:#14202c}h1{margin-bottom:4px}.subtitle{color:#617080}.box{border:1px solid #ccc;padding:24px;margin:24px 0}table{width:100%;border-collapse:collapse}td{padding:11px;border-bottom:1px solid #ddd}td:first-child{width:45%;font-weight:700}.total{font-size:30px;font-weight:bold}.no-print{margin-bottom:24px}.button{display:inline-block;border:0;background:#17212b;color:#fff;padding:10px 14px;border-radius:7px;font-weight:700;cursor:pointer;text-decoration:none;margin-right:8px}@media print{.no-print{display:none}body{margin:20px}}
</style></head><body>
<div class="no-print"><a class="button" href="../fields.php">← Zurück zu Schlägen</a><button class="button" type="button" onclick="window.print()">Drucken / als PDF speichern</button></div>
<h1>Schlagbericht</h1><p class="subtitle"><?=h($r['name'])?></p>
<div class="box"><table>
<tr><td>Name</td><td><?=h($r['name'])?></td></tr>
<tr><td>Kultur</td><td><?=h($r['crop'] ?: '–')?></td></tr>
<tr><td>Jahr</td><td><?=h($r['year'] ?: '–')?></td></tr>
<tr><td>Fläche</td><td><?=h($r['area'] !== null ? number_format((float)$r['area'],2,',','.') : '–')?><?= $r['area'] !== null ? ' ha' : '' ?></td></tr>
<tr><td>Gewogene Gesamtmenge</td><td class="total"><?=number_format((float)$r['total_net_weight'],1,',','.')?> kg</td></tr>
<tr><td>Gewogene Menge in Tonnen</td><td><?=number_format((float)$r['total_net_weight']/1000,2,',','.')?> t netto</td></tr>
<tr><td>Anzahl Wiegungen</td><td><?=h($r['weighing_count'])?></td></tr>
</table></div>
<?php if(!empty($r['notes'])): ?><p><strong>Notizen:</strong><br><?=nl2br(h($r['notes']))?></p><?php endif; ?>
</body></html>
