<?php
require_once __DIR__.'/functions.php';
requireLogin();
$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $pdo=db();
  if(isset($_POST['toggle_id'])){ $id=(int)$_POST['toggle_id'];$q=$pdo->prepare('SELECT active FROM products WHERE owner_user_id=? AND id=?');$q->execute([currentOwnerId(),$id]);$r=$q->fetch();if(!$r)throw new RuntimeException('Produkt wurde nicht gefunden.');$s=$pdo->prepare('UPDATE products SET active=? WHERE owner_user_id=? AND id=?');$s->execute([(int)$r['active']?0:1,currentOwnerId(),$id]);flash('Produktstatus wurde geändert.');redirect('products.php'); }
  if(isset($_POST['delete_id'])){ $id=(int)$_POST['delete_id'];$s=$pdo->prepare('DELETE FROM products WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$id]);flash($s->rowCount()?'Produkt wurde gelöscht.':'Produkt wurde nicht gefunden.');redirect('products.php'); }
  $name=trim((string)($_POST['name']??''));$notes=trim((string)($_POST['notes']??''));if($name==='')throw new RuntimeException('Bitte einen Produktnamen eingeben.');
  $s=$pdo->prepare('INSERT INTO products(name,notes) VALUES(?,?)');$s->execute([$name,$notes]);flash('Produkt wurde angelegt.');redirect('products.php');
 }catch(Throwable $e){$error=$e->getMessage();}
}
layoutStart('Produkte','products');if($error)echo '<div class="flash error"><strong>Produkt konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$rows=db()->query('SELECT p.*,COUNT(w.id) AS weighing_count FROM products p LEFT JOIN weighings w ON w.product_id=p.id AND w.owner_user_id=p.owner_user_id WHERE p.owner_user_id='.(int)currentOwnerId().' GROUP BY p.id ORDER BY p.name')->fetchAll();
?>
<div class="toolbar"><h1>Produkte</h1><a class="button primary" href="#neu">+ Produkt anlegen</a></div>
<div class="card table-wrap"><table><tr><th>Status</th><th>Produkt</th><th>Wiegungen</th><th></th></tr><?php foreach($rows as $r): ?><tr><td><?=((int)$r['active']?'Aktiv':'<span class="muted">Deaktiviert</span>')?></td><td><strong><?=h($r['name'])?></strong></td><td><?=h($r['weighing_count'])?></td><td class="row-actions"><form method="post" style="display:inline"><button class="button" name="toggle_id" value="<?=h($r['id'])?>"><?=((int)$r['active']?'Deaktivieren':'Aktivieren')?></button></form><form method="post" style="display:inline" onsubmit="return confirm(<?=json_encode('Produkt '.($r['name']??'').' wirklich endgültig löschen?\n\nBestehende Wiegungen bleiben erhalten, verlieren aber die Produkt-Zuordnung.\n\nDieser Vorgang kann nicht rückgängig gemacht werden.',JSON_UNESCAPED_UNICODE)?>)"><button class="button-danger" name="delete_id" value="<?=h($r['id'])?>">Löschen</button></form></td></tr><?php endforeach; ?></table></div>
<div class="card" id="neu"><h2>Produkt anlegen</h2><form method="post"><div class="form-grid"><div><label>Name</label><input name="name" required></div><div class="full"><label>Notizen</label><textarea name="notes"></textarea></div></div><p><button class="button primary">Produkt speichern</button></p></form></div>
<?php layoutEnd(); ?>
