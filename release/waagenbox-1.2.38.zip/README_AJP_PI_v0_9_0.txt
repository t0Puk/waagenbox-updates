AJP WAAGENBOX – Dini-Hardwarevorbereitung v0.9.0

Dieses Paket enthält die erste Hardware-Schicht für den Raspberry-Pi-Test.
Die bestehende Demo-Oberfläche bleibt die Grundlage; diese Dateien sind
zusätzliche Bausteine für die Dini 3590ET/3590EGT-Kommunikation.

Aus der bereitgestellten Dini-Dokumentation übernommen:
- Befehle werden mit CR/LF beendet.
- R = Gewicht lesen.
- REXT = erweiterter Gewichtsdatensatz.
- RALL = kompletter Datensatz inkl. Instrumentzustand und Tastencode.
- STAT = Arbeitszustand des Instruments.
- KEYPxx = Tastendruck simulieren.
- KEYR = Tastenfreigabe; laut Dokumentation unmittelbar nach KEYP senden.
- Für das von dir gezeigte AF09-Szenario:
    KEYP37 = 1. Wiegung
    KEYR
    KEYP38 = 2. Wiegung
    KEYR
- OUTP = digitale Ausgänge setzen; später für reale Ampel nutzbar.
- GETI = digitale Eingänge lesen.
- VER = Modell/Firmware abfragen.

WICHTIG:
Die bereitgestellten Unterlagen bestätigen Ethernet/TCP, nennen für die
interne Ethernet-Variante aber keinen eindeutigen TCP-Port. Deshalb steht in
config/dini.php nur ein Platzhalter. Wir ermitteln den tatsächlichen Port
beim ersten Test, statt einen Port zu erfinden.

Dateien:
hardware/Dini3590.php
    PHP-Treiber für die Dini-Kommandos.

config/dini.php
    IP, TCP-Port und Timeout.

api/dini_test.php
    Kleiner Test-Endpunkt:
      ?action=weight
      ?action=extended
      ?action=all
      ?action=state
      ?action=identify
      ?action=first
      ?action=second

Nächster Schritt:
1. Raspberry Pi Grundsystem fertigstellen.
2. Apache/PHP installieren.
3. Bestehende AJP-Software auf den Pi übertragen.
4. Dieses Hardware-Modul einfügen.
5. Dini-IP und den tatsächlich verwendeten TCP-Port testen.
6. Erst danach die normale Wiegungslogik von Demo auf Dini umschalten.

Die Ampel-Logik bleibt eine eigene Ebene:
READY / WAITING / PROCESSING.
Später kann READY/WAITING/PROCESSING zusätzlich auf OUTP/GPIO abgebildet
werden.
