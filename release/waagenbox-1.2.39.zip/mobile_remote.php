<?php
require_once __DIR__.'/functions.php';

$token=trim((string)($_GET['t']??''));
if($token===''){http_response_code(404);exit('Ungültiger QR-Code.');}
if(useMobileContextByToken($token)===null){http_response_code(404);exit('Ungültiger QR-Code.');}

$s=db()->prepare(
    'SELECT r.*,v.plate,v.name AS vehicle_name,v.first_weight,v.active AS vehicle_active
       FROM remotes r
       LEFT JOIN vehicles v
         ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id
      WHERE r.owner_user_id=? AND r.mobile_token=?
      LIMIT 1'
);
$s->execute([currentOwnerId(),$token]);
$remote=$s->fetch();

if(!$remote || (int)$remote['active']!==1 || (int)($remote['vehicle_active']??0)!==1){
    http_response_code(403);
    exit('Diese mobile Fernbedienung ist nicht aktiv.');
}

$gpsEnabledServer=appSetting('gps_enabled','0')==='1';
$vehicleLabel=trim(($remote['plate']??'').' – '.($remote['vehicle_name']??''),' –');
$brandName=trim(appSetting('brand_name','AJP WAAGE'));
if($brandName==='') $brandName='AJP WAAGE';

$contactEnabled=appSetting('contact_enabled','0')==='1';
$contactPhone=trim(appSetting('contact_phone',''));
$contactHref=preg_replace('/[^0-9+]/','',$contactPhone);
$showContact=$contactEnabled && $contactPhone!=='' && $contactHref!=='';
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#17212b">
<title><?=h($brandName)?> – <?=h($remote['name'])?></title>
<link rel="stylesheet" href="assets/style.css?v=<?=h((string)(@filemtime(__DIR__.'/assets/style.css') ?: APP_VERSION))?>">
</head>
<body class="mobile-remote-page">
<div class="mobile-remote">
  <div class="mobile-brand"><?=h($brandName)?></div>
  <div class="mobile-card">
    <div class="eyebrow">FERNBEDIENUNG</div>
    <h1><?=h($remote['name'])?></h1>
    <div class="mobile-vehicle">🚜 <?=h($vehicleLabel ?: 'Kein Fahrzeug')?></div>

    <div id="gpsBox" class="gps-box">
      <?= $gpsEnabledServer ? '📍 Standort wird geprüft …' : '🟢 GPS-Prüfung ist deaktiviert.' ?>
    </div>

    <div class="mobile-weight">
      <div class="eyebrow">AKTUELLES WAAGENGEWICHT</div>
      <div id="currentWeight">– <span>kg</span></div>
      <div id="firstWeight" class="mobile-first">Wiegestatus wird geladen …</div>
    </div>

    <button id="startButton" class="mobile-start" <?= $gpsEnabledServer ? 'disabled' : '' ?>>
      WIEGUNG<br>STARTEN
    </button>

    <div id="mobileStatus" class="mobile-status">
      <?= $gpsEnabledServer ? 'Bitte Standortzugriff erlauben.' : 'Bereit zum Wiegen.' ?>
    </div>

    <div id="successBox" class="mobile-success" style="display:none">
      <div class="mobile-success-icon">✓</div>
      <div id="successTitle" class="mobile-success-title">Wiegung gespeichert</div>
      <div id="successDetails" class="mobile-success-details"></div>
      <div class="mobile-success-countdown">
        Die Wiegeoberfläche wird in <span id="successCountdown">10</span> Sekunden wieder geöffnet.
      </div>
    </div>
  </div>

  <div id="mobileNote" class="mobile-note">
    Die Wiegung kann nur in der Nähe der hinterlegten Waage gestartet werden.
  </div>

  <?php if($showContact): ?>
    <div class="mobile-contact"><a href="tel:<?=h($contactHref)?>">Kontakt</a></div>
  <?php endif; ?>
</div>

<script>
const token=<?=json_encode($token)?>;
const startButton=document.getElementById('startButton');
const gpsBox=document.getElementById('gpsBox');
const statusBox=document.getElementById('mobileStatus');
const weightBox=document.getElementById('currentWeight');
const firstBox=document.getElementById('firstWeight');
const successBox=document.getElementById('successBox');
const successTitle=document.getElementById('successTitle');
const successDetails=document.getElementById('successDetails');
const successCountdown=document.getElementById('successCountdown');
const mobileNote=document.getElementById('mobileNote');

let locationData=<?= $gpsEnabledServer ? 'null' : '{gpsDisabled:true}' ?>;
let locationAllowed=<?= $gpsEnabledServer ? 'false' : 'true' ?>;
let gpsEnabled=<?= $gpsEnabledServer ? 'true' : 'false' ?>;
let running=false;
let successShown=false;
let finishTimer=null;
let lastWeight=0;

function roundedWeight(v){
  return Math.round((Number(v)||0)/5)*5;
}

function formattedWeight(v){
  return roundedWeight(v).toLocaleString('de-DE',{maximumFractionDigits:0});
}

function showWeight(v){
  weightBox.innerHTML=formattedWeight(v)+' <span>kg</span>';
}

function showReadyStatus(d){
  if(d.has_open_weighing){
    firstBox.textContent='Offene 1. Wiegung: '+formattedWeight(d.open_first_weight)+' kg';
    statusBox.textContent='🟢 1. Wiegung gespeichert. Bereit für die 2. Wiegung.';
  }else if(Number(d.vehicle_first_weight)>0){
    firstBox.textContent='Gespeichertes Leergewicht: '+formattedWeight(d.vehicle_first_weight)+' kg';
    statusBox.textContent='🟢 Bereit zum Wiegen.';
  }else{
    firstBox.textContent='Noch keine offene Wiegung';
    statusBox.textContent='🟢 Bereit für die 1. Wiegung.';
  }

  startButton.style.display='block';
  startButton.disabled=!locationAllowed;
}

async function refreshStatus(){
  if(successShown) return;

  try{
    const r=await fetch('api/mobile_status.php?t='+encodeURIComponent(token),{cache:'no-store'});
    const d=await r.json();

    if(!d.ok){
      statusBox.textContent='🔴 '+(d.message||'Status konnte nicht geladen werden.');
      return;
    }

    const w=Number(d.current_weight)||0;
    showWeight(w);

    if(d.pending){
      running=true;
      startButton.style.display='none';

      if(d.pending_mode==='first'){
        firstBox.textContent='1. Wiegung: wartet auf Überfahrt';

        if(w>0 && lastWeight<=0 && !finishTimer){
          statusBox.textContent='🟡 Gewicht erkannt. 1. Wiegung wird gespeichert …';
          finishTimer=setTimeout(()=>completeCurrentPass(),1000);
        }else if(w<=0 && !finishTimer){
          statusBox.textContent='🟢 1. Wiegung gestartet. Jetzt langsam über die Waage fahren …';
        }
      }else{
        firstBox.textContent='Referenzgewicht: '+formattedWeight(d.first_weight)+' kg';

        if(w>0 && lastWeight<=0 && !finishTimer){
          statusBox.textContent='🟡 Gewicht erkannt. Wiegung wird verarbeitet …';
          finishTimer=setTimeout(()=>completeCurrentPass(),1000);
        }else if(w<=0 && !finishTimer){
          statusBox.textContent='🟢 Wiegung gestartet. Jetzt langsam über die Waage fahren …';
        }
      }

      if(w<=0 && finishTimer){
        clearTimeout(finishTimer);
        finishTimer=null;
      }

      lastWeight=w>0?w:0;
    }else{
      running=false;
      lastWeight=w>0?w:0;
      showReadyStatus(d);
    }
  }catch(e){
    statusBox.textContent='🔴 Verbindung zur Waagenbox fehlgeschlagen.';
  }
}

function checkLocation(){
  if(!gpsEnabled){
    locationData={gpsDisabled:true};
    locationAllowed=true;
    gpsBox.textContent='🟢 GPS-Prüfung ist deaktiviert.';
    if(mobileNote) mobileNote.textContent='Die Wiegung kann ohne Standortfreigabe gestartet werden.';
    if(!running) startButton.disabled=false;
    return;
  }

  if(!navigator.geolocation){
    gpsBox.textContent='🔴 Dieses Smartphone unterstützt keine Standortabfrage.';
    statusBox.textContent='Wiegung nicht möglich.';
    return;
  }

  gpsBox.textContent='📍 Standort wird geprüft …';
  startButton.disabled=true;

  navigator.geolocation.getCurrentPosition(async p=>{
    locationData={
      lat:p.coords.latitude,
      lon:p.coords.longitude,
      accuracy:p.coords.accuracy
    };

    try{
      const r=await fetch('api/mobile_location.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          token,
          latitude:locationData.lat,
          longitude:locationData.lon,
          accuracy:locationData.accuracy
        })
      });
      const d=await r.json();

      if(d.ok){
        locationAllowed=true;
        gpsBox.textContent='🟢 Standort bestätigt · '+Math.round(d.distance_m)+' m von der Waage';
        if(!running) startButton.disabled=false;
      }else{
        locationAllowed=false;
        gpsBox.textContent='🔴 '+d.message;
        if(!running){
          statusBox.textContent='Wiegung nicht möglich.';
          startButton.disabled=true;
        }
      }
    }catch(e){
      locationAllowed=false;
      gpsBox.textContent='🔴 Standortprüfung fehlgeschlagen.';
      if(!running) startButton.disabled=true;
    }
  },e=>{
    locationAllowed=false;
    gpsBox.textContent='🔴 Standort konnte nicht ermittelt werden: '+e.message;
    if(!running){
      statusBox.textContent='Bitte Standortzugriff erlauben.';
      startButton.disabled=true;
    }
  },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
}

startButton.addEventListener('click',async()=>{
  if(!locationAllowed || !locationData){
    statusBox.textContent='🔴 Standortprüfung ist noch nicht abgeschlossen.';
    return;
  }

  startButton.disabled=true;
  statusBox.textContent='Wiegung wird gestartet …';

  try{
    const payload=locationData.gpsDisabled
      ? {token}
      : {
          token,
          latitude:locationData.lat,
          longitude:locationData.lon,
          accuracy:locationData.accuracy
        };

    const r=await fetch('api/mobile_trigger.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    });
    const d=await r.json();

    if(!d.ok) throw new Error(d.message||'Wiegung konnte nicht gestartet werden.');

    running=true;
    lastWeight=0;
    startButton.style.display='none';

    if(d.mode==='first'){
      statusBox.textContent='🟢 1. Wiegung gestartet. Jetzt langsam über die Waage fahren …';
      firstBox.textContent='1. Wiegung: wartet auf Überfahrt';
    }else if(d.mode==='second'){
      statusBox.textContent='🟢 2. Wiegung gestartet. Jetzt langsam über die Waage fahren …';
    }else{
      statusBox.textContent='🟢 Wiegung gestartet. Jetzt langsam über die Waage fahren …';
    }

    await refreshStatus();
  }catch(e){
    running=false;
    statusBox.textContent='🔴 '+(e.message||'Wiegung konnte nicht gestartet werden.');
    if(gpsEnabled) checkLocation();
    else startButton.disabled=false;
  }
});

async function completeCurrentPass(){
  finishTimer=null;
  if(successShown || !running) return;

  statusBox.textContent='Wiegung wird verarbeitet …';

  try{
    const r=await fetch('api/mobile_complete.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({token})
    });
    const d=await r.json();

    if(!d.ok) throw new Error(d.message||'Wiegung konnte nicht verarbeitet werden.');

    successShown=true;
    running=false;
    statusBox.style.display='none';
    successBox.style.display='block';

    if(d.phase==='first_saved'){
      successTitle.textContent='1. Wiegung gespeichert';
      successDetails.textContent='1. Gewicht: '+formattedWeight(d.first_weight)+' kg · Das Fahrzeug kann die Waage verlassen.';
      gpsBox.textContent='🟢 Die Waage ist wieder frei.';
    }else{
      successTitle.textContent='Wiegung erfolgreich abgeschlossen';
      successDetails.textContent='Netto: '+formattedWeight(d.net_weight)+' kg';
      gpsBox.textContent='🟢 Wiegung erfolgreich gespeichert.';
    }

    let remaining=10;
    successCountdown.textContent=remaining;

    const timer=setInterval(()=>{
      remaining--;
      successCountdown.textContent=remaining;

      if(remaining<=0){
        clearInterval(timer);
        window.location.reload();
      }
    },1000);
  }catch(e){
    statusBox.textContent='🔴 '+(e.message||'Wiegung konnte nicht verarbeitet werden.');
    lastWeight=0;
  }
}

refreshStatus().then(()=>{
  if(gpsEnabled) checkLocation();
  else{
    locationData={gpsDisabled:true};
    locationAllowed=true;
    startButton.disabled=false;
  }
});

setInterval(refreshStatus,500);
</script>
</body>
</html>
