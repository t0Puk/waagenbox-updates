# AGENTS.md – AJP Waagenbox

## Projektziel

Dieses Repository enthält die AJP Waagenbox, eine eigenentwickelte Wäge-Software für landwirtschaftliche Fahrzeugverwiegungen.

Die Anwendung läuft produktiv auf einem Raspberry Pi und verwaltet unter anderem Fahrzeuge, Schläge, Fernbedienungen/QR-Auslösung, Kunden, Produkte, Erst- und Zweitwiegungen, Wiegescheine, Backups und Updates.

Historischer vollständig dokumentierter Referenzstand: 1.2.31.
Aktuell produktiv freigegebener Stand: 1.2.38.
Aktueller Entwicklungs-/Release-Kandidat: 1.2.39 auf `feature/1.2.39-grossanzeige`.
Details zu 1.2.39: `docs/release-1.2.39.md`.

## Zielplattform

Produktivsystem:
- Raspberry Pi 3
- Debian 13
- Apache 2
- PHP 8.4 über mod_php
- MariaDB 11.8
- Webanwendung

Produktiver Anwendungspfad auf dem Raspberry Pi:

`/var/www/waage`

Git-Arbeitskopie auf dem Raspberry Pi:

`/home/pi/Waagenbox`

Separater Test-Worktree:

`/home/pi/Waagenbox-test`

Das GitHub-Repository ist die zentrale Quellcodeverwaltung. Das produktive Verzeichnis `/var/www/waage` darf nicht automatisch oder ungefragt überschrieben werden.

## Wichtige Sicherheitsregel

Änderungen am Produktivsystem dürfen niemals ungefragt ausgeführt werden.

Codex darf:
- Quellcode analysieren
- Änderungen im Git-Arbeitsbereich durchführen
- Tests vorbereiten und ausführen, sofern diese keine Produktivdaten verändern
- Fehler suchen und beheben
- Dokumentation ergänzen
- Migrationen erstellen
- Branches und Commits vorbereiten

Codex darf NICHT ohne ausdrückliche Anweisung:
- Dateien direkt in `/var/www/waage` verändern
- produktive MariaDB-Daten verändern oder löschen
- produktive Tabellen leeren oder zurücksetzen
- Backups oder Rollback-Daten löschen
- Apache-, MariaDB- oder Systemkonfiguration produktiv ändern
- SSH-Schlüssel, Passwörter oder andere Zugangsdaten auslesen oder veröffentlichen
- einen Produktiv-Deploy durchführen

Vor einem Produktiv-Deploy muss der Benutzer ausdrücklich zustimmen.

## Secrets und lokale Konfiguration

`config.php` enthält lokale/produktive Datenbankkonfiguration und gehört NICHT ins Repository.

Als Vorlage dient:

`config.example.php`

Niemals echte Zugangsdaten, Passwörter, API-Schlüssel, SSH-Private-Keys, Tokens oder Datenbank-Dumps committen.

Insbesondere nicht versionieren:
- `config.php`
- `.env`
- private Schlüssel
- Datenbank-Dumps wie `dbs*.sql`
- produktive Uploads
- temporäre Sicherungsdateien

Die vorhandene `.gitignore` ist zu beachten und darf nicht so abgeschwächt werden, dass Secrets oder Laufzeitdaten versioniert werden.

## Datenbank

Datenbank: MariaDB.

Datenbankzugriffe erfolgen zentral über `db.php` und die in `config.php` definierten Konstanten.

SQL-Dateien wie `schema.sql` und `migration_*.sql` sind Teil des Quellcodes und dürfen versioniert werden, solange sie keine echten Zugangsdaten oder produktiven Daten enthalten.

Neue Datenbankänderungen sollen grundsätzlich über nachvollziehbare Migrationen erfolgen.

Bestehende produktive Daten dürfen nicht stillschweigend verworfen werden.

## Wichtige Projektbereiche

- `dashboard.php` – Hauptoberfläche / Dashboard
- `weighing.php` – Wägeablauf
- `weighings.php` – Wiegungsliste
- `vehicles.php` – Fahrzeuge
- `fields.php` – Schläge
- `customers.php` – Kunden
- `products.php` – Produkte
- `remotes.php` – Fernbedienungen / Zuordnungen
- `remote_qr.php` – QR-Fernbedienung
- `mobile_remote.php` – mobile Fernbedienung
- `backup.php` – Backup-Oberfläche
- `settings.php` – Einstellungen
- `functions.php` – zentrale Hilfsfunktionen
- `db.php` – Datenbankverbindung
- `hardware/Dini3590.php` – Kommunikation mit der Waagentechnik
- `hardware/rf_remote_listener.py` – 433-MHz-Funkempfänger / Decoder
- `rf_remote_support.php` – serverseitige Funk-Fernbedienungslogik
- `cli/rf_remote_trigger.php` – CLI-Brücke für Funkwiegungen
- `api/rf_learn.php` – admin-geschützter Einlernmodus für 433-MHz-Handsender
- `reports/` – PDF-/Berichtsfunktionen
- `api/` – AJAX/API-Endpunkte
- `api/update_install.php` – Updateinstallation
- `api/update_rollback.php` – Rollback
- `api/backup_create.php` – Backup-Erstellung
- `api/backup_restore.php` – Backup-Wiederherstellung
- `version.php` – Versionsstand

## Update- und Rollback-System

Das Update-System ist sicherheitskritisch.

Der gewünschte Ablauf ist:
1. Updatepaket laden
2. SHA-256 prüfen
3. Paket in ein temporäres Staging-Verzeichnis entpacken
4. erforderliche Dateien validieren
5. Rollback-Sicherung der Anwendung erstellen
6. Datenbank-Dump erstellen
7. Update anwenden
8. Datenbankmigrationen ausführen
9. Ergebnis prüfen
10. bei Fehlern automatisch zurückrollen

Dauerhafte Rollback-Daten liegen außerhalb des Webroots unter:

`/var/lib/waagebox/rollback`

Diese Laufzeitdaten gehören nicht in Git.

Bei Arbeiten am Update-/Rollback-System besonders defensiv vorgehen. Keine bestehende Sicherung löschen, bevor eine neue Sicherung vollständig und verifiziert erstellt wurde.

## Backups

Backups sollen Anwendung und Datenbank sicher erfassen.

Später vorgesehen:
- manuelle Backups
- automatische tägliche oder wöchentliche Backups
- lokaler Speicher
- optional Cloud-Speicher
- Wiederherstellung aus der Admin-Oberfläche

Backup-Code darf niemals ungeprüft produktive Daten überschreiben.

## Wägefunktion

Die Wägefunktion ist die zentrale Kernfunktion des Systems.

Änderungen an Wägeabläufen müssen besonders vorsichtig erfolgen.

Vor Änderungen prüfen:
- Erstgewicht
- Zweitgewicht
- Nettogewicht
- Fahrzeugzuordnung
- Schlagzuordnung
- Kunde
- Produkt
- Fernbedienung / QR-Auslösung
- 433-MHz-Funkfernbedienung
- Wiegeschein
- Statusübergänge

Bestehende funktionierende Abläufe dürfen nicht unnötig umgebaut werden.

## Hardware

Die Anwendung kann mit einem Dini Argeo 3590-Wägeterminal kommunizieren.

Hardwarezugriffe liegen insbesondere unter:

`hardware/Dini3590.php`

Die 433-MHz-Funkfernbedienung wird über GPIO17 und `hardware/rf_remote_listener.py` eingelesen. Die GPIO-Eingangsspannung des Raspberry Pi darf 3,3 V nicht überschreiten; bei einem 5-V-Empfänger ist eine geeignete Pegelanpassung erforderlich.

Hardwareabhängige Änderungen müssen so implementiert werden, dass Entwicklung und Tests möglichst auch ohne angeschlossene Waage möglich bleiben.

Keine Hardwarebefehle ungefragt gegen das Produktivgerät senden.

## Kamera

Eine IP-Kamera kann für Livebild und Snapshots verwendet werden.

Produktive Kamera-Zugangsdaten oder Netzwerkkennwörter dürfen nicht versioniert werden.

Laufzeitbilder aus `uploads/` gehören nicht in Git. Nur notwendige Steuerdateien wie `.htaccess` dürfen versioniert werden.

## Arbeitsweise für Codex

Bei jeder Aufgabe:
1. Zuerst die betroffenen Dateien und bestehenden Abläufe lesen.
2. Bestehende Architektur möglichst erhalten.
3. Ursache des Problems bestimmen, bevor größere Umbauten erfolgen.
4. Änderungen klein und nachvollziehbar halten.
5. Keine Secrets erzeugen oder committen.
6. PHP-Syntax der geänderten PHP-Dateien prüfen.
7. Wenn möglich einen reproduzierbaren Test durchführen.
8. Auswirkungen auf Datenbank, Updates, Backups und Wägeablauf berücksichtigen.
9. Am Ende kurz dokumentieren:
   - Ursache
   - geänderte Dateien
   - durchgeführte Tests
   - verbleibende Risiken

## PHP-Prüfung

Für geänderte PHP-Dateien mindestens Syntaxprüfung durchführen, z. B.:

`php -l datei.php`

Bei mehreren geänderten PHP-Dateien alle betroffenen Dateien prüfen.

## Git-Arbeitsweise

`release/1.2.31` ist der unveränderliche, vollständig abgenommene Rückfall- und Vergleichsstand für die Entwicklung von 1.2.32.

Für größere Änderungen einen eigenen Branch verwenden, zum Beispiel:

`feature/...`

`fix/...`

`codex/...`

Keine Force-Pushes auf freigegebene Branches ohne ausdrückliche Anweisung.

Keine bestehende Historie löschen.

Commits sollen kurz und verständlich beschreiben, was geändert wurde.

## Tests vor Freigabe

Vor einer Empfehlung für den Produktiveinsatz mindestens prüfen:
- PHP-Syntax
- Python-Syntax bei Python-Komponenten
- offensichtliche Laufzeitfehler
- betroffene Datenbankabfragen
- Formular- und API-Parameter
- Schreib-/Dateirechte, falls relevant
- Update-/Rollback-Auswirkungen, falls relevant
- vollständige bestehende Sicherheits-/Regression-Suite
- spezialisierte RF-Decoder-, Dry-Run-, Einlern- und reale GPIO-/systemd-Prüfungen bei Änderungen an der Funkfunktion

## Sprache

Kommunikation, Erklärungen und Zusammenfassungen für den Benutzer vorzugsweise auf Deutsch.

Quellcode-Bezeichner dürfen Englisch bleiben, wenn dies zur bestehenden Struktur passt.

## Grundsatz

Stabilität und Datensicherheit haben Vorrang vor großen Umbauten.

Bestehende funktionierende Funktionen nur ändern, wenn dies für die Aufgabe notwendig ist.

Wenn eine Änderung potenziell produktive Daten, die Waagenhardware oder den Update-/Rollback-Mechanismus gefährden kann, muss vor dem produktiven Einsatz ausdrücklich darauf hingewiesen werden.
