-- AJP Waagenbox 1.2.39
-- Mehrere gleichzeitig offene Fahrzeugwiegungen.
--
-- Die Tabelle weighing_state bleibt der EINEN physisch aktiven Überfahrt auf
-- der Waage vorbehalten. Zwischen erster und zweiter Überfahrt wird der offene
-- Auftrag fahrzeugbezogen in open_vehicle_weighings gespeichert. Dadurch kann
-- die Waage zwischenzeitlich beliebig viele andere Fahrzeuge abfertigen.

CREATE TABLE IF NOT EXISTS open_vehicle_weighings (
    owner_user_id INT UNSIGNED NOT NULL,
    vehicle_id INT UNSIGNED NOT NULL,
    first_weight DECIMAL(12,3) NOT NULL,
    remote_id INT UNSIGNED NULL,
    field_id INT UNSIGNED NULL,
    customer_id INT UNSIGNED NULL,
    product_id INT UNSIGNED NULL,
    trigger_type VARCHAR(30) NOT NULL DEFAULT 'manual',
    first_measured_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (owner_user_id, vehicle_id),

    KEY idx_open_vehicle_owner_time (owner_user_id, first_measured_at),
    KEY idx_open_vehicle_remote (owner_user_id, remote_id),

    CONSTRAINT fk_open_vehicle_owner
        FOREIGN KEY (owner_user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_open_vehicle_vehicle
        FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_open_vehicle_remote
        FOREIGN KEY (remote_id)
        REFERENCES remotes(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_open_vehicle_field
        FOREIGN KEY (field_id)
        REFERENCES fields(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_open_vehicle_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_open_vehicle_product
        FOREIGN KEY (product_id)
        REFERENCES products(id)
        ON DELETE SET NULL
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
