-- AJP Waagenbox 1.2.39
-- Kennzeichnet temporäre externe Fahrzeuge aus manuellen Wiegungen.

ALTER TABLE vehicles
    ADD COLUMN IF NOT EXISTS manual_external TINYINT(1) NOT NULL DEFAULT 0
    AFTER active;

CREATE INDEX IF NOT EXISTS idx_vehicles_manual_external
    ON vehicles(owner_user_id, manual_external, active);
