<?php
declare(strict_types=1);

function feldmanagerEnabled(): bool {
    return appSetting('feldmanager_enabled','0')==='1';
}

function feldmanagerBaseUrl(): string {
    return rtrim(trim(appSetting('feldmanager_base_url','')),'/');
}

function feldmanagerRemoteTeamMap(): array {
    $raw=appSetting('feldmanager_remote_team_map','');
    if($raw==='') return [];
    $data=json_decode($raw,true);
    if(!is_array($data)) return [];
    $map=[];
    foreach($data as $remote=>$team){
        $rid=(int)$remote;
        $tn=(int)$team;
        if($rid>0&&$tn>0) $map[$rid]=$tn;
    }
    return $map;
}

function feldmanagerTeamForRemote(?int $remoteId): ?int {
    if(!$remoteId || $remoteId<=0) return null;
    $map=feldmanagerRemoteTeamMap();
    return isset($map[$remoteId]) ? (int)$map[$remoteId] : null;
}

function feldmanagerSetTeamForRemote(int $remoteId, ?int $teamId): void {
    if($remoteId<=0) return;
    $map=feldmanagerRemoteTeamMap();
    if($teamId===null || $teamId<=0) unset($map[$remoteId]);
    else $map[$remoteId]=(int)$teamId;
    saveAppSetting('feldmanager_remote_team_map',json_encode($map,JSON_UNESCAPED_UNICODE));
}

function feldmanagerRequest(string $endpoint): array {
    $base=feldmanagerBaseUrl();
    $token=trim(appSetting('feldmanager_api_token',''));
    if($base===''||$token==='') return ['ok'=>false,'error'=>'not_configured','message'=>'Feldmanager-Verbindung ist noch nicht vollständig konfiguriert.'];
    if(!preg_match('~^https://~i',$base)) return ['ok'=>false,'error'=>'invalid_url','message'=>'Die Feldmanager-URL muss HTTPS verwenden.'];

    $url=$base.'/'.ltrim($endpoint,'/');
    $headers=['Accept: application/json','X-AJP-Waagenbox-Token: '.$token];
    $body=false;
    $code=0;

    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_CONNECTTIMEOUT=>3,
            CURLOPT_TIMEOUT=>5,
            CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_USERAGENT=>'AJP-Waagenbox/'.APP_VERSION,
        ]);
        $body=curl_exec($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $err=(string)curl_error($ch);
        curl_close($ch);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Feldmanager nicht erreichbar: '.$err];
    } else {
        $ctx=stream_context_create([
            'http'=>[
                'method'=>'GET',
                'header'=>implode("\r\n",$headers)."\r\n",
                'timeout'=>5,
                'ignore_errors'=>true,
            ],
            'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true],
        ]);
        $body=@file_get_contents($url,false,$ctx);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Feldmanager nicht erreichbar.'];
        foreach($http_response_header??[] as $line){
            if(preg_match('~^HTTP/\S+\s+(\d+)~',$line,$m)){
                $code=(int)$m[1];
                break;
            }
        }
    }

    $data=json_decode((string)$body,true);
    if(!is_array($data)) return ['ok'=>false,'error'=>'invalid_response','message'=>'Feldmanager hat keine gültige JSON-Antwort geliefert.','http_status'=>$code];
    if($code<200||$code>=300||empty($data['ok'])){
        return [
            'ok'=>false,
            'error'=>(string)($data['error']??'http_error'),
            'message'=>'Feldmanager-API meldet einen Fehler.',
            'http_status'=>$code,
            'response'=>$data,
        ];
    }
    return $data;
}

function feldmanagerFields(): array {
    return feldmanagerRequest('api/waagenbox_fields.php');
}

function feldmanagerTeams(): array {
    return feldmanagerRequest('api/waagenbox_teams.php');
}

function feldmanagerMonitor(): array {
    return feldmanagerRequest('api/waagenbox_monitor.php');
}

function feldmanagerActiveField(?int $teamNumber=null): array {
    $team=max(0,(int)$teamNumber);
    $path='api/waagenbox_active_field.php'.($team>0?'?team_number='.$team:'');
    return feldmanagerRequest($path);
}

function feldmanagerResolveLocalField(array $remoteField): ?int {
    $name=trim((string)($remoteField['name']??''));
    if($name==='') return null;

    $q=db()->prepare('SELECT id FROM `fields` WHERE owner_user_id=? AND active=1 AND LOWER(TRIM(name))=LOWER(TRIM(?)) ORDER BY id');
    $q->execute([currentOwnerId(),$name]);
    $ids=$q->fetchAll(PDO::FETCH_COLUMN);

    return count($ids)===1?(int)$ids[0]:null;
}

function feldmanagerAssignmentStatus(?int $remoteId=null): array {
    if(!feldmanagerEnabled()){
        return [
            'ok'=>true,
            'state'=>'disabled',
            'message'=>'Automatische Schlagzuordnung ist deaktiviert.',
            'local_field_id'=>null,
        ];
    }

    $team=feldmanagerTeamForRemote($remoteId);
    if($remoteId!==null && $team===null){
        return [
            'ok'=>true,
            'state'=>'no_team',
            'message'=>'Für diese Fernbedienung ist kein Feldmanager-Team hinterlegt.',
            'local_field_id'=>null,
            'remote_id'=>$remoteId,
        ];
    }

    $status=feldmanagerActiveField($team);
    if(empty($status['ok'])){
        return [
            'ok'=>false,
            'state'=>'unavailable',
            'message'=>(string)($status['message']??'Feldmanager nicht erreichbar.'),
            'local_field_id'=>null,
            'api'=>$status,
        ];
    }

    $count=(int)($status['active_count']??0);
    if($count===0){
        return [
            'ok'=>true,
            'state'=>'no_active',
            'message'=>'Im Feldmanager ist derzeit kein Schlag aktiv.',
            'local_field_id'=>null,
            'api'=>$status,
        ];
    }

    if($count!==1 || empty($status['active']['field'])){
        return [
            'ok'=>false,
            'state'=>'ambiguous',
            'message'=>'Im Feldmanager sind mehrere aktive Schläge gefunden worden. Bitte die Team-Zuordnung der Fernbedienung prüfen.',
            'local_field_id'=>null,
            'api'=>$status,
        ];
    }

    $remote=$status['active'];
    $localId=feldmanagerResolveLocalField((array)$remote['field']);

    if($localId===null){
        return [
            'ok'=>false,
            'state'=>'unmapped',
            'message'=>'Der aktive Feldmanager-Schlag ist in der Waagenbox noch nicht eindeutig zugeordnet.',
            'local_field_id'=>null,
            'remote'=>$remote,
            'api'=>$status,
        ];
    }

    return [
        'ok'=>true,
        'state'=>'active',
        'message'=>'Aktiver Feldmanager-Schlag wurde zugeordnet.',
        'local_field_id'=>$localId,
        'remote'=>$remote,
        'api'=>$status,
    ];
}

function feldmanagerAutomaticFieldId(?int $fallbackFieldId=null, ?int $remoteId=null): ?int {
    if(!feldmanagerEnabled() || !$remoteId || $remoteId<=0) return $fallbackFieldId;

    try{
        $status=feldmanagerAssignmentStatus($remoteId);
        if(($status['state']??'')==='active' && !empty($status['local_field_id'])){
            return (int)$status['local_field_id'];
        }
    }catch(Throwable $e){
        error_log('Waagenbox Feldmanager: '.$e->getMessage());
    }

    return $fallbackFieldId;
}
