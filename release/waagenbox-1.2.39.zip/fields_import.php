<?php
require_once __DIR__.'/functions.php';
requireLogin();

function fieldImportNormalizeKey(string $key): string {
    $k=mb_strtolower(trim($key),'UTF-8');
    $k=strtr($k,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss',' '=>'_','-'=>'_']);
    return preg_replace('/[^a-z0-9_]/','',$k) ?? $k;
}
function fieldImportAutoMap(array $keys, array $candidates): string {
    $normalized=[];
    foreach($keys as $key) $normalized[fieldImportNormalizeKey((string)$key)]=(string)$key;
    foreach($candidates as $candidate){
        $n=fieldImportNormalizeKey($candidate);
        if(isset($normalized[$n])) return $normalized[$n];
    }
    return '';
}
function fieldImportScalar($value): string {
    if($value===null) return '';
    if(is_bool($value)) return $value?'1':'0';
    if(is_int($value)||is_float($value)||is_string($value)) return trim((string)$value);
    return '';
}
function fieldImportNumber($value): ?float {
    if(is_int($value)||is_float($value)) return (float)$value;
    $s=trim((string)$value);
    if($s==='') return null;
    $s=str_replace(["\xc2\xa0",' '],'',$s);
    if(str_contains($s,',') && str_contains($s,'.')){
        if(strrpos($s,',')>strrpos($s,'.')){
            $s=str_replace('.','',$s);
            $s=str_replace(',','.',$s);
        }else{
            $s=str_replace(',','',$s);
        }
    }else{
        $s=str_replace(',','.',$s);
    }
    if(!preg_match('/[-+]?\d+(?:\.\d+)?/',$s,$m)) return null;
    return (float)$m[0];
}

function fieldImportRingSignedAreaM2(array $ring): float {
    $points=[];
    $latSum=0.0;
    foreach($ring as $point){
        if(!is_array($point) || count($point)<2 || !is_numeric($point[0]) || !is_numeric($point[1])) continue;
        $lon=(float)$point[0];
        $lat=(float)$point[1];
        $points[]=[$lon,$lat];
        $latSum+=$lat;
    }
    $count=count($points);
    if($count<3) return 0.0;

    $earthRadius=6378137.0;
    $lat0=deg2rad($latSum/$count);
    $area=0.0;
    for($i=0;$i<$count;$i++){
        $j=($i+1)%$count;
        $x1=$earthRadius*deg2rad($points[$i][0])*cos($lat0);
        $y1=$earthRadius*deg2rad($points[$i][1]);
        $x2=$earthRadius*deg2rad($points[$j][0])*cos($lat0);
        $y2=$earthRadius*deg2rad($points[$j][1]);
        $area+=($x1*$y2)-($x2*$y1);
    }
    return $area/2.0;
}

function fieldImportPolygonAreaHa(array $polygon): float {
    if(!$polygon) return 0.0;
    $outer=abs(fieldImportRingSignedAreaM2(is_array($polygon[0]??null)?$polygon[0]:[]));
    $holes=0.0;
    for($i=1;$i<count($polygon);$i++){
        if(is_array($polygon[$i])) $holes+=abs(fieldImportRingSignedAreaM2($polygon[$i]));
    }
    return max(0.0,$outer-$holes)/10000.0;
}

function fieldImportGeometryAreaHa($geometry): ?float {
    if(!is_array($geometry)) return null;
    $type=(string)($geometry['type']??'');
    $coordinates=$geometry['coordinates']??null;
    if(!is_array($coordinates)) return null;

    if($type==='Polygon'){
        $area=fieldImportPolygonAreaHa($coordinates);
        return $area>0 ? $area : null;
    }

    if($type==='MultiPolygon'){
        $area=0.0;
        foreach($coordinates as $polygon){
            if(is_array($polygon)) $area+=fieldImportPolygonAreaHa($polygon);
        }
        return $area>0 ? $area : null;
    }

    return null;
}

$error=null;
$preview=$_SESSION['field_import_preview'] ?? null;

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        requireCsrfToken();
        $action=(string)($_POST['action']??'');

        if($action==='upload'){
            if(!isset($_FILES['geojson']) || !is_array($_FILES['geojson'])) throw new RuntimeException('Bitte eine GeoJSON-Datei auswählen.');
            $file=$_FILES['geojson'];
            if((int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new RuntimeException('Die GeoJSON-Datei konnte nicht hochgeladen werden.');
            $size=(int)($file['size']??0);
            if($size<=0 || $size>5*1024*1024) throw new RuntimeException('Die GeoJSON-Datei muss zwischen 1 Byte und 5 MB groß sein.');
            $raw=file_get_contents((string)$file['tmp_name']);
            if($raw===false) throw new RuntimeException('Die GeoJSON-Datei konnte nicht gelesen werden.');
            $data=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
            if(!is_array($data) || (string)($data['type']??'')!=='FeatureCollection' || !isset($data['features']) || !is_array($data['features'])){
                throw new RuntimeException('Die Datei ist keine gültige GeoJSON-FeatureCollection.');
            }
            if(count($data['features'])===0) throw new RuntimeException('Die GeoJSON-Datei enthält keine Schläge.');
            if(count($data['features'])>1000) throw new RuntimeException('Es können maximal 1000 Schläge auf einmal importiert werden.');

            $rows=[];$keySet=[];
            foreach($data['features'] as $feature){
                if(!is_array($feature)) continue;
                $props=$feature['properties']??[];
                if(!is_array($props)) $props=[];
                $clean=[];
                $geometryArea=fieldImportGeometryAreaHa($feature['geometry']??null);
                if($geometryArea!==null){
                    $clean['Berechnete Fläche aus GeoJSON-Geometrie (ha)']=round($geometryArea,4);
                    $keySet['Berechnete Fläche aus GeoJSON-Geometrie (ha)']=true;
                }
                foreach($props as $key=>$value){
                    if(!is_string($key)) continue;
                    if($value===null || is_scalar($value)){
                        $clean[$key]=$value;
                        $keySet[$key]=true;
                    }
                }
                $rows[]=$clean;
            }
            if(!$rows) throw new RuntimeException('Es konnten keine GeoJSON-Eigenschaften gelesen werden.');

            $keys=array_keys($keySet);
            natcasesort($keys);
            $keys=array_values($keys);
            $preview=[
                'token'=>bin2hex(random_bytes(16)),
                'filename'=>(string)($file['name']??'GeoJSON'),
                'rows'=>$rows,
                'keys'=>$keys,
                'map_name'=>fieldImportAutoMap($keys,['name','schlagname','schlag','field_name','field','bezeichnung']),
                'map_area'=>fieldImportAutoMap($keys,['Berechnete Fläche aus GeoJSON-Geometrie (ha)','area','area_ha','flaeche','fläche','flaeche_ha','fläche_ha','hektar','ha']),
                'map_crop'=>fieldImportAutoMap($keys,['crop','frucht','fruchtart','kultur','crop_name']),
            ];
            $_SESSION['field_import_preview']=$preview;
            redirect('fields_import.php?preview=1');
        }

        if($action==='cancel'){
            unset($_SESSION['field_import_preview']);
            redirect('fields_import.php');
        }

        if($action==='import'){
            $preview=$_SESSION['field_import_preview']??null;
            if(!is_array($preview) || !hash_equals((string)($preview['token']??''),(string)($_POST['preview_token']??''))){
                throw new RuntimeException('Die Import-Vorschau ist abgelaufen. Bitte Datei erneut auswählen.');
            }
            $keys=array_map('strval',$preview['keys']??[]);
            $mapName=(string)($_POST['map_name']??'');
            $mapArea=(string)($_POST['map_area']??'');
            $mapCrop=(string)($_POST['map_crop']??'');
            if($mapName==='' || !in_array($mapName,$keys,true)) throw new RuntimeException('Bitte die GeoJSON-Eigenschaft für den Schlag-Namen auswählen.');
            if($mapArea!=='' && !in_array($mapArea,$keys,true)) throw new RuntimeException('Ungültige Flächen-Zuordnung.');
            if($mapCrop!=='' && !in_array($mapCrop,$keys,true)) throw new RuntimeException('Ungültige Frucht-Zuordnung.');

            $selected=array_values(array_unique(array_map('intval',$_POST['rows']??[])));
            if(!$selected) throw new RuntimeException('Bitte mindestens einen Schlag zum Import auswählen.');

            $pdo=db();
            $exists=$pdo->prepare('SELECT id FROM `fields` WHERE owner_user_id=? AND name=? LIMIT 1');
            $insert=$pdo->prepare('INSERT INTO `fields` (owner_user_id,name,crop,year,area,notes,active) VALUES (?,?,?,?,?,?,1)');
            $imported=0;$duplicates=0;$invalid=0;$areaWarnings=0;
            $pdo->beginTransaction();
            foreach($selected as $idx){
                if(!isset($preview['rows'][$idx]) || !is_array($preview['rows'][$idx])){$invalid++;continue;}
                $props=$preview['rows'][$idx];
                $name=fieldImportScalar($props[$mapName]??null);
                if($name===''){$invalid++;continue;}
                $exists->execute([currentOwnerId(),$name]);
                if($exists->fetchColumn()){$duplicates++;continue;}
                $crop=$mapCrop!==''?fieldImportScalar($props[$mapCrop]??null):'';
                $area=null;
                if($mapArea!==''){
                    $rawArea=$props[$mapArea]??null;
                    $area=fieldImportNumber($rawArea);
                    if(fieldImportScalar($rawArea)!=='' && $area===null) $areaWarnings++;
                    if($area!==null && $area<0){$area=null;$areaWarnings++;}
                }
                $insert->execute([currentOwnerId(),$name,$crop,null,$area,'']);
                $imported++;
            }
            $pdo->commit();
            unset($_SESSION['field_import_preview']);
            $msg=$imported.' Schlag/Schläge importiert.';
            if($duplicates) $msg.=' '.$duplicates.' bereits vorhandene Schläge wurden übersprungen.';
            if($invalid) $msg.=' '.$invalid.' Einträge ohne gültigen Namen wurden übersprungen.';
            if($areaWarnings) $msg.=' Bei '.$areaWarnings.' Eintrag/Einträgen konnte die Fläche nicht übernommen werden.';
            flash($msg);
            redirect('fields.php');
        }

        throw new RuntimeException('Ungültige Import-Aktion.');
    }catch(Throwable $e){
        if(isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
        $error=$e->getMessage();
        $preview=$_SESSION['field_import_preview']??null;
    }
}

$existingNames=[];
$q=db()->prepare('SELECT name FROM `fields` WHERE owner_user_id=?');
$q->execute([currentOwnerId()]);
foreach($q->fetchAll(PDO::FETCH_COLUMN) as $name) $existingNames[]=mb_strtolower(trim((string)$name),'UTF-8');

layoutStart('Schläge importieren','fields');
if($error!==null) echo '<div class="flash error"><strong>Import konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
?>
<div class="toolbar"><h1>Schläge aus GeoJSON importieren</h1><a class="button" href="fields.php">← Zurück zu den Schlägen</a></div>

<?php if(!is_array($preview)): ?>
<div class="card">
  <h2>1. GeoJSON-Datei auswählen</h2>
  <p>Die Geometrie selbst wird nicht gespeichert. Falls die Datei keine eigene Flächen-Eigenschaft enthält, berechnet die Waagenbox die Fläche automatisch aus dem GeoJSON-Polygon. Importiert werden nur <strong>Name</strong>, <strong>Fläche</strong> und <strong>Frucht/Kultur</strong>.</p>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <input type="hidden" name="action" value="upload">
    <div><label>GeoJSON-Datei</label><input type="file" name="geojson" accept=".geojson,.json,application/geo+json,application/json" required></div>
    <p><button class="button primary">Datei einlesen und Vorschau öffnen</button></p>
  </form>
</div>
<?php else: ?>
<div class="card">
  <h2>2. Daten zuordnen</h2>
  <p>Datei: <strong><?=h($preview['filename']??'GeoJSON')?></strong> · <?=count($preview['rows']??[])?> Einträge</p>
  <p>Vorhandene Schläge werden <strong>nie überschrieben</strong>. Bei gleichem Schlag-Namen wird der Import des betreffenden Eintrags übersprungen.</p>
  <form method="post" id="fieldImportForm">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <input type="hidden" name="action" value="import">
    <input type="hidden" name="preview_token" value="<?=h($preview['token']??'')?>">
    <div class="form-grid">
      <div><label>Name <strong>(Pflicht)</strong></label><select name="map_name" id="mapName" required><option value="">Bitte wählen</option><?php foreach(($preview['keys']??[]) as $key):?><option value="<?=h($key)?>" <?=($key===($preview['map_name']??''))?'selected':''?>><?=h($key)?></option><?php endforeach;?></select></div>
      <div><label>Fläche in ha</label><select name="map_area" id="mapArea"><option value="">Nicht importieren</option><?php foreach(($preview['keys']??[]) as $key):?><option value="<?=h($key)?>" <?=($key===($preview['map_area']??''))?'selected':''?>><?=h($key)?></option><?php endforeach;?></select></div>
      <div><label>Frucht / Kultur</label><select name="map_crop" id="mapCrop"><option value="">Nicht importieren</option><?php foreach(($preview['keys']??[]) as $key):?><option value="<?=h($key)?>" <?=($key===($preview['map_crop']??''))?'selected':''?>><?=h($key)?></option><?php endforeach;?></select></div>
    </div>

    <p><button type="button" class="button" id="selectAll">Alle verfügbaren auswählen</button> <button type="button" class="button" id="selectNone">Auswahl aufheben</button></p>
    <div class="table-wrap"><table>
      <thead><tr><th>Import</th><th>Name</th><th>Fläche</th><th>Frucht / Kultur</th><th>Status</th></tr></thead>
      <tbody id="importRows"></tbody>
    </table></div>
    <p><button class="button primary">Ausgewählte Schläge importieren</button></p>
  </form>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <input type="hidden" name="action" value="cancel">
    <button class="button">Andere Datei auswählen</button>
  </form>
</div>
<script>
(() => {
  const rows=<?=json_encode($preview['rows']??[],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;
  const existing=new Set(<?=json_encode($existingNames,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>);
  const tbody=document.getElementById('importRows');
  const mapName=document.getElementById('mapName');
  const mapArea=document.getElementById('mapArea');
  const mapCrop=document.getElementById('mapCrop');

  function value(row,key){ if(!key || !Object.prototype.hasOwnProperty.call(row,key) || row[key]===null) return ''; return String(row[key]); }
  function render(){
    tbody.textContent='';
    rows.forEach((row,index)=>{
      const name=value(row,mapName.value).trim();
      const area=value(row,mapArea.value).trim();
      const crop=value(row,mapCrop.value).trim();
      const duplicate=name!=='' && existing.has(name.toLocaleLowerCase('de-DE'));
      const invalid=name==='';
      const tr=document.createElement('tr');
      const tdCheck=document.createElement('td');
      const cb=document.createElement('input');
      cb.type='checkbox'; cb.name='rows[]'; cb.value=String(index); cb.checked=!duplicate&&!invalid; cb.disabled=duplicate||invalid;
      tdCheck.appendChild(cb);
      const tdName=document.createElement('td'); tdName.textContent=name||'—';
      const tdArea=document.createElement('td'); tdArea.textContent=area||'—';
      const tdCrop=document.createElement('td'); tdCrop.textContent=crop||'—';
      const tdStatus=document.createElement('td');
      tdStatus.textContent=duplicate?'Bereits vorhanden – wird übersprungen':(invalid?'Kein Name – nicht importierbar':'Bereit zum Import');
      tr.append(tdCheck,tdName,tdArea,tdCrop,tdStatus);
      tbody.appendChild(tr);
    });
  }
  [mapName,mapArea,mapCrop].forEach(el=>el.addEventListener('change',render));
  document.getElementById('selectAll').addEventListener('click',()=>tbody.querySelectorAll('input[type=checkbox]:not(:disabled)').forEach(x=>x.checked=true));
  document.getElementById('selectNone').addEventListener('click',()=>tbody.querySelectorAll('input[type=checkbox]').forEach(x=>x.checked=false));
  render();
})();
</script>
<?php endif; ?>
<?php layoutEnd(); ?>
