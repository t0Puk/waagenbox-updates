<?php
require_once __DIR__.'/../functions.php';
requireLogin();

if (!cameraEnabled()) {
    http_response_code(404);
    exit;
}

$url = cameraSnapshotUrl();
if ($url === '' || !preg_match('~^https?://~i', $url)) {
    http_response_code(404);
    exit;
}

// Bewusst konservativ fuer Raspberry Pi 3 und aeltere IP-Kameras.
$intervalMs = (int)($_GET['interval'] ?? 1000);
$intervalMs = max(500, min(5000, $intervalMs));

// Eine dauerhafte MJPEG-Verbindung darf die PHP-Session nicht blockieren.
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

@set_time_limit(0);
@ini_set('zlib.output_compression', '0');

header('Content-Type: multipart/x-mixed-replace; boundary=waageboxframe');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');
header('X-Accel-Buffering: no');

// Vorhandene PHP-Ausgabepuffer koennen Livebilder sonst unnötig verzoegern.
while (ob_get_level() > 0) {
    @ob_end_flush();
}

/**
 * Holt genau einen Snapshot. Rueckgabe nur bei erfolgreicher HTTP-Antwort
 * mit plausibler Mindestgroesse. Es wird nichts auf die SD-Karte geschrieben.
 */
function waageboxCameraFetchSnapshot(string $url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'AJP-Waagenbox-Kamera-MJPEG/1.0',
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body !== false && $code >= 200 && $code < 400 && strlen($body) > 100) {
            return $body;
        }
    }

    $ctx = stream_context_create([
        'http' => [
            'timeout' => 5,
            'follow_location' => 1,
            'max_redirects' => 3,
            'user_agent' => 'AJP-Waagenbox-Kamera-MJPEG/1.0',
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    return ($body !== false && strlen($body) > 100) ? $body : false;
}

/**
 * MJPEG benoetigt JPEG-Frames. Liefert die Kamera bereits JPEG, wird das
 * Original ohne Re-Encoding weitergereicht. Andere von GD lesbare Bildtypen
 * werden nur bei Bedarf einmal pro Frame nach JPEG konvertiert.
 */
function waageboxCameraAsJpeg(string $data) {
    $info = @getimagesizefromstring($data);
    if (!is_array($info)) return false;

    $mime = strtolower((string)($info['mime'] ?? ''));
    if ($mime === 'image/jpeg') return $data;

    if (!function_exists('imagecreatefromstring') || !function_exists('imagejpeg')) return false;
    $img = @imagecreatefromstring($data);
    if ($img === false) return false;

    ob_start();
    $ok = @imagejpeg($img, null, 82);
    $jpeg = (string)ob_get_clean();
    imagedestroy($img);
    return ($ok && $jpeg !== '') ? $jpeg : false;
}

while (!connection_aborted()) {
    $started = microtime(true);
    $data = waageboxCameraFetchSnapshot($url);

    if ($data !== false) {
        $jpeg = waageboxCameraAsJpeg($data);
        if ($jpeg !== false) {
            echo "--waageboxframe\r\n";
            echo "Content-Type: image/jpeg\r\n";
            echo 'Content-Length: '.strlen($jpeg)."\r\n";
            echo "Cache-Control: no-cache\r\n\r\n";
            echo $jpeg;
            echo "\r\n";
            flush();
        }
    }

    $elapsedMs = (int)round((microtime(true) - $started) * 1000);
    $sleepMs = max(50, $intervalMs - $elapsedMs);
    usleep($sleepMs * 1000);
}
