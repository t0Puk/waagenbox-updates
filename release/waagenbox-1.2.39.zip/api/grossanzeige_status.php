<?php
declare(strict_types=1);

require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

function grossanzeigeJson(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$provided = trim((string)($_SERVER['HTTP_X_AJP_DISPLAY_TOKEN'] ?? ''));
if ($provided === '' || strlen($provided) > 256) {
    grossanzeigeJson(['ok'=>false,'error'=>'forbidden'], 403);
}

$hash = hash('sha256', $provided);
$pdo = db();

$tokenStmt = $pdo->prepare(
    'SELECT owner_user_id
       FROM settings
      WHERE `key`=? AND `value`=?
      LIMIT 2'
);
$tokenStmt->execute(['grossanzeige_api_token_hash', $hash]);
$owners = array_map('intval', $tokenStmt->fetchAll(PDO::FETCH_COLUMN));

if (count($owners) !== 1 || $owners[0] <= 0) {
    grossanzeigeJson(['ok'=>false,'error'=>'forbidden'], 403);
}

$ownerId = $owners[0];

global $mobileContextUserId;
$mobileContextUserId = $ownerId;
$pdo->exec('SET @ajp_user_id = ' . $ownerId);

if (appSetting('grossanzeige_enabled', '0') !== '1') {
    grossanzeigeJson([
        'ok'=>false,
        'error'=>'display_disabled',
        'api_version'=>1,
    ], 503);
}

try {
    $currentWeight = scaleDisplayWeight(currentWeight());
    $pending = pendingWeighing();
    $processing = scaleProcessingActive();

    $latestStmt = $pdo->prepare(
        'SELECT id, second_weight, net_weight, created_at,
                TIMESTAMPDIFF(SECOND, created_at, NOW()) AS age_seconds
           FROM weighings
          WHERE owner_user_id=?
          ORDER BY id DESC
          LIMIT 1'
    );
    $latestStmt->execute([$ownerId]);
    $latest = $latestStmt->fetch() ?: null;

    $state = 'ready';
    $displayWeight = 0.0;
    $processingKind = scaleProcessingKind();
    $processingWeight = scaleDisplayWeight(scaleProcessingWeight());
    $completeProcessingSeconds = grossanzeigeCompleteProcessingSeconds();
    $weightLabel = '';
    $weightLabelKey = '';

    if ($pending) {
        $isFirstPass = str_ends_with((string)($pending['trigger_type'] ?? ''), '_first_pass');
        $vehicleId = (int)($pending['vehicle_id'] ?? 0);
        $hasOpen = $vehicleId > 0 ? (bool)openVehicleWeighing($vehicleId) : false;

        if ($currentWeight > 0) {
            $state = 'processing';
            $displayWeight = $currentWeight;
            $weightLabel = $isFirstPass
                ? 'ERSTGEWICHT'
                : ($hasOpen ? 'ZWEITGEWICHT' : 'BRUTTOGEWICHT');
            $weightLabelKey = $isFirstPass ? 'first' : ($hasOpen ? 'second' : 'gross');
        } else {
            $state = 'drive_on';
            $displayWeight = 0.0;
            $weightLabel = '';
            $weightLabelKey = '';
        }
    } elseif ($processing) {
        if ($processingKind === 'complete' && $latest) {
            $age = max(0, (int)($latest['age_seconds'] ?? 0));
            if ($age < $completeProcessingSeconds) {
                $state = 'processing';
                $displayWeight = $processingWeight;
                $weightLabel = 'ZWEITGEWICHT';
                $weightLabelKey = 'second';
            } else {
                $state = 'success';
                $displayWeight = scaleDisplayWeight((float)$latest['net_weight']);
                $weightLabel = 'NETTOGEWICHT';
                $weightLabelKey = 'net';
            }
        } else {
            $state = 'processing';
            $displayWeight = $processingWeight;
            $weightLabel = 'ERSTGEWICHT';
            $weightLabelKey = 'first';
        }
    }

    grossanzeigeJson([
        'ok'=>true,
        'api_version'=>1,
        'state'=>$state,
        'weight_kg'=>$displayWeight,
        'weight_label'=>$weightLabel,
        'weight_label_key'=>$weightLabelKey,
        'display_enabled'=>grossanzeigeDisplayEnabled(),
        'current_weight_kg'=>$currentWeight,
        'pending'=>(bool)$pending,
        'processing'=>(bool)$processing,
        'processing_kind'=>$processing ? $processingKind : null,
        'latest_weighing_id'=>$latest ? (int)$latest['id'] : null,
        'latest_net_weight_kg'=>$latest ? scaleDisplayWeight((float)$latest['net_weight']) : null,
        'timestamp'=>date(DATE_ATOM),
    ]);
} catch (Throwable $e) {
    grossanzeigeJson([
        'ok'=>false,
        'error'=>'internal_error',
        'api_version'=>1,
    ], 500);
}
