<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$pdo=db();
$ownerId=currentOwnerId();

$vehicleStmt=$pdo->prepare('SELECT id,plate,name,active FROM vehicles WHERE owner_user_id=? ORDER BY id');
$vehicleStmt->execute([$ownerId]);
$vehicles=$vehicleStmt->fetchAll();

$fieldStmt=$pdo->prepare('SELECT id,name,crop,year,active FROM `fields` WHERE owner_user_id=? ORDER BY id');
$fieldStmt->execute([$ownerId]);
$fields=$fieldStmt->fetchAll();

$activeFields=array_values(array_filter($fields,static fn($f)=>(int)$f['active']===1));
$activeVehicleCount=count(array_filter($vehicles,static fn($v)=>(int)$v['active']===1));

$latestStmt=$pdo->prepare('SELECT COALESCE(MAX(id),0) FROM weighings WHERE owner_user_id=?');
$latestStmt->execute([$ownerId]);
$latestWeighingId=(int)$latestStmt->fetchColumn();

$feldmanagerOutboundState='off';
$feldmanagerOutboundLabel='Aus';
$feldmanagerInboundState='off';
$feldmanagerInboundLabel='Aus';
$grossanzeigeStatus=grossanzeigeConnectionStatus();
if(feldmanagerEnabled()){
    $check=feldmanagerMonitor();
    if(!empty($check['ok'])){
        $outbound=(array)($check['directions']['waagenbox_to_feldmanager']??[]);
        $inbound=(array)($check['directions']['feldmanager_to_waagenbox']??[]);
        $feldmanagerOutboundState=(string)($outbound['state']??'connected');
        $feldmanagerOutboundLabel=(string)($outbound['label']??'Verbunden');
        feldmanagerTelegramHandleOutboundState($feldmanagerOutboundState==='connected');
        $feldmanagerInboundState=(string)($inbound['state']??'unknown');
        $feldmanagerInboundLabel=(string)($inbound['label']??'Unbekannt');
    }else{
        $feldmanagerOutboundState='error';
        $feldmanagerOutboundLabel='Nicht erreichbar';
        feldmanagerTelegramHandleOutboundState(false);
        $feldmanagerInboundState='unknown';
        $feldmanagerInboundLabel='Nicht prüfbar';
    }
}

echo json_encode([
    'ok'=>true,
    'active_vehicle_count'=>$activeVehicleCount,
    'active_field_count'=>count($activeFields),
    'active_field_names'=>array_map(static fn($f)=>(string)$f['name'],$activeFields),
    'latest_weighing_id'=>$latestWeighingId,
    'feldmanager_outbound_state'=>$feldmanagerOutboundState,
    'feldmanager_outbound_label'=>$feldmanagerOutboundLabel,
    'feldmanager_inbound_state'=>$feldmanagerInboundState,
    'feldmanager_inbound_label'=>$feldmanagerInboundLabel,
    'grossanzeige_state'=>(string)($grossanzeigeStatus['state']??'unknown'),
    'grossanzeige_label'=>(string)($grossanzeigeStatus['label']??'Unbekannt'),
    'revision'=>hash('sha256',json_encode([$vehicles,$fields,$latestWeighingId],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
