<?php
require_once __DIR__.'/functions.php';
requireLogin();
$error = null;
$pdo = db();
$testWeightValue = testWeight();
$selected = (int)($_GET['vehicle_id'] ?? $_POST['vehicle_id'] ?? 0);
$selectedField = (int)($_GET['field_id'] ?? $_POST['field_id'] ?? 0);
$selectedCustomer = (int)($_GET['customer_id'] ?? $_POST['customer_id'] ?? 0);
$selectedProduct = (int)($_GET['product_id'] ?? $_POST['product_id'] ?? 0);
$vehicle = null;
if ($selected > 0) {
    $q=$pdo->prepare('SELECT id,plate,name,first_weight,max_weight FROM vehicles WHERE owner_user_id=? AND id=? AND active=1');
    $q->execute([currentOwnerId(),$selected]); $vehicle=$q->fetch() ?: null;
}
$fields = $pdo->query('SELECT id,name,crop,year,active FROM `fields` WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY active DESC, name ASC')->fetchAll();
$customers = $pdo->query('SELECT id,name FROM customers WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY name')->fetchAll();
$products = $pdo->query('SELECT id,name FROM products WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY name')->fetchAll();

function validateOptionalRefs(PDO $pdo, int $fieldId, int $customerId, int $productId): void {
    if ($fieldId > 0) { $s=$pdo->prepare('SELECT id FROM `fields` WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$fieldId]); if(!$s->fetchColumn()) throw new RuntimeException('Der ausgewählte Schlag wurde nicht gefunden.'); }
    if ($customerId > 0) { $s=$pdo->prepare('SELECT id FROM customers WHERE owner_user_id=? AND id=? AND active=1'); $s->execute([currentOwnerId(),$customerId]); if(!$s->fetchColumn()) throw new RuntimeException('Der ausgewählte Kunde ist nicht aktiv oder wurde nicht gefunden.'); }
    if ($productId > 0) { $s=$pdo->prepare('SELECT id FROM products WHERE owner_user_id=? AND id=? AND active=1'); $s->execute([currentOwnerId(),$productId]); if(!$s->fetchColumn()) throw new RuntimeException('Das ausgewählte Produkt ist nicht aktiv oder wurde nicht gefunden.'); }
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    try {
        $action = $_POST['action'] ?? '';
        if ($action === 'set_test_weight') {
            setTestWeight(max(0.0,(float)str_replace(',', '.', (string)($_POST['test_weight'] ?? '0'))));
            flash('Testgewicht wurde gesetzt.');
            redirect('weighing.php');
        }
        if ($action === 'clear_test_weight') {
            setTestWeight(0.0);
            flash('Testgewicht wurde gelöscht.');
            redirect('weighing.php');
        }
        $vid = (int)($_POST['vehicle_id'] ?? 0);
        $fid = (int)($_POST['field_id'] ?? 0);
        $cid = (int)($_POST['customer_id'] ?? 0);
        $pid = (int)($_POST['product_id'] ?? 0);
        if ($vid > 0) {
            $q=$pdo->prepare('SELECT id,plate,name,first_weight,max_weight FROM vehicles WHERE owner_user_id=? AND id=? AND active=1'); $q->execute([currentOwnerId(),$vid]); $vehicle=$q->fetch() ?: null;
            if (!$vehicle) throw new RuntimeException('Fahrzeug nicht gefunden.');
        }
        if ($action === 'start_vehicle') {
            if (!$vehicle) throw new RuntimeException('Bitte ein Fahrzeug auswählen.');
            validateOptionalRefs($pdo,$fid,$cid,$pid);
            $mode=startVehiclePass(
                (int)$vehicle['id'],
                null,
                'manual',
                $fid?:null,
                $cid?:null,
                $pid?:null
            );
            if ($mode === 'first') {
                flash('1. Überfahrt gestartet. Bitte jetzt langsam über die Waage fahren.');
            } elseif ($mode === 'second') {
                flash('2. Überfahrt gestartet. Bitte jetzt langsam über die Waage fahren.');
            } else {
                flash('Wiegung mit gespeichertem Leergewicht gestartet. Bitte jetzt langsam über die Waage fahren.');
            }
            redirect('weighing.php?vehicle_id='.(int)$vehicle['id']);
        }
        if ($action === 'capture_first_pass') {
            $pending=pendingWeighing();
            if(!$pending || !str_ends_with((string)($pending['trigger_type']??''),'_first_pass')) {
                throw new RuntimeException('Es ist keine erste Überfahrt aktiv.');
            }
            $weight=currentWeight();
            if($weight<=0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
            $saved=capturePendingFirstPass($weight);
            if(!empty($saved['waiting_for_second'])){
                flash('1. Überfahrt gespeichert: '.formatWeight((float)$saved['first_weight']).' kg. Bitte für diese manuelle Wiegung anschließend die 2. Überfahrt durchführen.');
            }else{
                flash('1. Überfahrt gespeichert: '.formatWeight((float)$saved['first_weight']).' kg. Die Waage ist wieder frei.');
            }
            redirect('weighing.php?first_saved=1&vehicle_id='.(int)$saved['vehicle_id']);
        }
        if ($action === 'start_unassigned') {
            validateOptionalRefs($pdo,$fid,$cid,$pid);
            $externalLabel=trim((string)($_POST['external_vehicle_label'] ?? ''));

            if($externalLabel!==''){
                $external=findOrCreateManualExternalVehicle($externalLabel);
                $mode=startVehiclePass(
                    (int)$external['id'],
                    null,
                    'manual',
                    $fid?:null,
                    $cid?:null,
                    $pid?:null
                );
                if($mode==='first'){
                    flash('1. Wiegung für externes Fahrzeug '.$external['plate'].' gestartet. Bitte jetzt langsam über die Waage fahren.');
                }elseif($mode==='second'){
                    flash('2. Wiegung für externes Fahrzeug '.$external['plate'].' gestartet. Bitte jetzt langsam über die Waage fahren.');
                }else{
                    flash('Wiegung für externes Fahrzeug '.$external['plate'].' mit gespeichertem Leergewicht gestartet.');
                }
                redirect('weighing.php?external='.rawurlencode((string)$external['plate']));
            }

            if (pendingWeighing()) throw new RuntimeException('Die Waage ist gerade durch eine andere Überfahrt belegt.');
            if (currentWeight() > 0) throw new RuntimeException('Die Waage muss vor dem Start der Überfahrt leer sein.');

            $s=$pdo->prepare(
                'INSERT INTO weighing_state
                 (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at)
                 VALUES (?,1,0,NULL,NULL,?,?,?,?,NOW())
                 ON DUPLICATE KEY UPDATE
                   first_weight=0,
                   vehicle_id=NULL,
                   remote_id=NULL,
                   field_id=VALUES(field_id),
                   customer_id=VALUES(customer_id),
                   product_id=VALUES(product_id),
                   trigger_type=VALUES(trigger_type),
                   started_at=VALUES(started_at)'
            );
            $s->execute([currentOwnerId(),$fid?:null,$cid?:null,$pid?:null,'manual_first_pass']);
            startFirstScaleWeighing();

            flash('1. Wiegung gestartet. Bitte jetzt langsam über die Waage fahren.');
            redirect('weighing.php');
        }
        if ($action === 'second') {
            $pending=pendingWeighing(); if(!$pending) throw new RuntimeException('Es ist keine laufende Wiegung vorhanden.');
            $weight=currentWeight(); if($weight<=0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
            $id = completePendingWeighing($weight, trim($_POST['notes'] ?? ''));
            // Nach dem Abschluss bleibt die Wiegeseite noch 5 Sekunden aktiv,
            // damit die rote Verarbeitungsanzeige sichtbar bleibt.
            redirect('weighing.php?completed=1&id='.(int)$id);
        }
    } catch(Throwable $e) { $error=$e->getMessage(); }
}
$vehicles=$pdo->query('SELECT id,plate,name,first_weight FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 AND manual_external=0 ORDER BY plate')->fetchAll();
$pending=pendingWeighing();
$openVehicleWeighings=openVehicleWeighings();
$pendingIsFirstPass=$pending && str_ends_with((string)($pending['trigger_type']??''),'_first_pass');
// Die Web-Wiegeseite darf nur manuell gestartete Überfahrten automatisch
// abschließen. QR-/Mobile-Überfahrten werden über mobile_complete.php beendet.
// Andernfalls können Web-Seite und Smartphone gleichzeitig abschließen und
// die Web-Seite meldet anschließend fälschlich "keine laufende Wiegung".
$pendingTrigger=(string)($pending['trigger_type']??'');
$autoWeightCapture = (bool)$pending && str_starts_with($pendingTrigger,'manual');
layoutStart('Wiegung','weighings');
if($error) echo '<div class="flash error"><strong>Wiegung konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$completed = isset($_GET['completed']) && $_GET['completed'] === '1';
?>
<?php if($completed): ?>
<div class="card" id="weighingProcessingNotice" style="text-align:center;margin-bottom:20px">
  <div class="eyebrow">WIEGUNG ERFOLGREICH ABGESCHLOSSEN</div>
  <h2>Daten werden verarbeitet …</h2>
  <p class="muted">Die Waage bleibt noch <strong id="processingCountdown">5</strong> Sekunden auf Rot. Anschließend werden die Wiegungen angezeigt.</p>
</div>
<script>
(function(){
  let remaining=5;
  const el=document.getElementById('processingCountdown');
  const timer=setInterval(function(){
    remaining--;
    if(el) el.textContent=remaining;
    if(remaining<=0){clearInterval(timer);window.location.href='weighings.php';}
  },1000);
})();
</script>
<?php endif; ?>
<div class="toolbar"><h1>Wiegung</h1><a class="button" href="weighings.php">Wiegungen anzeigen</a></div>
<div class="weighing-layout">
<section class="card live-scale-card">
  <div class="eyebrow">AKTUELLES WAAGENGEWICHT</div>
  <div id="weight" class="weight"><?=formatScaleWeight(currentWeight())?> <span>kg</span></div>
  <div id="weightStatus" class="status"><?=h(weightStatus())?></div>
  <div class="scale-status-panel">
    <div id="scaleLight" class="scale-light <?=h(scaleStatusKey())?>" data-status="<?=h(scaleStatusKey())?>"><span class="scale-bulb red"></span><span class="scale-bulb yellow"></span><span class="scale-bulb green"></span></div>
    <div><div class="eyebrow">WAAGENSTATUS</div><div id="scaleLightLabel" class="scale-light-label"><?=h(scaleStatusLabel())?></div></div>
  </div>
</section>
<section class="card weighing-form-card">
<?php if($pending): ?>
  <div class="eyebrow">LAUFENDE ÜBERFAHRT</div>
  <h2><?=$pendingIsFirstPass?'1. Überfahrt erfassen':'2. Überfahrt / aktuelle Wiegung erfassen'?></h2>
  <div class="weighing-summary">
    <?php if(!$pendingIsFirstPass): ?><div><span>Referenzgewicht</span><strong><?=formatWeight((float)$pending['first_weight'])?> kg</strong></div><?php endif; ?>
    <?php if(!empty($pending['vehicle_id'])):?><div><span>Fahrzeug</span><strong><?=h(vehicleLabel((int)$pending['vehicle_id']))?></strong></div><?php endif; ?>
    <?php if(!empty($pending['field_id'])):?><div><span>Schlag</span><strong><?=h(fieldName((int)$pending['field_id']))?></strong></div><?php endif; ?>
    <?php if(!empty($pending['customer_id'])):?><div><span>Kunde</span><strong><?=h(customerName((int)$pending['customer_id']))?></strong></div><?php endif; ?>
    <?php if(!empty($pending['product_id'])):?><div><span>Produkt</span><strong><?=h(productName((int)$pending['product_id']))?></strong></div><?php endif; ?>
  </div>
  <p class="muted"><?=$pendingIsFirstPass
    ? 'Die Waage wartet auf die erste Überfahrt. Sobald ein gültiges Gewicht erkannt wird, wird es automatisch fahrzeugbezogen gespeichert und die Waage wieder freigegeben.'
    : 'Die Waage wartet auf die aktuelle Überfahrt. Sobald ein gültiges Gewicht erkannt wird, wird die Wiegung automatisch abgeschlossen.'?></p>
  <?php if(!$pendingIsFirstPass): ?>
    <form method="post"><input type="hidden" name="action" value="second"><label>Notizen (optional)</label><textarea name="notes" placeholder="z. B. Besonderheiten zur Wiegung"></textarea><p><button class="button primary large-button">Gewicht jetzt übernehmen &amp; Wiegeschein erzeugen</button></p></form>
  <?php endif; ?>
<?php else: ?>
  <div class="eyebrow">NEUE WIEGUNG</div><h2>Wiegung starten</h2>
  <p class="muted">Wähle bei Bedarf ein Fahrzeug. Kunde, Produkt und Schlag können optional ergänzt werden.</p>
  <form method="get" class="select-row"><div class="full"><label>Fahrzeug</label><select name="vehicle_id"><option value="">Kein Fahrzeug</option><?php foreach($vehicles as $v): ?><option value="<?=$v['id']?>" <?=$selected===(int)$v['id']?'selected':''?>><?=h($v['plate'].' – '.$v['name'].' · Erstgewicht: '.formatWeight((float)$v['first_weight']).' kg')?></option><?php endforeach; ?></select></div><button class="button">Fahrzeug auswählen</button></form>
  <form method="post"><input type="hidden" name="vehicle_id" value="<?=$vehicle?(int)$vehicle['id']:0?>"><div class="form-grid"><?php if(!$vehicle): ?><div class="full"><label>Externes Kennzeichen / Bezeichnung (optional)</label><input name="external_vehicle_label" maxlength="50" value="<?=h($_POST['external_vehicle_label'] ?? $_GET['external'] ?? '')?>" placeholder="z. B. KH-AB 123 oder Spedition Müller 7"><small>Für fremde Fahrzeuge, die nicht in der Fahrzeugliste angelegt sind. Bei einer offenen Erstwiegung kann dasselbe Kennzeichen später für die Zweitwiegung erneut verwendet werden.</small></div><?php endif; ?><div><label>Kunde (optional)</label><select name="customer_id"><option value="0">Kein Kunde</option><?php foreach($customers as $c): ?><option value="<?=$c['id']?>" <?=$selectedCustomer===(int)$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach; ?></select></div><div><label>Produkt (optional)</label><select name="product_id"><option value="0">Kein Produkt</option><?php foreach($products as $pr): ?><option value="<?=$pr['id']?>" <?=$selectedProduct===(int)$pr['id']?'selected':''?>><?=h($pr['name'])?></option><?php endforeach; ?></select></div><div class="full"><label>Schlag (optional)</label><select name="field_id"><option value="0">Kein Schlag</option><?php foreach($fields as $f): ?><option value="<?=$f['id']?>" <?=$selectedField===(int)$f['id']?'selected':''?>><?=h($f['name'].(!empty($f['crop'])?' – '.$f['crop']:'').(!empty($f['year'])?' ('.$f['year'].')':''))?></option><?php endforeach; ?></select></div></div><div class="button-row weighing-actions">
  <?php if($vehicle): ?><button class="button primary large-button" name="action" value="start_vehicle">Wiegung starten</button><?php else: ?><button class="button primary large-button" name="action" value="start_unassigned">1. Wiegung starten</button><?php endif; ?>
  </div></form>
<?php endif; ?>
</section></div>
<?php if($openVehicleWeighings): ?>
<div class="card">
  <div class="eyebrow">OFFENE FAHRZEUGWIEGUNGEN</div>
  <h2>2. Überfahrt noch ausstehend</h2>
  <p class="muted">Diese Fahrzeuge haben bereits eine erste Überfahrt gespeichert. Die Waage bleibt für andere Fahrzeuge frei.</p>
  <div class="weighing-summary">
    <?php foreach($openVehicleWeighings as $ow): ?>
      <div>
        <span><?=h(trim(($ow['plate']??'').' – '.($ow['vehicle_name']??''),' –'))?></span>
        <strong><?=formatWeight((float)$ow['first_weight'])?> kg · seit <?=h((string)$ow['first_measured_at'])?></strong>
        <div style="margin-top:8px">
          <form method="post" style="display:inline">
            <input type="hidden" name="vehicle_id" value="<?=(int)$ow['vehicle_id']?>">
            <input type="hidden" name="field_id" value="<?=!empty($ow['field_id'])?(int)$ow['field_id']:0?>">
            <input type="hidden" name="customer_id" value="<?=!empty($ow['customer_id'])?(int)$ow['customer_id']:0?>">
            <input type="hidden" name="product_id" value="<?=!empty($ow['product_id'])?(int)$ow['product_id']:0?>">
            <button class="button primary" name="action" value="start_vehicle">2. Wiegung starten</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php if (demoMode()): ?>
<div class="card test-weight-card">
  <div class="eyebrow">TESTBETRIEB OHNE WAAGENCOMPUTER</div>
  <h2>Testgewicht setzen</h2>
  <p class="muted">Nur solange die Dini-Waage nicht aktiviert ist. Das Testgewicht wird wie ein echtes Waagengewicht verwendet, damit Wiegungen vorab geprüft werden können.</p>
  <form method="post" class="test-weight-form">
    <input type="hidden" name="action" value="set_test_weight">
    <div><label>Testgewicht (kg)</label><input type="number" name="test_weight" step="0.1" min="0" value="<?=h(number_format($testWeightValue,0,'.',''))?>" placeholder="z. B. 12500"></div>
    <button class="button primary">Testgewicht setzen</button>
  </form>
  <div class="actions"><form method="post"><input type="hidden" name="action" value="clear_test_weight"><button class="button">Testgewicht löschen</button></form></div>
  <p class="muted">Aktuell simuliert: <strong><?=formatScaleWeight($testWeightValue)?> kg</strong></p>
</div>
<?php endif; ?>
<script src="assets/app.js"></script>
<script>
window.pendingKey=<?=json_encode($pending ? ($pending['started_at'].'|'.($pending['remote_id']??0).'|'.($pending['vehicle_id']??0)) : null)?>;
window.pendingFirstWeight=<?=json_encode($pending ? (float)$pending['first_weight'] : 0)?>;
window.pendingMode=<?=json_encode($pendingIsFirstPass ? 'first' : ($pending ? 'second' : null))?>;
let autoFinishTimer=null;
let autoFinishing=false;
let lastObservedWeight=0;

async function pollPendingState(){
  try{
    const r=await fetch('api/pending.php',{cache:'no-store'});
    const d=await r.json();
    if(d.key!==window.pendingKey && !autoFinishing) location.reload();
  }catch(e){}
}

async function pollActiveWeight(){
  if(!window.pendingKey || autoFinishing) return;
  try{
    const r=await fetch('api/status.php',{cache:'no-store'});
    const d=await r.json();
    const w=Number(d.weight)||0;
    const differsFromReference=Math.abs(w-Number(window.pendingFirstWeight))>0.05;
    const validForMode=window.pendingMode==='first' ? w>0 : (w>0 && differsFromReference);

    if(validForMode && lastObservedWeight<=0 && !autoFinishTimer){
      autoFinishTimer=setTimeout(()=>{
        autoFinishTimer=null;
        finishActivePass();
      },1000);
    }

    if(!validForMode && autoFinishTimer){
      clearTimeout(autoFinishTimer);
      autoFinishTimer=null;
    }

    lastObservedWeight=validForMode ? w : 0;
  }catch(e){}
}

function finishActivePass(){
  if(autoFinishing) return;
  autoFinishing=true;
  const form=document.getElementById(
    window.pendingMode==='first' ? 'autoFirstPassForm' : 'autoSecondPassForm'
  );
  if(form) form.submit();
}

<?php if($autoWeightCapture): ?>
setInterval(pollActiveWeight,500);
<?php endif; ?>
setInterval(pollPendingState,3000);
</script>
<?php if($autoWeightCapture): ?>
<?php if($pendingIsFirstPass): ?>
<form id="autoFirstPassForm" method="post" style="display:none"><input type="hidden" name="action" value="capture_first_pass"></form>
<?php else: ?>
<form id="autoSecondPassForm" method="post" style="display:none"><input type="hidden" name="action" value="second"></form>
<?php endif; ?>
<?php endif; ?>
<?php layoutEnd(); ?>
