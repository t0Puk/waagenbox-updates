<?php
declare(strict_types=1);

require_once __DIR__.'/functions.php';
requireLogin();
$pdo=db();
$id=(int)($_GET['id']??$_POST['id']??0);
if($id<=0){flash('Ungültiges Fahrzeug.');redirect('vehicles.php');}

function loadVehicleForEdit(PDO $pdo,int $id): ?array{
    $s=$pdo->prepare('SELECT id,plate,name,first_weight,max_weight,notes,active FROM vehicles WHERE owner_user_id=? AND id=?');
    $s->execute([currentOwnerId(),$id]);
    return $s->fetch(PDO::FETCH_ASSOC)?:null;
}

$vehicle=loadVehicleForEdit($pdo,$id);
if(!$vehicle){flash('Fahrzeug wurde nicht gefunden.');redirect('vehicles.php');}
$error=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
    try{
        requireCsrfToken();
        $action=(string)($_POST['action']??'save');

        if($action==='clear_first_weight'){
            if((float)$vehicle['first_weight']<=0) throw new RuntimeException('Für dieses Fahrzeug ist kein Erstgewicht hinterlegt.');
            $p=$pdo->prepare('SELECT COUNT(*) FROM weighing_state WHERE owner_user_id=? AND id=1 AND vehicle_id=?');
            $p->execute([currentOwnerId(),$id]);
            if((int)$p->fetchColumn()>0) throw new RuntimeException('Das Erstgewicht kann während einer laufenden Wiegung dieses Fahrzeugs nicht gelöscht werden.');
            $s=$pdo->prepare('UPDATE vehicles SET first_weight=0 WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$id]);
            flash('Leergewicht / Erstgewicht wurde gelöscht.');
            redirect('vehicle_edit.php?id='.$id);
        }

        if($action!=='save') throw new RuntimeException('Unbekannte Aktion.');

        $plate=trim((string)($_POST['plate']??''));
        $name=trim((string)($_POST['name']??''));
        $maxRaw=trim((string)($_POST['max_weight']??''));
        $notes=trim((string)($_POST['notes']??''));

        if($plate==='') throw new RuntimeException('Bitte ein Kennzeichen oder eine vorläufige Fahrzeugnummer eingeben.');
        if($name==='') throw new RuntimeException('Bitte eine Bezeichnung eingeben.');

        $max=$maxRaw===''?null:(float)str_replace(',','.',$maxRaw);
        if($max!==null && $max<0) throw new RuntimeException('Das maximale Gewicht darf nicht negativ sein.');

        $q=$pdo->prepare('SELECT id FROM vehicles WHERE owner_user_id=? AND plate=? AND id<>? LIMIT 1');
        $q->execute([currentOwnerId(),$plate,$id]);
        if($q->fetchColumn()) throw new RuntimeException('Dieses Kennzeichen bzw. diese Fahrzeugnummer ist bereits einem anderen Fahrzeug zugeordnet.');

        $s=$pdo->prepare('UPDATE vehicles SET plate=?,name=?,max_weight=?,notes=? WHERE owner_user_id=? AND id=?');
        $s->execute([$plate,$name,$max,$notes,currentOwnerId(),$id]);

        flash('Fahrzeug wurde gespeichert.');
        redirect('vehicle_edit.php?id='.$id);
    }catch(Throwable $e){
        $error=$e->getMessage();
    }
    $vehicle=loadVehicleForEdit($pdo,$id)??$vehicle;
}

layoutStart('Fahrzeug bearbeiten','vehicles');
if($error) echo '<div class="flash error"><strong>Fahrzeug konnte nicht gespeichert werden.</strong><br>'.h($error).'</div>';
?>
<div class="toolbar"><h1>Fahrzeug bearbeiten</h1><a class="button" href="vehicles.php">← Zurück zu Fahrzeuge</a></div>

<div class="card">
<h2>Stammdaten</h2>
<p class="muted">Für einen schnellen Start kann morgens zunächst z. B. „1“ / „Fahrzeug 1“ verwendet und das echte Kennzeichen später ergänzt werden.</p>
<form method="post">
<input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="action" value="save">
<div class="form-grid">
<div><label>Kennzeichen / vorläufige Fahrzeugnummer</label><input name="plate" required value="<?=h($vehicle['plate'])?>"></div>
<div><label>Name / Bezeichnung</label><input name="name" required value="<?=h($vehicle['name'])?>"></div>
<div><label>Gespeichertes Leergewicht / Erstgewicht</label><input value="<?= (float)$vehicle['first_weight']>0?h(formatWeight((float)$vehicle['first_weight']).' kg'):'nicht gesetzt' ?>" disabled></div>
<div><label>Max. Gewicht (kg)</label><input type="number" step="5" min="0" name="max_weight" value="<?=h($vehicle['max_weight']??'')?>"></div>
<div class="full"><label>Notizen</label><textarea name="notes"><?=h($vehicle['notes']??'')?></textarea></div>
</div>
<p><button class="button primary">Änderungen speichern</button></p>
</form>
</div>

<div class="card">
<h2>Leergewicht / Erstgewicht</h2>
<p>Das Löschen betrifft nur das gespeicherte Erstgewicht des Fahrzeugs. Bereits abgeschlossene Wiegungen und Wiegescheine bleiben unverändert.</p>
<form method="post" onsubmit="return confirm('Leergewicht / Erstgewicht für <?=h($vehicle['plate'])?> wirklich löschen?\n\nDanach muss vor der nächsten normalen Wiegung ein neues Erstgewicht erfasst werden.');">
<input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="action" value="clear_first_weight">
<button class="button-danger" <?= (float)$vehicle['first_weight']<=0?'disabled':'' ?>>Leergewicht löschen</button>
</form>
</div>
<?php layoutEnd(); ?>
