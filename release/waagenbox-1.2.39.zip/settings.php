<?php
require_once __DIR__.'/functions.php';
requireLogin();
$pdo=db(); $error=null;
$tab=(string)($_GET['tab']??'allgemein');
$allowed=['allgemein','gps','waagencomputer','wiegescheine','backup','kamera','feldmanager','telegram','grossanzeige','updates','zugang'];
if(!in_array($tab,$allowed,true)) $tab='allgemein';
if (in_array($tab,['backup','wiegescheine','feldmanager','telegram','grossanzeige'],true) || in_array(($_POST['section'] ?? ''),['backup','wiegescheine','feldmanager','telegram','grossanzeige'],true)) requireAdmin();
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    $section=(string)($_POST['section']??'');
    if($section==='allgemein'){
      $brand=trim((string)($_POST['brand_name']??'')); if($brand==='')$brand='AJP WAAGE';
      if(mb_strlen($brand)>80)throw new RuntimeException('Der Name der Waage darf höchstens 80 Zeichen lang sein.');
      $contactPhone=trim((string)($_POST['contact_phone']??''));
      $contactEnabled=isset($_POST['contact_enabled'])?'1':'0';
      if(mb_strlen($contactPhone)>40) throw new RuntimeException('Die Kontakt-Telefonnummer darf höchstens 40 Zeichen lang sein.');
      if($contactEnabled==='1'&&$contactPhone==='') throw new RuntimeException('Bitte eine Telefonnummer eintragen oder die Kontaktanzeige deaktivieren.');
      saveAppSetting('brand_name',$brand);
      saveAppSetting('contact_phone',$contactPhone);
      saveAppSetting('contact_enabled',$contactEnabled);
      flash('Allgemeine Einstellungen wurden gespeichert.'); redirect('settings.php?tab=allgemein');
    }
    if($section==='gps'){
      $enabled=isset($_POST['gps_enabled'])?'1':'0'; $lat=trim((string)($_POST['gps_lat']??'')); $lon=trim((string)($_POST['gps_lon']??''));
      $radius=max(1,(int)($_POST['gps_radius_m']??50)); $accuracy=max(1,(int)($_POST['gps_accuracy_m']??50));
      if($enabled==='1'&&($lat===''||$lon===''))throw new RuntimeException('Bitte den Standort der Waage angeben oder über den Standort-Button übernehmen.');
      if($lat!==''&&(!is_numeric(str_replace(',','.',$lat))||(float)str_replace(',','.',$lat)<-90||(float)str_replace(',','.',$lat)>90))throw new RuntimeException('Die Latitude ist ungültig.');
      if($lon!==''&&(!is_numeric(str_replace(',','.',$lon))||(float)str_replace(',','.',$lon)<-180||(float)str_replace(',','.',$lon)>180))throw new RuntimeException('Die Longitude ist ungültig.');
      $lat=str_replace(',','.',$lat);$lon=str_replace(',','.',$lon);
      foreach([['gps_enabled',$enabled],['gps_lat',$lat],['gps_lon',$lon],['gps_radius_m',(string)$radius],['gps_accuracy_m',(string)$accuracy]]as[$k,$v])saveAppSetting($k,$v);
      flash('GPS-Einstellungen wurden gespeichert.');redirect('settings.php?tab=gps');
    }
    if($section==='waagencomputer'){
      $demo=isset($_POST['demo_mode'])?'1':'0';
      $previousDemo=appSetting('demo_mode','1')==='1';
      if($demo==='1' && !$previousDemo && !isset($_POST['demo_confirm'])) throw new RuntimeException('Bitte bestätige, dass du wirklich in den Demo-Modus wechseln möchtest.');
      $enabled=isset($_POST['dini_enabled'])?'1':'0';$host=trim((string)($_POST['dini_host']??''));$port=(int)($_POST['dini_port']??0);$timeout=(float)str_replace(',','.',(string)($_POST['dini_timeout']??2));
      if($host==='')throw new RuntimeException('Bitte die IP-Adresse des Waagencomputers eintragen.');if($port<1||$port>65535)throw new RuntimeException('Der TCP-Port muss zwischen 1 und 65535 liegen.');if($timeout<0.2||$timeout>20)throw new RuntimeException('Das Timeout muss zwischen 0,2 und 20 Sekunden liegen.');
      if($demo==='1') $enabled='0';
      saveAppSetting('demo_mode',$demo);saveAppSetting('dini_enabled',$enabled);saveAppSetting('dini_host',$host);saveAppSetting('dini_port',(string)$port);saveAppSetting('dini_timeout',number_format($timeout,3,'.',''));
      flash($demo==='1' ? 'Demo-Modus wurde aktiviert. Die Waagencomputer-Anbindung wurde automatisch deaktiviert.' : 'Waagencomputer-Einstellungen wurden gespeichert.');redirect('settings.php?tab=waagencomputer');
    }
    if($section==='wiegescheine'){
      requireCsrfToken();
      if(($_POST['action']??'')!=='reset_ticket_numbers') throw new RuntimeException('Ungültige Aktion.');
      resetTicketNumberSequence();
      flash('Wiegeschein-Nummernkreis wurde zurückgesetzt. Die nächste neue Wiegung erhält die Nummer 000001. Bestehende Wiegescheine behalten ihre bisherigen Nummern.');
      redirect('settings.php?tab=wiegescheine');
    }
    if($section==='updates'){
      $channel=(string)($_POST['update_channel']??'release');
      if(!in_array($channel,['release','staging'],true)) $channel='release';
      $url=rtrim(trim((string)($_POST['update_server_url']??'')),'/');
      if($url!==''&&!preg_match('~^https://~i',$url))throw new RuntimeException('Der Update-Server muss über HTTPS erreichbar sein.');
      saveAppSetting('update_channel',$channel);
      // Offizielle Server-URL folgt dem gewählten Kanal. Eigene URLs bleiben erhalten.
      if($url==='' || in_array($url,['https://update.ajp-bg.de/release','https://update.ajp-bg.de/staging'],true)) {
        $url='https://update.ajp-bg.de/'.$channel;
      }
      saveAppSetting('update_server_url',$url);
      $rollbackEmail=trim((string)($_POST['rollback_email']??''));
      if($rollbackEmail!=='' && !filter_var($rollbackEmail,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Die E-Mail-Adresse für Rückmeldungen ist ungültig.');
      saveAppSetting('rollback_email',$rollbackEmail);
      saveAppSetting('update_ignored_version',''); saveAppSetting('update_manifest_cache',''); saveAppSetting('update_last_check','');
      flash('Update-Einstellungen wurden gespeichert.'); redirect('settings.php?tab=updates');
    }
    if($section==='backup'){
      $enabled=isset($_POST['backup_enabled'])?'1':'0';$frequency=(string)($_POST['backup_frequency']??'daily');if(!in_array($frequency,['hourly','daily','weekly'],true))$frequency='daily';
      $time=(string)($_POST['backup_time']??'03:00');if(!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$time))$time='03:00';$weekday=max(1,min(7,(int)($_POST['backup_weekday']??1)));$ret=max(1,min(90,(int)($_POST['backup_retention']??14)));
      $gd=isset($_POST['gdrive_enabled'])?'1':'0';$remote=trim((string)($_POST['gdrive_remote']??''));$path=trim((string)($_POST['gdrive_path']??'Waagenbox-Backups'));if($path==='')$path='Waagenbox-Backups';
      foreach([['backup_enabled',$enabled],['backup_frequency',$frequency],['backup_time',$time],['backup_weekday',(string)$weekday],['backup_retention',(string)$ret],['gdrive_enabled',$gd],['gdrive_remote',$remote],['gdrive_path',$path]]as[$k,$v])saveAppSetting($k,$v);
      flash('Backup-Einstellungen wurden gespeichert.');redirect('settings.php?tab=backup');
    }
    if($section==='feldmanager'){
      requireAdmin();
      requireCsrfToken();
      $enabled=isset($_POST['feldmanager_enabled'])?'1':'0';
      $base=rtrim(trim((string)($_POST['feldmanager_base_url']??'')),'/');
      if($base!==''&&!preg_match('~^https://~i',$base)) throw new RuntimeException('Die Feldmanager-Adresse muss mit https:// beginnen.');
      $token=trim((string)($_POST['feldmanager_api_token']??''));
      if($token!=='') saveAppSetting('feldmanager_api_token',$token);
      $storedToken=$token!==''?$token:appSetting('feldmanager_api_token','');
      if($enabled==='1'&&($base===''||$storedToken==='')) throw new RuntimeException('Für die automatische Zuordnung werden Feldmanager-Adresse und API-Token benötigt.');
      if($storedToken!==''&&strlen($storedToken)<24) throw new RuntimeException('Der Feldmanager-API-Token muss mindestens 24 Zeichen lang sein.');

      saveAppSetting('feldmanager_enabled',$enabled);
      saveAppSetting('feldmanager_base_url',$base);
      flash('Feldmanager-Verknüpfung wurde gespeichert.');
      redirect('settings.php?tab=feldmanager');
    }
    if($section==='telegram'){
      requireAdmin();
      requireCsrfToken();
      $enabled=isset($_POST['telegram_enabled'])?'1':'0';
      $token=trim((string)($_POST['telegram_bot_token']??''));
      $chatId=trim((string)($_POST['telegram_chat_id']??''));
      if($token!=='') saveAppSetting('telegram_bot_token',$token);
      $storedToken=$token!==''?$token:appSetting('telegram_bot_token','');
      if($storedToken!==''&&strlen($storedToken)<20) throw new RuntimeException('Der Telegram-Bot-Token erscheint ungültig.');
      if($enabled==='1'&&($storedToken===''||$chatId==='')) throw new RuntimeException('Für Telegram werden Bot-Token und Chat-ID benötigt.');
      saveAppSetting('telegram_enabled',$enabled);
      saveAppSetting('telegram_chat_id',$chatId);
      saveAppSetting('feldmanager_outbound_notify_state','');

      $action=(string)($_POST['action']??'save');
      if($action==='test'){
        if($storedToken===''||$chatId==='') throw new RuntimeException('Bitte zuerst Bot-Token und Chat-ID eintragen.');
        $result=telegramSendMessage("✅ Telegram-Test erfolgreich\n".appSetting('brand_name','AJP WAAGE')."\nDie Waagenbox kann Telegram-Nachrichten senden.");
        if(empty($result['ok'])) throw new RuntimeException((string)($result['message']??'Telegram-Testnachricht konnte nicht gesendet werden.'));
        flash('Telegram-Testnachricht wurde gesendet.');
      }else{
        flash('Telegram-Einstellungen wurden gespeichert.');
      }
      redirect('settings.php?tab=telegram');
    }
    if($section==='grossanzeige'){
      requireAdmin();
      requireCsrfToken();
      $action=(string)($_POST['action']??'save');
      if($action==='generate_token'){
        $token=bin2hex(random_bytes(32));
        saveAppSetting('grossanzeige_api_token_hash',hash('sha256',$token));
        saveAppSetting('grossanzeige_api_token_created_at',date(DATE_ATOM));
        $_SESSION['grossanzeige_generated_token']=$token;
        flash('Neuer Großanzeigen-Token wurde erzeugt. Bitte jetzt in die Großanzeige kopieren; er wird nur einmal angezeigt.');
        redirect('settings.php?tab=grossanzeige');
      }
      if($action==='display_toggle'){
        saveAppSetting('grossanzeige_display_enabled',isset($_POST['grossanzeige_display_enabled'])?'1':'0');
        flash(isset($_POST['grossanzeige_display_enabled']) ? 'Großanzeige wurde aktiviert.' : 'Großanzeige wurde deaktiviert.');
        redirect('settings.php?tab=grossanzeige');
      }
      $enabled=isset($_POST['grossanzeige_enabled'])?'1':'0';
      $address=trim((string)($_POST['grossanzeige_address']??''));
      $firstProcessing=max(1,min(120,(int)($_POST['grossanzeige_first_processing_seconds']??10)));
      $completeProcessing=max(1,min(120,(int)($_POST['grossanzeige_complete_processing_seconds']??10)));
      $successSeconds=max(1,min(120,(int)($_POST['grossanzeige_success_seconds']??10)));
      if(mb_strlen($address)>255) throw new RuntimeException('Die Adresse der Großanzeige ist zu lang.');
      if($address!=='' && preg_match('/\s/',$address)) throw new RuntimeException('Die Adresse der Großanzeige darf keine Leerzeichen enthalten.');
      if($enabled==='1' && trim(appSetting('grossanzeige_api_token_hash',''))==='') throw new RuntimeException('Bitte zuerst einen Großanzeigen-Token erzeugen.');
      saveAppSetting('grossanzeige_enabled',$enabled);
      saveAppSetting('grossanzeige_address',$address);
      saveAppSetting('grossanzeige_first_processing_seconds',(string)$firstProcessing);
      saveAppSetting('grossanzeige_complete_processing_seconds',(string)$completeProcessing);
      saveAppSetting('grossanzeige_success_seconds',(string)$successSeconds);
      flash('Großanzeigen-Einstellungen wurden gespeichert.');
      redirect('settings.php?tab=grossanzeige');
    }
    if($section==='kamera'){
      $enabled=isset($_POST['camera_enabled'])?'1':'0';
      $snap=isset($_POST['camera_snapshot_enabled'])?'1':'0';
      $stream=rtrim(trim((string)($_POST['camera_stream_url']??'')),'/');
      $snapshot=trim((string)($_POST['camera_snapshot_url']??''));
      if($stream!==''&&!preg_match('~^https?://~i',$stream))throw new RuntimeException('Die Stream-URL muss mit http:// oder https:// beginnen.');
      if($snapshot!==''&&!preg_match('~^https?://~i',$snapshot))throw new RuntimeException('Die Schnappschuss-URL muss mit http:// oder https:// beginnen.');
      if($snap==='1'&&$snapshot==='')throw new RuntimeException('Für automatische Schnappschüsse muss eine Schnappschuss-URL eingetragen werden.');
      saveAppSetting('camera_enabled',$enabled);saveAppSetting('camera_stream_url',$stream);saveAppSetting('camera_snapshot_enabled',$snap);saveAppSetting('camera_snapshot_url',$snapshot);
      flash('Kamera-Einstellungen wurden gespeichert.');redirect('settings.php?tab=kamera');
    }
  }catch(Throwable $e){$error=$e->getMessage();$tab=in_array($section,$allowed,true)?$section:$tab;}
}
$brand=appSetting('brand_name','AJP WAAGE');
$contactPhone=appSetting('contact_phone','');
$contactEnabled=appSetting('contact_enabled','0')==='1';
$rollbackEmail=appSetting('rollback_email',''); $rollbackInfo=rollbackInfo();
$gpsEnabled=appSetting('gps_enabled','0')==='1';$lat=appSetting('gps_lat','');$lon=appSetting('gps_lon','');$radius=appSetting('gps_radius_m','50');$accuracy=appSetting('gps_accuracy_m','50');
$demoMode=demoMode();$diniCfg=diniConfig();$diniEnabled=!empty($diniCfg['enabled']);$diniHost=$diniCfg['host'];$diniPort=$diniCfg['port'];$diniTimeout=$diniCfg['timeout'];$mobileRemoteBase=mobileRemoteBaseUrl();
$backupEnabled=appSetting('backup_enabled','0')==='1';$backupFrequency=appSetting('backup_frequency','daily');$backupTime=appSetting('backup_time','03:00');$backupWeekday=(int)appSetting('backup_weekday','1');$backupRetention=(int)appSetting('backup_retention','14');$gdriveEnabled=appSetting('gdrive_enabled','0')==='1';$gdriveRemote=appSetting('gdrive_remote','');$gdrivePath=appSetting('gdrive_path','Waagenbox-Backups');
$connection=diniConnectionStatus();$updateChannel=appSetting('update_channel',(defined('WEB_DEVELOPMENT')&&WEB_DEVELOPMENT)?'staging':'release');if(!in_array($updateChannel,['release','staging'],true))$updateChannel=(defined('WEB_DEVELOPMENT')&&WEB_DEVELOPMENT)?'staging':'release';$updateUrl=updateBaseUrl();$lastUpdateCheck=appSetting('update_last_check','');$ignoredUpdate=updateIgnoredVersion();$lastBackup=appSetting('backup_last','');$lastBackupFile=appSetting('backup_last_file','');
$cameraEnabled=cameraEnabled();$cameraStream=cameraStreamUrl();$cameraSnapshotEnabled=cameraSnapshotEnabled();$cameraSnapshot=cameraSnapshotUrl();
$feldmanagerEnabled=feldmanagerEnabled();
$telegramEnabled=telegramEnabled();
$telegramTokenConfigured=telegramBotToken()!=='';
$telegramChatId=telegramChatId();
$grossanzeigeEnabled=appSetting('grossanzeige_enabled','0')==='1';
$grossanzeigeDisplayEnabled=grossanzeigeDisplayEnabled();
$grossanzeigeAddress=appSetting('grossanzeige_address','');
$grossanzeigeBaseUrl=grossanzeigeBaseUrl();
$grossanzeigeAdminUrl=$grossanzeigeBaseUrl!=='' ? $grossanzeigeBaseUrl.'/' : '';
$grossanzeigeDisplayUrl=$grossanzeigeBaseUrl!=='' ? $grossanzeigeBaseUrl.'/display/' : '';
$grossanzeigeFirstProcessingSeconds=grossanzeigeFirstProcessingSeconds();
$grossanzeigeCompleteProcessingSeconds=grossanzeigeCompleteProcessingSeconds();
$grossanzeigeSuccessSeconds=grossanzeigeSuccessSeconds();
$grossanzeigeTokenConfigured=trim(appSetting('grossanzeige_api_token_hash',''))!=='';
$grossanzeigeTokenCreatedAt=appSetting('grossanzeige_api_token_created_at','');
$grossanzeigeGeneratedToken=(string)($_SESSION['grossanzeige_generated_token']??'');
unset($_SESSION['grossanzeige_generated_token']);
$feldmanagerBase=feldmanagerBaseUrl();
$feldmanagerTokenConfigured=trim(appSetting('feldmanager_api_token',''))!=='';
$feldmanagerTeamsResponse=['ok'=>false,'teams'=>[]];
$feldmanagerTeams=[];
$feldmanagerRemoteTeams=feldmanagerRemoteTeamMap();
$feldmanagerRemoteRows=[];
if($tab==='feldmanager'){
  if($feldmanagerBase!==''&&$feldmanagerTokenConfigured) $feldmanagerTeamsResponse=feldmanagerTeams();
  if(!empty($feldmanagerTeamsResponse['ok'])) $feldmanagerTeams=(array)($feldmanagerTeamsResponse['teams']??[]);
  $feldmanagerRemoteRows=$pdo->query('SELECT r.id,r.code,r.name,v.plate,v.name AS vehicle_name FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id='.(int)currentOwnerId().' AND r.active=1 ORDER BY r.name,r.code')->fetchAll();
}

$nextTicketNumber=nextTicketNumberPreview();
layoutStart('Einstellungen','settings');
if($error)echo '<div class="flash error"><strong>Einstellungen konnten nicht gespeichert werden.</strong><br>'.h($error).'</div>';
?>
<div class="toolbar"><h1>Einstellungen</h1></div><?php if(isAdmin()): ?><p class="button-row"><a class="button" href="service_wlan.php">Service-WLAN</a><a class="button" href="dini_diagnostics.php">Dini-Diagnose</a></p><?php endif; ?>
<nav class="settings-tabs">
<a class="<?= $tab==='allgemein'?'active':'' ?>" href="settings.php?tab=allgemein">Allgemein</a>
<a class="<?= $tab==='gps'?'active':'' ?>" href="settings.php?tab=gps">Standort / GPS</a>
<a class="<?= $tab==='waagencomputer'?'active':'' ?>" href="settings.php?tab=waagencomputer">Waagencomputer</a>
<a class="<?= $tab==='wiegescheine'?'active':'' ?>" href="settings.php?tab=wiegescheine">Wiegescheine</a>
<a class="<?= $tab==='backup'?'active':'' ?>" href="settings.php?tab=backup">Backup</a>
<a class="<?= $tab==='kamera'?'active':'' ?>" href="settings.php?tab=kamera">Kamera</a>
<a class="<?= $tab==='feldmanager'?'active':'' ?>" href="settings.php?tab=feldmanager">Feldmanager</a>
<a class="<?= $tab==='telegram'?'active':'' ?>" href="settings.php?tab=telegram">Telegram</a>
<a class="<?= $tab==='grossanzeige'?'active':'' ?>" href="settings.php?tab=grossanzeige">Großanzeige</a>
<a class="<?= $tab==='updates'?'active':'' ?>" href="settings.php?tab=updates">Updates</a>
<a class="<?= $tab==='zugang'?'active':'' ?>" href="settings.php?tab=zugang">Zugang</a>
<a href="system.php">System</a>
</nav>
<?php if($tab==='allgemein'): ?>
<div class="card"><h2>Name der Waage</h2><p>Dieser Name wird oben links in der Weboberfläche angezeigt. So kannst du mehrere Waagenboxen später eindeutig unterscheiden.</p><form method="post"><input type="hidden" name="section" value="allgemein"><div class="form-grid"><div class="full"><label for="brand_name">Name der Waage</label><input id="brand_name" name="brand_name" maxlength="80" value="<?=h($brand)?>" placeholder="z. B. Hof Nord – Waage 1"></div><div class="full"><label for="contact_phone">Kontakt-Telefonnummer für QR-Fernbedienungen</label><input id="contact_phone" type="tel" name="contact_phone" maxlength="40" value="<?=h($contactPhone)?>" placeholder="z. B. +49 171 1234567"><small class="muted">Diese Nummer kann auf der mobilen QR-Fernbedienung als anklickbarer Kontakt angezeigt werden.</small></div><div class="full"><label class="setting-toggle"><input type="checkbox" name="contact_enabled" value="1" <?=$contactEnabled?'checked':''?>> <span>Kontakt-Link auf QR-Fernbedienungen anzeigen</span></label></div></div><p><button class="button primary">Speichern</button></p></form></div>
<div class="card"><h2>Testbetrieb ohne Waagencomputer</h2><p>Zum Testen der Wägeabläufe kannst du auf der Wiegeseite ein Testgewicht setzen. Sobald der echte Waagencomputer aktiviert ist, wird ausschließlich das reale Gewicht verwendet.</p><a class="button" href="weighing.php">Zur Wiegeseite</a></div>
<?php elseif($tab==='gps'): ?>
<div class="card"><h2>Standortprüfung für mobile QR-Fernbedienungen</h2><p>Die GPS-Prüfung wird nur beim Versuch einer mobilen Wiegung verwendet. Der Standort wird nicht dauerhaft überwacht.</p><form method="post"><input type="hidden" name="section" value="gps"><label class="setting-toggle"><input type="checkbox" name="gps_enabled" value="1" <?=$gpsEnabled?'checked':''?>> <span>GPS-Prüfung aktiv</span></label><div class="form-grid" style="margin-top:16px"><div><label>Latitude der Waage</label><input id="gps_lat" name="gps_lat" value="<?=h($lat)?>" placeholder="z. B. 52.123456"></div><div><label>Longitude der Waage</label><input id="gps_lon" name="gps_lon" value="<?=h($lon)?>" placeholder="z. B. 9.123456"></div><div><label>Zulässiger Radius (Meter)</label><input type="number" min="1" name="gps_radius_m" value="<?=h($radius)?>"></div><div><label>Maximale GPS-Ungenauigkeit (Meter)</label><input type="number" min="1" name="gps_accuracy_m" value="<?=h($accuracy)?>"></div></div><p class="button-row"><button type="button" class="button" onclick="useCurrentLocation()">📍 Aktuellen Standort übernehmen</button><button class="button primary">Einstellungen speichern</button></p><p class="muted">Wenn „GPS-Prüfung aktiv“ deaktiviert ist, darf die mobile Fernbedienung ohne Standortfreigabe wiegen.</p><p id="gps_status" class="muted">Noch nicht abgefragt.</p></form></div>
<?php elseif($tab==='waagencomputer'): ?>
<div class="card"><h2>Verbindung zum Waagencomputer</h2><div class="connection-status <?=$connection['state']==='connected'?'connected':($connection['state']==='error'?'error':'disabled')?>"><span class="connection-dot"></span><div><strong><?=h($connection['label'])?></strong><div><?=h($connection['detail'])?></div></div></div><p class="muted">Die IP-Adresse und der TCP-Port werden hier für die Dini-3590-Anbindung verwendet. Der genaue TCP-Port des eingesetzten ETHKR-1 muss vor Aktivierung geprüft werden.</p><form method="post" id="waagencomputerForm"><input type="hidden" name="section" value="waagencomputer"><input type="hidden" name="demo_confirm" id="demoConfirm" value=""><label class="setting-toggle"><input type="checkbox" id="demoMode" name="demo_mode" value="1" <?=$demoMode?'checked':''?>> <span>Demo-Modus aktiv</span></label><p class="muted">Im Demo-Modus werden Testgewichte auf Dashboard und Wiegeseite angezeigt. Dies funktioniert auch auf dem Raspberry. Die Waagencomputer-Anbindung wird beim Aktivieren automatisch deaktiviert. Beim Deaktivieren wird sie nicht automatisch aktiviert.</p><label class="setting-toggle"><input type="checkbox" name="dini_enabled" value="1" <?=$diniEnabled?'checked':''?> <?=$demoMode?'disabled':''?>> <span>Waagencomputer-Anbindung aktiv</span></label><div class="form-grid" style="margin-top:16px"><div><label>IP-Adresse / Hostname</label><input name="dini_host" value="<?=h($diniHost)?>" placeholder="z. B. 192.168.55.50"></div><div><label>TCP-Port</label><input type="number" min="1" max="65535" name="dini_port" value="<?=h($diniPort)?>"></div><div><label>Timeout (Sekunden)</label><input type="number" min="0.2" max="20" step="0.1" name="dini_timeout" value="<?=h($diniTimeout)?>"></div></div><div class="form-grid" style="margin-top:24px"><div class="full"><label>Adresse für mobile QR-Fernbedienungen</label><input type="url" readonly value="<?=h($mobileRemoteBase)?>" ><small class="muted">Diese HTTPS-Adresse wird unabhängig davon für neue QR-Codes verwendet, unter welcher Adresse die Waagenbox lokal geöffnet ist. Der Endpunkt ist zentral festgelegt.</small></div></div><p><button class="button primary">Verbindungseinstellungen speichern</button></p></form></div>
<?php elseif($tab==='wiegescheine'): ?>
<div class="card">
  <h2>Wiegeschein-Nummernkreis</h2>
  <p>Hier kann der fortlaufende Nummernkreis einmalig vor dem Start des Echtbetriebs zurückgesetzt werden.</p>
  <p>Die nächste neue Wiegung erhält aktuell die Nummer <strong><?=h($nextTicketNumber)?></strong>.</p>
  <p class="muted"><strong>Wichtig:</strong> Bereits vorhandene Wiegescheine behalten ihre aktuelle Nummer. Dadurch können nach einem Reset Nummern mehrfach vorkommen, zum Beispiel einmal im Testbetrieb und einmal im späteren Echtbetrieb.</p>
  <form method="post" onsubmit="return confirm('Wiegeschein-Nummernkreis wirklich zurücksetzen?\n\nBestehende Wiegescheine behalten ihre Nummern. Die nächste neue Wiegung beginnt wieder bei 000001.');">
    <input type="hidden" name="section" value="wiegescheine">
    <input type="hidden" name="action" value="reset_ticket_numbers">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <button type="submit" class="button-danger">Wiegeschein-Nummernkreis zurücksetzen</button>
  </form>
</div>
<?php elseif($tab==='backup'): ?>
<div class="card"><h2>Automatische Backups</h2><p>Die Waagenbox kann die Datenbank automatisch lokal sichern. Optional kann das fertige Backup zusätzlich über <strong>rclone</strong> zu Google Drive übertragen werden.</p><form method="post"><input type="hidden" name="section" value="backup"><label class="setting-toggle"><input type="checkbox" name="backup_enabled" value="1" <?=$backupEnabled?'checked':''?>> <span>Automatische Backups aktiv</span></label><div class="form-grid" style="margin-top:16px"><div><label>Intervall</label><select name="backup_frequency"><option value="hourly" <?=$backupFrequency==='hourly'?'selected':''?>>Stündlich</option><option value="daily" <?=$backupFrequency==='daily'?'selected':''?>>Täglich</option><option value="weekly" <?=$backupFrequency==='weekly'?'selected':''?>>Wöchentlich</option></select></div><div><label>Uhrzeit</label><input type="time" name="backup_time" value="<?=h($backupTime)?>"></div><div><label>Wochentag bei wöchentlichem Backup</label><select name="backup_weekday"><?php foreach([1=>'Montag',2=>'Dienstag',3=>'Mittwoch',4=>'Donnerstag',5=>'Freitag',6=>'Samstag',7=>'Sonntag'] as $n=>$day): ?><option value="<?=$n?>" <?=$backupWeekday===$n?'selected':''?>><?=h($day)?></option><?php endforeach; ?></select></div><div><label>Aufbewahrung lokal (Anzahl)</label><input type="number" min="1" max="90" name="backup_retention" value="<?=h($backupRetention)?>"></div></div><h3>Google Drive</h3><label class="setting-toggle"><input type="checkbox" name="gdrive_enabled" value="1" <?=$gdriveEnabled?'checked':''?>> <span>Backups zusätzlich zu Google Drive übertragen</span></label><div class="form-grid" style="margin-top:16px"><div><label>rclone-Remote</label><input name="gdrive_remote" value="<?=h($gdriveRemote)?>" placeholder="z. B. gdrive"></div><div><label>Zielordner in Google Drive</label><input name="gdrive_path" value="<?=h($gdrivePath)?>" placeholder="Waagenbox-Backups"></div></div><p class="muted">Die einmalige Google-Drive-Anmeldung erfolgt separat per rclone auf dem Raspberry Pi. Danach verwendet die automatische Sicherung das hier eingetragene Remote.</p><p><button class="button primary">Backup-Einstellungen speichern</button></p></form></div>
<div class="card"><h2>Manuelles Backup</h2><p>Hier kannst du jederzeit ein vollständiges Datenbank-Backup als komprimierte SQL-Datei herunterladen.</p><p><button type="button" class="button primary" onclick="createManualBackup()">Backup jetzt erstellen</button></p><div id="backupCreateResult" class="update-result"></div></div>
<div class="card"><h2>Backup wiederherstellen</h2><p><strong>Achtung:</strong> Die Wiederherstellung ersetzt den aktuellen Datenbestand durch den Stand des ausgewählten Backups. Dieser Vorgang kann nicht rückgängig gemacht werden.</p><form id="restoreBackupForm" enctype="multipart/form-data"><label>Backupdatei (.sql oder .sql.gz)</label><input type="file" name="backup_file" accept=".sql,.gz,application/sql,application/gzip" required><label class="setting-toggle" style="margin-top:16px"><input type="checkbox" name="confirm_restore" value="1" required> <span>Ich möchte den aktuellen Datenbestand durch dieses Backup ersetzen.</span></label><p><button type="submit" class="button">Backup wiederherstellen</button></p></form><div id="backupRestoreResult" class="update-result"></div></div>
<div class="card"><h2>Letzte automatische Sicherung</h2><p><a class="button" href="api/backup_latest.php">Letztes automatisches Backup herunterladen</a></p><p><?= $lastBackup ? 'Zuletzt: '.h($lastBackup) : 'Noch keine automatische Sicherung durchgeführt.' ?></p><?php if($lastBackupFile): ?><p class="muted"><?=h($lastBackupFile)?></p><?php endif; ?><p class="muted">Die automatische Ausführung läuft unabhängig von einer geöffneten Weboberfläche.</p></div>
<?php elseif($tab==='kamera'): ?>
<div class="card"><h2>IP-Kamera</h2><p>Hier wird die Kamera für die Waagenbox eingerichtet. Die Stream-URL wird auf dem Dashboard angezeigt. Für automatische Bilder nach einer Wiegung wird zusätzlich eine direkte Schnappschuss-URL der Kamera benötigt.</p><form method="post"><input type="hidden" name="section" value="kamera"><label class="setting-toggle"><input type="checkbox" name="camera_enabled" value="1" <?=$cameraEnabled?'checked':''?>> <span>IP-Kamera aktiv</span></label><div class="form-grid" style="margin-top:16px"><div class="full"><label>Stream-URL</label><input type="url" name="camera_stream_url" value="<?=h($cameraStream)?>" placeholder="z. B. http://192.168.0.50/mjpeg"><small class="muted">Für die Anzeige im Browser, z. B. HTTP-MJPEG oder ein einzelnes JPEG. RTSP kann der Browser nicht direkt anzeigen.</small></div><div class="full"><label>Schnappschuss-URL</label><input type="url" name="camera_snapshot_url" value="<?=h($cameraSnapshot)?>" placeholder="z. B. http://192.168.0.50/snapshot.jpg"><small class="muted">Direkte URL, über die die Kamera ein aktuelles JPEG-Bild liefert.</small></div></div><h3 style="margin-top:24px">Wiegungsbilder</h3><label class="setting-toggle"><input type="checkbox" name="camera_snapshot_enabled" value="1" <?=$cameraSnapshotEnabled?'checked':''?>> <span>Nach jeder erfolgreichen Wiegung automatisch einen Schnappschuss speichern</span></label><p class="muted">Das Bild wird der Wiegung zugeordnet und in der Wiegungsübersicht angezeigt. Es wird ausdrücklich nicht in den PDF-Wiegeschein übernommen.</p><p><button class="button primary">Kamera-Einstellungen speichern</button></p></form></div>
<?php elseif($tab==='feldmanager'): ?>
<div class="card">
  <h2>Feldmanager-Verknüpfung</h2>
  <p>Wenn diese Funktion aktiv ist, übernimmt eine Fernbedienungswiegung automatisch den aktuell laufenden Schlag des Feldmanager-Teams, das der jeweiligen Fernbedienung zugeordnet ist.</p>
  <form method="post">
    <input type="hidden" name="section" value="feldmanager">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <label class="setting-toggle"><input type="checkbox" name="feldmanager_enabled" value="1" <?=$feldmanagerEnabled?'checked':''?>> <span>Automatische Schlagzuordnung über Feldmanager aktiv</span></label>
    <div class="form-grid" style="margin-top:16px">
      <div class="full"><label>Feldmanager-Prototyp-Adresse</label><input type="url" name="feldmanager_base_url" value="<?=h($feldmanagerBase)?>" placeholder="https://remote.ajp-bg.de/prototyp/public"></div>
      <div class="full"><label>API-Token</label><input type="password" name="feldmanager_api_token" autocomplete="new-password" value="" placeholder="<?=$feldmanagerTokenConfigured?'Token gespeichert – leer lassen zum Beibehalten':'Token eintragen'?>"></div>
    </div>
    <p><button class="button primary">Feldmanager-Einstellungen speichern</button> <a class="button" href="settings.php?tab=feldmanager">Status neu laden</a></p>
  </form>
</div>

<div class="card">
  <h2>Aktueller Automatik-Status</h2>
  <?php if(!$feldmanagerEnabled): ?>
    <p><strong>Automatische Schlagzuordnung ist deaktiviert.</strong></p>
  <?php elseif(empty($feldmanagerTeamsResponse['ok'])): ?>
    <div class="flash error">Feldmanager-Teams konnten nicht geladen werden: <?=h((string)($feldmanagerTeamsResponse['message']??$feldmanagerTeamsResponse['error']??'Unbekannter Fehler'))?></div>
  <?php else: ?>
    <p><strong>Verbindung zum Feldmanager hergestellt.</strong> Die Team-Zuordnung wird unter <em>Fernbedienungen → Zuordnungen</em> gepflegt.</p>
    <?php $teamNames=[]; foreach($feldmanagerTeams as $t){$teamNames[(int)($t['id']??0)]=(string)($t['name']??'');} ?>
    <table>
      <tr><th>Fernbedienung</th><th>Fahrzeug</th><th>Feldmanager-Team</th></tr>
      <?php foreach($feldmanagerRemoteRows as $rr): $rid=(int)$rr['id']; $tid=(int)($feldmanagerRemoteTeams[$rid]??0); ?>
        <tr>
          <td><?=h((string)($rr['name']?:$rr['code']))?> <small>#<?=h((string)$rr['code'])?></small></td>
          <td><?=h(trim((string)($rr['plate']??'').' – '.(string)($rr['vehicle_name']??''),' –'))?></td>
          <td><?=$tid>0?h($teamNames[$tid]??('Team #'.$tid.' – nicht aktiv/nicht gefunden')):'–'?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
<?php elseif($tab==='telegram'): ?>
<div class="card">
  <h2>Telegram-Benachrichtigungen</h2>
  <p>Die Waagenbox kann bei einer Störung der Verbindung <strong>Waagenbox → Feldmanager</strong> direkt eine Telegram-Nachricht senden. Die Meldung funktioniert unabhängig davon, ob der Feldmanager selbst noch erreichbar ist.</p>
  <form method="post">
    <input type="hidden" name="section" value="telegram">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <label class="setting-toggle"><input type="checkbox" name="telegram_enabled" value="1" <?=$telegramEnabled?'checked':''?>> <span>Telegram-Benachrichtigungen aktiv</span></label>
    <div class="form-grid" style="margin-top:16px">
      <div class="full"><label>Bot-Token</label><input type="password" name="telegram_bot_token" autocomplete="new-password" value="" placeholder="<?=$telegramTokenConfigured?'Token gespeichert – leer lassen zum Beibehalten':'Bot-Token eintragen'?>"></div>
      <div class="full"><label>Chat-ID</label><input name="telegram_chat_id" value="<?=h($telegramChatId)?>" placeholder="z. B. 123456789"></div>
    </div>
    <p class="muted">Bei einem Zustandswechsel wird genau eine Störungsmeldung beziehungsweise eine Entwarnung gesendet. Wiederholte Prüfungen erzeugen keine Nachrichtenflut.</p>
    <p class="button-row">
      <button class="button primary" type="submit" name="action" value="save">Telegram-Einstellungen speichern</button>
      <button class="button" type="submit" name="action" value="test">Testnachricht senden</button>
    </p>
  </form>
</div>
<?php elseif($tab==='grossanzeige'): ?>
<div class="card">
  <h2>Großanzeige</h2>
  <p>Hier wird die Verbindung zu einer separaten AJP Großanzeige vorbereitet. Die Großanzeige liest den Waagenstatus später selbstständig über eine geschützte HTTP/JSON-Schnittstelle. Ein Ausfall der Großanzeige darf die Wägefunktion nicht beeinflussen.</p>
  <form method="post">
    <input type="hidden" name="section" value="grossanzeige">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <label class="setting-toggle"><input type="checkbox" name="grossanzeige_enabled" value="1" <?=$grossanzeigeEnabled?'checked':''?>> <span>Großanzeigen-Schnittstelle aktiv</span></label>
    <div class="form-grid" style="margin-top:16px">
      <div class="full">
        <label>IP-Adresse / Hostname der Großanzeige</label>
        <input name="grossanzeige_address" value="<?=h($grossanzeigeAddress)?>" placeholder="z. B. grossanzeige.local oder 192.168.55.90">
        <small class="muted">Diese Adresse ist für Diagnose und spätere Verbindungstests vorgesehen. Die eigentlichen Statusdaten werden von der Großanzeige bei der Waagenbox abgefragt; deshalb bleibt die Waagenbox auch bei einem Ausfall der Anzeige unabhängig funktionsfähig.</small>
      </div>
    </div>
    <h3 style="margin-top:22px">Anzeigezeiten</h3>
    <p class="muted">Hier legst du fest, wie lange die einzelnen Phasen nach einer Überfahrt auf der Großanzeige sichtbar bleiben.</p>
    <div class="form-grid">
      <div>
        <label>1. Gewicht – Verarbeitung (Sekunden)</label>
        <input type="number" min="1" max="120" name="grossanzeige_first_processing_seconds" value="<?=h((string)$grossanzeigeFirstProcessingSeconds)?>">
      </div>
      <div>
        <label>2. Gewicht – Verarbeitung (Sekunden)</label>
        <input type="number" min="1" max="120" name="grossanzeige_complete_processing_seconds" value="<?=h((string)$grossanzeigeCompleteProcessingSeconds)?>">
      </div>
      <div>
        <label>Nettogewicht / Abschluss (Sekunden)</label>
        <input type="number" min="1" max="120" name="grossanzeige_success_seconds" value="<?=h((string)$grossanzeigeSuccessSeconds)?>">
      </div>
    </div>
    <p><button class="button primary" type="submit" name="action" value="save">Großanzeigen-Einstellungen speichern</button></p>
  </form>
</div>

<div class="card">
  <h2>Großanzeige ein-/ausschalten</h2>
  <p class="muted">Hier kannst du die Anzeige direkt von der Waagenbox aus aktivieren oder deaktivieren. Die Verbindung bleibt dabei bestehen, damit sie jederzeit wieder eingeschaltet werden kann.</p>
  <form method="post">
    <input type="hidden" name="section" value="grossanzeige">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <label class="setting-toggle"><input type="checkbox" name="grossanzeige_display_enabled" value="1" <?=$grossanzeigeDisplayEnabled?'checked':''?>> <span>Großanzeige aktiviert</span></label>
    <p><button class="button primary" type="submit" name="action" value="display_toggle">Zustand speichern</button></p>
  </form>
</div>

<div class="card">
  <h2>Direktzugriff</h2>
  <?php if($grossanzeigeBaseUrl!==''): ?>
    <p class="muted">Die Links werden automatisch aus der oben eingetragenen IP-Adresse bzw. dem Hostnamen erzeugt.</p>
    <p class="button-row">
      <a class="button primary" href="<?=h($grossanzeigeAdminUrl)?>" target="_blank" rel="noopener">Administration der Großanzeige öffnen</a>
      <a class="button" href="<?=h($grossanzeigeDisplayUrl)?>" target="_blank" rel="noopener">Großanzeige öffnen</a>
    </p>
  <?php else: ?>
    <p class="muted">Bitte zuerst oben die IP-Adresse oder den Hostnamen der Großanzeige eintragen und speichern.</p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>API-Token</h2>
  <p>Der Token authentifiziert ausschließlich die lokale Großanzeigen-Schnittstelle. Beim Erzeugen wird der bisherige Token sofort ungültig.</p>
  <?php if($grossanzeigeGeneratedToken!==''): ?>
    <div class="flash" style="word-break:break-all">
      <strong>Neuer Token – wird nur dieses eine Mal angezeigt:</strong><br>
      <code id="grossanzeigeGeneratedToken"><?=h($grossanzeigeGeneratedToken)?></code>
    </div>
    <p><button type="button" class="button" onclick="navigator.clipboard?.writeText(document.getElementById('grossanzeigeGeneratedToken').textContent)">Token kopieren</button></p>
  <?php elseif($grossanzeigeTokenConfigured): ?>
    <p><strong>Token ist eingerichtet.</strong><?php if($grossanzeigeTokenCreatedAt!==''): ?> Erzeugt am <?=h($grossanzeigeTokenCreatedAt)?>.<?php endif; ?></p>
    <p class="muted">Der vorhandene Token kann aus Sicherheitsgründen nicht erneut angezeigt werden. Falls er verloren gegangen ist, bitte einen neuen erzeugen.</p>
  <?php else: ?>
    <p><strong>Noch kein Großanzeigen-Token eingerichtet.</strong></p>
  <?php endif; ?>
  <form method="post" onsubmit="return confirm('Neuen Großanzeigen-Token erzeugen? Ein eventuell vorhandener Token wird dadurch sofort ungültig.');">
    <input type="hidden" name="section" value="grossanzeige">
    <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
    <button class="button" type="submit" name="action" value="generate_token"><?=$grossanzeigeTokenConfigured?'Neuen Token erzeugen':'Token erzeugen'?></button>
  </form>
</div>
<?php elseif($tab==='zugang'): ?>
<div class="card"><h2>Netzwerk-Zugang schützen</h2><p>Auf dem Raspberry wird der Zugriff über das Netzwerk mit einem Passwort geschützt. Der direkte Zugriff über <strong>localhost</strong> bleibt ohne Passwort. Die mobile QR-Fernbedienung bleibt ebenfalls ohne Passwort und wird ausschließlich über ihren QR-Token geschützt.</p><?php if(defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT): ?><p class="muted">Web-Entwicklung: Das Zugangspasswort wird hier nur für die aktuelle Testsitzung gespeichert und nicht in der gemeinsamen Datenbank. Der Raspberry-Betrieb bleibt dadurch unverändert.</p><?php endif; ?><p><a class="button" href="change_access_password.php">Passwort ändern</a> <a class="button" href="logout.php">Abmelden</a></p></div>
<?php elseif($tab==='updates'): ?>
<div class="card"><h2>Software-Updates</h2><p>Die Waagenbox kann regelmäßig prüfen, ob auf dem zentralen Update-Server eine neue Version bereitsteht. Updates werden nur über HTTPS geladen und vor der Installation per SHA-256-Prüfsumme geprüft.</p><form method="post"><input type="hidden" name="section" value="updates"><div class="form-grid"><div><label for="update_channel">Update-Kanal</label><select id="update_channel" name="update_channel"><option value="release" <?=$updateChannel==='release'?'selected':''?>>Freigegebene Versionen</option><option value="staging" <?=$updateChannel==='staging'?'selected':''?>>Testversionen (Staging)</option></select><small class="muted">Staging ist für diese Waagenbox gedacht, um von dir getestete Versionen direkt zu prüfen.</small></div><div><label for="update_server_url">Update-Server</label><input id="update_server_url" name="update_server_url" value="<?=h($updateUrl)?>" placeholder="https://update.ajp-bg.de/release"><small class="muted">Bei den offiziellen AJP-Servern wird der Pfad automatisch an den gewählten Kanal angepasst.</small></div></div><div class="form-grid" style="margin-top:16px"><div class="full"><label for="rollback_email">E-Mail-Adresse für Rückmeldungen bei einem Rollback</label><input id="rollback_email" type="email" name="rollback_email" value="<?=h($rollbackEmail)?>" placeholder="z. B. name@firma.de"><small class="muted">Nach einem manuellen Rollback auf dem Raspberry wird eine Fehlerbeschreibung an diese Adresse gesendet. Die E-Mail wird vom Raspberry aus versendet.</small></div></div><p class="muted">Unter dieser Adresse erwartet die Waagenbox eine <code>manifest.json</code> mit Versionsnummer, Download-Adresse und SHA-256-Prüfsumme.</p><p class="button-row"><button class="button primary">Speichern</button><button type="button" class="button" onclick="checkUpdate(true)">Jetzt nach Update suchen</button></p></form><p class="muted" id="updateLastCheck">Letzte Prüfung: <?= $lastUpdateCheck ? h($lastUpdateCheck) : 'noch nicht durchgeführt' ?></p><div id="updateSettingsResult" class="update-result"></div></div>
<?php if($tab==='updates' && !(defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT)): ?>
<div class="card" style="margin-top:20px"><h2>Zur vorherigen Version zurückkehren</h2><?php if($rollbackInfo): ?><p>Für die zuletzt installierte Version <strong><?=h($rollbackInfo['previous_version'])?></strong> ist eine vollständige Sicherheitskopie von <strong><?=h($rollbackInfo['created_at'] ?? '')?></strong> vorhanden.</p><p class="muted">Beim Rollback werden Programmdateien und Datenbank auf diesen Stand zurückgesetzt.</p><p><button type="button" class="button" id="rollbackButton">Zur vorherigen Version zurückkehren</button></p><div id="rollbackResult" class="update-result"></div><?php else: ?><p>Derzeit ist keine vorherige Version für einen manuellen Rollback gespeichert. Eine Sicherheitskopie wird automatisch vor dem nächsten Update angelegt.</p><?php endif; ?></div>
<?php endif; ?>
<?php if($tab==='updates' && defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT): ?><div class="card" style="margin-top:20px"><h2>Raspberry-Testversion veröffentlichen</h2><p>Die aktuell getestete Web-Version wird als vollständiges Raspberry-Update-Paket in den Staging-Bereich übertragen. Das Paket enthält <strong>keinen</strong> Veröffentlichungs-Button für den Raspberry.</p><p><button type="button" class="button primary" id="publishStagingButton" onclick="publishStagingVersion()">Getestete Version zum Raspberry übertragen</button></p><div id="publishStagingResult" class="update-result"></div></div><?php endif; ?>
<?php endif; ?>
<script>async function checkUpdate(force=false){const out=document.getElementById('updateSettingsResult');const last=document.getElementById('updateLastCheck');if(out)out.innerHTML='<span>Update wird geprüft …</span>';try{const r=await fetch('api/update_check.php'+(force?'?force=1':''),{cache:'no-store'});const d=await r.json();if(last&&d.checked_at)last.textContent='Letzte Prüfung: '+d.checked_at;if(!out)return;if(d.update_available&&!d.ignored&&!d.snoozed){const hide=d.mandatory?'':'<button type="button" class="button" id="settingsIgnoreUpdate">Diese Version ausblenden</button>';const install=(<?= (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) ? 'false' : 'true' ?>)?'<button type="button" class="button primary" id="settingsInstallUpdate">Update jetzt installieren</button>':'';out.innerHTML='<div class="software-update-inline"><strong>Update verfügbar: Version '+escapeHtml(d.version)+'</strong><span>'+escapeHtml(d.message||'Eine neue Version der Waagenbox ist verfügbar.')+'</span><div class="software-update-actions">'+(install?'':'<span class="muted">Installation erfolgt auf dem Raspberry Pi.</span>')+install+'<button type="button" class="button" id="settingsLaterUpdate">Später</button>'+hide+'</div></div>';const installBtn=document.getElementById('settingsInstallUpdate');if(installBtn)installBtn.onclick=installSoftwareUpdateFromSettings;document.getElementById('settingsLaterUpdate').onclick=async()=>{await fetch('api/update_snooze.php',{method:'POST',headers:csrfHeaders()});out.innerHTML='<span>Update wurde für 24 Stunden zurückgestellt.</span>';};const ig=document.getElementById('settingsIgnoreUpdate');if(ig)ig.onclick=async()=>{await fetch('api/update_ignore.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',...csrfHeaders()},body:'version='+encodeURIComponent(d.version)});out.innerHTML='<span>Version '+escapeHtml(d.version)+' wurde ausgeblendet.</span>';};}else if(d.ok){out.innerHTML='<span>Die Waagenbox ist aktuell.</span>';}else{out.innerHTML='<span>Update-Prüfung fehlgeschlagen: '+escapeHtml(d.message||'')+'</span>';}}catch(e){if(out)out.innerHTML='<span>Update-Prüfung fehlgeschlagen.</span>';}}
function escapeHtml(v){const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML;}
async function installSoftwareUpdateFromSettings(){const out=document.getElementById('updateSettingsResult');if(out)out.innerHTML='<strong>Update wird installiert …</strong><span>Bitte die Waagenbox währenddessen nicht ausschalten.</span>';try{const r=await fetch('api/update_install.php',{method:'POST',headers:csrfHeaders(),cache:'no-store'});const d=await r.json();if(!d.ok){if(out)out.innerHTML='<strong>Update fehlgeschlagen</strong><span>'+escapeHtml(d.message||'Unbekannter Fehler')+'</span>';return;}if(out)out.innerHTML='<strong>Update erfolgreich installiert.</strong><span>Die neue Version wird jetzt geladen.</span>';setTimeout(()=>{window.location.href='index.php?updated=1';},1800);}catch(e){if(out)out.innerHTML='<strong>Update fehlgeschlagen</strong><span>Keine Antwort vom Update-Prozess.</span>';}}
async function createManualBackup(){const out=document.getElementById('backupCreateResult');if(out)out.innerHTML='<span>Backup wird erstellt …</span>';try{const r=await fetch('api/backup_create.php',{cache:'no-store'});if(!r.ok)throw new Error('Backup konnte nicht erstellt werden.');const blob=await r.blob();const cd=r.headers.get('Content-Disposition')||'';const m=cd.match(/filename="?([^";]+)"?/i);const name=m?m[1]:'waagenbox_backup.sql';const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);if(out)out.innerHTML='<span>Backup wurde erstellt und heruntergeladen.</span>';}catch(e){if(out)out.innerHTML='<span>Backup fehlgeschlagen: '+escapeHtml(e.message||'Unbekannter Fehler')+'</span>';}}
document.getElementById('restoreBackupForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!confirm('Soll der aktuelle Datenbestand wirklich durch das ausgewählte Backup ersetzt werden?'))return;const out=document.getElementById('backupRestoreResult');const form=e.currentTarget;if(out)out.innerHTML='<span>Backup wird wiederhergestellt …</span>';try{const r=await fetch('api/backup_restore.php',{method:'POST',body:new FormData(form)});const d=await r.json();if(!d.ok)throw new Error(d.message||'Wiederherstellung fehlgeschlagen.');if(out)out.innerHTML='<span>'+escapeHtml(d.message||'Wiederherstellung erfolgreich.')+'</span>';setTimeout(()=>location.reload(),1800);}catch(err){if(out)out.innerHTML='<span>Wiederherstellung fehlgeschlagen: '+escapeHtml(err.message||'Unbekannter Fehler')+'</span>';}});
async function publishStagingVersion(){
 const out=document.getElementById('publishStagingResult'); const b=document.getElementById('publishStagingButton');
 if(!confirm('Soll die aktuell getestete Web-Version wirklich für den Raspberry-Test veröffentlicht werden?')) return;
 if(b)b.disabled=true; if(out)out.innerHTML='<span>Version wird zusammengestellt und übertragen …</span>';
 try{const r=await fetch('api/publish_staging.php',{method:'POST',cache:'no-store'});const d=await r.json();if(!d.ok)throw new Error(d.message||'Veröffentlichung fehlgeschlagen.');if(out)out.innerHTML='<strong>Erfolgreich veröffentlicht.</strong><span>Version '+escapeHtml(d.version)+' wurde in den Raspberry-Staging-Bereich übertragen.</span>';}catch(e){if(out)out.innerHTML='<span>Veröffentlichung fehlgeschlagen: '+escapeHtml(e.message||'Unbekannter Fehler')+'</span>';}finally{if(b)b.disabled=false;}}
async function rollbackPreviousVersion(){
 const reason=window.prompt('Warum soll auf die vorherige Version zurückgewechselt werden?\n\nBitte möglichst genau beschreiben, was mit der neuen Version nicht funktioniert.');
 if(reason===null)return; const text=reason.trim();
 if(!text){alert('Bitte eine Fehlerbeschreibung oder einen Grund eingeben.');return;}
 if(!confirm('Die Waagenbox wird auf die vorherige Version zurückgesetzt. Die aktuelle Version und ihre Datenbankänderungen werden dabei verworfen. Wirklich fortfahren?'))return;
 const out=document.getElementById('rollbackResult'), b=document.getElementById('rollbackButton'); if(b)b.disabled=true; if(out)out.innerHTML='<span>Rollback wird durchgeführt … Bitte die Waagenbox nicht ausschalten.</span>';
 try{const r=await fetch('api/update_rollback.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',...csrfHeaders()},body:'reason='+encodeURIComponent(text),cache:'no-store'}); const d=await r.json(); if(!d.ok)throw new Error(d.message||'Rollback fehlgeschlagen.'); if(out)out.innerHTML='<strong>Rollback erfolgreich.</strong><span>Die Waagenbox wurde auf Version '+escapeHtml(d.version)+' zurückgesetzt.'+(d.email_sent?' Die Fehlerbeschreibung wurde per E-Mail versendet.':' Die E-Mail konnte nicht versendet werden.')+'</span>'; setTimeout(()=>location.href='index.php?rolledback=1',1800);}catch(e){if(out)out.innerHTML='<span>Rollback fehlgeschlagen: '+escapeHtml(e.message||'Unbekannter Fehler')+'</span>';}finally{if(b)b.disabled=false;}
}
document.getElementById('rollbackButton')?.addEventListener('click',rollbackPreviousVersion);
function useCurrentLocation(){const out=document.getElementById('gps_status');if(!navigator.geolocation){out.textContent='Dieses Gerät unterstützt keine Standortabfrage.';return;}out.textContent='Standort wird ermittelt …';navigator.geolocation.getCurrentPosition(p=>{document.getElementById('gps_lat').value=p.coords.latitude.toFixed(7);document.getElementById('gps_lon').value=p.coords.longitude.toFixed(7);out.textContent='Standort übernommen. Genauigkeit: ca. '+Math.round(p.coords.accuracy)+' m';},e=>{out.textContent='Standort konnte nicht ermittelt werden: '+e.message;},{enableHighAccuracy:true,timeout:10000,maximumAge:0});}
document.getElementById('demoMode')?.addEventListener('change',function(){const c=document.getElementById('demoConfirm');if(this.checked){if(!confirm('Demo-Modus aktivieren? Testgewicht wird angezeigt und die Waagencomputer-Anbindung wird automatisch deaktiviert.')){this.checked=false;return;}c.value='1';}else{c.value='';}});</script>
<?php layoutEnd(); ?>

