# AJP Waagenbox – Release 1.2.39

Stand: 2026-09-25

## Status

Release-Kandidat nach praktischer Abnahme auf der separaten Testinstanz. Noch nicht produktiv veröffentlicht oder installiert.

## Basis

- produktiv freigegebener Ausgangspunkt: `release/1.2.38`
- Entwicklungsbranch: `feature/1.2.39-grossanzeige`
- Zielversion: `1.2.39`
- Produktivpfad `/var/www/waage` blieb während der Entwicklung unverändert
- Test-Webpfad: `/var/www/waage-test`
- Test-Worktree: `/home/pi/Waagenbox-test`

## Hauptänderungen

### Einheitlicher Wägeablauf mit mehreren offenen Fahrzeugwiegungen

Die Waagenbox trennt jetzt die aktuell physisch laufende Überfahrt von dauerhaft offenen Fahrzeugwiegungen.

- `weighing_state` enthält nur die aktuell laufende Überfahrt auf der Waage.
- `open_vehicle_weighings` speichert offene erste Überfahrten fahrzeugbezogen.
- Mehrere Fahrzeuge können gleichzeitig eine offene erste Überfahrt besitzen.
- Pro Fahrzeug ist höchstens eine offene Wiegung möglich.
- Andere Fahrzeuge können gewogen werden, während ein Fahrzeug zum Laden/Entladen unterwegs ist.
- Das erste gemessene Gewicht ist chronologisch die erste Überfahrt und nicht automatisch das Leergewicht.
- Nach der zweiten Überfahrt gilt:
  - Tara = kleineres der beiden Gewichte;
  - Brutto = größeres der beiden Gewichte;
  - Netto = Brutto minus Tara.
- Bei einem Stammfahrzeug mit bereits gespeichertem Leergewicht genügt weiterhin eine aktuelle Überfahrt.
- Temporär angelegte externe Fahrzeuge verwenden bewusst kein dauerhaft gespeichertes Leergewicht.

Datenbankmigration:

- `migration_v1_2_39_open_vehicle_weighings.sql`
- `migration_v1_2_39_manual_external.sql`

### Manuelle externe Fahrzeuge

Für externe, nicht dauerhaft angelegte Fahrzeuge kann in der manuellen Wiegung eine Bezeichnung bzw. ein Kennzeichen eingetragen werden.

- temporäre Fahrzeuge sind als `manual_external` markiert;
- sie erscheinen nicht in der normalen Fahrzeugübersicht;
- sie bekommen kein dauerhaftes Leergewicht;
- eine zweite Überfahrt kann über dieselbe Bezeichnung wieder zugeordnet werden.

### QR-/Mobile-Wiegung auf einheitlichen Ablauf umgestellt

QR-Wiegungen verwenden denselben Wägekern wie manuelle Wiegungen.

- Start über `startVehiclePass()`;
- erste Überfahrt wird fahrzeugbezogen offen gespeichert;
- zweite Überfahrt bzw. Wiegung mit gespeichertem Leergewicht wird über denselben Abschlussweg beendet;
- QR-Status unterscheidet erste und zweite Überfahrt;
- die mobile Oberfläche verwendet einen einheitlichen Startablauf.

### Schutz vor QR-/Web-Doppelabschluss

Die geöffnete manuelle Wiegeseite beendet nur noch manuell gestartete Überfahrten automatisch.

QR-/Mobile-Wiegungen werden ausschließlich über den mobilen Abschluss-Endpunkt beendet. Dadurch entsteht nach einer bereits erfolgreich gespeicherten QR-Wiegung nicht mehr die irreführende Fehlermeldung:

`Es ist keine laufende Wiegung vorhanden.`

Regressionstest:

- `tests/qr_web_double_complete_regression_test.php`

### Großanzeigen-Schnittstelle

Die Waagenbox stellt eine token-geschützte JSON-Schnittstelle für eine separate AJP Großanzeige bereit:

- `api/grossanzeige_status.php`

Die Großanzeige ist nur ein Ausgabegerät. Ein Ausfall darf die Wägefunktion nicht blockieren.

Übertragen werden unter anderem:

- semantischer Anzeigezustand;
- Anzeigegewicht;
- Gewichtsart-Schlüssel;
- Status für Aktivierung/Deaktivierung der Anzeige.

Gewichtsarten:

- Erstgewicht;
- Zweitgewicht;
- Bruttogewicht;
- Netto Gewicht.

Beim Zustand `drive_on` wird bewusst noch keine Gewichtsart übertragen. Die Gewichtsart erscheint erst, wenn ein tatsächliches Gewicht verarbeitet wird.

### Einstellbare Anzeigezeiten

Unter **Einstellungen → Großanzeige** sind getrennt konfigurierbar:

- Verarbeitung 1. Gewicht;
- Verarbeitung 2. Gewicht;
- Anzeige Netto/Abschluss.

### Großanzeige von der Waagenbox aus verwalten

Unter **Einstellungen → Großanzeige** stehen zusätzlich zur Verfügung:

- Großanzeige aktivieren/deaktivieren;
- dynamischer Link zur Administrationsseite der Großanzeige;
- dynamischer Link direkt zur Displayseite.

Die Links werden aus der gespeicherten IP-Adresse bzw. dem Hostnamen erzeugt. Ein Standortwechsel erfordert deshalb keine Quellcodeänderung.

### Dashboard-Verbindungsstatus zur Großanzeige

Unter dem Waagenstatus zeigt das Dashboard zusätzlich:

`Waagenbox → Großanzeige`

Mögliche Zustände:

- Verbunden;
- Nicht erreichbar;
- Nicht konfiguriert;
- Aus.

Praktisch geprüft wurde insbesondere:

- Großanzeigen-Raspberry neu gestartet;
- Status wechselte auf `Nicht erreichbar`;
- nach abgeschlossenem Boot automatisch wieder auf `Verbunden`;
- HDMI-Anzeige startete danach selbstständig wieder.

## Separate AJP Großanzeige

Das eigenständige Displayprojekt befindet sich in:

`t0Puk/Grossfeldanzeige_Waagenbox`

Praktisch getestet:

- Raspberry Pi 2 / Debian 13 Trixie;
- nginx + Flask;
- Cog/WPE über DRM auf HDMI;
- automatischer Start nach Reboot;
- Liveanbindung an die Waagenbox;
- Offline-Anzeige;
- Testbetrieb;
- einstellbare Anzeigezustände;
- editierbare Gewichtsbezeichnungen und Schriftgrößen;
- Passwortschutz der Administration;
- 15-Minuten-Inaktivitätslogout;
- Neustart/Herunterfahren aus der Administration;
- Konfigurationsbackup erstellen, herunterladen und wiederherstellen;
- Aktivieren/Deaktivieren durch die Waagenbox.

Die Großanzeigen-Software selbst ist ein separates Repository und nicht Bestandteil des Waagenbox-Update-ZIP.

## Praktische Abnahme 25.09.2026

Erfolgreich auf der Testinstanz geprüft:

- manuelle Wiegungen;
- QR-Code-Wiegungen;
- erste und zweite Überfahrt;
- Rückkehr in Standby;
- Nettoanzeige;
- Fahrzeug mit gespeichertem Leergewicht;
- parallele/offene fahrzeugbezogene Erstwiegungen;
- temporäres externes Fahrzeug ohne Persistieren eines Leergewichts;
- keine erneute falsche QR-Doppelabschlussmeldung;
- Großanzeigen-Livebetrieb;
- Erstgewicht/Zweitgewicht/Netto Gewicht auf der Großanzeige;
- Gewichtsart beim Auffahren noch ausgeblendet;
- editierbare Texte und Schriftgrößen;
- Großanzeige nach Neustart wieder in Standby;
- Großanzeigen-Verbindungsstatus auf dem Waagenbox-Dashboard;
- Fernaktivierung/-deaktivierung der Großanzeige;
- dynamische Direktlinks;
- Erreichbarkeitsstatus bei Reboot korrekt.

## Produktionsschutz

- keine direkte Änderung an `/var/www/waage`;
- keine produktiven Daten verändert;
- privater Release-Schlüssel bleibt ausschließlich auf dem lokalen Windows-Rechner;
- Release-Artefakte werden erst nach vollständiger Regression und Release-Preflight erzeugt;
- Produktivinstallation erfolgt ausschließlich über die normale signierte Update-Funktion.

## Vor Release-Freeze noch auszuführen

1. PHP-Syntax aller geänderten PHP-Dateien.
2. `tests/release_1_2_39_test.php`.
3. `tests/qr_web_double_complete_regression_test.php`.
4. vorhandene Release-/Sicherheitsregression.
5. Python-Syntax der betroffenen Python-Komponenten.
6. `git diff --check`.
7. `tools/release_preflight.py`.
8. Migrationen in der Testdatenbank bestätigt lassen.
9. getesteten Source-Commit festlegen.
10. unveränderlichen Branch `release/1.2.39` erst nach erfolgreicher Prüfung erstellen.
11. signiertes Updatepaket aus exakt diesem Commit bauen.
12. ZIP-Pfade, SHA-256 und Signatur vor Veröffentlichung erneut prüfen.
