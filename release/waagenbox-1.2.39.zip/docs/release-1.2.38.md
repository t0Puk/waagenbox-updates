# AJP Waagenbox – Entwicklung 1.2.38

Stand: 2026-09-23

## Ziel

Optionale Verknüpfung der Waagenbox mit dem Feldmanager-Testsystem.

Wenn im Feldmanager genau ein Schlag aktiv ist, kann eine neu gestartete Wiegung automatisch diesem Schlag zugeordnet werden.

## Basis

- produktiv abgenommener Ausgangspunkt: `release/1.2.37`
- Source-Commit: `f895c6cb75eeb9147a6baf81c6bfcf7d96c38022`
- Entwicklungsbranch: `feature/1.2.38-feldmanager-link`
- produktiver 1.2.37-Stand bleibt unverändert

## Funktionsweise

Unter `Einstellungen → Feldmanager` kann die Verknüpfung vollständig aktiviert oder deaktiviert werden.

Konfigurierbar sind:

- Feldmanager-Basis-URL;
- API-Token;
- eine Team-Nummer für die Zuordnung;
- feste Zuordnung Feldmanager-Schlag-ID → lokaler Waagenbox-Schlag.

Ohne feste Zuordnung wird versucht, einen aktiven Waagenbox-Schlag mit exakt gleichem Namen eindeutig zu finden.

## Wägeablauf

Beim Start einer neuen normalen Wiegung wird der Feldmanager abgefragt.

- genau ein aktiver und zugeordneter Feldmanager-Schlag: dieser lokale Schlag überschreibt die bisherige Schlagzuordnung der neuen Wiegung;
- kein aktiver Schlag: bestehende manuelle/Fernbedienungs-Zuordnung bleibt bestehen;
- Feldmanager nicht erreichbar: bestehende Zuordnung bleibt bestehen;
- aktiver Schlag nicht zugeordnet: bestehende Zuordnung bleibt bestehen;
- mehrere aktive Schläge ohne eindeutigen Fahrerfilter: bestehende Zuordnung bleibt bestehen und der Status wird als mehrdeutig angezeigt.

Die Waagenbox bleibt dadurch auch ohne Feldmanager funktionsfähig.

## Sicherheit

- Verbindung ausschließlich über HTTPS;
- API-Token wird serverseitig gesendet und nicht in URLs eingebaut;
- Token wird im Einstellungsformular nach dem Speichern nicht wieder ausgegeben;
- Einstellungen sind admin- und CSRF-geschützt;
- keine Datenbankmigration erforderlich;
- keine Änderungen am produktiven Pfad im Entwicklungsstand.

## Feldmanager-Gegenstelle

Der Feldmanager-Testbranch ist:

`feature/0.1.25-waagenbox-link`

API-Endpunkte:

- `api/waagenbox_active_field.php`
- `api/waagenbox_fields.php`

Die Feldmanager-API ist dort standardmäßig deaktiviert und wird pro Installation über `config.local.php` freigeschaltet.

## Testplan

1. Feldmanager-Prototyp mit 0.1.25-Branch bereitstellen.
2. nur in der Prototyp-`config.local.php` API aktivieren und einen langen zufälligen Token setzen.
3. Waagenbox-Testinstanz auf 1.2.38-Branch aktualisieren.
4. unter `Einstellungen → Feldmanager` Prototyp-URL und denselben Token eintragen.
5. Schlagzuordnungen kontrollieren.
6. automatische Zuordnung aktivieren.
7. im Feldmanager einen Schlag starten.
8. Waagenbox-Status muss Auftrag, Fahrer, aktiven Feldmanager-Schlag und lokalen Waagenbox-Schlag anzeigen.
9. Testwiegung durchführen und kontrollieren, dass sie dem aktiven Schlag zugeordnet wurde.
10. Schlag im Feldmanager abschließen, nächsten starten und zweite Testwiegung durchführen.
11. Automatik deaktivieren und prüfen, dass wieder die normale Waagenbox-Zuordnung verwendet wird.
12. Fehlerfälle prüfen: kein aktiver Schlag, API nicht erreichbar, falsches Token, mehrere aktive Schläge.


## Feldmanager-Healthcheck

Die Waagenbox stellt zusätzlich einen token-geschützten Status-Endpunkt bereit:

- `api/feldmanager_status.php`

Der Feldmanager kann damit prüfen:

- ob die Waagenbox erreichbar ist;
- ob die Feldmanager-Automatik in der Waagenbox tatsächlich aktiviert ist;
- welche Team-Nummer in der Waagenbox eingestellt ist.

Damit können Telegram-Störmeldungen im Feldmanager so gesteuert werden, dass ein Verbindungsalarm nur dann ausgelöst wird, wenn die Waagenbox bei der letzten erfolgreichen Prüfung ihre Feldmanager-Automatik als aktiv gemeldet hat.
