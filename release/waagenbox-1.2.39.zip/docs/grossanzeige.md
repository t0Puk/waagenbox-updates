# Großanzeigen-Anbindung – Entwicklungsstand 1.2.39

Branch: `feature/1.2.39-grossanzeige`
Ausgangsbasis: `release/1.2.38`

## Ziel
Die bestehende AJP Waagenbox bleibt das führende System. Eine separate AJP Großanzeige darf nur Status und Gewicht lesen. Ein Ausfall der Großanzeige darf keine Wiegung verhindern.

## Einstellungen
Unter `Einstellungen -> Großanzeige` wurden vorgesehen:

- Großanzeigen-Schnittstelle aktiv/inaktiv
- IP-Adresse / Hostname der Großanzeige
- Token erzeugen
- vorhandener Token wird nicht erneut im Klartext angezeigt
- beim Erzeugen eines neuen Tokens wird der bisherige Token sofort ungültig

Der Klartext-Token wird nur einmal angezeigt. Persistiert wird ausschließlich sein SHA-256-Hash.

Die gespeicherte Großanzeigen-Adresse dient zunächst Diagnose und späteren Verbindungstests. Für den eigentlichen Datenweg pollt die Großanzeige die Waagenbox, damit die Waagenbox nie von der Anzeige abhängig wird.

## API
Read-only Endpunkt:

`GET /api/grossanzeige_status.php`

Header:

`X-AJP-Display-Token: <token>`

Zustände:
- `ready`
- `drive_on`
- `processing`
- `success`

Die Anzeige entscheidet lokal, welche Texte, Farben und Blinkmodi zu diesen Zuständen gehören.

## Quellen für den Status
- `pendingWeighing()`
- `currentWeight()`
- `scaleProcessingActive()`
- jüngste abgeschlossene Wiegung für das kurzzeitige Abschlussgewicht

## Teststrategie
Keine direkte Änderung an `/var/www/waage`.

Zuerst:
1. Branch in `/home/pi/Waagenbox-test` auschecken/aktualisieren.
2. Test-Webinstanz `/var/www/waage-test` verwenden.
3. PHP-Syntax prüfen.
4. Token in der Testinstanz erzeugen.
5. Großanzeige auf Testinstanz konfigurieren.
6. Demo-/Testwiegungen ausführen.
7. Erst nach erfolgreicher Abnahme Release vorbereiten.


## Erweiterter Wägeablauf: mehrere offene Fahrzeuge

Ab 1.2.39 wird zwischen der physisch aktiven Überfahrt und einer bereits gespeicherten ersten Überfahrt unterschieden.

- `weighing_state` bleibt ausschließlich für die aktuell aktive Überfahrt auf der Waage zuständig.
- Neue Tabelle `open_vehicle_weighings` speichert pro Fahrzeug eine bereits erfasste erste Überfahrt, solange die zweite Überfahrt noch fehlt.
- Dadurch kann Fahrzeug A die erste Überfahrt erledigen, anschließend abladen/aufladen und später zurückkehren, während Fahrzeug B, C usw. zwischenzeitlich normal gewogen werden.
- Pro Fahrzeug ist höchstens eine offene Zwei-Pass-Wiegung zulässig.
- Bei der zweiten Überfahrt gilt unabhängig von der Reihenfolge:
  - Tara = kleineres der beiden Gewichte
  - Brutto = größeres der beiden Gewichte
  - Netto = Brutto - Tara
- Ein bisher unbekanntes Fahrzeug-Leergewicht darf erst nach zwei realen Überfahrten aus dem kleineren Wert abgeleitet werden.
- Ein bereits gespeichertes Fahrzeug-Leergewicht wird nicht stillschweigend überschrieben.

### Geplanter Zustandsablauf für die Großanzeige

1. Start einer Überfahrt -> `drive_on`, 0 kg, Auffahrhinweis.
2. Gewicht erkannt -> `processing`, aktuelles gemessenes Gewicht.
3. Erste Überfahrt ohne bekannte Gegenwiegung -> erste Überfahrt fahrzeugbezogen speichern, Waage wieder freigeben.
4. Zweite Überfahrt -> Gewichte vergleichen, Tara/Brutto/Netto bestimmen.
5. Abschluss -> `success`, Nettogewicht, „WIEGUNG BEENDET / VIELEN DANK“.
6. Danach zurück zu `ready`.

Diese Architektur gilt gleichermaßen als Ziel für manuelle Wiegung, QR-Fernbedienung und Funkfernbedienung.
