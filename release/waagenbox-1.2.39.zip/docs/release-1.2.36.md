# AJP Waagenbox – Release 1.2.36

Stand: 2026-09-19

## Status

Release-Kandidat. Noch nicht produktiv veröffentlicht oder installiert.

## Basis

- stabiler Ausgangspunkt: `release/1.2.35`
- Source-Commit der Basis: `873d02cf6e156bb7f6b5ea5cd609d1c675197f1d`
- Entwicklungsbranch: `feature/1.2.36-weighing-number-rf-localhost`

## Änderungen

### Fortlaufende Wiegescheinnummer

Der Einzel-Wiegeschein zeigt neben dem Erstellungsdatum eine gut sichtbare `Wiegeschein-Nr.`.

Die Nummer wird sechsstellig mit führenden Nullen dargestellt, z. B. `000123`. Standardmäßig entspricht sie weiterhin der bestehenden Wiegungs-ID. Zusätzlich kann unter **Einstellungen → Wiegescheine** ein neuer Nummernkreis begonnen werden.

Beim Zurücksetzen:

- bleiben alle bereits vorhandenen Wiegescheine und deren sichtbare Nummern unverändert;
- erhält die nächste neue Wiegung die Nummer `000001`;
- werden keine Wiegungen gelöscht oder verändert;
- werden keine Datenbank-IDs zurückgesetzt;
- wird die Reset-Historie dauerhaft in den Einstellungen gespeichert, sodass auch bei einem späteren weiteren Reset ältere Nummern stabil bleiben.

Da alte Test-Wiegescheine ihre Nummer behalten, können nach einem Reset Nummern in unterschiedlichen Zeiträumen doppelt vorkommen. Der Reset ist deshalb vor allem für den einmaligen Übergang vom Test- in den Echtbetrieb vorgesehen.

Geänderte Datei:

- `reports/weighing.php`

### Navigation im Wiegeschein

Der Zurück-Button im Einzel-Wiegeschein führt nicht mehr zum Dashboard, sondern direkt zurück zur Wiegescheinübersicht.

Geänderte Datei:

- `reports/weighing.php`

### Funkfernbedienung lokal einlernen

`api/rf_learn.php` erlaubt den Einlernaufruf auf echtem Loopback-Zugriff des Raspberry-Kiosks ohne zusätzliche Admin-Anmeldung. Externe Aufrufe bleiben admin-geschützt.

Die bestehende Funktion `isLocalAccess()` entscheidet ausschließlich anhand des tatsächlichen Remote-Zugriffs; ein manipulierter Host-Header erzeugt keinen Localhost-Bypass.

Geänderte Datei:

- `api/rf_learn.php`

### Erstgewicht über QR-Fernbedienung

Die mobile QR-Fernbedienung kann jetzt das Erst-/Leergewicht des zugeordneten Fahrzeugs erfassen.

Verhalten:

- ist noch kein Erstgewicht gespeichert, erscheint der Button `1. GEWICHT (LEERGEWICHT) ERFASSEN`;
- die normale Wiegung bleibt solange gesperrt;
- die Erstgewichtserfassung verwendet dieselbe Token- und GPS-Näheprüfung wie die normale mobile Wiegung;
- bei laufender Wiegung wird die Erstgewichtserfassung abgelehnt;
- die Waage muss beim Start der Leergewichtserfassung zunächst frei sein;
- nach Druck auf den Erstgewicht-Button wird die Erfassung scharf geschaltet und wartet auf das Fahrzeug;
- erst wenn anschließend ein positives Gewicht erkannt wird, wird dieses als Leer-/Erstgewicht gespeichert;
- ein vorhandenes Erstgewicht wird über den mobilen Endpunkt nicht überschrieben;
- nach erfolgreicher Erfassung verschwindet der Erstgewicht-Button und die normale Wiegung ist wieder verfügbar.

Geänderte/neue Dateien:

- `mobile_remote.php`
- neu: `api/mobile_first_weight.php`

### Leergewicht eines Fahrzeugs löschen

Der bestätigungspflichtige Button `Leergewicht löschen` wird ausschließlich auf der Seite `Fahrzeug bearbeiten` angezeigt. Die Fahrzeugübersicht bleibt frei von dieser Aktion.

Die Aktion:

- ist CSRF-geschützt;
- setzt ausschließlich `vehicles.first_weight` des gewählten Fahrzeugs auf `0`;
- wird während einer laufenden Wiegung desselben Fahrzeugs abgelehnt;
- verändert keine abgeschlossenen Wiegungen und keine vorhandenen Wiegescheine.

Geänderte Datei:

- `vehicles.php`
- `vehicle_edit.php`

### Ganze Kilogrammanzeige und Testabschluss

Gewichte aus der Dini-Waage werden in 5-kg-Schritten verarbeitet. Anzeigen für Fahrzeug-Erstgewichte und laufende Wiegungen verwenden deshalb ganze Kilogramm ohne Nachkommastelle.

Im Demo-/Testbetrieb darf eine über QR/Fernbedienung gestartete Wiegung nur von der mobilen Fernbedienung abgeschlossen werden. Die geöffnete Wiegungsseite beobachtet diesen Vorgang, startet aber keinen zweiten automatischen Abschluss. Damit wird die irreführende Meldung `Es ist keine laufende Wiegung vorhanden.` nach bereits erfolgreich gespeicherter QR-Wiegung vermieden.

Geänderte Dateien:

- `weighing.php`
- `vehicles.php`
- `vehicle_edit.php`

### Geplante ELDAT-Fernbedienungslogik

Die ELDAT-Hardware bleibt ausdrücklich außerhalb von 1.2.36. Für die spätere RX09-Integration ist folgender Bedienablauf festgelegt:

- 1-Tasten-Fernbedienung: Taste startet ausschließlich eine normale Wiegung mit bereits vorhandenem Leergewicht;
- 2-Tasten-Fernbedienung: eine Taste erfasst das Leer-/Erstgewicht, die zweite startet die normale Wiegung;
- sobald ein Leergewicht gespeichert ist, wird die Leergewichtstaste softwareseitig ignoriert;
- nach dem Löschen des Leergewichts wird diese Taste wieder freigegeben;
- die normale Wiegungstaste verhält sich identisch zur Taste einer 1-Tasten-Fernbedienung.

### Live-Aktualisierung des Raspberry-Dashboards

Das Dashboard aktualisiert die Anzahl aktiver Fahrzeuge, die Anzahl aktiver Schläge und die Namen der aktiven Schläge jetzt automatisch im Hintergrund. Änderungen, die über den Netzwerk-/Domain-Zugriff vorgenommen werden, erscheinen dadurch innerhalb weniger Sekunden auch auf dem dauerhaft geöffneten localhost-Dashboard am Raspberry.

Die Aktualisierung erfolgt ohne vollständigen Seitenreload, damit Kameraanzeige und Bedienoberfläche nicht unnötig neu geladen werden.

Geänderte/neue Dateien:

- `index.php`
- neu: `api/dashboard_status.php`

## Nicht Bestandteil dieses Releases

Die vorbereitete ELDAT-Entwicklung aus `feature/1.2.36-eldat-remote-workflow` ist ausdrücklich nicht Bestandteil dieses Releases. Sie war nie freigegeben und wird nach der RX09-Hardwareentscheidung auf einen späteren Entwicklungsstand weitergeführt.

## Tests

Neu:

- `tests/release_1_2_36_test.php`
- 21 statische Checks für Wiegescheinnummer, Localhost-RF-Learn, QR-Erstgewicht und Leergewicht-Löschen

Bereits außerhalb des Raspberrys erfolgreich:

- PHP-Syntax der beiden geänderten PHP-Dateien
- PHP-Syntax des neuen Tests
- neue Release-Checks wurden um die QR-/Leergewicht-Funktionen erweitert; finaler Raspberry-Lauf steht noch aus

Vor Freeze/Veröffentlichung noch auszuführen:

- vollständige bestehende Sicherheits-/Regression-Suite auf dem Test-Worktree
- `git diff --check`
- Release-Preflight auf committed HEAD
- anschließend Raspberry-Test der PDF-/Druckansicht
- QR-Test ohne Erstgewicht: Button sichtbar, Erstgewicht erfassen, Button verschwindet
- Fahrzeugverwaltung: Leergewicht löschen und danach QR-Button erneut sichtbar
- lokaler Einlerntest über den Kiosk/localhost

## Produktionsschutz

- `/var/www/waage` wurde durch diese Entwicklung nicht verändert.
- keine produktiven Daten wurden verändert.
- keine Migration ist erforderlich.
- keine privaten Schlüssel oder produktiven Zugangsdaten gehören in diesen Branch.
- Veröffentlichung und Produktivinstallation erfolgen erst nach erfolgreicher Abnahme.
