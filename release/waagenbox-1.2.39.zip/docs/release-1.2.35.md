# AJP Waagenbox – Release 1.2.35

Stand: 2026-09-16

## Status

Release-Vorbereitung.

Diese Version ist noch nicht veröffentlicht und noch nicht produktiv installiert.

## Ausgangspunkt

- Basisversion: `1.2.34`
- Basis-Release-Branch: `release/1.2.34`
- Basis-Commit: `e431b76261f3c1875ce213737564f86c9c342ace`
- Entwicklungsbranch: `feature/1.2.35-camera-snapshot-live`

## Hauptänderung

### Snapshot-basierte Kamera-Liveansicht

Für IP-Kameras ohne direkt browserfähigen MJPEG-Stream kann die vorhandene Snapshot-URL jetzt automatisch als Livebildquelle verwendet werden.

Verhalten:

- Eine konfigurierte echte Stream-URL hat weiterhin Vorrang.
- Ist keine Stream-URL gesetzt, aber eine Snapshot-URL vorhanden, verwendet das Dashboard die interne Snapshot-zu-MJPEG-Bridge.
- Standardintervall: 1000 ms.
- Die Kamera-Einstellungsseite bleibt unverändert.
- Keine Kamera-IP oder Zugangsdaten sind im Quellcode fest hinterlegt.
- Die vorhandene Snapshot-Konfiguration bleibt die Quelle der Kameraadresse.
- Kamerabilder für Wiegungen bleiben unabhängig von der Dashboard-Liveansicht.

## Technische Umsetzung

Neue Datei:

- `api/camera_mjpeg.php`

Geändert:

- `index.php`

Tests:

- `tests/camera_snapshot_live_test.py`

Dokumentation:

- `docs/camera-snapshot-live.md`

## Sicherheits- und Ressourcenverhalten

Die MJPEG-Bridge:

- verlangt die bestehende Waagenbox-Authentifizierung;
- verwendet ausschließlich die vorhandene Snapshot-URL;
- schreibt keine Livebilder auf die SD-Karte;
- validiert empfangene Bilddaten;
- verwendet begrenzte Kamera-Timeouts;
- setzt No-Cache-Header;
- schließt die PHP-Session für die langlebige MJPEG-Verbindung;
- vermeidet JPEG-Neukodierung, wenn die Kamera bereits JPEG liefert;
- begrenzt das abrufbare Intervall.

## Praktischer Kameratest

Mit der vorhandenen Foscam-Kamera wurde erfolgreich geprüft:

- Snapshot-Abruf über die bestehende Konfiguration;
- HTTP 200;
- gültiges JPEG;
- 1920 × 1080;
- Snapshot-zu-MJPEG-Bridge;
- Multipart-MJPEG-Ausgabe;
- Darstellung in Chromium unter Raspberry-Pi-Wayland;
- sichtbare Aktualisierung ungefähr einmal pro Sekunde.

1000 ms wurden als ausreichendes Standardintervall gewählt.

## Automatisierte Tests

Vor der Versionsanhebung erfolgreich:

- Kamera-spezifischer Test: 22 Checks
- vollständige Python-Regression
- vollständige PHP-Regression
- Syntaxprüfung aller getrackten PHP-Dateien
- Syntaxprüfung aller getrackten Python-Dateien
- Diff-Prüfung gegen `release/1.2.34`

Die vollständige Release-Regression nach Versionsanhebung muss noch erfolgen.

## Finaler Änderungsumfang vor Versionsanhebung

Gegenüber `release/1.2.34`:

- `api/camera_mjpeg.php`
- `docs/camera-snapshot-live.md`
- `index.php`
- `tests/camera_snapshot_live_test.py`

Zusätzlich für die Release-Vorbereitung:

- `version.php`
- `docs/release-1.2.35.md`

## Noch offen vor Freeze

- vollständige Regression mit `APP_VERSION = 1.2.35`
- Release-Preflight
- finalen Source-Commit festlegen
- Release-Branch `release/1.2.35` erst nach erfolgreicher Prüfung erstellen
- Release-Artefakte erst nach ausdrücklicher Freigabe bauen
- Signaturprüfung durchführen
- Veröffentlichung im Update-Repository erst nach Freigabe
- Produktivinstallation nur nach ausdrücklicher Freigabe

## Produktionsschutz

- `/var/www/waage` nicht im Rahmen dieser Vorbereitung verändern.
- Produktive Datenbank nicht verändern.
- Privaten Release-Schlüssel niemals nach GitHub oder auf den Raspberry kopieren.
- Bestehenden Release-Branch `release/1.2.34` nicht verändern.
