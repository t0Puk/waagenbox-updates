# AJP Waagenbox – Release 1.2.37

Stand: 2026-09-23

## Status

Entwicklungsstand. Noch nicht produktiv veröffentlicht oder installiert.

## Basis

- stabiler Ausgangspunkt: `release/1.2.36`
- Basis-Commit: `3fc8f11f8650a00c96767744208367f809ef78e2`
- Entwicklungsbranch: `feature/1.2.37-field-import-edit-inputs`

## Änderungen

### Flächengröße mit Dezimalkomma

Beim manuellen Anlegen und Bearbeiten eines Schlags kann die Fläche jetzt mit deutschem Dezimalkomma eingegeben werden, zum Beispiel `1,00`. Intern wird der Wert weiterhin numerisch gespeichert. In der Schlagübersicht wird die Fläche mit deutschem Komma dargestellt.

### Schlag bearbeiten

Vorhandene Schläge können über einen neuen Button `Bearbeiten` nachträglich geändert werden. Änderbar sind:

- Name
- Frucht / Kultur
- Jahr
- Fläche
- Notizen

Die Schlag-ID bleibt unverändert. Dadurch bleiben bestehende Wiegungen mit dem Schlag verknüpft.

### GeoJSON-Schlagimport

Unter `Schläge → GeoJSON importieren` kann eine GeoJSON-FeatureCollection eingelesen werden.

Ablauf:

1. GeoJSON-Datei auswählen.
2. Vorschau öffnen.
3. GeoJSON-Eigenschaften den Zielfeldern Name, Fläche und Frucht/Kultur zuordnen.
4. Einzelne Schläge per Checkbox auswählen.
5. Auswahl importieren.

Schutzregeln:

- GeoJSON-Geometrien werden nicht gespeichert.
- Enthält die Datei keine eigene Flächen-Eigenschaft, wird die Fläche in Hektar aus Polygon/MultiPolygon-Geometrie berechnet.
- Es werden nur ausgewählte Eigenschaften importiert.
- Name ist Pflicht; Fläche und Frucht/Kultur sind optional. Beim geprüften Feldmanager-Export werden `name` und `crop` automatisch erkannt; die Fläche wird aus dem Polygon berechnet, weil der Export kein separates Flächenfeld enthält.
- Bereits vorhandene Schläge mit gleichem Namen werden niemals überschrieben, sondern übersprungen.
- maximal 5 MB pro Datei und maximal 1000 Features;
- Upload und Import sind CSRF-geschützt.
- Keine Datenbankmigration erforderlich.

### Führende Nullen bei Fernbedienungscodes

Manuell eingegebene Fernbedienungscodes bleiben exakt erhalten. Ein Dummy-Code wie `0001` wird daher auch als `0001` gespeichert und angezeigt.

Für Funkerkennung und Duplikatprüfung wird der Code weiterhin numerisch verglichen. Dadurch entspricht `0001` technisch demselben 24-Bit-Code wie `1`, ohne dass zwei numerisch gleiche Codes angelegt werden können.

## Geänderte / neue Dateien

- `version.php`
- `fields.php`
- neu: `field_edit.php`
- neu: `fields_import.php`
- `remotes.php`
- `rf_remote_support.php`
- `api/rf_learn.php`
- neu: `tests/release_1_2_37_test.php`

## Produktionsschutz

- `release/1.2.36` bleibt unverändert.
- `/var/www/waage` wird durch diese Entwicklung nicht verändert.
- Produktive Daten werden nicht verändert.
- Die Änderungen werden zuerst ausschließlich in der Testinstanz geprüft.


## Praktische Abnahme

Am 2026-09-23 auf der separaten Testinstanz erfolgreich geprüft:

- Schlagfläche lässt sich mit deutschem Dezimalkomma eingeben und korrekt speichern;
- vorhandene Schläge lassen sich nachträglich bearbeiten;
- Fernbedienungscode mit führenden Nullen (z. B. `0001`) bleibt erhalten;
- Feldmanager-GeoJSON kann eingelesen werden;
- automatische Zuordnung von Name/Frucht und berechneter Fläche funktioniert;
- einzelne Schläge können gezielt ausgewählt werden;
- bereits vorhandene Schläge werden nicht überschrieben.

Der 1.2.37-Spezialtest lief mit 26/26 Checks erfolgreich durch.
