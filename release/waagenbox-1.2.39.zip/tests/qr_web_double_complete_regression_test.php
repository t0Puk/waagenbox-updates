<?php
declare(strict_types=1);

/**
 * Regressionstest: Die manuelle Web-Wiegeseite darf QR/Mobile-Pending nicht
 * automatisch abschließen. Sonst konkurrieren weighing.php und mobile_complete.php.
 */

function autoCaptureForTrigger(?array $pending): bool {
    if (!$pending) return false;
    $trigger=(string)($pending['trigger_type']??'');
    return str_starts_with($trigger,'manual');
}

$cases=[
    [null,false,'kein Pending'],
    [['trigger_type'=>'manual'],true,'manuelle Zweitwiegung'],
    [['trigger_type'=>'manual_first_pass'],true,'manuelle Erstwiegung'],
    [['trigger_type'=>'mobile'],false,'QR/Mobile Zweitwiegung'],
    [['trigger_type'=>'mobile_first_pass'],false,'QR/Mobile Erstwiegung'],
    [['trigger_type'=>'rf'],false,'RF'],
];

$failed=0;
foreach($cases as [$pending,$expected,$label]){
    $actual=autoCaptureForTrigger($pending);
    if($actual!==$expected){
        fwrite(STDERR,"FAIL: {$label}\n");
        $failed++;
    }else{
        echo "PASS: {$label}\n";
    }
}
if($failed>0){
    echo "RESULT {$failed} failed\n";
    return;
}
echo "RESULT 6 checks passed\n";
