#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

mjpeg = (ROOT / 'api' / 'camera_mjpeg.php').read_text(encoding='utf-8')
dashboard = (ROOT / 'index.php').read_text(encoding='utf-8')
settings = (ROOT / 'settings.php').read_text(encoding='utf-8')

checks = {
    'mjpeg bridge requires login':
        'requireLogin();' in mjpeg,

    'mjpeg bridge uses existing snapshot setting':
        'cameraSnapshotUrl()' in mjpeg,

    'mjpeg bridge does not write snapshots to disk':
        'file_put_contents' not in mjpeg and 'fopen(' not in mjpeg,

    'mjpeg bridge closes session lock':
        'session_write_close();' in mjpeg,

    'mjpeg bridge uses multipart jpeg':
        'multipart/x-mixed-replace' in mjpeg
        and 'Content-Type: image/jpeg' in mjpeg,

    'mjpeg bridge clamps refresh interval':
        'max(500, min(5000, $intervalMs))' in mjpeg,

    'mjpeg bridge default interval is 1000 ms':
        "($_GET['interval'] ?? 1000)" in mjpeg,

    'mjpeg bridge has bounded camera timeout':
        'CURLOPT_CONNECTTIMEOUT => 2' in mjpeg
        and 'CURLOPT_TIMEOUT => 5' in mjpeg,

    'mjpeg bridge validates source image':
        'getimagesizefromstring' in mjpeg,

    'mjpeg bridge avoids jpeg re-encoding when possible':
        "if ($mime === 'image/jpeg') return $data;" in mjpeg,

    'mjpeg bridge disables output compression':
        'zlib.output_compression' in mjpeg,

    'mjpeg bridge uses no-cache headers':
        'Cache-Control: no-store' in mjpeg,

    'dashboard reads configured stream url':
        'cameraStreamUrl()' in dashboard,

    'dashboard reads configured snapshot url':
        'cameraSnapshotUrl()' in dashboard,

    'dashboard keeps direct stream support':
        'src="<?=h($cameraStream)?>"' in dashboard,

    'dashboard snapshot bridge is fallback':
        "elseif(cameraEnabled() && $cameraSnapshot!=='')" in dashboard,

    'dashboard uses internal mjpeg endpoint':
        'api/camera_mjpeg.php?interval=1000' in dashboard,

    'dashboard prefers stream before snapshot fallback':
        dashboard.find("if(cameraEnabled() && $cameraStream!=='')") != -1
        and dashboard.find("elseif(cameraEnabled() && $cameraSnapshot!=='')") != -1
        and dashboard.find("if(cameraEnabled() && $cameraStream!=='')") <
            dashboard.find("elseif(cameraEnabled() && $cameraSnapshot!=='')"),

    'dashboard contains no hardcoded camera ip':
        '192.168.55.115' not in dashboard,

    'settings page still contains stream field':
        'name="camera_stream_url"' in settings,

    'settings page still contains snapshot field':
        'name="camera_snapshot_url"' in settings,

    'settings page has no internal bridge special case':
        'camera_mjpeg.php' not in settings,
}

failed = [name for name, ok in checks.items() if not ok]

for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)

if failed:
    print()
    print('FAILED:')
    for name in failed:
        print('-', name)
    raise SystemExit(1)

print()
print(f'RESULT {len(checks)} camera MJPEG checks passed')
