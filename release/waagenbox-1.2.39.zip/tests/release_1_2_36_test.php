<?php
// Statischer Regressionstest für Release 1.2.36.
// Keine Datenbank, Hardware oder Produktivpfade werden geladen.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Nur CLI.'); }

$root = dirname(__DIR__);
$checks = 0;
function ok136(bool $condition, string $message): void {
    global $checks;
    if (!$condition) throw new RuntimeException('FAIL '.$message);
    $checks++;
    echo "PASS {$message}\n";
}

$report = file_get_contents($root.'/reports/weighing.php');
$rfLearn = file_get_contents($root.'/api/rf_learn.php');
$mobileRemote = file_get_contents($root.'/mobile_remote.php');
$mobileFirst = file_get_contents($root.'/api/mobile_first_weight.php');
$mobileStatus = file_get_contents($root.'/api/mobile_status.php');
$vehicles = file_get_contents($root.'/vehicles.php');
$vehicleEdit = file_get_contents($root.'/vehicle_edit.php');
$weighingPage = file_get_contents($root.'/weighing.php');
$functions = file_get_contents($root.'/functions.php');
$settings = file_get_contents($root.'/settings.php');
$dashboard = file_get_contents($root.'/index.php');
$dashboardStatus = file_get_contents($root.'/api/dashboard_status.php');

ok136($report !== false, 'Wiegeschein-Report lesbar');
ok136(str_contains($report, 'Wiegeschein-Nr.'), 'Wiegescheinnummer wird ausgegeben');
ok136(str_contains($report, "formattedTicketNumberForWeighing((int)\$r['id'])"), 'Wiegeschein nutzt stabilen Nummernkreis-Helfer');
ok136(str_contains($report, 'weighing-meta') && str_contains($report, 'gap:48px'), 'Nummer steht mit Abstand neben dem Datum');
ok136(str_contains($report, 'href="../weighings.php"') && str_contains($report, 'Zur Wiegescheinübersicht'), 'Wiegeschein führt zurück zur Wiegescheinübersicht');
ok136(!str_contains($report, 'MAX(') && !str_contains($report, 'COUNT('), 'Report selbst enthält keine fehleranfällige Zählerabfrage');

ok136($rfLearn !== false, 'RF-Learn-Endpunkt lesbar');
ok136(str_contains($rfLearn, 'if (!isLocalAccess()) requireAdmin();'), 'Lokaler Kiosk darf RF-Learn ohne Login verwenden');
ok136(!preg_match('/^requireAdmin\(\);/m', $rfLearn), 'Kein bedingungsloser Adminzwang im RF-Learn-Endpunkt');

ok136($mobileRemote !== false && str_contains($mobileRemote, 'firstWeightButton'), 'QR-Fernbedienung enthält Erstgewicht-Button');
ok136(str_contains($mobileRemote, 'api/mobile_first_weight.php'), 'QR-Fernbedienung ruft Erstgewicht-Endpunkt auf');
ok136(str_contains($mobileRemote, "hasFirstWeight?'none':'block'"), 'Erstgewicht-Button wird nach gespeichertem Gewicht ausgeblendet');
ok136(str_contains($mobileRemote, 'startButton.disabled=!hasFirstWeight'), 'Normale QR-Wiegung bleibt ohne Erstgewicht gesperrt');

ok136($mobileFirst !== false && str_contains($mobileFirst, 'startFirstScaleWeighing();'), 'QR-Erstgewicht startet zuerst den bestehenden Erstwiegebefehl');
ok136(str_contains($mobileFirst, "'mobile_first_weight'"), 'QR-Erstgewicht legt einen wartenden Erstgewicht-Zustand an');
ok136(str_contains($mobileFirst, "action==='complete'"), 'QR-Erstgewicht besitzt getrennten Abschluss nach Gewichtserkennung');
ok136(str_contains($mobileFirst, 'currentWeight()>0'), 'Start der Erstgewichtserfassung verlangt eine leere Waage');
ok136(str_contains($mobileFirst, '$weight=currentWeight();'), 'Abschluss liest das erst danach anliegende Gewicht');
ok136(str_contains($mobileFirst, 'AND first_weight<=0'), 'Vorhandenes Erstgewicht wird nicht überschrieben');
ok136(str_contains($mobileFirst, 'gps_enabled') && str_contains($mobileFirst, 'gps_radius_m'), 'QR-Erstgewicht übernimmt GPS-Schutz');
ok136(str_contains($mobileFirst, 'pendingWeighing()'), 'QR-Erstgewicht schützt vor parallelen Wiegungen');
ok136($mobileStatus !== false && str_contains($mobileStatus, "'pending_mode'"), 'Mobile Status-API unterscheidet Erstgewicht und normale Wiegung');
ok136(str_contains($mobileRemote, 'completeFirstWeight()'), 'QR-Oberfläche speichert Erstgewicht erst nach erkannter Überfahrt');
ok136(str_contains($mobileRemote, 'Bitte jetzt mit dem Fahrzeug über die Waage fahren'), 'QR-Oberfläche fordert nach Tastendruck zur Überfahrt auf');

ok136($vehicles !== false && !str_contains($vehicles, 'clear_first_weight_id'), 'Fahrzeugübersicht enthält keinen Leergewicht-löschen-Button');
ok136(str_contains($vehicles, 'vehicle_edit.php?id='), 'Fahrzeugliste bietet Bearbeiten-Link');
ok136(str_contains($vehicles, 'vorläufige Fahrzeugnummer'), 'Schnelle vorläufige Fahrzeugnummer wird unterstützt');

ok136($vehicleEdit !== false && str_contains($vehicleEdit, 'UPDATE vehicles SET plate=?,name=?,max_weight=?,notes=?'), 'Fahrzeugstammdaten sind nachträglich bearbeitbar');
ok136(str_contains($vehicleEdit, 'first_weight'), 'Bearbeiten zeigt vorhandenes Erstgewicht an');
ok136(!str_contains($vehicleEdit, 'SET first_weight=?'), 'Normales Bearbeiten verändert das Erstgewicht nicht');
ok136(str_contains($vehicleEdit, 'clear_first_weight'), 'Erstgewicht kann gezielt separat gelöscht werden');

ok136($weighingPage !== false && str_contains($weighingPage, "\$autoDemoFinish = \$pending && demoMode() && ((\$pending['trigger_type'] ?? '') === 'manual');"), 'Demo-Autoabschluss läuft nur für manuell gestartete Wiegungen');
ok136(substr_count($weighingPage, '<?php if($autoDemoFinish): ?>') >= 2, 'QR-/Mobile-Wiegungen erzeugen keinen zweiten automatischen Abschluss auf der Wiegungsseite');
ok136(str_contains($weighingPage, "formatWeight((float)\$pending['first_weight'])"), 'Laufendes Erstgewicht wird ohne Nachkommastelle dargestellt');
ok136(str_contains($weighingPage, "formatWeight((float)\$v['first_weight'])"), 'Fahrzeugauswahl zeigt Erstgewicht ohne Nachkommastelle');
ok136(str_contains($vehicles, "formatWeight((float)\$r['first_weight'])"), 'Fahrzeugübersicht zeigt Erstgewicht ohne Nachkommastelle');
ok136(str_contains($vehicleEdit, "formatWeight((float)\$vehicle['first_weight'])"), 'Fahrzeug-Bearbeiten zeigt Erstgewicht ohne Nachkommastelle');

ok136($functions !== false && str_contains($functions, 'function ticketNumberResetBases(): array'), 'Nummernkreis-Reset-Historie ist vorhanden');
ok136(str_contains($functions, 'function ticketNumberForWeighing(int $weighingId): int'), 'Wiegescheinnummer wird unabhängig von der Datenbank-ID berechnet');
ok136(str_contains($functions, 'ticket_number_reset_bases'), 'Reset-Grenzen werden dauerhaft in Einstellungen gespeichert');
ok136(str_contains($functions, 'if($candidate < $weighingId) $base=$candidate;'), 'Bestehende Wiegescheine behalten bei späteren Resets ihre Nummer');
ok136(str_contains($functions, 'function resetTicketNumberSequence(): int'), 'Nummernkreis kann gezielt zurückgesetzt werden');
ok136($settings !== false && str_contains($settings, "'wiegescheine'"), 'Einstellungen enthalten Untermenü Wiegescheine');
ok136(str_contains($settings, 'reset_ticket_numbers'), 'Wiegeschein-Nummernkreis besitzt Reset-Aktion');
ok136(str_contains($settings, 'requireCsrfToken();'), 'Nummernkreis-Reset ist CSRF-geschützt');
ok136(str_contains($settings, 'requireAdmin();'), 'Sicherheitskritische Einstellungen bleiben admin-geschützt');
ok136(str_contains($settings, 'Bestehende Wiegescheine behalten ihre Nummern'), 'UI weist auf Erhalt alter Wiegescheinnummern hin');

ok136($dashboard !== false && str_contains($dashboard, 'id="activeVehicleCount"'), 'Dashboard-Fahrzeugzahl ist live aktualisierbar');
ok136(str_contains($dashboard, 'id="activeFieldCount"') && str_contains($dashboard, 'id="activeFieldNames"'), 'Dashboard-Schlagdaten sind live aktualisierbar');
ok136(str_contains($dashboard, "fetch('api/dashboard_status.php'"), 'Dashboard fragt den Live-Status ab');
ok136(str_contains($dashboard, 'setInterval(refreshDashboardData,3000)'), 'Dashboard aktualisiert Stammdaten regelmäßig ohne Seitenreload');
ok136($dashboardStatus !== false && str_contains($dashboardStatus, "'active_vehicle_count'"), 'Dashboard-Status liefert aktive Fahrzeuge');
ok136(str_contains($dashboardStatus, "'active_field_count'") && str_contains($dashboardStatus, "'active_field_names'"), 'Dashboard-Status liefert aktive Schläge und Namen');
ok136(str_contains($dashboardStatus, "header('Cache-Control: no-store')"), 'Dashboard-Live-Status wird nicht zwischengespeichert');

echo "RESULT {$checks} checks passed\n";
