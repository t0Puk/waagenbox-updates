<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$trigger=(string)file_get_contents($root.'/api/mobile_trigger.php');
$status=(string)file_get_contents($root.'/api/mobile_status.php');
$complete=(string)file_get_contents($root.'/api/mobile_complete.php');
$page=(string)file_get_contents($root.'/mobile_remote.php');

$checks=[
    'trigger uses shared vehicle pass' => strpos($trigger,'startVehiclePass(')!==false,
    'trigger no first-weight rejection' => strpos($trigger,'noch kein Erstgewicht hinterlegt')===false,
    'status detects first pass' => strpos($status,"'_first_pass'")!==false,
    'status exposes open weighing' => strpos($status,'has_open_weighing')!==false,
    'complete captures first pass' => strpos($complete,'capturePendingFirstPass(')!==false,
    'complete closes second pass' => strpos($complete,'completePendingWeighing(')!==false,
    'complete net is direction independent' => strpos($complete,'abs($weight-$first)')!==false,
    'mobile page has one start button' => substr_count($page,'id="startButton"')===1,
    'old first weight button removed' => strpos($page,'firstWeightButton')===false,
    'old first-weight API removed from page' => strpos($page,'mobile_first_weight.php')===false,
    'mobile page handles first saved' => strpos($page,"d.phase==='first_saved'")!==false,
];

$failed=0;
foreach($checks as $name=>$ok){
    echo ($ok?'PASS: ':'FAIL: '),$name,PHP_EOL;
    if(!$ok)$failed++;
}
if($failed){
    echo "RESULT: {$failed} checks failed",PHP_EOL;
    exit(1);
}
echo 'RESULT: '.count($checks).' checks passed',PHP_EOL;
