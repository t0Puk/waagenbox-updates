<?php
declare(strict_types=1);

require_once dirname(__DIR__).'/db.php';

$pdo = db();

$checks = [];

$table = $pdo->query("SHOW TABLES LIKE 'open_vehicle_weighings'")->fetchColumn();
$checks['table exists'] = $table !== false;

if ($checks['table exists']) {
    $cols = $pdo->query("SHOW COLUMNS FROM open_vehicle_weighings")->fetchAll(PDO::FETCH_COLUMN);
    foreach (['owner_user_id','vehicle_id','first_weight','remote_id','field_id','customer_id','product_id','trigger_type','first_measured_at','updated_at'] as $col) {
        $checks['column '.$col] = in_array($col, $cols, true);
    }

    $idxRows = $pdo->query("SHOW INDEX FROM open_vehicle_weighings")->fetchAll(PDO::FETCH_ASSOC);
    $primary = [];
    foreach ($idxRows as $row) {
        if (($row['Key_name'] ?? '') === 'PRIMARY') {
            $primary[(int)$row['Seq_in_index']] = (string)$row['Column_name'];
        }
    }
    ksort($primary);
    $checks['primary owner+vehicle'] = array_values($primary) === ['owner_user_id','vehicle_id'];
}

$failed = 0;
foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS: ' : 'FAIL: '), $name, PHP_EOL;
    if (!$ok) $failed++;
}

if ($failed) {
    echo "RESULT: {$failed} checks failed", PHP_EOL;
    exit(1);
}

echo 'RESULT: '.count($checks).' checks passed', PHP_EOL;
