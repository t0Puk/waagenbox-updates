<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$functions=(string)file_get_contents($root.'/functions.php');

$checks=[
    'external tare ignored in fast path' =>
        strpos($functions, '$savedTare > 0 && !$manualExternal') !== false,
    'vehicle lookup includes manual_external' =>
        strpos($functions, 'SELECT first_weight,manual_external') !== false,
    'external tare not persisted after completion' =>
        strpos($functions, 'AND manual_external=0') !== false,
];

$failed=0;
foreach($checks as $name=>$ok){
    echo ($ok?'PASS: ':'FAIL: '),$name,PHP_EOL;
    if(!$ok)$failed++;
}
if($failed){
    echo "RESULT: {$failed} checks failed",PHP_EOL;
    exit(1);
}
echo 'RESULT: '.count($checks).' checks passed',PHP_EOL;
