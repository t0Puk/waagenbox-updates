<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$checks=0;

function ok139(bool $condition,string $label):void{
    global $checks;
    if(!$condition){fwrite(STDERR,"FAIL $label\n");exit(1);}
    $checks++;
    echo "PASS $label\n";
}
function read139(string $path):string{
    $v=file_get_contents($path);
    if($v===false){fwrite(STDERR,"FAIL Datei nicht lesbar: $path\n");exit(1);}
    return $v;
}

$version=read139($root.'/version.php');
$functions=read139($root.'/functions.php');
$weighing=read139($root.'/weighing.php');
$mobileTrigger=read139($root.'/api/mobile_trigger.php');
$mobileComplete=read139($root.'/api/mobile_complete.php');
$mobileStatus=read139($root.'/api/mobile_status.php');
$grossStatus=read139($root.'/api/grossanzeige_status.php');
$settings=read139($root.'/settings.php');
$dashboard=read139($root.'/index.php');
$dashboardStatus=read139($root.'/api/dashboard_status.php');
$migrationOpen=read139($root.'/migration_v1_2_39_open_vehicle_weighings.sql');
$migrationExternal=read139($root.'/migration_v1_2_39_manual_external.sql');

ok139(str_contains($version,"APP_VERSION = '1.2.39'"),'Version ist 1.2.39');
ok139(str_contains($migrationOpen,'open_vehicle_weighings'),'Migration für offene Fahrzeugwiegungen vorhanden');
ok139(str_contains($migrationExternal,'manual_external'),'Migration für manuelle externe Fahrzeuge vorhanden');
ok139(str_contains($functions,'function startVehiclePass('),'Einheitlicher Fahrzeug-Überfahrtstart vorhanden');
ok139(str_contains($functions,'function capturePendingFirstPass('),'Erste Überfahrt wird zentral erfasst');
ok139(str_contains($functions,'function completePendingWeighing('),'Wiegungsabschluss ist zentral');
ok139(str_contains($functions,'min($firstWeight, $secondWeight)'),'Tara wird aus kleinerem Gewicht ermittelt');
ok139(str_contains($functions,'max($firstWeight, $secondWeight)'),'Brutto wird aus größerem Gewicht ermittelt');
ok139(str_contains($functions,'manual_external=0'),'Temporäre externe Fahrzeuge bekommen kein dauerhaftes Leergewicht');
ok139(str_contains($weighing,"str_starts_with(\$pendingTrigger,'manual')"),'Web-Autoabschluss ist auf manuelle Wiegungen begrenzt');
ok139(str_contains($mobileTrigger,'startVehiclePass('),'QR-Start verwendet einheitlichen Wägekern');
ok139(str_contains($mobileComplete,'capturePendingFirstPass('),'QR-Erstüberfahrt verwendet zentralen Erfassungsweg');
ok139(str_contains($mobileComplete,'completePendingWeighing('),'QR-Abschluss verwendet zentralen Abschlussweg');
ok139(str_contains($mobileStatus,'openVehicleWeighing'),'QR-Status berücksichtigt offene Fahrzeugwiegung');
ok139(str_contains($grossStatus,"'weight_label_key'"),'Großanzeigen-API liefert Gewichtsart-Schlüssel');
ok139(str_contains($grossStatus,"'display_enabled'=>grossanzeigeDisplayEnabled()"),'Großanzeigen-API überträgt Fernschaltzustand');
ok139(str_contains($grossStatus,"\$weightLabel = '';"),'Großanzeigen-API kann Gewichtsbezeichnung ausblenden');
ok139(str_contains($settings,'grossanzeige_first_processing_seconds'),'Zeit für Erstgewicht ist einstellbar');
ok139(str_contains($settings,'grossanzeige_complete_processing_seconds'),'Zeit für Zweitgewicht ist einstellbar');
ok139(str_contains($settings,'grossanzeige_success_seconds'),'Zeit für Nettoabschluss ist einstellbar');
ok139(str_contains($settings,"value=\"display_toggle\""),'Großanzeige kann von Waagenbox ein-/ausgeschaltet werden');
ok139(str_contains($settings,'Administration der Großanzeige öffnen'),'Dynamischer Admin-Link der Großanzeige vorhanden');
ok139(str_contains($settings,'Großanzeige öffnen'),'Dynamischer Display-Link vorhanden');
ok139(str_contains($functions,'function grossanzeigeBaseUrl()'),'Großanzeigen-URL wird aus Einstellung erzeugt');
ok139(str_contains($functions,'function grossanzeigeConnectionStatus()'),'Großanzeigen-Erreichbarkeit wird geprüft');
ok139(str_contains($dashboard,'id="grossanzeigeLed"'),'Dashboard zeigt Großanzeigen-LED');
ok139(str_contains($dashboardStatus,"'grossanzeige_state'"),'Dashboard-API liefert Großanzeigenstatus');

echo "RESULT $checks checks passed\n";
