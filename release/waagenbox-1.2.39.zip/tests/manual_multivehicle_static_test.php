<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$functions = (string)file_get_contents($root.'/functions.php');
$weighing = (string)file_get_contents($root.'/weighing.php');
$display = (string)file_get_contents($root.'/api/grossanzeige_status.php');

$checks = [
    'open vehicle lookup' => strpos($functions, 'function openVehicleWeighing(') !== false,
    'start vehicle pass' => strpos($functions, 'function startVehiclePass(') !== false,
    'known tare path' => strpos($functions, "return 'saved_tare';") !== false,
    'first pass capture' => strpos($functions, 'function capturePendingFirstPass(') !== false,
    'direction independent tare' => strpos($functions, 'min($firstWeight, $secondWeight)') !== false,
    'direction independent gross' => strpos($functions, 'max($firstWeight, $secondWeight)') !== false,
    'manual unified start button' => strpos($weighing, 'value="start_vehicle"') !== false,
    'manual first-pass auto capture' => strpos($weighing, 'capture_first_pass') !== false,
    'open weighing overview' => strpos($weighing, 'OFFENE FAHRZEUGWIEGUNGEN') !== false,
    'display processing current weight' => strpos($display, '$displayWeight = $currentWeight;') !== false,
    'display final net weight' => strpos($display, "latest['net_weight']") !== false,
    'external vehicle helper' => strpos($functions, 'function findOrCreateManualExternalVehicle(') !== false,
    'external vehicle input' => strpos($weighing, 'external_vehicle_label') !== false,
    'external second weighing button' => strpos($weighing, '2. Wiegung starten') !== false && strpos($weighing, 'name="action" value="start_vehicle"') !== false,
    'first-pass processing ten seconds' => strpos($functions, "setScaleProcessing(10, \$weight, 'first_pass')") !== false,
    'extended complete display' => strpos($functions, "setScaleProcessing(20, \$secondWeight, 'complete')") !== false,
    'complete processing then success' => strpos($display, "if (\$age < 10)") !== false,
    'test QR base URL' => strpos($functions, "http://waagensteuerung.local/waage-test") !== false,
];

$failed = 0;
foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS: ' : 'FAIL: '), $name, PHP_EOL;
    if (!$ok) $failed++;
}

if ($failed) {
    echo "RESULT: {$failed} checks failed", PHP_EOL;
    exit(1);
}

echo 'RESULT: '.count($checks).' checks passed', PHP_EOL;
