<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$checks = [
    'settings tab' => [file_get_contents($root.'/settings.php'), "tab==='grossanzeige'"],
    'token generation' => [file_get_contents($root.'/settings.php'), "grossanzeige_api_token_hash"],
    'display address' => [file_get_contents($root.'/settings.php'), "grossanzeige_address"],
    'api header auth' => [file_get_contents($root.'/api/grossanzeige_status.php'), "HTTP_X_AJP_DISPLAY_TOKEN"],
    'read only states' => [file_get_contents($root.'/api/grossanzeige_status.php'), "'drive_on'"],
    'success state' => [file_get_contents($root.'/api/grossanzeige_status.php'), "'success'"],
];

$failed = 0;
foreach ($checks as $name => [$haystack, $needle]) {
    if (strpos((string)$haystack, $needle) === false) {
        echo "FAIL: {$name}\n";
        $failed++;
    } else {
        echo "PASS: {$name}\n";
    }
}

if ($failed > 0) {
    echo "RESULT: {$failed} checks failed\n";
    exit(1);
}

echo "RESULT: ".count($checks)." checks passed\n";
