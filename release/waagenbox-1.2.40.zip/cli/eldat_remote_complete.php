<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/rf_remote_support.php';

$args = array_slice($argv, 1);

if (
    count($args) !== 5 ||
    !preg_match('/^\d+$/', (string)$args[0]) ||
    !preg_match('/^\d+$/', (string)$args[1]) ||
    !preg_match('/^\d+$/', (string)$args[2])
) {
    fwrite(
        STDERR,
        "Verwendung: php cli/eldat_remote_complete.php " .
        "<owner_id> <remote_id> <vehicle_id> <trigger> <started_at>" .
        PHP_EOL
    );
    exit(64);
}

$ownerId = (int)$args[0];
$expectedRemoteId = (int)$args[1];
$expectedVehicleId = (int)$args[2];
$expectedTrigger = trim((string)$args[3]);
$expectedStartedAt = trim((string)$args[4]);

if (
    $ownerId <= 0 ||
    $expectedRemoteId <= 0 ||
    $expectedVehicleId <= 0 ||
    !in_array(
        $expectedTrigger,
        ['eldat', 'eldat_first_pass', 'eldat_first_weight'],
        true
    ) ||
    !preg_match(
        '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
        $expectedStartedAt
    )
) {
    fwrite(STDERR, "Ungültiger ELDAT-Abschlussauftrag." . PHP_EOL);
    exit(64);
}

$pdo = db();

/*
 * Alle Waagenfunktionen arbeiten besitzerbezogen. Deshalb muss der
 * Hintergrundprozess denselben Kontext setzen wie der ELDAT-Trigger.
 */
rfRemoteUseOwnerContext($pdo, $ownerId);

$pending = pendingWeighing();

if (!$pending) {
    fwrite(STDOUT, "ELDAT Abschluss: keine laufende Wiegung." . PHP_EOL);
    exit(2);
}

$trigger = (string)($pending['trigger_type'] ?? '');

$pendingRemoteId = (int)($pending['remote_id'] ?? 0);
$pendingVehicleId = (int)($pending['vehicle_id'] ?? 0);
$pendingStartedAt = (string)($pending['started_at'] ?? '');

if (
    $pendingRemoteId !== $expectedRemoteId ||
    $pendingVehicleId !== $expectedVehicleId ||
    $trigger !== $expectedTrigger ||
    $pendingStartedAt !== $expectedStartedAt
) {
    fwrite(
        STDOUT,
        "ELDAT Abschluss: Auftrag ist nicht mehr aktuell." . PHP_EOL
    );
    exit(2);
}

if (
    $trigger !== 'eldat' &&
    $trigger !== 'eldat_first_pass' &&
    $trigger !== 'eldat_first_weight'
) {
    fwrite(
        STDOUT,
        "ELDAT Abschluss: ignoriert (Trigger {$trigger})." . PHP_EOL
    );
    exit(2);
}

$weight = currentWeight();

if ($weight <= 0) {
    fwrite(STDOUT, "ELDAT Abschluss: noch kein gültiges Gewicht." . PHP_EOL);
    exit(2);
}

try {
    if ($trigger === 'eldat_first_pass') {
        $result = capturePendingFirstPass($weight);

        fwrite(
            STDOUT,
            'ELDAT Abschluss erste Überfahrt: ' .
            json_encode(
                $result,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) .
            PHP_EOL
        );
        exit(0);
    }

    if ($trigger === 'eldat_first_weight') {
        $vehicleId = (int)($pending['vehicle_id'] ?? 0);

        $result = completeVehicleFirstWeight($weight, $vehicleId);

        fwrite(
            STDOUT,
            'ELDAT Abschluss Erstgewicht: ' .
            json_encode(
                $result,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) .
            PHP_EOL
        );
        exit(0);
    }

    $weighingId = completePendingWeighing($weight);

    fwrite(
        STDOUT,
        "ELDAT Abschluss Wiegung: Wiegeschein-ID {$weighingId}." . PHP_EOL
    );
    exit(0);

} catch (Throwable $e) {
    fwrite(
        STDERR,
        "ELDAT Abschluss fehlgeschlagen: " . $e->getMessage() . PHP_EOL
    );
    exit(3);
}
