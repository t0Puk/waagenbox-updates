<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/rf_remote_support.php';

$args = array_slice($argv, 1);
$dryRun = in_array('--dry-run', $args, true);
$args = array_values(array_filter(
    $args,
    static fn(string $arg): bool => $arg !== '--dry-run'
));

if (count($args) !== 2) {
    fwrite(
        STDERR,
        "Verwendung: php cli/eldat_remote_trigger.php <sender> <taste> [--dry-run]" . PHP_EOL
    );
    exit(64);
}

$sender = strtolower(trim((string)$args[0]));
$button = strtoupper(trim((string)$args[1]));

if (!preg_match('/^[0-9a-f]{1,32}$/', $sender)) {
    fwrite(STDERR, "Ungültige ELDAT-Senderkennung." . PHP_EOL);
    exit(64);
}

if (!preg_match('/^[A-D]$/', $button)) {
    fwrite(STDERR, "Ungültige ELDAT-Taste." . PHP_EOL);
    exit(64);
}

$pdo = db();

$s = $pdo->prepare(
    'SELECT
        r.id AS remote_id,
        r.owner_user_id,
        r.active,
        r.vehicle_id,
        r.eldat_weigh_button,
        r.eldat_tare_button,
        v.first_weight,
        v.active AS vehicle_active
     FROM remotes r
     LEFT JOIN vehicles v
       ON v.id=r.vehicle_id
      AND v.owner_user_id=r.owner_user_id
     WHERE r.eldat_sender=?
     LIMIT 2'
);
$s->execute([$sender]);
$matches = $s->fetchAll();

if (count($matches) === 0) {
    fwrite(STDOUT, "ELDAT {$sender}/{$button}: ignoriert (unknown)" . PHP_EOL);
    exit(2);
}

if (count($matches) > 1) {
    fwrite(STDERR, "ELDAT {$sender}: Sender ist nicht eindeutig zugeordnet." . PHP_EOL);
    exit(3);
}

$remote = $matches[0];

if (
    (int)$remote['active'] !== 1 ||
    (int)($remote['vehicle_active'] ?? 0) !== 1
) {
    fwrite(STDERR, "ELDAT {$sender}: Fernbedienung oder Fahrzeug ist nicht aktiv." . PHP_EOL);
    exit(3);
}

$vehicleId = (int)($remote['vehicle_id'] ?? 0);
if ($vehicleId <= 0) {
    fwrite(STDERR, "ELDAT {$sender}: Kein Fahrzeug zugeordnet." . PHP_EOL);
    exit(3);
}

$ownerId = (int)$remote['owner_user_id'];
$remoteId = (int)$remote['remote_id'];
$weighButton = strtoupper((string)($remote['eldat_weigh_button'] ?? ''));
$tareButton = strtoupper((string)($remote['eldat_tare_button'] ?? ''));

if ($button !== $weighButton && ($tareButton === '' || $button !== $tareButton)) {
    fwrite(STDOUT, "ELDAT {$sender}/{$button}: ignoriert (Taste nicht zugeordnet)" . PHP_EOL);
    exit(2);
}

/*
 * Ab hier wird der Besitzerkontext benötigt, damit die vorhandene
 * Waagenbox-Logik exakt auf den Besitzer der Fernbedienung arbeitet.
 */
rfRemoteUseOwnerContext($pdo, $ownerId);

if ($button === $weighButton) {
    $firstWeight = (float)($remote['first_weight'] ?? 0);

    if ($firstWeight <= 0) {
        fwrite(
            STDOUT,
            "ELDAT {$sender}/{$button}: ignoriert (kein Erstgewicht vorhanden; zuerst Taste B verwenden)." .
            PHP_EOL
        );
        exit(2);
    }

    $fieldId = rfRemoteAssignment(
        $pdo,
        'remote_fields',
        'field_id',
        $remoteId,
        $ownerId
    );
    $customerId = rfRemoteAssignment(
        $pdo,
        'remote_customers',
        'customer_id',
        $remoteId,
        $ownerId
    );
    $productId = rfRemoteAssignment(
        $pdo,
        'remote_products',
        'product_id',
        $remoteId,
        $ownerId
    );

    if ($dryRun) {
        fwrite(
            STDOUT,
            'ELDAT DRY-RUN Wiegung: ' .
            json_encode([
                'sender'=>$sender,
                'button'=>$button,
                'remote_id'=>$remoteId,
                'vehicle_id'=>$vehicleId,
                'field_id'=>$fieldId,
                'customer_id'=>$customerId,
                'product_id'=>$productId,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
            PHP_EOL
        );
        exit(0);
    }

    try {
        $mode = startVehiclePass(
            $vehicleId,
            $remoteId,
            'eldat',
            $fieldId,
            $customerId,
            $productId
        );

        $pending = pendingWeighing();

        if (
            !$pending ||
            (int)($pending['remote_id'] ?? 0) !== $remoteId ||
            (int)($pending['vehicle_id'] ?? 0) !== $vehicleId ||
            !in_array(
                (string)($pending['trigger_type'] ?? ''),
                ['eldat', 'eldat_first_pass'],
                true
            ) ||
            (string)($pending['started_at'] ?? '') === ''
        ) {
            throw new RuntimeException(
                'ELDAT-Pending konnte nach dem Start nicht eindeutig gelesen werden.'
            );
        }

        startDiniPendingWorker();

        fwrite(
            STDOUT,
            "ELDAT {$sender}/{$button}: Wiegung gestartet ({$mode})." . PHP_EOL
        );

        if (empty(diniConfig()['enabled'])) {
            fwrite(
                STDOUT,
                'ELDAT_JOB:' .
                json_encode([
                    'owner_id'=>$ownerId,
                    'remote_id'=>$remoteId,
                    'vehicle_id'=>$vehicleId,
                    'trigger'=>(string)$pending['trigger_type'],
                    'started_at'=>(string)$pending['started_at'],
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
                PHP_EOL
            );
        }

        exit(0);
    } catch (Throwable $e) {
        clearPendingWeighing();
        fwrite(
            STDERR,
            "ELDAT {$sender}/{$button}: " . $e->getMessage() . PHP_EOL
        );
        exit(3);
    }
}

/*
 * Zweite Taste: persistentes Erst-/Leergewicht.
 *
 * Existiert bereits ein Erstgewicht, wird die Taste absichtlich ohne
 * Fehlermeldung ignoriert. Nach Löschen des Erstgewichts funktioniert
 * dieselbe Taste automatisch wieder.
 */
if ($tareButton !== '' && $button === $tareButton) {
    $firstWeight = (float)($remote['first_weight'] ?? 0);

    if ($firstWeight > 0) {
        fwrite(
            STDOUT,
            "ELDAT {$sender}/{$button}: ignoriert (Erstgewicht bereits vorhanden)." . PHP_EOL
        );
        exit(0);
    }

    if ($dryRun) {
        fwrite(
            STDOUT,
            'ELDAT DRY-RUN Erstgewicht: ' .
            json_encode([
                'sender'=>$sender,
                'button'=>$button,
                'remote_id'=>$remoteId,
                'vehicle_id'=>$vehicleId,
                'first_weight'=>$firstWeight,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
            PHP_EOL
        );
        exit(0);
    }

    if (pendingWeighing()) {
        fwrite(STDERR, "ELDAT {$sender}/{$button}: Es läuft bereits eine Wiegung." . PHP_EOL);
        exit(3);
    }

    if (currentWeight() > 0) {
        fwrite(
            STDERR,
            "ELDAT {$sender}/{$button}: Die Waage muss vor der Erstgewichtserfassung leer sein." . PHP_EOL
        );
        exit(3);
    }

    try {
        $q = $pdo->prepare(
            'INSERT INTO weighing_state
             (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at)
             VALUES (?,1,0,?,?,NULL,NULL,NULL,?,NOW())'
        );
        $q->execute([
            $ownerId,
            $vehicleId,
            $remoteId,
            'eldat_first_weight'
        ]);

        startDiniPendingWorker();

        $pending = pendingWeighing();

        if (
            !$pending ||
            (int)($pending['remote_id'] ?? 0) !== $remoteId ||
            (int)($pending['vehicle_id'] ?? 0) !== $vehicleId ||
            (string)($pending['trigger_type'] ?? '') !== 'eldat_first_weight' ||
            (string)($pending['started_at'] ?? '') === ''
        ) {
            throw new RuntimeException(
                'ELDAT-Pending konnte nach dem Start der Erstgewichtserfassung nicht eindeutig gelesen werden.'
            );
        }

        fwrite(
            STDOUT,
            "ELDAT {$sender}/{$button}: Erstgewichtserfassung gestartet." . PHP_EOL
        );

        if (empty(diniConfig()['enabled'])) {
            fwrite(
                STDOUT,
                'ELDAT_JOB:' .
                json_encode([
                    'owner_id'=>$ownerId,
                    'remote_id'=>$remoteId,
                    'vehicle_id'=>$vehicleId,
                    'trigger'=>(string)$pending['trigger_type'],
                    'started_at'=>(string)$pending['started_at'],
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) .
                PHP_EOL
            );
        }

        exit(0);
    } catch (Throwable $e) {
        clearPendingWeighing();
        fwrite(
            STDERR,
            "ELDAT {$sender}/{$button}: Erstgewichtserfassung konnte nicht gestartet werden: " .
            $e->getMessage() . PHP_EOL
        );
        exit(3);
    }
}

fwrite(STDOUT, "ELDAT {$sender}/{$button}: ignoriert." . PHP_EOL);
exit(2);
