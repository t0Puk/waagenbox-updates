<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
$token=trim((string)($_GET['t']??''));
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
if(useMobileContextByToken($token)===null){http_response_code(404);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
$pdo=db();
function getMobileSetting(PDO $pdo,int $ownerId,string $key,string $default=''): string { $q=$pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1'); $q->execute([$ownerId,$key]); $v=$q->fetchColumn(); return $v===false?$default:(string)$v; }
$s=$pdo->prepare('SELECT r.id,r.active,r.vehicle_id,v.first_weight,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.mobile_token=? LIMIT 1');
$s->execute([currentOwnerId(),$token]);$r=$s->fetch();
if(!$r||(int)$r['active']!==1||(int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Diese mobile Fernbedienung ist nicht aktiv.']);exit;}
$p=pendingWeighing();
$pendingForThis=$p && (int)($p['remote_id']??0)===(int)$r['id'];
$pendingIsFirst=$pendingForThis && str_ends_with((string)($p['trigger_type']??''),'_first_pass');
$open=openVehicleWeighing((int)$r['vehicle_id']);

$lastStmt=$pdo->prepare(
    'SELECT id,net_weight
       FROM weighings
      WHERE owner_user_id=?
        AND vehicle_id=?
        AND remote_id=?
      ORDER BY id DESC
      LIMIT 1'
);
$lastStmt->execute([
    currentOwnerId(),
    (int)$r['vehicle_id'],
    (int)$r['id']
]);
$lastWeighing=$lastStmt->fetch();

echo json_encode([
    'ok'=>true,
    'dynamic_dini'=>!empty(diniConfig()['enabled']),
    'current_weight'=>currentWeight(),
    'pending'=>$pendingForThis,
    'pending_mode'=>$pendingForThis ? ($pendingIsFirst?'first':'second') : null,
    'gps_enabled'=>getMobileSetting($pdo,(int)$r['owner_user_id'],'gps_enabled','0')==='1',
    'first_weight'=>$pendingForThis?(float)$p['first_weight']:0.0,
    'vehicle_first_weight'=>(float)$r['first_weight'],
    'open_first_weight'=>$open?(float)$open['first_weight']:0.0,
    'has_open_weighing'=>(bool)$open,
    'last_weighing_id'=>$lastWeighing?(int)$lastWeighing['id']:0,
    'last_net_weight'=>$lastWeighing?(float)$lastWeighing['net_weight']:0.0
],JSON_UNESCAPED_UNICODE);
