<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');

function mobileFirstInput(): array {
    $d=json_decode(file_get_contents('php://input'),true);
    return is_array($d)?$d:$_POST;
}
function mobileFirstSetting(PDO $pdo,int $ownerId,string $key,string $default=''): string {
    $s=$pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
    $s->execute([$ownerId,$key]);
    $v=$s->fetchColumn();
    return $v===false?$default:(string)$v;
}
function mobileFirstDistance(float $a,float $b,float $c,float $d): float {
    $r=6371000;
    $p1=deg2rad($a);$p2=deg2rad($c);
    $dp=deg2rad($c-$a);$dl=deg2rad($d-$b);
    $x=sin($dp/2)**2+cos($p1)*cos($p2)*sin($dl/2)**2;
    return 2*$r*asin(min(1,sqrt($x)));
}
function mobileFirstReply(array $payload,int $status=200): never {
    http_response_code($status);
    echo json_encode($payload,JSON_UNESCAPED_UNICODE);
    exit;
}

$d=mobileFirstInput();
$action=(string)($d['action']??'start');
$token=trim((string)($d['token']??''));
$lat=(float)($d['latitude']??0);
$lon=(float)($d['longitude']??0);
$acc=(float)($d['accuracy']??99999);

if($token==='') mobileFirstReply(['ok'=>false,'message'=>'Ungültiger Token.'],400);
if(!in_array($action,['start','complete'],true)) mobileFirstReply(['ok'=>false,'message'=>'Ungültige Aktion.'],400);

$pdo=db();
$s=$pdo->prepare(
    'SELECT r.id AS remote_id,r.owner_user_id,r.active,r.vehicle_id,
            v.plate,v.first_weight,v.active AS vehicle_active
     FROM remotes r
     LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id
     WHERE r.mobile_token=? LIMIT 1'
);
$s->execute([$token]);
$r=$s->fetch();

if(!$r || (int)$r['active']!==1 || (int)($r['vehicle_active']??0)!==1 || (int)($r['vehicle_id']??0)<=0){
    mobileFirstReply(['ok'=>false,'message'=>'Fernbedienung oder Fahrzeug ist nicht aktiv.'],403);
}

$ownerId=(int)$r['owner_user_id'];
$remoteId=(int)$r['remote_id'];
$vehicleId=(int)$r['vehicle_id'];
useMobileContextByToken($token);

if($action==='complete'){
    if(!empty(diniConfig()['enabled'])){
        mobileFirstReply([
            'ok'=>false,
            'message'=>'Die dynamische DINI-Erstgewichtserfassung wird automatisch abgeschlossen.'
        ],409);
    }

    $p=pendingWeighing();
    if(!$p || ($p['trigger_type']??'')!=='mobile_first_weight' ||
       (int)($p['remote_id']??0)!==$remoteId || (int)($p['vehicle_id']??0)!==$vehicleId){
        mobileFirstReply(['ok'=>false,'message'=>'Es läuft keine Leergewichtserfassung für dieses Fahrzeug.'],409);
    }

    $weight=currentWeight();

    try{
        $result=completeVehicleFirstWeight($weight,$vehicleId);
    }catch(Throwable $e){
        mobileFirstReply(['ok'=>false,'message'=>$e->getMessage()],409);
    }

    mobileFirstReply([
        'ok'=>true,
        'message'=>!empty($result['already_present'])
            ? 'Leergewicht ist bereits gespeichert.'
            : 'Leergewicht / Erstgewicht wurde gespeichert.',
        'first_weight'=>(float)$result['first_weight'],
        'vehicle_id'=>(int)$result['vehicle_id'],
        'plate'=>(string)$result['plate']
    ]);
}

if((float)$r['first_weight']>0){
    mobileFirstReply(['ok'=>false,'message'=>'Für dieses Fahrzeug ist bereits ein Erstgewicht hinterlegt.'],409);
}

$gpsEnabled=mobileFirstSetting($pdo,$ownerId,'gps_enabled','0')==='1';
if($gpsEnabled){
    if($lat<-90||$lat>90||$lon<-180||$lon>180){
        mobileFirstReply(['ok'=>false,'message'=>'Ungültige Standortdaten.'],400);
    }
    $scaleLat=mobileFirstSetting($pdo,$ownerId,'gps_lat','');
    $scaleLon=mobileFirstSetting($pdo,$ownerId,'gps_lon','');
    if($scaleLat===''||$scaleLon===''){
        mobileFirstReply(['ok'=>false,'message'=>'Der Standort der Waage ist noch nicht konfiguriert.'],503);
    }
    $dist=mobileFirstDistance($lat,$lon,(float)$scaleLat,(float)$scaleLon);
    $radius=max(1,(float)mobileFirstSetting($pdo,$ownerId,'gps_radius_m','50'));
    $maxAcc=max(1,(float)mobileFirstSetting($pdo,$ownerId,'gps_accuracy_m','50'));
    if($acc>$maxAcc) mobileFirstReply(['ok'=>false,'message'=>'GPS-Genauigkeit zu schlecht.'],403);
    if($dist>$radius) mobileFirstReply(['ok'=>false,'message'=>'Du bist zu weit von der Waage entfernt.'],403);
}

if(pendingWeighing()){
    mobileFirstReply(['ok'=>false,'message'=>'Es läuft bereits eine Wiegung.'],409);
}

if(empty(diniConfig()['enabled']) && currentWeight()>0){
    mobileFirstReply(['ok'=>false,'message'=>'Die Waage muss vor dem Start der Leergewichtserfassung leer sein.'],409);
}

try{
    $q=$pdo->prepare(
        'INSERT INTO weighing_state
         (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at)
         VALUES (?,1,0,?,?,NULL,NULL,NULL,?,NOW())'
    );
    $q->execute([$ownerId,$vehicleId,$remoteId,'mobile_first_weight']);
    startDiniPendingWorker();
}catch(Throwable $e){
    clearPendingWeighing();
    mobileFirstReply(['ok'=>false,'message'=>'Leergewichtserfassung konnte nicht gestartet werden.'],500);
}

mobileFirstReply([
    'ok'=>true,
    'waiting'=>true,
    'message'=>'Leergewichtserfassung gestartet. Bitte jetzt mit dem Fahrzeug über die Waage fahren.'
]);
