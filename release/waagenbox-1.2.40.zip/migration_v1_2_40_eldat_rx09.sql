-- AJP Waagenbox 1.2.40
-- Unterstützung für ELDAT RX09 / Easywave Handsender.
--
-- Ein bestehender Fernbedienungs-Datensatz kann weiterhin QR-Fernbedienung
-- und bisherigen 433-MHz-Code verwenden. Die ELDAT-Zuordnung wird deshalb
-- ergänzend und unabhängig in eigenen Spalten gespeichert.

ALTER TABLE remotes
    MODIFY COLUMN code VARCHAR(100) NULL,
    ADD COLUMN IF NOT EXISTS eldat_sender VARCHAR(32) NULL AFTER code,
    ADD COLUMN IF NOT EXISTS eldat_weigh_button VARCHAR(1) NULL AFTER eldat_sender,
    ADD COLUMN IF NOT EXISTS eldat_tare_button VARCHAR(1) NULL AFTER eldat_weigh_button;

CREATE UNIQUE INDEX IF NOT EXISTS uq_remote_owner_eldat_sender
    ON remotes(owner_user_id, eldat_sender);
