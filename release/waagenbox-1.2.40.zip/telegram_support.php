<?php
declare(strict_types=1);

function telegramEnabled(): bool {
    return appSetting('telegram_enabled','0')==='1';
}

function telegramBotToken(): string {
    return trim(appSetting('telegram_bot_token',''));
}

function telegramChatId(): string {
    return trim(appSetting('telegram_chat_id',''));
}

function telegramConfigured(): bool {
    return telegramBotToken()!=='' && telegramChatId()!=='';
}

function telegramSendMessage(string $message): array {
    $token=telegramBotToken();
    $chatId=telegramChatId();
    if($token===''||$chatId==='') return ['ok'=>false,'error'=>'not_configured','message'=>'Telegram ist noch nicht vollständig konfiguriert.'];

    $url='https://api.telegram.org/bot'.$token.'/sendMessage';
    $payload=http_build_query([
        'chat_id'=>$chatId,
        'text'=>$message,
        'disable_web_page_preview'=>'true',
    ]);

    $body=false;
    $code=0;
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>$payload,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>4,
            CURLOPT_TIMEOUT=>8,
            CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_USERAGENT=>'AJP-Waagenbox/'.APP_VERSION,
        ]);
        $body=curl_exec($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $err=(string)curl_error($ch);
        curl_close($ch);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Telegram nicht erreichbar: '.$err];
    }else{
        $ctx=stream_context_create([
            'http'=>[
                'method'=>'POST',
                'header'=>"Content-Type: application/x-www-form-urlencoded\r\n",
                'content'=>$payload,
                'timeout'=>8,
                'ignore_errors'=>true,
            ],
            'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true],
        ]);
        $body=@file_get_contents($url,false,$ctx);
        if($body===false) return ['ok'=>false,'error'=>'connection_failed','message'=>'Telegram nicht erreichbar.'];
        foreach($http_response_header??[] as $line){
            if(preg_match('~^HTTP/\S+\s+(\d+)~',$line,$m)){ $code=(int)$m[1]; break; }
        }
    }

    $data=json_decode((string)$body,true);
    if($code<200||$code>=300||!is_array($data)||empty($data['ok'])){
        return ['ok'=>false,'error'=>'telegram_error','message'=>'Telegram hat die Nachricht nicht bestätigt.','http_status'=>$code];
    }
    return ['ok'=>true];
}

function feldmanagerTelegramOutboundDecision(
    bool $connected,
    string $notifyState,
    int $failureSince,
    int $now,
    int $graceSeconds=120
): array {
    if($notifyState===''){
        return [
            'action'=>'initialize',
            'notify_state'=>'connected',
            'failure_since'=>$connected ? 0 : $now,
        ];
    }

    if($connected){
        if($notifyState==='error'){
            return [
                'action'=>'recovery',
                'notify_state'=>$notifyState,
                'failure_since'=>0,
            ];
        }

        return [
            'action'=>'none',
            'notify_state'=>$notifyState,
            'failure_since'=>0,
        ];
    }

    if($failureSince<=0 || $failureSince>$now){
        return [
            'action'=>'wait',
            'notify_state'=>$notifyState,
            'failure_since'=>$now,
        ];
    }

    if($notifyState==='error'){
        return [
            'action'=>'none',
            'notify_state'=>$notifyState,
            'failure_since'=>$failureSince,
        ];
    }

    if(($now-$failureSince)<$graceSeconds){
        return [
            'action'=>'wait',
            'notify_state'=>$notifyState,
            'failure_since'=>$failureSince,
        ];
    }

    return [
        'action'=>'outage',
        'notify_state'=>$notifyState,
        'failure_since'=>$failureSince,
    ];
}

function feldmanagerTelegramHandleOutboundState(bool $connected, ?int $now=null): void {
    if(!telegramEnabled() || !telegramConfigured() || !feldmanagerEnabled()) return;

    $notifyState=appSetting('feldmanager_outbound_notify_state','');
    $failureSince=(int)appSetting('feldmanager_outbound_failure_since','0');
    $now ??= time();

    $decision=feldmanagerTelegramOutboundDecision(
        $connected,
        $notifyState,
        $failureSince,
        $now
    );

    if($decision['notify_state']!==$notifyState){
        saveAppSetting('feldmanager_outbound_notify_state',(string)$decision['notify_state']);
    }
    if((int)$decision['failure_since']!==$failureSince){
        saveAppSetting('feldmanager_outbound_failure_since',(string)$decision['failure_since']);
    }

    if($decision['action']==='outage'){
        $brand=appSetting('brand_name','AJP WAAGE');
        $message="🚨 Verbindungsstörung\n".$brand."\nWaagenbox → Feldmanager ist seit mindestens 2 Minuten nicht erreichbar.\nBitte Schlagzuordnung prüfen und bei Bedarf manuell reagieren.";
        $sent=telegramSendMessage($message);

        if(!empty($sent['ok'])){
            saveAppSetting('feldmanager_outbound_notify_state','error');
        }else{
            error_log('Waagenbox Telegram: '.(string)($sent['message']??'Nachricht konnte nicht gesendet werden.'));
        }
        return;
    }

    if($decision['action']==='recovery'){
        $brand=appSetting('brand_name','AJP WAAGE');
        $message="✅ Verbindung wiederhergestellt\n".$brand."\nWaagenbox → Feldmanager ist wieder verbunden.";
        $sent=telegramSendMessage($message);

        if(!empty($sent['ok'])){
            saveAppSetting('feldmanager_outbound_notify_state','connected');
        }else{
            error_log('Waagenbox Telegram: '.(string)($sent['message']??'Nachricht konnte nicht gesendet werden.'));
        }
    }
}
