# AJP Waagenbox – Release 1.2.39

Stand: 2026-09-25

## Status

Produktiv veröffentlicht, über die normale signierte Update-Funktion installiert und am 25.09.2026 praktisch abgenommen.

- Source-Commit: `4c3968b6a7aa3ddb9d5dda590385d6142fbc62d0`
- unveränderlicher Release-Branch: `release/1.2.39`
- Update-Repository-Commit: `adc080f`
- Paket-SHA256: `043f9463b4ac63032bb5e0c2ae37cffcd9aa94d8df555dba870118e33e168894`
- Paketgröße: 298833 Bytes
- Signatur vor Veröffentlichung lokal erfolgreich mit `Verified OK` geprüft
- veröffentlichte ZIP nach dem Push bytegenau erneut geladen und mit demselben SHA256 bestätigt

## Basis

- produktiv freigegebener Ausgangspunkt: `release/1.2.38`
- Entwicklungsbranch: `feature/1.2.39-grossanzeige`
- Zielversion: `1.2.39`
- Produktivpfad `/var/www/waage` blieb während der Entwicklung unverändert
- Test-Webpfad: `/var/www/waage-test`
- Test-Worktree: `/home/pi/Waagenbox-test`

## Hauptänderungen

### Einheitlicher Wägeablauf mit mehreren offenen Fahrzeugwiegungen

Die Waagenbox trennt jetzt die aktuell physisch laufende Überfahrt von dauerhaft offenen Fahrzeugwiegungen.

- `weighing_state` enthält nur die aktuell laufende Überfahrt auf der Waage.
- `open_vehicle_weighings` speichert offene erste Überfahrten fahrzeugbezogen.
- Mehrere Fahrzeuge können gleichzeitig eine offene erste Überfahrt besitzen.
- Pro Fahrzeug ist höchstens eine offene Wiegung möglich.
- Andere Fahrzeuge können gewogen werden, während ein Fahrzeug zum Laden/Entladen unterwegs ist.
- Das erste gemessene Gewicht ist chronologisch die erste Überfahrt und nicht automatisch das Leergewicht.
- Nach der zweiten Überfahrt gilt:
  - Tara = kleineres der beiden Gewichte;
  - Brutto = größeres der beiden Gewichte;
  - Netto = Brutto minus Tara.
- Bei einem Stammfahrzeug mit bereits gespeichertem Leergewicht genügt weiterhin eine aktuelle Überfahrt.
- Temporär angelegte externe Fahrzeuge verwenden bewusst kein dauerhaft gespeichertes Leergewicht.

Datenbankmigration:

- `migration_v1_2_39_open_vehicle_weighings.sql`
- `migration_v1_2_39_manual_external.sql`

### Manuelle externe Fahrzeuge

Für externe, nicht dauerhaft angelegte Fahrzeuge kann in der manuellen Wiegung eine Bezeichnung bzw. ein Kennzeichen eingetragen werden.

- temporäre Fahrzeuge sind als `manual_external` markiert;
- sie erscheinen nicht in der normalen Fahrzeugübersicht;
- sie bekommen kein dauerhaftes Leergewicht;
- eine zweite Überfahrt kann über dieselbe Bezeichnung wieder zugeordnet werden.

### QR-/Mobile-Wiegung auf einheitlichen Ablauf umgestellt

QR-Wiegungen verwenden denselben Wägekern wie manuelle Wiegungen.

- Start über `startVehiclePass()`;
- erste Überfahrt wird fahrzeugbezogen offen gespeichert;
- zweite Überfahrt bzw. Wiegung mit gespeichertem Leergewicht wird über denselben Abschlussweg beendet;
- QR-Status unterscheidet erste und zweite Überfahrt;
- die mobile Oberfläche verwendet einen einheitlichen Startablauf.

### Schutz vor QR-/Web-Doppelabschluss

Die geöffnete manuelle Wiegeseite beendet nur noch manuell gestartete Überfahrten automatisch.

QR-/Mobile-Wiegungen werden ausschließlich über den mobilen Abschluss-Endpunkt beendet. Dadurch entsteht nach einer bereits erfolgreich gespeicherten QR-Wiegung nicht mehr die irreführende Fehlermeldung:

`Es ist keine laufende Wiegung vorhanden.`

Regressionstest:

- `tests/qr_web_double_complete_regression_test.php`

### Großanzeigen-Schnittstelle

Die Waagenbox stellt eine token-geschützte JSON-Schnittstelle für eine separate AJP Großanzeige bereit:

- `api/grossanzeige_status.php`

Die Großanzeige ist nur ein Ausgabegerät. Ein Ausfall darf die Wägefunktion nicht blockieren.

Übertragen werden unter anderem:

- semantischer Anzeigezustand;
- Anzeigegewicht;
- Gewichtsart-Schlüssel;
- Status für Aktivierung/Deaktivierung der Anzeige.

Gewichtsarten:

- Erstgewicht;
- Zweitgewicht;
- Bruttogewicht;
- Netto Gewicht.

Beim Zustand `drive_on` wird bewusst noch keine Gewichtsart übertragen. Die Gewichtsart erscheint erst, wenn ein tatsächliches Gewicht verarbeitet wird.

### Einstellbare Anzeigezeiten

Unter **Einstellungen → Großanzeige** sind getrennt konfigurierbar:

- Verarbeitung 1. Gewicht;
- Verarbeitung 2. Gewicht;
- Anzeige Netto/Abschluss.

### Großanzeige von der Waagenbox aus verwalten

Unter **Einstellungen → Großanzeige** stehen zusätzlich zur Verfügung:

- Großanzeige aktivieren/deaktivieren;
- dynamischer Link zur Administrationsseite der Großanzeige;
- dynamischer Link direkt zur Displayseite.

Die Links werden aus der gespeicherten IP-Adresse bzw. dem Hostnamen erzeugt. Ein Standortwechsel erfordert deshalb keine Quellcodeänderung.

### Dashboard-Verbindungsstatus zur Großanzeige

Unter dem Waagenstatus zeigt das Dashboard zusätzlich:

`Waagenbox → Großanzeige`

Mögliche Zustände:

- Verbunden;
- Nicht erreichbar;
- Nicht konfiguriert;
- Aus.

Praktisch geprüft wurde insbesondere:

- Großanzeigen-Raspberry neu gestartet;
- Status wechselte auf `Nicht erreichbar`;
- nach abgeschlossenem Boot automatisch wieder auf `Verbunden`;
- HDMI-Anzeige startete danach selbstständig wieder.

## Separate AJP Großanzeige

Das eigenständige Displayprojekt befindet sich in:

`t0Puk/Grossfeldanzeige_Waagenbox`

Praktisch getestet:

- Raspberry Pi 2 / Debian 13 Trixie;
- nginx + Flask;
- Cog/WPE über DRM auf HDMI;
- automatischer Start nach Reboot;
- Liveanbindung an die Waagenbox;
- Offline-Anzeige;
- Testbetrieb;
- einstellbare Anzeigezustände;
- editierbare Gewichtsbezeichnungen und Schriftgrößen;
- Passwortschutz der Administration;
- 15-Minuten-Inaktivitätslogout;
- Neustart/Herunterfahren aus der Administration;
- Konfigurationsbackup erstellen, herunterladen und wiederherstellen;
- Aktivieren/Deaktivieren durch die Waagenbox.

Die Großanzeigen-Software selbst ist ein separates Repository und nicht Bestandteil des Waagenbox-Update-ZIP.

## Praktische Abnahme 25.09.2026

Erfolgreich auf der Testinstanz geprüft:

- manuelle Wiegungen;
- QR-Code-Wiegungen;
- erste und zweite Überfahrt;
- Rückkehr in Standby;
- Nettoanzeige;
- Fahrzeug mit gespeichertem Leergewicht;
- parallele/offene fahrzeugbezogene Erstwiegungen;
- temporäres externes Fahrzeug ohne Persistieren eines Leergewichts;
- keine erneute falsche QR-Doppelabschlussmeldung;
- Großanzeigen-Livebetrieb;
- Erstgewicht/Zweitgewicht/Netto Gewicht auf der Großanzeige;
- Gewichtsart beim Auffahren noch ausgeblendet;
- editierbare Texte und Schriftgrößen;
- Großanzeige nach Neustart wieder in Standby;
- Großanzeigen-Verbindungsstatus auf dem Waagenbox-Dashboard;
- Fernaktivierung/-deaktivierung der Großanzeige;
- dynamische Direktlinks;
- Erreichbarkeitsstatus bei Reboot korrekt.

## Produktionsschutz und Release-Abschluss

- keine direkte Entwicklungsänderung an `/var/www/waage`;
- Produktivinstallation ausschließlich über die normale signierte Update-Funktion;
- privater Release-Schlüssel blieb ausschließlich auf dem lokalen Windows-Rechner;
- finaler Release-Test `tests/release_1_2_39_test.php`: 27 Checks bestanden;
- QR-Doppelabschluss-Regression bestanden;
- PHP-Syntax aller getrackten PHP-Dateien ohne Fehler;
- Python-Syntaxprüfungen ohne Fehler;
- `git diff --check` ohne Beanstandung;
- Release-Preflight erfolgreich, 179 exportierte Pfade geprüft;
- Release-Branch `release/1.2.39` zeigt unverändert auf den exakt getesteten Source-Commit;
- das signierte Paket wurde lokal geprüft, veröffentlicht und danach nochmals bytegenau über GitHub verifiziert.

## Produktive Nachprüfung

Nach erfolgreicher Installation wurden auf der produktiven Waagenbox insbesondere geprüft:

- Verbindung zur separaten Großanzeige mit neu erzeugtem produktivem API-Token;
- QR-/Mobile-Wiegung;
- manuelle Wiegung;
- Erst- und Zweitüberfahrt;
- Fahrzeug mit gespeichertem Leergewicht;
- Anzeige von Erstgewicht, Zweitgewicht, Bruttogewicht und Netto Gewicht;
- korrekte Statusübergänge der Großanzeige;
- Rückkehr in Standby;
- Dashboard-Verbindungsstatus zur Großanzeige.

Zusätzlich wurden zwei produktive Alt-/Datenzustände bereinigt:

1. `mobile_remote_base_url` enthielt noch eine frühere Tailscale-Adresse. Der gespeicherte Override wurde geleert, sodass wieder der feste Standard `https://waage-ajp.de` verwendet wird. Die QR-Tokens blieben unverändert gültig.
2. Bei einer aktiven QR-Fernbedienung war das zugeordnete Fahrzeug deaktiviert. Da `mobile_remote.php` sowohl die Fernbedienung als auch das Fahrzeug auf `active=1` prüft, erschien korrekt die Meldung „Diese mobile Fernbedienung ist nicht aktiv.“ Nach Aktivierung des Fahrzeugs funktionierte die QR-Fernbedienung. Es war keine Codekorrektur nötig.
