# AJP Waagenbox – Release 1.2.40

Stand: 2026-10-06

## Status

Release-Kandidat. Auf der Testinstanz und mit realer DINI-/ELDAT-Hardware praktisch geprüft.

Die produktive Waagenbox bleibt bis zur Installation über die normale signierte Update-Funktion und anschließender Produktivabnahme auf Version 1.2.39.

## Basis

- produktiv freigegebener Ausgangspunkt: `release/1.2.39`
- dokumentierte Ausgangsbasis: `baseline/1.2.39-documented`
- Entwicklungsbranch: `feature/1.2.40-eldat-dini`
- Zielversion: `1.2.40`
- Produktivpfad `/var/www/waage` blieb während der Entwicklung unverändert
- Test-Webpfad: `/var/www/waage-test`
- Test-Worktree: `/home/pi/Waagenbox-test`

## Hauptänderungen

### ELDAT RX09 / Easywave

Version 1.2.40 integriert den ELDAT RX09 als zusätzliche Funkfernbedienung.

Verwendete Hardware:

- ELDAT RX09 / Easywave
- USB-Seriell-Gerät:
  `/dev/serial/by-id/usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0`
- Baudrate: 57600

Die Zuordnung erfolgt senderbezogen. Pro Fernbedienung können getrennt hinterlegt werden:

- ELDAT-Sender;
- Taste für normale Wiegung;
- Taste für Erstgewicht.

Die QR-Fernbedienung bleibt davon unabhängig erhalten.

Datenbankmigration:

- `migration_v1_2_40_eldat_rx09.sql`

Neue Felder in `remotes`:

- `eldat_sender`
- `eldat_weigh_button`
- `eldat_tare_button`

`code` ist für reine ELDAT-/QR-Fernbedienungen nullable.

Der Sender ist über `uq_remote_owner_eldat_sender` je Besitzer eindeutig.

### ELDAT Zwei-Tasten-Ablauf

Praktisch bestätigt:

- Taste A mit vorhandenem Erstgewicht startet die normale Wiegung;
- Taste A ohne Erstgewicht wird ignoriert;
- Taste B ohne Erstgewicht startet die Erstgewichtserfassung;
- Taste B mit vorhandenem Erstgewicht wird ignoriert;
- nach Löschen des Erstgewichts kann Taste B erneut verwendet werden;
- QR-Fernbedienungen funktionieren weiterhin mit und ohne vorhandenes Erstgewicht.

### Reale DINI-Argeo-3590ETKR-Integration

Die DINI-Anbindung wurde mit echter Hardware geprüft.

Verwendeter Netzwerkendpunkt im Testaufbau:

- Hi-Link HLK-RM04
- `192.168.16.254:8080`
- Raspberry-Zusatzadresse `192.168.16.200/24`

Bestätigter dynamischer Ablauf:

1. Waagenbox startet die Wiegung.
2. DINI erhält `KEYP37`.
3. Anschließend wird `KEYR` gesendet.
4. DINI zeigt „Warte auf Überfahrt“.
5. Fahrzeug fährt über die Waage.
6. Der abschließende dynamische Datensatz wird empfangen und ausgewertet.
7. Die Waagenbox verarbeitet das Ergebnis über ihren zentralen Wägeablauf.

Für beide physischen Überfahrten wird `KEYP37` verwendet.

`KEYP38` wird bewusst nicht verwendet, da dieser Weg am realen Gerät die Auswahl einer vorherigen Wiegung öffnet.

Der DINI-Worker verwendet ein Zeitfenster von 360 Sekunden, damit auch längere dynamische Überfahrten sicher abgeschlossen werden können.

### ELDAT → DINI

ELDAT-Wiegungen starten nach erfolgreicher Validierung direkt den DINI-Pending-Worker.

Dies gilt für:

- normale Wiegung;
- erste Überfahrt einer Zwei-Pass-Wiegung;
- persistente Erstgewichtserfassung.

Der ELDAT-Listener startet für den Abschluss einen separaten Worker. Der RX09-Listener bleibt dadurch frei für weitere Funktelegramme.

### Telegram-Verbindungsentprellung

Kurzzeitige Verbindungsunterbrechungen von Waagenbox → Feldmanager erzeugen nicht mehr sofort eine Telegram-Meldungsfolge aus „Störung“ und „wiederhergestellt“.

Für diese Richtung gilt:

- 120 Sekunden Karenzzeit;
- kurze Ausfälle bleiben still;
- erst nach mindestens 120 Sekunden wird die Störung gemeldet;
- eine Wiederherstellungsmeldung wird nur gesendet, wenn zuvor tatsächlich eine Störungsmeldung versendet wurde.

## Produktiver ELDAT-Systemdienst

Neu enthalten:

- `systemd/waagenbox-eldat-rx09.service`
- `install_eldat_rx09_systemd.sh`

Der Produktivdienst:

- läuft als `www-data`;
- erhält über `dialout` Zugriff auf den RX09;
- verwendet ausschließlich Pfade unter `/var/www/waage`;
- verwendet den gemeinsamen RF-Lernpfad `/run/waagenbox-rf`;
- erhält unter `ProtectSystem=strict` gezielten Schreibzugriff auf `/var/lib/waagebox/dini`.

Der bestehende 433-MHz-Dienst wird mit 1.2.40 nicht automatisch entfernt oder deaktiviert.

## Systeminstallation

Die normale signierte Update-Funktion installiert Anwendungscode und Datenbankmigration.

Der neue ELDAT-systemd-Dienst ist eine explizite Systemänderung und wird deshalb nicht still durch den normalen App-Updater eingerichtet.

Geplanter Produktivablauf:

1. Version 1.2.40 über die normale signierte Update-Funktion installieren.
2. Prüfen, dass die Datenbankmigration erfolgreich angewendet wurde.
3. Den ELDAT-Testdienst stoppen und deaktivieren, damit nur ein Prozess auf den RX09 zugreift.
4. Produktiven ELDAT-Dienst mit `install_eldat_rx09_systemd.sh` installieren.
5. Produktivdienst und RX09-Verbindung prüfen.
6. Bestehenden 433-MHz-Dienst zunächst aktiv lassen.
7. Reale ELDAT-/DINI- und QR-Wiegungen produktiv prüfen.

Der produktive ELDAT-Dienst darf nicht gestartet werden, solange der ELDAT-Testdienst noch auf denselben RX09 zugreift.

## Praktisch geprüfter Hardwarestand

Mit realer DINI-/ELDAT-Hardware erfolgreich geprüft:

- DINI-Start über `KEYP37` + `KEYR`;
- dynamischer DINI-Abschlussdatensatz;
- Zwei-Pass-Wiegung ohne gespeichertes Erstgewicht;
- Ein-Pass-Wiegung mit gespeichertem Erstgewicht;
- QR/Mobile → DINI mit Erstgewicht;
- QR/Mobile → DINI ohne Erstgewicht;
- ELDAT → DINI mit Erstgewicht;
- ELDAT-Erstgewichtserfassung;
- Wiederholungsdruck auf Erstgewichtstaste wird bei vorhandenem Erstgewicht ignoriert;
- normaler ELDAT-A-Pfad startet den DINI-Worker;
- Rückkehr in den normalen Waagenbox-Ablauf nach erfolgreichem Abschluss.

## Release-Prüfungen

Aktuell erfolgreich:

- `tests/release_1_2_40_test.php`: 25 Checks;
- `tests/telegram_debounce_test.php`: 18 Checks;
- `tests/dini_completion_dispatch_test.php`: 6 Checks;
- `tests/dini_worker_two_pass_test.php`: 12 Checks;
- `tests/eldat_systemd_installer_test.py`: 19 Checks;
- PHP-Syntax des 1.2.40-Release-Tests ohne Fehler;
- `git diff --check` ohne Beanstandung;
- Testdatenbank-Schema für ELDAT-Migration geprüft.

Die vollständige finale Release-/Preflight-Prüfung erfolgt vor dem Einfrieren des Source-Commits und dem Bau des signierten Updatepakets.

## Noch nicht abgeschlossen

Vor Kennzeichnung als produktiv freigegeben:

- finalen Release-Preflight ausführen;
- Source-Commit einfrieren;
- unveränderlichen Release-Branch `release/1.2.40` erstellen;
- signiertes Updatepaket nach dem bestehenden Releaseverfahren erzeugen;
- Paket und Signatur prüfen;
- Update über die normale produktive Update-Funktion installieren;
- produktiven ELDAT-Systemdienst kontrolliert aktivieren;
- reale Produktivabnahme durchführen;
- Release-Commit, Update-Repository-Commit und Paket-SHA256 hier nachtragen;
- `START-HERE.md` anschließend auf den neuen bekannten guten Referenzstand aktualisieren.

## Produktionsschutz

- keine direkte Entwicklungsänderung an `/var/www/waage`;
- Produktivinstallation der Anwendung ausschließlich über die normale signierte Update-Funktion;
- privater Release-Schlüssel bleibt ausschließlich auf dem lokalen Windows-Rechner;
- Systemdienst erst nach erfolgreichem App-Update explizit installieren;
- Test- und Produktiv-ELDAT-Dienst niemals gleichzeitig auf demselben RX09 betreiben.
