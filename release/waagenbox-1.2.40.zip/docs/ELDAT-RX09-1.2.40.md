# Entwicklungsstand 1.2.40 – ELDAT RX09

Stand: 2026-10-02  
Branch: `feature/1.2.40-eldat-rx09`  
Getesteter Zwischenstand: `c00154bbb77e25aa134ec93c76d95a7f77c75d7b`  
Ausgangsbasis: `baseline/1.2.39-documented`

## Status

Dieser Branch ist ein praktisch getesteter Entwicklungsstand für die Umstellung der Funkfernbedienung auf den ELDAT RX09 / Easywave USB-Transceiver. Er ist **noch kein produktives Release 1.2.40**. Die produktive Waagenbox bleibt auf dem freigegebenen Stand 1.2.39.

Die ELDAT-Wägeabläufe wurden auf der separaten Raspberry-Testinstanz erfolgreich mit echten Handsendern geprüft. Der aktuelle Stand soll zunächst unverändert erhalten bleiben. Weitere Feinheiten werden zusammen mit der nächsten Entwicklungsrunde und der realen DINI-Anbindung bearbeitet.

## Hardware und Schnittstelle

Getesteter Empfänger:

- ELDAT RX09 / USB Transceiver Easywave 868,30 MHz
- USB-ID: `155a:1006`
- USB-Seriennummer: `00021695`
- stabiler Gerätepfad: `/dev/serial/by-id/usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0`
- serielle Kommunikation: 57600 Baud, 8N1, ASCII, Abschluss `\r`

Beobachtetes Telegrammformat:

- Taste A: `REC,<sender>,A`
- Taste B: `REC,<sender>,B`

Beispiel des getesteten Zwei-Tasten-Senders: `18d2c3`.

## Implementierter Ablauf

Relevante Komponenten:

- `hardware/eldat_rx09_listener.py` – RX09-Listener, Entprellung, Lernmodus und Start des Abschluss-Workers
- `cli/eldat_remote_trigger.php` – Zuordnung Sender/Taste/Fahrzeug und Start des passenden Wägeablaufs
- `hardware/eldat_remote_worker.py` – unabhängiger Abschluss-Worker
- `cli/eldat_remote_complete.php` – Abschluss mit exakter Pending-Identität
- `remotes.php` / `api/rf_learn.php` – ELDAT-Verwaltung und Einlernen
- `migration_v1_2_40_eldat_rx09.sql` – Datenbankschema für ELDAT-Sender und Tasten
- `systemd/waagenbox-eldat-rx09-test.service` – auf der Testinstanz praktisch getesteter systemd-Dienst

Der Listener bleibt während einer laufenden Wiegung ansprechbar. Der Abschluss erfolgt in einem separaten Worker. Der Abschluss-CLI prüft Owner, Remote, Fahrzeug, Trigger und `started_at`, damit ein veralteter Worker keine fremde oder neuere Wiegung abschließen kann.

## Tastenlogik

Zwei-Tasten-Handsender:

- **A** startet eine normale Wiegung nur, wenn für das Fahrzeug bereits ein gespeichertes Erst-/Leergewicht vorhanden ist.
- Ist kein Erstgewicht vorhanden, wird A ignoriert. Zuerst muss B verwendet werden.
- **B** erfasst das dauerhafte Erst-/Leergewicht, wenn noch keines vorhanden ist.
- Ist bereits ein Erstgewicht gespeichert, wird B ignoriert.

Ein-Tasten-Handsender:

- verwendet Taste A;
- mit gespeichertem Erstgewicht startet A die normale Wiegung;
- ohne gespeichertes Erstgewicht wird A ignoriert.

Der reguläre Web-/QR-Zwei-Pass-Ablauf ohne gespeichertes Erstgewicht bleibt erhalten. Nach dem zweiten Gewicht wird das kleinere Gewicht als Erstgewicht gespeichert.

## Praktisch getestete Funktionen

Am 02.10.2026 auf der separaten Testinstanz erfolgreich geprüft:

- ELDAT RX09 wird über den stabilen `/dev/serial/by-id`-Pfad geöffnet;
- echter Zwei-Tasten-Handsender wird erkannt;
- echter Ein-Tasten-Handsender wird erkannt und eingelernt;
- Taste A mit vorhandenem Erstgewicht startet und beendet eine normale Wiegung;
- Taste A ohne Erstgewicht wird korrekt ignoriert;
- Taste B ohne Erstgewicht startet die Erstgewichtserfassung und speichert das Gewicht;
- Taste B bei bereits vorhandenem Erstgewicht wird ignoriert;
- Wiegungen werden korrekt gespeichert und Wiegescheine erzeugt;
- Listener und Abschluss-Worker funktionieren gemeinsam;
- Schutz gegen veraltete/falsche Pending-Identität wurde geprüft;
- QR-/Mobile-Wiegung mit gespeichertem Erstgewicht wurde regressionsgeprüft;
- regulärer Zwei-Pass-Ablauf ohne Erstgewicht wurde regressionsgeprüft;
- systemd-Dienst läuft als `www-data` mit `SupplementaryGroups=dialout`;
- Zugriff auf den Test-Worktree wurde gezielt per ACL ermöglicht;
- systemd-Autostart wurde durch echten Raspberry-Neustart bestätigt;
- nach dem Neustart wurde ohne manuellen Listener-Start eine reale ELDAT-Wiegung vollständig bis zum Wiegeschein abgeschlossen.

Der getestete Listener verwendet aktuell eine Freigabe nach 1,0 Sekunden Funkstille, um Mehrfachauslösungen eines Tastendrucks zu vermeiden.

## Test-systemd und Berechtigungen

Der Testdienst läuft aus `/home/pi/Waagenbox-test`. Da `/home/pi` nicht allgemein für `www-data` durchquerbar ist, wurde für die Testumgebung eine gezielte ACL für `www-data` verwendet. Die seriellen Rechte werden ausschließlich im Dienst über `SupplementaryGroups=dialout` ergänzt; `www-data` muss dafür nicht global der Gruppe `dialout` hinzugefügt werden.

Der im Repository gespeicherte Test-Service entspricht dem beim erfolgreichen Reboot-/Hardwaretest installierten Service.

Für das spätere Produktivrelease soll ein eigener Produktionsdienst mit Pfaden unter `/var/www/waage` erstellt und über den normalen Release-/Updateprozess installiert werden. Der alte 433-MHz-Dienst wird bis dahin nicht ungefragt produktiv entfernt.

## Datenbank

Die Migration `migration_v1_2_40_eldat_rx09.sql` ergänzt die ELDAT-Felder und erlaubt ELDAT-Fernbedienungen ohne alten Legacy-RF-Code.

Die Migration wurde ausschließlich auf `waagebox_test` angewendet. Die produktive Datenbank wurde im Rahmen dieser Entwicklung nicht migriert.

## Bekannte offene Feinheiten

Diese Punkte sind bewusst für die nächste Entwicklungsrunde zurückgestellt:

- ELDAT-Tastenvalidierung überall konsistent auf die tatsächlich verwendeten Tasten A/B begrenzen;
- Polling-Ausgabe des Abschluss-Workers im Journal reduzieren;
- Rückgabestatus für „noch kein Gewicht“ und „veralteter Auftrag“ sauberer unterscheiden, damit veraltete Worker sofort enden können;
- Runtime-Verzeichnis für den Lernmodus im endgültigen systemd-Dienst robust durch systemd anlegen lassen;
- produktiven ELDAT-systemd-Dienst erstellen und den alten 433-MHz-Dienst erst im freigegebenen Update kontrolliert ablösen;
- `schema.sql` und Release-/Installer-Details vor einem 1.2.40-Release final angleichen;
- dauerhafte QR-Basis-URL für Testumgebungen nicht an eine dynamische LAN-IP koppeln;
- vollständige Release-Regression und signierten Updater erst nach Abschluss der nächsten Entwicklungsrunde erstellen.

## Nächster großer Entwicklungsschritt: DINI

Als nächstes wird die reale DINI Argeo 3590ETKR an die Waagenbox angeschlossen und die tatsächliche Kommunikation anhand des echten Systems geprüft.

Die vorhandene separate DINI-Arbeit auf `feature/1.2.40-dini-driver` bleibt erhalten und soll nicht blind in diesen Branch gemischt werden. Zuerst wird am echten Terminal festgestellt, welcher Betriebsmodus und welches Telegrammformat tatsächlich verwendet werden. Danach werden DINI und ELDAT sauber in den gemeinsamen Wägeablauf integriert.

Ziel bleibt:

1. Wiegung wird über Web, QR oder ELDAT gestartet.
2. Die Waagenbox kennt dadurch Fahrzeug und Wägekontext.
3. DINI übernimmt ausschließlich die Gewichtserfassung.
4. Das finale Gesamtgewicht wird von der Waagenbox übernommen.
5. Die bestehende zentrale Wäge-/Speicherlogik verarbeitet den Abschluss.
6. Danach ist DINI für die nächste Überfahrt wieder bereit.

## Release-Regel

Dieser Branch darf nicht allein aufgrund der erfolgreichen ELDAT-Tests produktiv ausgerollt werden. Vor einem Release 1.2.40 sind mindestens DINI-Integration, offene Feinheiten, Regression, Release-Preflight, Migrationstest und der normale signierte Update-/Rollback-Prozess abzuschließen.


## Vorgemerkte gemeinsame Feinheiten für die DINI-Integrationsrunde

Bei der nächsten Entwicklungsrunde zur realen DINI-Integration nicht nur die oben genannten ELDAT-Restpunkte bearbeiten, sondern ausdrücklich auch die Verbindungsüberwachung zwischen Waagenbox und Feldmanager überarbeiten.

### Telegram-Verbindungsüberwachung entprellen

Aktuell können sehr kurze Kommunikationsausfälle von ungefähr einer Minute zu einer unnötigen Meldungsfolge führen: zuerst Telegram „Verbindungsstörung“ und kurz danach „Verbindung wiederhergestellt“.

Gewünschtes Verhalten für **beide Kommunikationsrichtungen**:

- Waagenbox → Feldmanager
- Feldmanager → Waagenbox

Anforderungen:

- ein einzelner fehlgeschlagener Check darf noch keine Telegram-Störungsmeldung erzeugen;
- eine Störung erst nach anhaltendem Ausfall melden, z. B. nach ungefähr zwei Minuten oder mehreren aufeinanderfolgenden Fehlversuchen;
- wird die Verbindung innerhalb dieser Karenzzeit wiederhergestellt, darf weder eine Störungs- noch eine Wiederherstellungsmeldung versendet werden;
- eine Telegram-Meldung „Verbindung wiederhergestellt“ nur dann senden, wenn zuvor tatsächlich eine Störungsmeldung versendet wurde;
- die konkrete Umsetzung (Zeit-Schwellwert oder Fehlerzähler) bei der nächsten Runde anhand der vorhandenen Monitor-/Cron-Logik festlegen und testen.

Dieser Punkt gehört zusammen mit den ELDAT-Feinheiten und der DINI-Anbindung auf die Aufgabenliste für die nächste Entwicklungsrunde und darf vor einem späteren 1.2.40-Release nicht vergessen werden.


---

## Nachtrag 06.10.2026 – ELDAT RX09 mit realem DINI vollständig geprüft

Die ELDAT-Integration wurde auf dem kombinierten Branch `feature/1.2.40-eldat-dini` mit dem realen DINI Argeo 3590ETKR end-to-end geprüft.

Bestätigte Zwei-Tasten-Logik am echten System:

- vorhandenes Erstgewicht + Taste A → normale DINI-Wiegung bis zum Wiegeschein;
- vorhandenes Erstgewicht + Taste B → wird absichtlich ignoriert;
- kein Erstgewicht + Taste A → wird absichtlich ignoriert;
- kein Erstgewicht + Taste B → DINI-Erstgewichtserfassung; Ergebnis wird dauerhaft am Fahrzeug gespeichert;
- danach Taste B erneut → wird wegen vorhandenem Erstgewicht ignoriert;
- danach Taste A → normale DINI-Wiegung mit dem gespeicherten Erstgewicht bis zum Wiegeschein.

Beim ersten kombinierten A-Test wurde entdeckt, dass `cli/eldat_remote_trigger.php` im normalen Wägepfad zwar den Pending-Auftrag anlegte, aber den DINI-Worker nicht startete. Dies wurde mit `startDiniPendingWorker()` behoben und real erfolgreich getestet.

Commit: `94adfc3` – `Start DINI worker for ELDAT weighing`.

Zusätzlich verhinderte die systemd-Härtung `ProtectSystem=strict` zunächst den Workerstart aus dem ELDAT-Dienst, weil `/var/lib/waagebox/dini/worker.log` nicht beschreibbar war. Die eng begrenzte Freigabe

```ini
ReadWritePaths=/var/lib/waagebox/dini
```

wurde real getestet und in die Test-Unit übernommen.

Commit: `5290f99` – `Allow ELDAT service to start DINI worker`.

Der alte produktive 433-MHz-Dienst und die produktive Waagenbox wurden dabei nicht verändert. Die offenen ELDAT-Feinheiten (A/B-Validierung, Journal-Spam, eindeutiger Status für stale Worker, systemd-RuntimeDirectory, finaler Produktionsdienst und Installer-/Schema-Angleichung) bleiben vor Release 1.2.40 abzuarbeiten.
