# AJP Waagenbox – Projektstand und Referenzwissen

Stand: 2026-09-14
Referenzversion: 1.2.31
Getesteter Source-Commit: `8b749cad33803c6156265ee3aeb2c87afe6adbc9`
Fester Release-Branch: `release/1.2.31`

## Zweck dieses Dokuments

Dieses Dokument ist der technische Einstiegspunkt für spätere Arbeiten an der AJP Waagenbox. Vor Änderungen immer zuerst dieses Dokument und `AGENTS.md` lesen. Ziel ist, den vollständig getesteten Referenzstand 1.2.31 nachvollziehbar zu erhalten und bekannte Fehlerquellen nicht erneut zu erzeugen.

## Referenzstatus 1.2.31

Version 1.2.31 wurde auf dem produktiven Raspberry Pi installiert und anschließend vollständig praktisch abgenommen. Der produktive Stand gilt als funktionsfähig und als Ausgangspunkt für zukünftige Änderungen.

Erfolgreich praktisch getestet wurden unter anderem:

- Fahrzeuge anlegen und verwalten
- Kunden anlegen und verwalten
- Produkte anlegen und verwalten
- Schläge anlegen und verwalten
- Fernbedienungen anlegen und verwalten
- bestehende und neu erzeugte QR-Fernbedienungen
- Wiegungen per QR-Fernbedienung
- manuelle Wiegungen
- Sitzungs- und Inaktivitäts-Logout
- Standort/GPS
- automatisches Backup herunterladen
- manuelles Backup erstellen und herunterladen
- Dini-Herstellerdiagnose bei nicht erreichbarem Wiegecomputer: saubere Fehlermeldung statt PHP-/Systemfehler
- Service-WLAN nach Neustart
- Zugriff über `http://10.42.0.1`
- Zugriff über normale Raspberry-IP parallel zum Service-WLAN
- Chromium-Kioskstart nach Reboot
- Dashboard automatisch im Vollbild
- Desktop muss nicht manuell bedient werden
- kein Desktop-Loginfenster vor dem Kiosk
- normaler Weblogin

Die produktive Oberfläche zeigte nach Installation korrekt Version 1.2.31.

## Zielplattform

- Raspberry Pi 3
- Debian 13 / Trixie
- Apache2
- PHP 8.4 als Apache-Modul
- MariaDB 11.8
- NetworkManager für normale Netzwerkverbindungen
- LightDM
- Benutzer `pi` mit Autologin
- Desktop-Session `rpd-labwc`
- Wayland / labwc
- Chromium unter `/usr/bin/chromium`

## Wichtige Pfade auf dem Raspberry

Produktive Anwendung:

- `/var/www/waage`

Git-Arbeitskopie:

- `/home/pi/Waagenbox`

Separater Test-Worktree:

- `/home/pi/Waagenbox-test`

Rollback-/Update-Laufzeitdaten:

- `/var/lib/waagebox/rollback`
- `/var/lib/waagebox/deploy`

Automatische Datenbank-Backups:

- `/var/backups/waagenbox`

Der produktive Pfad `/var/www/waage` darf nicht ungefragt direkt durch Entwicklungs- oder Codex-Aktionen überschrieben werden.

## GitHub-Struktur

Privates Source-Repository:

- `t0Puk/Waagenbox`

Öffentliches Update-Repository:

- `t0Puk/waagenbox-updates`

Der getestete Source-Commit von 1.2.31 ist:

- `8b749cad33803c6156265ee3aeb2c87afe6adbc9`

Dieser Commit ist unverändert als `release/1.2.31` gesichert.

Das veröffentlichte Update 1.2.31 liegt im Update-Repository. Release-Commit:

- `dcee03c4d944a3754771ef976043872007a22462`

SHA256 des veröffentlichten ZIP-Pakets:

- `25929a3fb60bdb4efcfaddb0e2e65c23d82164aeb629f6dce948d9c983b463ba`

## Versionsquelle

`version.php` ist die einzige reguläre Quelle für `APP_VERSION`.

Für 1.2.31:

```php
const APP_VERSION = '1.2.31';
```

Keine zweite fest codierte Versionsquelle einführen.

## Update- und Rollback-Architektur

Der Updater wurde sicherheitskritisch gehärtet. Die Grundprinzipien dürfen nicht vereinfacht oder umgangen werden:

1. Manifest laden.
2. Paket über HTTPS laden.
3. SHA256 prüfen.
4. signiertes inneres Manifest prüfen.
5. Paket in Staging entpacken.
6. Pfade und Paketstruktur validieren.
7. vor Mutation vollständigen Snapshot erstellen.
8. Datenbank-Dump validieren.
9. Anwendung über privilegierten Deploy-Helper ändern.
10. Migrationen kontrolliert ausführen.
11. Ergebnis prüfen.
12. bei Fehler automatische kombinierte Wiederherstellung von Anwendung und Datenbank.
13. Fehler-/Rescue-Arbeitsverzeichnisse nicht voreilig löschen.

Das bestehende Sicherheitsniveau des Updaters darf nicht zugunsten von Bequemlichkeit reduziert werden.

## Signiertes Releaseformat

Öffentliches Manifest:

```json
{"version":"1.2.31","download_url":"...zip","signature_url":"...sig","sha256":"..."}
```

Das signierte innere Manifest muss exakt folgendes Format mit abschließendem LF haben und UTF-8 ohne BOM sein:

```json
{"version":"1.2.31","package_sha256":"<sha256>"}
```

Die detached Signatur bezieht sich auf exakt diese Bytes.

Der private Release-Schlüssel bleibt ausschließlich lokal auf dem Windows-Rechner und darf niemals nach GitHub oder auf den Raspberry kopiert werden.

## Wichtige Release-Erkenntnis: ZIP-Pfade

Ein früheres 1.2.30-Paket scheiterte sicher vor der Mutation, weil ein unter Windows erzeugtes ZIP Backslashes in Unterverzeichnis-Einträgen enthielt.

Seitdem gilt zwingend:

- ZIP-Eintragsnamen ausschließlich mit `/`
- keine `\` in ZIP-Pfaden
- vor Veröffentlichung fertiges ZIP erneut öffnen und alle Eintragsnamen prüfen
- keine absoluten Pfade
- keine `..`-Traversal-Pfade
- keine Symlinks aus unsicheren Paketquellen
- Paket muss produktionsäquivalent validiert werden

Das korrigierte 1.2.31-Paket enthielt 84 geprüfte Einträge mit POSIX-Pfaden.

## Dateien, die niemals in Release oder Git gelangen dürfen

Insbesondere nicht einchecken oder ausliefern:

- produktive `config.php`
- `.env*`
- private Schlüssel (`*.key`, private PEMs, SSH-Keys, PPK, P12, PFX)
- echte Datenbank-Dumps
- `*.sql.gz`
- Backups und Rollback-Inhalte
- Runtime-Uploads
- Logs
- Python-Cache (`__pycache__`, `*.pyc`)

Erlaubte SQL-Dateien im Release sind nur:

- `schema.sql`
- versionierte `migration_*.sql`

Programmdateien mit dem Wort `backup` im Namen sind nicht automatisch Backups und dürfen nicht pauschal ausgeschlossen werden.

## Datenhaltung und Schutzregeln

Produktionsdaten haben Vorrang vor Komfort oder Refactoring.

- keine Tabellen leeren oder neu initialisieren
- keine produktiven Daten löschen
- DB-Migrationen nur versioniert und rückwärts nachvollziehbar
- Rollback-Snapshot immer vor Mutation
- vorhandenes Rollback nicht löschen, bevor neuer Snapshot vollständig und geprüft ist
- bestehende Rescue-Verzeichnisse nach Fehlern zunächst erhalten
- keine Secrets aus `config.php` in Tests, Logs, Git oder Dokumentation übernehmen

## Service-WLAN 1.2.31

Der ursprüngliche NetworkManager-Hotspot wurde verworfen, weil auf Raspberry Pi OS/Debian Trixie mit BCM43430 ein WPA2-Hotspot über wpa_supplicant/NetworkManager mit `802.1X supplicant took too long to authenticate` scheiterte.

Die funktionierende Lösung verwendet:

- `hostapd`
- einen eigenen `dnsmasq`-Prozess
- `wlan0` außerhalb der NetworkManager-Verwaltung
- keine Internetfreigabe

Feste Werte:

- Interface: `wlan0`
- Service-IP: `10.42.0.1/24`
- DHCP ungefähr `10.42.0.20` bis `10.42.0.100`
- 2,4 GHz
- Kanal 6
- Land `DE`
- WPA2 / CCMP

Systemd-Dienste:

- `waagenbox-service-wlan-prepare.service`
- `waagenbox-service-hostapd.service`
- `waagenbox-service-dnsmasq.service`

Wichtige Binärpfade:

- `/usr/sbin/rfkill`
- `/usr/sbin/ip`
- `/usr/sbin/hostapd`
- `/usr/sbin/dnsmasq`

Ein früher Fehler entstand durch den falschen Pfad `/usr/bin/rfkill`. Diesen Fehler nicht wieder einführen.

Die Weboberfläche nutzt den privilegierten Helper:

- `/usr/local/sbin/waagenbox-service-wlan`

SSID und Passwort werden validiert. Der Hostapd-PSK wird abgeleitet; kein Klartext-WLAN-Passwort soll in Git oder Logs landen.

## Systeminstallation für Service-WLAN und Kiosk

Systemkomponenten werden bewusst nicht automatisch bei jedem normalen App-Update als root verändert.

Relevante Datei:

- `install_service_components.py`

Read-only-Prüfung:

```bash
sudo /usr/bin/python3 install_service_components.py --check
```

Explizit freizugebende Installation:

```bash
sudo /usr/bin/python3 install_service_components.py --install
```

Vor Systemänderungen immer Remote-Zugriff prüfen. Niemals `wlan0` übernehmen, wenn die aktuelle SSH-Verbindung darüber läuft.

## Kioskmodus

Der Raspberry startet grafisch mit LightDM und Autologin des Benutzers `pi` in `rpd-labwc`.

Der Kioskstarter ist:

- `/usr/local/bin/waagenbox-kiosk`

Autostartzeile:

```text
/usr/local/bin/waagenbox-kiosk & # AJP Waagenbox kiosk
```

Chromium startet unter `pi`, niemals als root, mit Wayland und Kioskmodus auf:

- `http://127.0.0.1/`

Der Launcher wartet bei langsamem Boot auf den lokalen HTTP-Dienst und startet Chromium bei Bedarf erneut.

## Authentifizierung und Sitzungen

- externe Zugriffe erfordern Login
- reine Loopback-Zugriffe (`127.0.0.1`, `::1`) dürfen lokal behandelt werden
- ein manipulierter `Host: localhost`-Header darf keinen lokalen Bypass erzeugen
- Inaktivitäts-Timeout: 15 Minuten
- Hintergrund-Polling verlängert die Sitzung nicht
- echte Benutzeraktivität verlängert die Sitzung
- Logout funktioniert normal
- QR-Mobile-Endpunkte bleiben tokenbasiert

## Öffentliche Erreichbarkeit

Produktive öffentliche URL:

- `https://waage-ajp.de`

Die Veröffentlichung erfolgt über Cloudflare Tunnel zum lokalen HTTP-Dienst. Es sind dafür keine eingehenden Router-Ports erforderlich.

QR-Links verwenden zentral die Domain `waage-ajp.de`.

## Dini / Wiegecomputer

Die Herstellerdiagnose ist read-only und admin-geschützt.

Freigegebene Diagnosearten:

- Gewicht
- Identify
- State/Status
- Extended
- All

Wenn der Wiegecomputer nicht angeschlossen oder nicht erreichbar ist, muss die Oberfläche sauber `DINI nicht erreichbar oder keine gültige Antwort` bzw. einen vergleichbaren kontrollierten Fehler melden. Dies wurde in Produktion mit deaktiviertem Demo-Modus erfolgreich geprüft.

Die reale Kommunikation mit dem Dini-Terminal wird beim Waagenhersteller mit angeschlossener Hardware abschließend geprüft.

## Backups

Manuelles Backup:

- kann über die Weboberfläche erstellt und heruntergeladen werden
- Dateiname enthält Waagenbox/Version/Zeitstempel

Automatisches Backup:

- liegt außerhalb des Webroots unter `/var/backups/waagenbox`
- neuestes gültiges Backup kann admin-geschützt heruntergeladen werden
- Traversal, Symlinks und Fremddateien werden abgelehnt

## Relevante Tests für Releases

Vor einem neuen Release mindestens die zu der Änderung passenden Tests sowie die vorhandene Sicherheits-/Regression-Suite ausführen.

Für 1.2.31 wurden erfolgreich ausgeführt:

- `update_safety_test.php`: 76 Checks
- `update_access_control_test.php`: 6 gezählte Suite-Checks; zusätzlich alle ausgegebenen Schutzprüfungen PASS
- `updater_v2_static_test.php`: 22 Checks
- `updater_v2_phase4_test.php`: 17 Checks
- `updater_v2_phase5_test.php`: 14 Checks
- `deploy_bridge_test.php`: 8 Checks
- `service_wlan_test.py`: 13 Tests
- `service_components_installer_test.py`: 5 Tests
- `kiosk_test.py`: 4 Tests
- `release_preflight_test.py`: 2 Tests
- `release_1_2_30_test.php`: 63 Regressionchecks im Raspberry-Lauf für 1.2.31
- `session_http_test.py`: 22 HTTP-/Sessionchecks
- PHP-Syntaxprüfungen
- Python-Syntaxprüfungen
- `git diff --check`
- Release-Preflight
- reale Raspberry-Systemtests
- Reboot-Test
- produktive Funktionsabnahme

## Deploy-Bridge-Test auf dem Raspberry

Der Test benötigt exakt diese beiden Umgebungsvariablen:

- `WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE`
- `WAAGEBOX_DEPLOY_CLIENT_TEST_HELPER`

Die Testpfade müssen mit `/tmp/waagenbox_deploy_bridge_test_...` beginnen. Bei Bash-Tests die Variablen exportieren, damit PHP sie über `getenv()` erhält.

## Shell-/Test-Erkenntnisse

Bei großen Bash-Blöcken in einer interaktiven SSH-/PuTTY-Sitzung kein top-level `exit` verwenden. Das beendet die SSH-Sitzung und kann wie ein Raspberry-Absturz wirken.

Besser:

- `FAIL=1`
- Bedingungen
- `false` innerhalb kontrollierter Unterblöcke

Python-Testläufe erzeugen eventuell `__pycache__` in Git-Worktrees. Vor Cleanliness-Prüfungen diese Cacheverzeichnisse entfernen oder ignorieren; nicht mit echten Source-Änderungen verwechseln.

## Windows-/PowerShell-Erkenntnisse

PowerShell 5.1 kann bei `Set-Content -Encoding UTF8` einen BOM schreiben. Für signierte/manifestsensitive Dateien stattdessen .NET verwenden:

```powershell
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($Path, $Text, $Utf8NoBom)
```

Native Programme wie `git`, `openssl` oder `tar` werfen bei Fehlern nicht zuverlässig PowerShell-Exceptions. Nach nativen Befehlen `$LASTEXITCODE` explizit prüfen.

OpenSSL wurde beim 1.2.31-Release aus Git for Windows verwendet:

- `C:\Program Files\Git\usr\bin\openssl.exe`

## Release 1.2.31 – veröffentlichte Artefakte

Source-Commit:

- `8b749cad33803c6156265ee3aeb2c87afe6adbc9`

Update-Repo-Commit:

- `dcee03c4d944a3754771ef976043872007a22462`

ZIP:

- `release/waagenbox-1.2.31.zip`

Signatur:

- `release/waagenbox-1.2.31.sig`

Signiertes Manifest:

- `release/waagenbox-1.2.31.signed-manifest.json`

SHA256:

- `25929a3fb60bdb4efcfaddb0e2e65c23d82164aeb629f6dce948d9c983b463ba`

Die Veröffentlichung wurde lokal und nach dem Push bytegenau gegen GitHub geprüft.

## Empfohlener Ablauf für die nächste Änderung

1. Dieses Dokument und `AGENTS.md` lesen.
2. `release/1.2.31` als unveränderliche Referenz behandeln.
3. Neue Feature-/Fix-Branch für die nächste Version erzeugen.
4. Niemals direkt in `/var/www/waage` entwickeln.
5. Änderung lokal/Codex erstellen.
6. statische Tests und Regressionstests ausführen.
7. Raspberry-Test in `/home/pi/Waagenbox-test` auf exakt dem Zielcommit.
8. Systemänderungen nur separat und mit ausdrücklicher Freigabe.
9. Reboot-/Hardwaretest, falls relevant.
10. Release aus exakt getestetem Commit bauen.
11. ZIP-Eintragsnamen und Secrets kontrollieren.
12. SHA256 berechnen.
13. exaktes inneres Manifest ohne BOM erstellen und signieren.
14. Signatur lokal verifizieren.
15. Update-Repository nur nach Freigabe aktualisieren.
16. Remote Git-Blobs nach Push bytegenau vergleichen.
17. Produktivupdate über normale Waagenbox-Updatefunktion durchführen.
18. Datenbestand und Kernfunktionen danach erneut prüfen.
19. neuen getesteten Release-Branch festlegen und dieses Dokument aktualisieren.

## Grundsatz

Version 1.2.31 ist der bekannte gute Referenzstand. Stabilität, Datenintegrität und reproduzierbare Releases haben Vorrang vor schnellen Änderungen. Wenn eine neue Änderung unklar ist, zuerst von diesem Stand aus analysieren und testen, statt bestehende Schutzmechanismen zu umgehen.


---

## Aktueller Nachtrag 25.09.2026 – 1.2.39 Großanzeige und Wägeablauf

Der historische Referenzteil oben bleibt bewusst erhalten. Der aktuell produktiv freigegebene Stand ist inzwischen 1.2.38; die laufende Entwicklung für 1.2.39 befindet sich auf `feature/1.2.39-grossanzeige`.

Für 1.2.39 wurden auf der separaten Raspberry-Testinstanz praktisch geprüft:

- fahrzeugbezogene offene Erstwiegungen über `open_vehicle_weighings`;
- mehrere offene Fahrzeugwiegungen bei weiterhin nur einer physisch aktiven Überfahrt;
- manuelle externe Fahrzeuge ohne dauerhaftes Leergewicht;
- einheitlicher Wägekern für manuelle und QR-/Mobile-Wiegungen;
- Schutz vor QR-/Web-Doppelabschluss;
- Live-Anbindung der separaten AJP Großanzeige;
- semantische Anzeige von Erstgewicht, Zweitgewicht, Bruttogewicht und Netto Gewicht;
- keine Gewichtsart während `drive_on` bei 0 kg;
- konfigurierbare Anzeigezeiten;
- Dashboard-Verbindungsstatus `Waagenbox → Großanzeige`;
- Fernaktivierung/-deaktivierung der Großanzeige;
- dynamische Links zur Großanzeigen-Administration und Displayseite aus der konfigurierten IP/dem Hostnamen;
- Großanzeigen-Raspberry-Reboot: Status wechselt auf nicht erreichbar und nach Boot wieder auf verbunden.

Die eigenständige Großanzeigen-Software liegt im privaten Repository `t0Puk/Grossfeldanzeige_Waagenbox` und wird nicht in das Waagenbox-Releasepaket aufgenommen.

Vollständige Release-Dokumentation: `docs/release-1.2.39.md`.

Vor Veröffentlichung muss der exakte 1.2.39-Source-Commit durch die finale Regression und `tools/release_preflight.py` bestätigt werden. Erst danach darf `release/1.2.39` als unveränderlicher Release-Branch erstellt und das signierte Updatepaket aus genau diesem Commit gebaut werden.


---

## Finaler Produktivstand 25.09.2026 – 1.2.39

Der aktuell bekannte gute Produktivstand ist **AJP Waagenbox 1.2.39**.

### Referenzen

- getesteter und veröffentlichter Source-Commit: `4c3968b6a7aa3ddb9d5dda590385d6142fbc62d0`
- unveränderlicher Release-Branch: `release/1.2.39`
- dokumentierte Weiterarbeitsbasis: `baseline/1.2.39-documented`
- Update-Repository-Commit: `adc080f`
- Paket-SHA256: `043f9463b4ac63032bb5e0c2ae37cffcd9aa94d8df555dba870118e33e168894`
- veröffentlichte ZIP-Größe: 298833 Bytes

### Release-Prüfungen

Vor Veröffentlichung erfolgreich:

- `tests/release_1_2_39_test.php`: 27 Checks bestanden;
- QR-/Web-Doppelabschluss-Regression bestanden;
- PHP-Syntax aller getrackten PHP-Dateien ohne Fehler;
- Python-Syntax ohne Fehler;
- `git diff --check` sauber;
- Release-Preflight erfolgreich mit 179 geprüften Exportpfaden;
- lokale Signaturprüfung: `Verified OK`;
- veröffentlichte ZIP nach Push erneut geladen und SHA256 bytegenau bestätigt.

### Produktive Abnahme

Das Update von 1.2.38 auf 1.2.39 wurde über die normale signierte Updatefunktion installiert und lief sauber durch.

Im Anschluss wurden die für 1.2.39 relevanten Produktivabläufe mit der real angebundenen Großanzeige praktisch geprüft. Der Benutzer bestätigte, dass die Waagenbox im Zusammenspiel mit der Großanzeige wie vorgesehen funktioniert.

Geprüft wurden unter anderem:

- produktive Token-Verbindung zur Großanzeige;
- QR-/Mobile-Wiegung;
- manuelle Wiegung;
- Erst- und Zweitgewicht;
- Fahrzeug mit gespeichertem Leergewicht;
- Brutto-/Nettoanzeige;
- semantische Zustandswechsel der Großanzeige;
- Standby-Rückkehr;
- Dashboard-Verbindungsstatus;
- Fernaktivierung/-deaktivierung der Anzeige.

### Produktionsspezifische QR-Erkenntnisse

Nach dem Update war in der produktiven Datenbank noch der historische Einstellungswert `mobile_remote_base_url=https://waagensteuerung.tail2ca00b.ts.net` vorhanden. Dieser Laufzeit-Override übersteuerte den im Code korrekten Standard `https://waage-ajp.de`.

Der Override wurde gezielt geleert. Danach lieferte `mobileRemoteBaseUrl()` wieder `https://waage-ajp.de`. Bestehende QR-Tokens blieben gültig.

Eine weitere Meldung „Diese mobile Fernbedienung ist nicht aktiv.“ hatte keine Codeursache. Die betroffene Fernbedienung war aktiv, ihr zugeordnetes Fahrzeug jedoch deaktiviert. `mobile_remote.php` verlangt absichtlich beide Zustände `active=1`. Nach Aktivierung des Fahrzeugs funktionierte die QR-Fernbedienung.

Diese beiden Korrekturen waren produktive Konfigurations-/Datenbereinigungen und ändern den Source-Commit des Releases nicht.

### Nächster Entwicklungsstart

Für zukünftige Änderungen zuerst lesen:

1. `AGENTS.md`
2. `docs/START-HERE.md`
3. `docs/PROJECT-STATE.md`
4. `docs/release-1.2.39.md`

Neue Entwicklung nicht direkt auf `release/1.2.39` und niemals ungefragt in `/var/www/waage` durchführen. Ausgangspunkt ist `baseline/1.2.39-documented` bzw. für eine reine Codebasis der unveränderte Release-Commit.


## Nachtrag 25.09.2026 – automatisches Backup mit Google Drive produktiv eingerichtet

Die bereits integrierte automatische Datensicherung wurde auf der produktiven Waagenbox vollständig eingerichtet und praktisch geprüft.

Produktiver Stand:

- `rclone` ist auf der Waagenbox installiert.
- rclone-Remote: `gdrive`
- Google-Drive-Zielordner: `Waagenbox-Backups`
- lokales Backup-Verzeichnis: `/var/backups/waagenbox`
- der systemd-Dienst `waagenbox-backup.service` läuft als `www-data`
- der Timer `waagenbox-backup.timer` ist installiert, aktiviert und prüft alle 5 Minuten, ob gemäß Anwendungseinstellung ein Backup fällig ist
- ein echter Datenbank-Backup-Lauf inklusive Upload zu Google Drive wurde erfolgreich durchgeführt
- die hochgeladene Datei wurde anschließend mit rclone im Zielordner verifiziert
- der automatische systemd-Aufruf endete mit `status=0/SUCCESS`

### rclone-Konfiguration für den Dienstbenutzer

Wichtig: Ein unter Benutzer `pi` eingerichtetes rclone-Remote reicht für den automatischen Dienst nicht aus, weil `waagenbox-backup.service` als `www-data` läuft und `backup.php` rclone ohne explizites `--config` startet.

Die funktionierende produktive Konfiguration liegt deshalb zusätzlich unter:

`/var/www/.config/rclone/rclone.conf`

Eigentümer und Schutz:

- Benutzer/Gruppe: `www-data:www-data`
- Verzeichnis: Modus `0700`
- Konfigurationsdatei: Modus `0600`

Prüfung des Dienstkontexts:

```bash
sudo -u www-data env HOME=/var/www rclone about gdrive:
```

### systemd-Installation

Die Unit-Dateien liegen in der Anwendung unter:

- `systemd/waagenbox-backup.service`
- `systemd/waagenbox-backup.timer`

Der Installer ist:

- `install_backup_systemd.sh`

Auf Release-Installationen kann das Ausführungsbit eines Shell-Skripts fehlen. Deshalb den Installer robust über den Interpreter aufrufen:

```bash
sudo sh /var/www/waage/install_backup_systemd.sh
```

### Wichtige CRLF-Erkenntnis

Im produktiv installierten 1.2.39-Paket hatte `install_backup_systemd.sh` CRLF-Zeilenenden. Dadurch scheiterte `/bin/sh` mit:

```text
set: Illegal option -
```

Die Ursache wurde produktiv bestätigt mit `file` und `sed -n '1,5l'`. Nach Konvertierung auf LF lief der Installer korrekt.

Für zukünftige Releases gilt deshalb zusätzlich:

- Shell-Skripte müssen mit LF ausgeliefert werden.
- `.gitattributes` erzwingt ab der dokumentierten Weiterarbeitsbasis `*.sh text eol=lf`.
- Beim Erstellen eines Releasepakets unter Windows dürfen Shell-Skripte nicht wieder auf CRLF umgeschrieben werden.
- Vor Veröffentlichung mindestens `install_backup_systemd.sh` auf CRLF prüfen.
- Der unveränderliche Release-Branch `release/1.2.39` wurde nicht nachträglich verändert; die Korrektur liegt in `baseline/1.2.39-documented` für die nächste Version.


---

## Entwicklungsstand 02.10.2026 – ELDAT RX09 für 1.2.40

Ausgehend von `baseline/1.2.39-documented` wurde auf `feature/1.2.40-eldat-rx09` die Anbindung des ELDAT RX09 / Easywave USB-Transceivers umgesetzt und auf der separaten Raspberry-Testinstanz mit echter Hardware praktisch geprüft.

Getesteter funktionaler Zwischenstand vor der Abschlussdokumentation:

- `c00154bbb77e25aa134ec93c76d95a7f77c75d7b`

Bestätigt wurden unter anderem Ein- und Zwei-Tasten-Handsender, A-/B-Logik für normale Wiegung und Erstgewicht, unabhängiger Abschluss-Worker, Speicherung/Wiegeschein, QR-/Zwei-Pass-Regression sowie der automatische Start des RX09-Listeners nach einem echten Raspberry-Neustart. Eine nach dem Reboot ausgelöste reale ELDAT-Wiegung wurde vollständig abgeschlossen.

Die produktive Waagenbox und produktive Datenbank wurden für diese Entwicklung nicht auf 1.2.40 umgestellt. Der alte 433-MHz-Dienst bleibt bis zum kontrollierten späteren Release unangetastet.

Vollständige technische Dokumentation, Testumfang und bekannte Restpunkte:

- `docs/ELDAT-RX09-1.2.40.md`

Der aktuelle Stand soll zunächst bestehen bleiben. Die dokumentierten Feinheiten werden in der nächsten Entwicklungsrunde zusammen mit der realen DINI-Integration bearbeitet. Die separate Arbeit auf `feature/1.2.40-dini-driver` bleibt dafür erhalten; vor einer Zusammenführung zuerst das echte DINI-Terminal diagnostizieren.

---

## Entwicklungsstand 05.10.2026 – reale DINI-Integration für 1.2.40

Die reale DINI-Argeo-3590ETKR-Anbindung wurde auf dem kombinierten Branch `feature/1.2.40-eldat-dini` mit echter Hardware praktisch geprüft.

Getesteter funktionaler Stand:

- `82f873e` – `Fix tested DINI dynamic weighing completion`

Bestätigt sind insbesondere der automatische Start der dynamischen DINI-Wiegung über `KEYP37`/`KEYR`, das Warten auf den abschließenden Semikolon-Datensatz über dieselbe TCP-Verbindung, die Verarbeitung des DINI-Gesamtgewichts sowie der vollständige Abschluss in der Waagenbox.

Am realen System wurden erfolgreich geprüft:

- Zwei-Pass-Wiegung ohne gespeichertes Erstgewicht: DINI-ID 9 = 600 kg, DINI-ID 10 = 200 kg, Wiegeschein 79 = 400 kg Netto; 200 kg wurden anschließend als dauerhaftes Erst-/Leergewicht gespeichert.
- Ein-Pass-Wiegung mit gespeichertem Erstgewicht 200 kg: DINI-ID 11 = 800 kg, Wiegeschein 80 = 600 kg Netto; das Erstgewicht blieb erhalten.
- Pending-State und DINI-Worker werden nach erfolgreichem Abschluss sauber beendet.

Während der realen Tests wurde außerdem ein Preflight-Fehler gefunden: Der interne Dummywert `1.0` des `--check`-Aufrufs konnte wegen eines fehlenden frühen `exit(0)` als echtes Gewicht verarbeitet werden. Der Fehler wurde in `82f873e` behoben und direkt gegen `waagebox_test` sowie durch Regressionstests abgesichert.

Die produktive Waagenbox bleibt unverändert auf 1.2.39. Der aktuelle kombinierte Branch ist weiterhin Entwicklungsstand und kein Release.

Vollständige Hardware-, Protokoll-, Implementierungs- und Testdokumentation:

- `docs/DINI-3590-1.2.40.md`
- `docs/ELDAT-RX09-1.2.40.md`

Als nächste reale Tests folgen QR/Mobile → DINI und ELDAT RX09 → DINI. Danach sind die dokumentierten ELDAT-Feinheiten, Installer-/Schema-Angleichung, vollständige Regression und der normale signierte Releaseprozess abzuarbeiten.


---

## Entwicklungsstand 06.10.2026 – QR + ELDAT + DINI real end-to-end bestätigt

Auf `feature/1.2.40-eldat-dini` wurden die vorgesehenen realen DINI-Startwege weiter geprüft und erfolgreich abgeschlossen.

Zusätzlich zum bereits dokumentierten direkten DINI-Workflow sind jetzt praktisch bestätigt:

- dynamischer DINI-Timeout auf 360 Sekunden erhöht (`5120ee3`);
- QR/Mobile → DINI mit vorhandenem Erstgewicht erfolgreich;
- QR/Mobile → DINI ohne Erstgewicht als vollständiger Zwei-Pass-Ablauf erfolgreich;
- ELDAT Taste A mit vorhandenem Erstgewicht → DINI → Wiegeschein erfolgreich;
- ELDAT Taste A ohne Erstgewicht wird ignoriert;
- ELDAT Taste B ohne Erstgewicht erfasst und speichert das dauerhafte Erst-/Leergewicht;
- ELDAT Taste B mit vorhandenem Erstgewicht wird ignoriert;
- danach normale Wiegung über Taste A mit dem gespeicherten Erstgewicht erfolgreich.

Beim kombinierten ELDAT/DINI-Test wurden zwei Ursachen für einen zunächst fehlenden DINI-Start gefunden und behoben:

1. Im normalen ELDAT-A-Pfad fehlte `startDiniPendingWorker()` (`94adfc3`).
2. Der gehärtete ELDAT-systemd-Dienst mit `ProtectSystem=strict` durfte `/var/lib/waagebox/dini` nicht beschreiben. Die gezielte Freigabe `ReadWritePaths=/var/lib/waagebox/dini` wurde real bestätigt und in die Test-Unit übernommen (`5290f99`).

Der funktionierende Hardware-Zwischenstand ist damit auf GitHub bis `5290f99` festgeschrieben. Die produktive Installation bleibt auf 1.2.39 und wurde durch diese Tests nicht verändert.

Vor einem Release 1.2.40 bleiben die dokumentierten Feinheiten und Releasearbeiten offen: ELDAT-Tastenvalidierung A/B, Worker-Logging und stale-worker-Status, systemd-RuntimeDirectory, finaler Produktionsdienst und Ablösung des alten 433-MHz-Dienstes, Schema/Migration/Installer-Angleichung, dauerhafte QR-Basis-URL, Telegram-Verbindungsüberwachung mit Entprellung in beide Richtungen, vollständige Regression/Migrationstest sowie der normale signierte Updater.

---

## Release-Kandidat 1.2.40 – 06.10.2026

Die kombinierte ELDAT-RX09-/DINI-Entwicklung auf `feature/1.2.40-eldat-dini` hat den Release-Kandidaten-Stand erreicht.

Die reale Hardwareintegration wurde erfolgreich geprüft. ELDAT-Taste A/B, QR/Mobile und der DINI Argeo 3590ETKR arbeiten über den zentralen Waagenbox-Wägeablauf zusammen.

Zusätzlich enthält 1.2.40 eine 120-Sekunden-Entprellung für Telegram-Verbindungsstörungen in Richtung Waagenbox → Feldmanager.

Für den produktiven ELDAT-Betrieb wurden `systemd/waagenbox-eldat-rx09.service` und `install_eldat_rx09_systemd.sh` ergänzt. Der bestehende 433-MHz-Dienst bleibt zunächst bestehen. Test- und Produktiv-ELDAT-Dienst dürfen wegen des gemeinsamen RX09 niemals gleichzeitig laufen.

Der 1.2.40-Release-Gate umfasst aktuell:

- `tests/release_1_2_40_test.php`: 25 Checks PASS;
- `tests/telegram_debounce_test.php`: 18 Checks PASS;
- `tests/dini_completion_dispatch_test.php`: 6 Checks PASS;
- `tests/dini_worker_two_pass_test.php`: 12 Checks PASS;
- `tests/eldat_systemd_installer_test.py`: 19 Checks PASS;
- `git diff --check`: PASS.

Die Testdatenbank `waagebox_test` besitzt die vorgesehenen ELDAT-Spalten und den eindeutigen Index `uq_remote_owner_eldat_sender`.

Details:

- `docs/release-1.2.40.md`
- `docs/ELDAT-RX09-1.2.40.md`
- `docs/DINI-3590-1.2.40.md`

Bis zur Installation über das signierte Update und anschließender realer Produktivabnahme bleibt Version 1.2.39 der bekannte gute Produktivstand.
