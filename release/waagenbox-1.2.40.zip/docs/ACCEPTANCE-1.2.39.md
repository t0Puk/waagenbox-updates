# ACCEPTANCE 1.2.39 – AJP Waagenbox

Stand: 25.09.2026

## Freigabestatus

AJP Waagenbox 1.2.39 ist produktiv installiert und praktisch abgenommen.

- Source-Commit: `4c3968b6a7aa3ddb9d5dda590385d6142fbc62d0`
- Release-Branch: `release/1.2.39`
- dokumentierte Ausgangsbasis: `baseline/1.2.39-documented`
- Update-Repository-Commit: `adc080f`
- Paket-SHA256: `043f9463b4ac63032bb5e0c2ae37cffcd9aa94d8df555dba870118e33e168894`
- Paketgröße: 298833 Bytes

## Vor Veröffentlichung geprüft

- `tests/release_1_2_39_test.php`: 27 Checks bestanden
- QR-/Web-Doppelabschluss-Regression bestanden
- PHP-Syntax aller getrackten PHP-Dateien ohne Fehler
- Python-Syntax ohne Fehler
- `git diff --check` sauber
- Release-Preflight erfolgreich; 179 exportierte Pfade geprüft
- Signatur lokal erfolgreich mit `Verified OK` geprüft
- veröffentlichtes ZIP nach Push erneut geladen und SHA256 bytegenau bestätigt

## Produktivinstallation

Das Update wurde ausschließlich über die normale signierte Update-Funktion installiert. Der Installationslauf endete erfolgreich.

Keine Entwicklungsdateien wurden manuell in `/var/www/waage` kopiert.

## Praktisch abgenommen

- manuelle Wiegung
- QR-/Mobile-Wiegung
- erste und zweite Überfahrt
- mehrere offene fahrzeugbezogene Erstwiegungen
- Fahrzeug mit gespeichertem Leergewicht
- temporäres externes Fahrzeug ohne dauerhaftes Leergewicht
- korrekte Tara-/Brutto-/Netto-Berechnung
- kein QR-/Web-Doppelabschluss
- Großanzeigen-Liveanbindung
- Erstgewicht / Zweitgewicht / Bruttogewicht / Netto Gewicht auf der Großanzeige
- keine Gewichtsart während Auffahrt / `drive_on`
- Standby-Rückkehr
- Dashboard-Verbindungsstatus
- Fernaktivierung/-deaktivierung der Großanzeige
- Großanzeigen-Reboot und Wiederverbindung

## Produktive QR-Konfigurationsbereinigung

Nach dem Update war in der produktiven Datenbank noch der historische Override

`mobile_remote_base_url=https://waagensteuerung.tail2ca00b.ts.net`

gespeichert.

Der Override wurde geleert. Danach verwendet `mobileRemoteBaseUrl()` wieder den im Source vorgesehenen Standard:

`https://waage-ajp.de`

Die vorhandenen QR-Tokens mussten nicht erneuert werden.

## Meldung „Diese mobile Fernbedienung ist nicht aktiv.“

Die betroffene Fernbedienung war aktiv, das zugeordnete Fahrzeug jedoch deaktiviert.

`mobile_remote.php` verlangt absichtlich:

- Fernbedienung `active=1`
- zugeordnetes Fahrzeug `active=1`

Nach Aktivierung des Fahrzeugs funktionierte die QR-Fernbedienung. Es war keine Codeänderung erforderlich.

## Separate AJP Großanzeige

Repository:

`t0Puk/Grossfeldanzeige_Waagenbox`

Die Großanzeige ist ein read-only Verbraucher des Waagenbox-Zustands und darf die Wägefunktion nicht blockieren.

Nach der Produktivabnahme wurde zusätzlich die Administrationsoberfläche der Großanzeige vereinheitlicht. Alle speichernden Einstellungsbereiche zeigen jetzt eine sichtbare Erfolgs- oder Fehlermeldung.

Relevante Großanzeigen-Commits:

- `72f4f7c3e2861f415464c31a4e09a9b38ecdc33e` – Speicherbestätigung in allen Einstellungen
- `57953fe32a3ec7b7574a6cd8921e36857d41f938` – Dokumentation dazu
- `ec84d1f1bd8e0c3b1b7d6742691adf4c53d00ffc` – finaler Produktivstand dokumentiert

Die Änderung wurde auf dem Großanzeigen-Raspberry übernommen und praktisch bestätigt.

## Einstieg für die nächste Änderung

Vor zukünftiger Entwicklung lesen:

1. `AGENTS.md`
2. `docs/START-HERE.md`
3. `docs/PROJECT-STATE.md`
4. `docs/release-1.2.39.md`
5. dieses Dokument

Neue Entwicklung nicht direkt auf `release/1.2.39` durchführen. Der Release-Branch bleibt unverändert. Für neue Arbeiten von `baseline/1.2.39-documented` aus einen neuen Feature-/Fix-Branch erstellen.


## Nachträgliche produktive Backup-Abnahme am 25.09.2026

Nach der eigentlichen Release-Abnahme wurde die bereits vorhandene automatische Backup-Funktion produktiv eingerichtet und geprüft.

Bestätigt wurden:

- lokales Datenbank-Backup nach `/var/backups/waagenbox`;
- erfolgreicher rclone-Zugriff auf das Remote `gdrive`;
- erfolgreicher Upload nach `gdrive:Waagenbox-Backups`;
- Sichtprüfung der hochgeladenen `.sql.gz`-Datei über rclone;
- Zugriff im tatsächlichen Dienstkontext `www-data`;
- Installation und Aktivierung von `waagenbox-backup.timer`;
- Timerzustand `active (waiting)`;
- automatischer Start von `waagenbox-backup.service`;
- erfolgreicher Service-Lauf mit `status=0/SUCCESS`.

Dabei wurde ein Verpackungsproblem des 1.2.39-Installers festgestellt: `install_backup_systemd.sh` lag auf dem Produktivsystem mit CRLF-Zeilenenden vor und scheiterte unter `/bin/sh` mit `set: Illegal option -`. Dies wurde auf der dokumentierten Weiterarbeitsbasis durch die Git-Regel `*.sh text eol=lf` abgesichert. `release/1.2.39` bleibt unverändert.
