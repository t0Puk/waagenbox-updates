# START HERE – AJP Waagenbox

Für jede zukünftige Änderung an der Waagenbox zuerst lesen:

1. `AGENTS.md`
2. `docs/PROJECT-STATE.md`
3. `docs/release-1.2.39.md`
4. `docs/ACCEPTANCE-1.2.39.md`
5. bei Service-WLAN-Änderungen zusätzlich `docs/service-wlan.md`

## Bekannter guter Referenzstand

- Produktiv abgenommene Version: `1.2.39`
- Getesteter Source-Commit: `4c3968b6a7aa3ddb9d5dda590385d6142fbc62d0`
- Unveränderlicher Release-Branch: `release/1.2.39`
- Dokumentierte Ausgangsbasis für die nächste Änderung: `baseline/1.2.39-documented`
- Öffentliches Update-Repository: `t0Puk/waagenbox-updates`
- Release-Commit im Update-Repository: `adc080f`
- SHA256 des veröffentlichten ZIP-Pakets: `043f9463b4ac63032bb5e0c2ae37cffcd9aa94d8df555dba870118e33e168894`

## Produktive Abnahme 25.09.2026

Version 1.2.39 wurde über die normale signierte Update-Funktion auf der produktiven Waagenbox installiert. Das Update lief sauber durch.

Anschließend wurden die neue Großanzeigen-Anbindung und die produktiven Wägeabläufe praktisch geprüft. QR-/Mobile-Wiegungen, manuelle Wiegungen, Erst-/Zweitgewicht, gespeichertes Leergewicht, Nettoanzeige, Statuswechsel und Rückkehr in Standby funktionierten wie vorgesehen.

Produktionsspezifische Korrektur nach dem Update:

- In der produktiven Datenbank war noch ein alter Override `mobile_remote_base_url` auf eine frühere Tailscale-Adresse gespeichert.
- Der Override wurde geleert; damit verwendet die Anwendung wieder den im Code vorgesehenen Standard `https://waage-ajp.de`.
- Die QR-Tokens mussten dafür nicht neu erzeugt werden.
- Eine zunächst als „mobile Fernbedienung nicht aktiv“ erscheinende Meldung wurde als Datenzustand identifiziert: Die Fernbedienung war aktiv, das zugeordnete Fahrzeug jedoch deaktiviert. Nach Aktivierung des Fahrzeugs funktionierte die QR-Seite korrekt.
- Diese Punkte waren keine nachträglichen Codeänderungen am Releasepaket.

## Regel für die nächste Version

Neue Entwicklung nicht direkt im produktiven Pfad und nicht auf `release/1.2.39` durchführen.

Für die nächste Version von `baseline/1.2.39-documented` bzw. dem unveränderten Release-Commit aus einen neuen Feature-/Fix-Branch erzeugen. Änderungen zuerst in der Testumgebung prüfen und erst nach erfolgreicher Regression ein neues Release bauen.

`release/1.2.39` bleibt die technische, unveränderte Releasebasis. `baseline/1.2.39-documented` enthält die nach der Produktivabnahme ergänzte Dokumentation sowie die für die nächste Version vorgemerkte LF-Härtung für Shell-Skripte (`*.sh text eol=lf`).

## Backup-/rclone-Hinweis für die nächste Version

Die produktive automatische Sicherung nach Google Drive ist eingerichtet und geprüft. Verwendet werden `gdrive:Waagenbox-Backups` und der systemd-Dienstbenutzer `www-data`.

Vor Änderungen am Backup-System unbedingt den entsprechenden Nachtrag in `docs/PROJECT-STATE.md` lesen. Besonders beachten:

- rclone-Konfiguration muss für `www-data` verfügbar sein;
- `install_backup_systemd.sh` über `sudo sh ...` starten, falls das Ausführungsbit im Release fehlt;
- Shell-Skripte ausschließlich mit LF ausliefern;
- 1.2.39 enthielt produktiv bei diesem Installer CRLF und scheiterte dadurch mit `set: Illegal option -`;
- `.gitattributes` erzwingt deshalb in der Weiterarbeitsbasis `*.sh text eol=lf`.


## Entwicklungsnachtrag 05.10.2026 – ELDAT + reale DINI-Integration

Die laufende 1.2.40-Entwicklung befindet sich jetzt auf dem kombinierten Branch `feature/1.2.40-eldat-dini`.

Der zuvor separat praktisch getestete ELDAT-RX09-/Easywave-Stand bildet die Basis. Zusätzlich wurde die reale DINI-Argeo-3590ETKR-Anbindung mit echter Hardware erfolgreich integriert und geprüft.

Bestätigt sind unter anderem:

- DINI-Start über `KEYP37` + `KEYR` und Anzeige „Warte auf Überfahrt“;
- Empfang und Parsing des abschließenden dynamischen DINI-Datensatzes;
- Zwei-Pass-Wiegung ohne gespeichertes Erstgewicht: 600 kg → 200 kg, Wiegeschein 79 = 400 kg Netto, 200 kg dauerhaft als Erstgewicht;
- Ein-Pass-Wiegung mit gespeichertem Erstgewicht: 200 kg + 800 kg, Wiegeschein 80 = 600 kg Netto;
- korrigierter side-effect-freier DINI-Preflight; real getesteter Fix-Commit `82f873e`.

Dieser Stand ist weiterhin **kein produktives Release 1.2.40**. Die produktive Waagenbox bleibt auf 1.2.39.

Vor der Fortsetzung zusätzlich lesen:

- `docs/ELDAT-RX09-1.2.40.md`
- `docs/DINI-3590-1.2.40.md`

Als nächste reale Tests folgen QR/Mobile → DINI und ELDAT RX09 → DINI. Die ältere Arbeit auf `feature/1.2.40-dini-driver` wird nicht pauschal gemergt; die real bestätigte Integration liegt auf `feature/1.2.40-eldat-dini`.


---

## Getesteter Hardware-Zwischenstand 06.10.2026

Die laufende 1.2.40-Entwicklung liegt weiterhin auf `feature/1.2.40-eldat-dini`. Der real getestete Hardwarestand ist bis Commit `5290f99` festgeschrieben.

Seit dem vorherigen Nachtrag wurden zusätzlich erfolgreich geprüft:

- QR/Mobile → DINI mit und ohne vorhandenes Erstgewicht;
- ELDAT Zwei-Tasten-Ablauf vollständig am echten DINI;
- A mit Erstgewicht → normale Wiegung und Wiegeschein;
- A ohne Erstgewicht → ignoriert;
- B ohne Erstgewicht → Erstgewicht erfassen und speichern;
- B mit Erstgewicht → ignoriert;
- DINI-Timeout 360 Sekunden für längere dynamische Auswertungen.

Wichtige Fixes:

- `94adfc3`: normaler ELDAT-A-Pfad startet den DINI-Worker;
- `5290f99`: ELDAT-Testdienst erhält unter `ProtectSystem=strict` ausschließlich für `/var/lib/waagebox/dini` Schreibzugriff.

Für Details vor weiteren Änderungen immer `docs/DINI-3590-1.2.40.md` und `docs/ELDAT-RX09-1.2.40.md` lesen. Dieser Stand ist kein Release; Produktion bleibt auf 1.2.39.
