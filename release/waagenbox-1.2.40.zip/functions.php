<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/version.php';
require_once __DIR__ . '/auth.php';

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function currentOwnerId(): int {
    global $mobileContextUserId;
    if(!empty($mobileContextUserId)) return (int)$mobileContextUserId;
    $u=currentUser();
    if($u) return (int)$u['id'];
    static $ownerId = null;
    if($ownerId !== null) return $ownerId;
    try {
        $ownerId = (int)(db()->query("SELECT id FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1")->fetchColumn() ?: 0);
    } catch(Throwable $e) { $ownerId = 0; }
    return $ownerId;
}

function useMobileContextByToken(string $token): ?int {
    global $mobileContextUserId;
    $pdo=db();
    $s=$pdo->prepare('SELECT owner_user_id FROM remotes WHERE mobile_token=? LIMIT 1');
    $s->execute([$token]);
    $uid=$s->fetchColumn();
    if($uid===false) return null;
    $mobileContextUserId=(int)$uid;
    $pdo->exec('SET @ajp_user_id = '.(int)$mobileContextUserId);
    return $mobileContextUserId;
}

function redirect(string $url): never { header('Location: ' . $url); exit; }
function flash(?string $message = null): ?string {
    if ($message !== null) { $_SESSION['flash'] = $message; return null; }
    $m = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $m;
}

function activeField(): ?array {
    $stmt = db()->query('SELECT * FROM `fields` WHERE owner_user_id = '.(int)currentOwnerId().' AND active = 1 ORDER BY id DESC LIMIT 1');
    return $stmt->fetch() ?: null;
}
function activeFields(): array {
    return db()->query('SELECT * FROM `fields` WHERE owner_user_id = '.(int)currentOwnerId().' AND active = 1 ORDER BY name ASC')->fetchAll();
}

function demoMode(): bool {
    $default = (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) ? '1' : '0';
    return appSetting('demo_mode', $default) === '1';
}
function diniConfig(): array {
    static $config = null;
    if ($config !== null) return $config;
    $defaults = require __DIR__ . '/config/dini.php';
    $enabled = !demoMode() && appSetting('dini_enabled', !empty($defaults['enabled']) ? '1' : '0') === '1';
    $host = appSetting('dini_host', (string)$defaults['host']);
    $port = (int)appSetting('dini_port', (string)$defaults['port']);
    $timeout = (float)appSetting('dini_timeout', (string)$defaults['timeout']);
    $config = ['enabled'=>$enabled,'host'=>$host,'port'=>$port,'timeout'=>$timeout];
    return $config;
}
function dini(): ?Dini3590 {
    static $instance = null;
    $cfg = diniConfig();
    if (empty($cfg['enabled'])) return null;
    if ($instance === null) {
        require_once __DIR__ . '/hardware/Dini3590.php';
        $instance = new Dini3590((string)$cfg['host'], (int)$cfg['port'], (float)$cfg['timeout']);
    }
    return $instance;
}
function testWeight(): float {
    try {
        $s=db()->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
        $s->execute([currentOwnerId(),'test_weight']);
        $v=$s->fetchColumn();
        return $v===false ? 0.0 : max(0.0,(float)$v);
    } catch(Throwable $e) { return 0.0; }
}
function setTestWeight(float $weight): void {
    $s=db()->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
    $s->execute([currentOwnerId(),'test_weight',number_format(max(0.0,$weight),3,'.','')]);
}
function scaleDisplayWeight(float $weight): float { return round(max(0.0,$weight) / 5.0) * 5.0; }
function formatScaleWeight(float $weight): string { return number_format(scaleDisplayWeight($weight),0,',','.'); }
function formatWeight(float $weight): string { return number_format(round($weight / 5.0) * 5.0, 0, ',', '.'); }
function diniWorkerBusy(): bool {
    $lockPath = '/var/lib/waagebox/dini/worker.lock';
    $handle = @fopen($lockPath, 'c');

    if ($handle === false) {
        return false;
    }

    if (!flock($handle, LOCK_EX | LOCK_NB)) {
        fclose($handle);
        return true;
    }

    flock($handle, LOCK_UN);
    fclose($handle);
    return false;
}

function currentWeight(): float {
    $scale = dini();
    if ($scale === null) return testWeight();

    if (diniWorkerBusy()) return 0.0;

    try {
        $r = $scale->readWeight();
        $status = strtoupper((string)($r['status'] ?? ''));
        if (in_array($status, ['OL','UL','ER'], true)) return 0.0;
        return max(0.0, (float)($r['weight'] ?? 0));
    } catch (Throwable $e) {
        return 0.0;
    }
}
function weightStatus(): string {
    $scale = dini();
    if ($scale === null) return currentWeight() > 0 ? 'Gewicht erkannt' : 'Bereit';

    if (diniWorkerBusy()) return 'Wiegung läuft';

    try {
        $r = $scale->readWeight();
        $status = strtoupper((string)($r['status'] ?? ''));
        return match ($status) {
            'OL' => 'Überlast',
            'UL' => 'Unterlast',
            'ER' => 'Waagenfehler',
            'ST' => 'Gewicht erkannt',
            default => ((float)($r['weight'] ?? 0) > 0 ? 'Gewicht erkannt' : 'Bereit'),
        };
    } catch (Throwable $e) {
        return 'Waage nicht erreichbar';
    }
}
function scaleProcessingActive(): bool {
    try {
        $v = appSetting('scale_processing_until', '0');
        return (int)$v > time();
    } catch(Throwable $e) { return false; }
}
function scaleStatusKey(): string {
    if (scaleProcessingActive()) return 'processing';
    return pendingWeighing() ? 'waiting' : 'ready';
}
function scaleStatusLabel(): string {
    if (scaleProcessingActive()) return 'Wiegung wird verarbeitet …';
    return pendingWeighing() ? 'Wiegung gestartet – wartet auf Überfahrt' : 'Bereit für nächste Wiegung';
}
function startSecondScaleWeighing(): void {
    $scale = dini();
    if ($scale !== null) $scale->startSecondWeighing();
}
function startFirstScaleWeighing(): void {
    $scale = dini();
    if ($scale !== null) $scale->startFirstWeighing();
}

function nav(string $active): void {
    $items = [
      'dashboard'=>'Dashboard','vehicles'=>'Fahrzeuge','customers'=>'Kunden','products'=>'Produkte','fields'=>'Schläge','remotes'=>'Fernbedienungen','weighings'=>'Wiegungen','settings'=>'Einstellungen'
    ];
    echo '<nav class="nav">';
    foreach ($items as $key=>$label) {
        echo '<a class="'.($active===$key?'active':'').'" href="'.($key==='dashboard'?'index.php':$key.'.php').'">'.h($label).'</a>';
    }
    echo '<a class="button" href="logout.php">Abmelden</a></nav>';
}
function layoutStart(string $title, string $active=''): void {
    $brand = appSetting('brand_name','AJP WAAGE');
    if ($brand === '') $brand = 'AJP WAAGE';
    echo '<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>'.h($title).' – '.h($brand).'</title><meta name="csrf-token" content="'.h(csrfToken()).'"><script>function csrfHeaders(){return {"X-CSRF-Token":document.querySelector("meta[name=csrf-token]")?.content||""};}</script><link rel="stylesheet" href="assets/style.css"></head><body class="page-'.h($active).'">';
    echo '<header class="top"><div class="brand-block"><div class="brand">'.h($brand).'</div><div class="sub">Waagensteuerung · Weboberfläche · Version '.h(APP_VERSION).'</div><div class="dashboard-clock-header"><span id="dashboardClock">–</span></div></div>';
    nav($active);
    echo '</header><main class="container">';
    if ($m = flash()) echo '<div class="flash">'.h($m).'</div>';
}
function layoutEnd(bool $dashboardCopyright = false): void {
    if (passwordProtectionRequired()) echo '<script src="assets/session.js"></script>';
    echo '</main><footer>AJP Waagensteuerung · Version '.h(APP_VERSION).($dashboardCopyright ? '<br>Copyright by Tobias Purk' : '').'</footer>';
    echo '<script>function updateDashboardClock(){const e=document.getElementById("dashboardClock");if(e)e.textContent=new Date().toLocaleString("de-DE",{dateStyle:"short",timeStyle:"medium"});}updateDashboardClock();setInterval(updateDashboardClock,1000);</script>';
    echo '</body></html>';
}

function appSetting(string $key, string $default=''): string {
    static $cache = [];
    $ownerId = currentOwnerId();
    $cacheKey = $ownerId.':'.$key;
    if (array_key_exists($cacheKey, $cache)) return $cache[$cacheKey];
    try {
        $s = db()->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
        $s->execute([$ownerId,$key]);
        $v = $s->fetchColumn();
        return $cache[$cacheKey] = ($v===false ? $default : (string)$v);
    } catch(Throwable $e) { return $cache[$cacheKey] = $default; }
}
function saveAppSetting(string $key, string $value): void {
    $s = db()->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
    $s->execute([currentOwnerId(),$key,$value]);
}
require_once __DIR__.'/telegram_support.php';
require_once __DIR__.'/feldmanager_link.php';

function diniConnectionStatus(): array {
    $cfg = diniConfig();
    if (empty($cfg['enabled'])) return ['state'=>'disabled','label'=>'Nicht aktiviert','detail'=>'Die Verbindung zum Waagencomputer ist derzeit deaktiviert.'];
    try {
        $scale = dini();
        if ($scale === null) return ['state'=>'disabled','label'=>'Nicht aktiviert','detail'=>'Die Verbindung ist deaktiviert.'];
        $version = trim($scale->identify());
        return ['state'=>'connected','label'=>'Verbunden','detail'=>$version !== '' ? 'Antwort: '.$version : 'Waagencomputer antwortet.'];
    } catch(Throwable $e) {
        return ['state'=>'error','label'=>'Nicht erreichbar','detail'=>$e->getMessage()];
    }
}

function updateBaseUrl(): string {
    $saved = rtrim(trim(appSetting('update_server_url','')), '/');
    $channelDefault = (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) ? 'staging' : 'release';
    $channel = appSetting('update_channel', $channelDefault);
    if (!in_array($channel, ['release','staging'], true)) $channel = $channelDefault;

    // Die beiden offiziellen Kanäle werden zentral geschaltet. Eine ausdrücklich
    // abweichende Server-URL bleibt für Sonderinstallationen erhalten.
    $official = ['https://update.ajp-bg.de/release','https://update.ajp-bg.de/staging'];
    if ($saved === '' || in_array($saved, $official, true)) {
        return 'https://update.ajp-bg.de/'.$channel;
    }
    return $saved;
}
function updateCheckUrl(): string {
    return updateBaseUrl().'/manifest.json';
}
function updateIgnoredVersion(): string { return appSetting('update_ignored_version',''); }
function setUpdateIgnoredVersion(string $version): void { saveAppSetting('update_ignored_version',$version); }
function updateSnoozedUntil(): string { return appSetting('update_snoozed_until',''); }
function setUpdateSnoozedUntil(string $until): void { saveAppSetting('update_snoozed_until',$until); }
function compareAppVersions(string $a,string $b): int { return version_compare($a,$b); }

function rollbackBackupRoot(): string {
    $default = '/var/lib/waagebox/rollback';
    if (!defined('ROLLBACK_BACKUP_ROOT')) return $default;
    $override = ROLLBACK_BACKUP_ROOT;
    if (!is_string($override) || $override === '' || str_contains($override, "\0") || $override === '/' ||
        !preg_match('~^/(?:[^/\\0]+/)*[^/\\0]+$~D', $override) ||
        (in_array('..', explode('/', $override), true) || in_array('.', explode('/', $override), true))) {
        throw new RuntimeException('Ungültiger ROLLBACK_BACKUP_ROOT. Erwartet wird ein absoluter Linux-Pfad ohne relative Bestandteile.');
    }
    return $override;
}
function rollbackInfo(): ?array {
    $file=rollbackBackupRoot().'/metadata.json';
    if(!is_file($file)) return null;
    $data=json_decode((string)@file_get_contents($file),true);
    if(!is_array($data) || empty($data['previous_version']) || !is_dir(rollbackBackupRoot().'/app') || !is_file(rollbackBackupRoot().'/database.sql')) return null;
    return $data;
}
function numOrNull($v) {
    return ($v === '' || $v === null) ? null : (float)str_replace(',', '.', (string)$v);
}
function pendingWeighing(): ?array {
    try { $s=db()->prepare('SELECT * FROM weighing_state WHERE owner_user_id=? AND id=1'); $s->execute([currentOwnerId()]); return $s->fetch() ?: null; }
    catch(Throwable $e) { return $_SESSION['pending_weighing'] ?? null; }
}

function startDiniPendingWorker(float $resultTimeout = 360.0): bool {
    $cfg = diniConfig();

    // Demo-/Testbetrieb oder deaktivierter DINI:
    // Es wird bewusst kein Hardware-Worker gestartet.
    if (empty($cfg['enabled'])) {
        return false;
    }

    if ($resultTimeout <= 0) {
        throw new InvalidArgumentException(
            'DINI Ergebnis-Timeout muss größer als 0 sein.'
        );
    }

    $pending = pendingWeighing();
    if (!$pending) {
        throw new RuntimeException(
            'DINI Worker kann ohne laufende Wiegung nicht gestartet werden.'
        );
    }

    $ownerId = currentOwnerId();
    $vehicleId = (int)($pending['vehicle_id'] ?? 0);
    $trigger = trim((string)($pending['trigger_type'] ?? ''));
    $startedAt = trim((string)($pending['started_at'] ?? ''));

    if (
        $ownerId <= 0 ||
        $vehicleId < 0 ||
        $trigger === '' ||
        !preg_match(
            '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
            $startedAt
        )
    ) {
        throw new RuntimeException(
            'DINI Worker: laufender Auftrag besitzt keine gültige Identität.'
        );
    }

    $worker = __DIR__ . '/cli/dini_weighing_worker.php';
    $log = '/var/lib/waagebox/dini/worker.log';

    if (!is_file($worker)) {
        throw new RuntimeException(
            'DINI Worker wurde nicht gefunden.'
        );
    }

    $command = implode(' ', array_map(
        'escapeshellarg',
        [
            '/usr/bin/php8.4',
            $worker,
            '--host',
            (string)$cfg['host'],
            '--port',
            (string)(int)$cfg['port'],
            '--timeout',
            (string)$resultTimeout,
            '--owner-id',
            (string)$ownerId,
            '--vehicle-id',
            (string)$vehicleId,
            '--trigger',
            $trigger,
            '--started-at',
            $startedAt,
        ]
    ));

    $shellCommand =
        'nohup ' . $command .
        ' >> ' . escapeshellarg($log) .
        ' 2>&1 < /dev/null &';

    $process = proc_open(
        ['/bin/sh', '-c', $shellCommand],
        [
            0 => ['file', '/dev/null', 'r'],
            1 => ['file', '/dev/null', 'a'],
            2 => ['file', '/dev/null', 'a'],
        ],
        $pipes,
        __DIR__
    );

    if (!is_resource($process)) {
        throw new RuntimeException(
            'DINI Hintergrundworker konnte nicht gestartet werden.'
        );
    }

    $rc = proc_close($process);

    if ($rc !== 0) {
        throw new RuntimeException(
            "DINI Hintergrundworker konnte nicht gestartet werden (RC={$rc})."
        );
    }

    return true;
}

function findOrCreateManualExternalVehicle(string $label): array {
    $label=trim(preg_replace('/\s+/u',' ',$label));
    if ($label === '') throw new RuntimeException('Bitte Kennzeichen oder Bezeichnung des externen Fahrzeugs eingeben.');
    if (mb_strlen($label) > 50) throw new RuntimeException('Kennzeichen / Bezeichnung darf höchstens 50 Zeichen lang sein.');

    $pdo=db();
    $ownerId=currentOwnerId();

    $s=$pdo->prepare(
        'SELECT id,plate,name,first_weight,manual_external,active
           FROM vehicles
          WHERE owner_user_id=? AND plate=?
          LIMIT 1'
    );
    $s->execute([$ownerId,$label]);
    $existing=$s->fetch();

    if($existing){
        if((int)$existing['manual_external']!==1){
            throw new RuntimeException('Dieses Kennzeichen ist bereits als Stammfahrzeug vorhanden. Bitte das Fahrzeug aus der Liste auswählen.');
        }
        if((int)$existing['active']!==1){
            $u=$pdo->prepare('UPDATE vehicles SET active=1 WHERE owner_user_id=? AND id=?');
            $u->execute([$ownerId,(int)$existing['id']]);
            $existing['active']=1;
        }
        return $existing;
    }

    $stmt=$pdo->prepare(
        'INSERT INTO vehicles
         (owner_user_id,plate,name,first_weight,max_weight,notes,active,manual_external)
         VALUES (?,?,?,?,?,?,1,1)'
    );
    $stmt->execute([$ownerId,$label,'Externes Fahrzeug',0,null,'Automatisch durch manuelle Wiegung angelegt.']);

    return [
        'id'=>(int)$pdo->lastInsertId(),
        'plate'=>$label,
        'name'=>'Externes Fahrzeug',
        'first_weight'=>0.0,
        'manual_external'=>1,
        'active'=>1
    ];
}

function openVehicleWeighing(int $vehicleId): ?array {
    if ($vehicleId <= 0) return null;
    try {
        $s=db()->prepare('SELECT * FROM open_vehicle_weighings WHERE owner_user_id=? AND vehicle_id=? LIMIT 1');
        $s->execute([currentOwnerId(),$vehicleId]);
        return $s->fetch() ?: null;
    } catch(Throwable $e) {
        return null;
    }
}

function openVehicleWeighings(): array {
    try {
        $s=db()->prepare(
            'SELECT o.*,v.plate,v.name AS vehicle_name
               FROM open_vehicle_weighings o
               JOIN vehicles v
                 ON v.owner_user_id=o.owner_user_id AND v.id=o.vehicle_id
              WHERE o.owner_user_id=?
              ORDER BY o.first_measured_at ASC'
        );
        $s->execute([currentOwnerId()]);
        return $s->fetchAll();
    } catch(Throwable $e) {
        return [];
    }
}

function saveOpenVehicleWeighing(
    int $vehicleId,
    float $firstWeight,
    ?int $remoteId=null,
    string $trigger='manual',
    ?int $fieldId=null,
    ?int $customerId=null,
    ?int $productId=null
): void {
    if ($vehicleId <= 0) throw new RuntimeException('Für eine offene Wiegung muss ein Fahrzeug ausgewählt sein.');
    if ($firstWeight <= 0) throw new RuntimeException('Es wurde noch kein gültiges erstes Gewicht erkannt.');
    $fieldId=feldmanagerAutomaticFieldId($fieldId,$remoteId);
    $s=db()->prepare(
        'INSERT INTO open_vehicle_weighings
         (owner_user_id,vehicle_id,first_weight,remote_id,field_id,customer_id,product_id,trigger_type,first_measured_at)
         VALUES (?,?,?,?,?,?,?,?,NOW())
         ON DUPLICATE KEY UPDATE
           first_weight=VALUES(first_weight),
           remote_id=VALUES(remote_id),
           field_id=VALUES(field_id),
           customer_id=VALUES(customer_id),
           product_id=VALUES(product_id),
           trigger_type=VALUES(trigger_type),
           first_measured_at=VALUES(first_measured_at)'
    );
    $s->execute([
        currentOwnerId(),$vehicleId,$firstWeight,$remoteId,$fieldId,$customerId,$productId,$trigger
    ]);
}

function clearOpenVehicleWeighing(int $vehicleId): void {
    if ($vehicleId <= 0) return;
    try {
        $s=db()->prepare('DELETE FROM open_vehicle_weighings WHERE owner_user_id=? AND vehicle_id=?');
        $s->execute([currentOwnerId(),$vehicleId]);
    } catch(Throwable $e) {}
}

function startVehiclePass(
    int $vehicleId,
    ?int $remoteId=null,
    string $trigger='manual',
    ?int $fieldId=null,
    ?int $customerId=null,
    ?int $productId=null
): string {
    if (pendingWeighing()) throw new RuntimeException('Die Waage ist gerade durch eine andere Überfahrt belegt.');
    if (currentWeight() > 0) throw new RuntimeException('Die Waage muss vor dem Start der Überfahrt leer sein.');
    $open=openVehicleWeighing($vehicleId);
    if ($open) {
        setPendingWeighing(
            (float)$open['first_weight'],
            $vehicleId,
            $remoteId ?? (!empty($open['remote_id']) ? (int)$open['remote_id'] : null),
            $trigger,
            $fieldId ?? (!empty($open['field_id']) ? (int)$open['field_id'] : null),
            $customerId ?? (!empty($open['customer_id']) ? (int)$open['customer_id'] : null),
            $productId ?? (!empty($open['product_id']) ? (int)$open['product_id'] : null)
        );
        try {
            startDiniPendingWorker();
        } catch (Throwable $e) {
            clearPendingWeighing();
            throw $e;
        }
        return 'second';
    }

    $vehicleStmt=db()->prepare(
        'SELECT first_weight,manual_external
           FROM vehicles
          WHERE owner_user_id=? AND id=? AND active=1
          LIMIT 1'
    );
    $vehicleStmt->execute([currentOwnerId(),$vehicleId]);
    $vehicleData=$vehicleStmt->fetch() ?: [];
    $savedTare=(float)($vehicleData['first_weight'] ?? 0);
    $manualExternal=(int)($vehicleData['manual_external'] ?? 0)===1;

    if ($savedTare > 0 && !$manualExternal) {
        setPendingWeighing(
            $savedTare,
            $vehicleId,
            $remoteId,
            $trigger,
            $fieldId,
            $customerId,
            $productId
        );
        try {
            startDiniPendingWorker();
        } catch (Throwable $e) {
            clearPendingWeighing();
            throw $e;
        }
        return 'saved_tare';
    }

    // first_weight=0 kennzeichnet eine gestartete erste Überfahrt. Das Gewicht
    // wird erst erfasst, wenn DINI bzw. der Testbetrieb tatsächlich Gewicht meldet.
    try {
        $s=db()->prepare(
            'INSERT INTO weighing_state
             (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at)
             VALUES (?,1,0,?,?,?,?,?,?,NOW())
             ON DUPLICATE KEY UPDATE
               first_weight=0,
               vehicle_id=VALUES(vehicle_id),
               remote_id=VALUES(remote_id),
               field_id=VALUES(field_id),
               customer_id=VALUES(customer_id),
               product_id=VALUES(product_id),
               trigger_type=VALUES(trigger_type),
               started_at=VALUES(started_at)'
        );
        $s->execute([
            currentOwnerId(),$vehicleId,$remoteId,$fieldId,$customerId,$productId,$trigger.'_first_pass'
        ]);
        startDiniPendingWorker();
    } catch(Throwable $e) {
        clearPendingWeighing();
        throw $e;
    }
    return 'first';
}

function capturePendingFirstPass(float $weight): array {
    $pending=pendingWeighing();
    if(!$pending) throw new RuntimeException('Es ist keine erste Überfahrt gestartet.');
    $vehicleId=(int)($pending['vehicle_id']??0);
    if($weight<=0) throw new RuntimeException('Es wurde noch kein gültiges Gewicht erkannt.');

    $baseTrigger=preg_replace('/_first_pass$/','',(string)($pending['trigger_type']??'manual')) ?: 'manual';

    if($vehicleId>0){
        saveOpenVehicleWeighing(
            $vehicleId,
            $weight,
            !empty($pending['remote_id']) ? (int)$pending['remote_id'] : null,
            $baseTrigger,
            !empty($pending['field_id']) ? (int)$pending['field_id'] : null,
            !empty($pending['customer_id']) ? (int)$pending['customer_id'] : null,
            !empty($pending['product_id']) ? (int)$pending['product_id'] : null
        );
        clearPendingWeighing();
    }else{
        // Ohne Fahrzeug kann die erste Überfahrt keinem später zurückkehrenden
        // Fahrzeug zugeordnet werden. Deshalb bleibt diese manuelle Wiegung
        // aktiv und wartet direkt auf die zweite Überfahrt.
        $s=db()->prepare(
            'UPDATE weighing_state
                SET first_weight=?, trigger_type=?, started_at=NOW()
              WHERE owner_user_id=? AND id=1'
        );
        $s->execute([$weight,$baseTrigger,currentOwnerId()]);
    }

    if (dini() === null) setTestWeight(0.0);
    setScaleProcessing(grossanzeigeFirstProcessingSeconds(), $weight, 'first_pass');

    return [
        'vehicle_id'=>$vehicleId,
        'first_weight'=>$weight,
        'waiting_for_second'=>$vehicleId<=0
    ];
}
function completeVehicleFirstWeight(float $weight, int $vehicleId): array {
    if ($vehicleId <= 0) {
        throw new RuntimeException('Für die Erstgewichtserfassung ist kein Fahrzeug ausgewählt.');
    }

    $pdo = db();

    $s = $pdo->prepare(
        'SELECT plate,first_weight
           FROM vehicles
          WHERE owner_user_id=? AND id=? AND active=1
          LIMIT 1'
    );
    $s->execute([currentOwnerId(),$vehicleId]);
    $vehicle = $s->fetch();

    if (!$vehicle) {
        throw new RuntimeException('Fahrzeug wurde nicht gefunden oder ist nicht aktiv.');
    }

    $existing = (float)($vehicle['first_weight'] ?? 0);
    if ($existing > 0) {
        clearPendingWeighing();
        return [
            'saved'=>false,
            'already_present'=>true,
            'vehicle_id'=>$vehicleId,
            'plate'=>(string)($vehicle['plate'] ?? ''),
            'first_weight'=>$existing
        ];
    }

    if ($weight <= 0) {
        throw new RuntimeException(
            'Es wurde noch kein gültiges Gewicht erkannt.'
        );
    }

    $u = $pdo->prepare(
        'UPDATE vehicles
            SET first_weight=?
          WHERE owner_user_id=? AND id=? AND first_weight<=0'
    );
    $u->execute([$weight,currentOwnerId(),$vehicleId]);

    if ($u->rowCount() !== 1) {
        throw new RuntimeException('Das Erstgewicht wurde zwischenzeitlich bereits gesetzt.');
    }

    clearPendingWeighing();
    if (dini() === null) setTestWeight(0.0);

    return [
        'saved'=>true,
        'already_present'=>false,
        'vehicle_id'=>$vehicleId,
        'plate'=>(string)($vehicle['plate'] ?? ''),
        'first_weight'=>$weight
    ];
}

function setPendingWeighing(float $first, ?int $vehicleId=null, ?int $remoteId=null, string $trigger='manual', ?int $fieldId=null, ?int $customerId=null, ?int $productId=null): void {
    $fieldId=feldmanagerAutomaticFieldId($fieldId,$remoteId);
    try {
        $s=db()->prepare('INSERT INTO weighing_state (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at) VALUES (?,1,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE first_weight=VALUES(first_weight),vehicle_id=VALUES(vehicle_id),remote_id=VALUES(remote_id),field_id=VALUES(field_id),customer_id=VALUES(customer_id),product_id=VALUES(product_id),trigger_type=VALUES(trigger_type),started_at=VALUES(started_at)');
        $s->execute([currentOwnerId(),$first,$vehicleId,$remoteId,$fieldId,$customerId,$productId,$trigger]);
    } catch(Throwable $e) {
        $_SESSION['pending_weighing'] = ['first_weight'=>$first,'vehicle_id'=>$vehicleId,'remote_id'=>$remoteId,'field_id'=>$fieldId,'customer_id'=>$customerId,'product_id'=>$productId,'trigger_type'=>$trigger,'started_at'=>date('Y-m-d H:i:s')];
        throw $e;
    }
}
function fieldName(int $fieldId): string {
    $stmt = db()->prepare('SELECT name FROM `fields` WHERE owner_user_id=? AND id=?'); $stmt->execute([currentOwnerId(),$fieldId]);
    return (string)($stmt->fetchColumn() ?: 'Unbekannter Schlag');
}
function vehicleLabel(int $vehicleId): string {
    $stmt = db()->prepare('SELECT CONCAT(plate, IF(name IS NULL OR name="", "", CONCAT(" – ", name))) FROM vehicles WHERE owner_user_id=? AND id=?');
    $stmt->execute([currentOwnerId(),$vehicleId]); return (string)($stmt->fetchColumn() ?: 'Unbekanntes Fahrzeug');
}
function customerName(int $id): string { $s=db()->prepare('SELECT name FROM customers WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$id]); return (string)($s->fetchColumn() ?: 'Unbekannter Kunde'); }
function productName(int $id): string { $s=db()->prepare('SELECT name FROM products WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$id]); return (string)($s->fetchColumn() ?: 'Unbekanntes Produkt'); }
function remoteAssignment(PDO $pdo, string $table, string $column, int $remoteId): ?int {
    $q=$pdo->prepare("SELECT $column FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 ORDER BY is_default DESC, $column LIMIT 1");
    $q->execute([currentOwnerId(),$remoteId]);
    $first=$q->fetchColumn();
    if($first===false) return null;
    $c=$pdo->prepare("SELECT COUNT(*) FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1");
    $c->execute([currentOwnerId(),$remoteId]);
    if((int)$c->fetchColumn()>1){
        $q=$pdo->prepare("SELECT $column FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 AND is_default=1 LIMIT 1");
        $q->execute([currentOwnerId(),$remoteId]);
        $v=$q->fetchColumn();
        return $v===false?null:(int)$v;
    }
    return (int)$first;
}
function mobileRemoteUrl(string $token): string {
    return mobileRemoteBaseUrl().'/mobile_remote.php?t='.rawurlencode($token);
}

function mobileRemoteBaseUrl(): string {
    // Optionaler installationsbezogener Override. Die Testdatenbank kann so
    // gezielt auf /waage-test zeigen, ohne den produktiven Endpunkt zu ändern.
    $override=trim(appSetting('mobile_remote_base_url',''));
    if($override!=='') return rtrim($override,'/');

    return 'https://waage-ajp.de';
}


function ticketNumberResetBases(): array {
    $raw=appSetting('ticket_number_reset_bases','');
    if($raw==='') return [];
    $data=json_decode($raw,true);
    if(!is_array($data)) return [];
    $bases=[];
    foreach($data as $v){
        $n=(int)$v;
        if($n>=0) $bases[$n]=$n;
    }
    ksort($bases,SORT_NUMERIC);
    return array_values($bases);
}
function ticketNumberForWeighing(int $weighingId): int {
    if($weighingId<=0) return 0;
    $base=0;
    foreach(ticketNumberResetBases() as $candidate){
        if($candidate < $weighingId) $base=$candidate;
        else break;
    }
    return max(1,$weighingId-$base);
}
function formattedTicketNumberForWeighing(int $weighingId): string {
    return str_pad((string)ticketNumberForWeighing($weighingId),6,'0',STR_PAD_LEFT);
}
function nextTicketNumberPreview(): string {
    $s=db()->prepare('SELECT COALESCE(MAX(id),0)+1 FROM weighings WHERE owner_user_id=?');
    $s->execute([currentOwnerId()]);
    return formattedTicketNumberForWeighing((int)$s->fetchColumn());
}
function resetTicketNumberSequence(): int {
    $pdo=db();
    $s=$pdo->prepare('SELECT COALESCE(MAX(id),0) FROM weighings WHERE owner_user_id=?');
    $s->execute([currentOwnerId()]);
    $base=(int)$s->fetchColumn();
    $bases=ticketNumberResetBases();
    if(!in_array($base,$bases,true)){
        $bases[]=$base;
        sort($bases,SORT_NUMERIC);
        saveAppSetting('ticket_number_reset_bases',json_encode(array_values($bases),JSON_UNESCAPED_UNICODE));
    }
    return $base;
}

function cameraEnabled(): bool { return appSetting('camera_enabled','0') === '1'; }
function cameraStreamUrl(): string { return trim(appSetting('camera_stream_url','')); }
function cameraSnapshotEnabled(): bool { return appSetting('camera_snapshot_enabled','0') === '1'; }
function cameraSnapshotUrl(): string { return trim(appSetting('camera_snapshot_url','')); }
function cameraSnapshotRelativePath(int $weighingId): string { return 'uploads/camera/weighing_'.$weighingId.'.jpg'; }
function cameraSnapshotAbsolutePath(int $weighingId): string { return __DIR__ . '/' . cameraSnapshotRelativePath($weighingId); }
function deleteCameraSnapshot(int $weighingId): void { $p=cameraSnapshotAbsolutePath($weighingId); if(is_file($p)) @unlink($p); }
function captureCameraSnapshot(int $weighingId): bool {
    if (!cameraEnabled() || !cameraSnapshotEnabled()) return false;
    $url=cameraSnapshotUrl();
    if ($url==='') return false;
    if (!preg_match('~^https?://~i',$url)) return false;
    $dir=dirname(cameraSnapshotAbsolutePath($weighingId));
    if (!is_dir($dir)) @mkdir($dir,0775,true);
    if (!is_dir($dir) || !is_writable($dir)) return false;
    $data=false;
    if (function_exists('curl_init')) {
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>8,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>'AJP-Waagenbox-Kamera/1.0']);
        $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $type=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE); curl_close($ch);
        if ($body!==false && $code>=200 && $code<400 && strlen($body)>100) $data=$body;
    }
    if ($data===false) {
        $ctx=stream_context_create(['http'=>['timeout'=>8,'follow_location'=>1,'user_agent'=>'AJP-Waagenbox-Kamera/1.0'],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $body=@file_get_contents($url,false,$ctx);
        if ($body!==false && strlen($body)>100) $data=$body;
    }
    if ($data===false) return false;
    $img=@imagecreatefromstring($data);
    if (!$img) return false;
    $path=cameraSnapshotAbsolutePath($weighingId);
    $ok=@imagejpeg($img,$path,88); imagedestroy($img);
    return $ok && is_file($path) && filesize($path)>0;
}

function completePendingWeighing(float $secondWeight, string $notes=''): int {
    $pending = pendingWeighing();
    if (!$pending) throw new RuntimeException('Es ist keine laufende Wiegung vorhanden.');
    if ($secondWeight <= 0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
    $pdo = db();
    $firstWeight = (float)$pending['first_weight'];
    $tareWeight = min($firstWeight, $secondWeight);
    $grossWeight = max($firstWeight, $secondWeight);
    $net = $grossWeight - $tareWeight;
    $stmt = $pdo->prepare('INSERT INTO weighings (owner_user_id,vehicle_id,field_id,customer_id,product_id,remote_id,first_weight,second_weight,net_weight,trigger_type,scale_status,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
    $stmt->execute([currentOwnerId(),!empty($pending['vehicle_id']) ? (int)$pending['vehicle_id'] : null,!empty($pending['field_id']) ? (int)$pending['field_id'] : null,!empty($pending['customer_id']) ? (int)$pending['customer_id'] : null,!empty($pending['product_id']) ? (int)$pending['product_id'] : null,!empty($pending['remote_id']) ? (int)$pending['remote_id'] : null,$pending['first_weight'],$secondWeight,$net,$pending['trigger_type'] ?? 'manual','completed',trim($notes)]);
    $id = (int)$pdo->lastInsertId();
    // Ein Kameraschnappschuss gehört zur Wiegung, blockiert den Abschluss aber nicht,
    // falls die Kamera nicht erreichbar ist.
    captureCameraSnapshot($id);
    clearPendingWeighing();

    $vehicleId = !empty($pending['vehicle_id']) ? (int)$pending['vehicle_id'] : 0;
    if ($vehicleId > 0) {
        clearOpenVehicleWeighing($vehicleId);

        // Ein bisher unbekanntes Stammfahrzeug-Leergewicht wird erst nach
        // zwei tatsächlichen Überfahrten aus dem kleineren der beiden Werte
        // abgeleitet. Temporäre externe Fahrzeuge bekommen bewusst KEIN
        // dauerhaftes Leergewicht, damit jede neue Lieferung wieder aus zwei
        // echten Überfahrten besteht.
        $u=$pdo->prepare(
            'UPDATE vehicles
                SET first_weight=?
              WHERE owner_user_id=?
                AND id=?
                AND first_weight<=0
                AND manual_external=0'
        );
        $u->execute([$tareWeight,currentOwnerId(),$vehicleId]);
    }

    // Im Testbetrieb (kein Dini-Waagencomputer aktiv) wird die simulierte
    // Waage nach erfolgreichem Abschluss wieder auf 0 kg gesetzt.
    if (dini() === null) setTestWeight(0.0);
    // Die rote Verarbeitungsphase gilt für Web-Testbetrieb und Raspberry.
    setScaleProcessing(grossanzeigeCompleteProcessingSeconds()+grossanzeigeSuccessSeconds(), $secondWeight, 'complete');

    return $id;
}
function clearPendingWeighing(): void { try { $s=db()->prepare('DELETE FROM weighing_state WHERE owner_user_id=? AND id=1'); $s->execute([currentOwnerId()]); } catch(Throwable $e) {} unset($_SESSION['pending_weighing']); }

function grossanzeigeInterfaceEnabled(): bool {
    return appSetting('grossanzeige_enabled','0') === '1';
}

function grossanzeigeDisplayEnabled(): bool {
    return appSetting('grossanzeige_display_enabled','1') === '1';
}

function grossanzeigeBaseUrl(): string {
    $address=trim(appSetting('grossanzeige_address',''));
    if($address==='') return '';
    if(!preg_match('~^https?://~i',$address)) $address='http://'.$address;
    return rtrim($address,'/');
}

function grossanzeigeConnectionStatus(): array {
    if(!grossanzeigeInterfaceEnabled()) return ['state'=>'off','label'=>'Aus'];
    $base=grossanzeigeBaseUrl();
    if($base==='') return ['state'=>'unknown','label'=>'Nicht konfiguriert'];

    $url=$base.'/api/status';
    try {
        if(function_exists('curl_init')){
            $ch=curl_init($url);
            curl_setopt_array($ch,[
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_CONNECTTIMEOUT_MS=>700,
                CURLOPT_TIMEOUT_MS=>1200,
                CURLOPT_FOLLOWLOCATION=>false,
                CURLOPT_HTTPHEADER=>['Accept: application/json'],
            ]);
            $body=curl_exec($ch);
            $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
            curl_close($ch);
            if($body!==false && $code>=200 && $code<300){
                $data=json_decode((string)$body,true);
                if(is_array($data)) return ['state'=>'connected','label'=>'Verbunden'];
            }
        }else{
            $ctx=stream_context_create(['http'=>['timeout'=>1.2,'ignore_errors'=>true,'header'=>"Accept: application/json\r\n"]]);
            $body=@file_get_contents($url,false,$ctx);
            if($body!==false && is_array(json_decode((string)$body,true))) return ['state'=>'connected','label'=>'Verbunden'];
        }
    } catch(Throwable $e) {}
    return ['state'=>'error','label'=>'Nicht erreichbar'];
}

function grossanzeigeFirstProcessingSeconds(): int {
    return max(1,min(120,(int)appSetting('grossanzeige_first_processing_seconds','10')));
}

function grossanzeigeCompleteProcessingSeconds(): int {
    return max(1,min(120,(int)appSetting('grossanzeige_complete_processing_seconds','10')));
}

function grossanzeigeSuccessSeconds(): int {
    return max(1,min(120,(int)appSetting('grossanzeige_success_seconds','10')));
}

function setScaleProcessing(int $seconds = 5, ?float $displayWeight = null, string $kind = 'processing'): void {
    try {
        $pdo=db();
        $until=time()+max(1,$seconds);
        $u = $pdo->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
        $u->execute([currentOwnerId(),'scale_processing_until',(string)$until]);
        $u->execute([currentOwnerId(),'scale_processing_kind',$kind]);
        if ($displayWeight !== null) {
            $u->execute([currentOwnerId(),'scale_processing_weight',(string)max(0.0,$displayWeight)]);
        }
    } catch(Throwable $e) {}
}

function scaleProcessingWeight(): float {
    try {
        return max(0.0,(float)appSetting('scale_processing_weight','0'));
    } catch(Throwable $e) {
        return 0.0;
    }
}

function scaleProcessingKind(): string {
    try {
        return trim(appSetting('scale_processing_kind','processing')) ?: 'processing';
    } catch(Throwable $e) {
        return 'processing';
    }
}
