<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$file = $root . '/cli/dini_weighing_complete.php';

$src = file_get_contents($file);
if ($src === false) {
    fwrite(STDERR, "FAIL: dini_weighing_complete.php konnte nicht gelesen werden.\n");
    exit(1);
}

$checks = [
    'first-pass uses capturePendingFirstPass' =>
        str_contains($src, "str_ends_with(\$pendingTrigger, '_first_pass')") &&
        str_contains($src, 'capturePendingFirstPass($weight)'),

    'ELDAT first weight is supported' =>
        str_contains($src, "'eldat_first_weight'"),

    'mobile first weight is supported' =>
        str_contains($src, "'mobile_first_weight'"),

    'first-weight dispatch uses completeVehicleFirstWeight' =>
        str_contains($src, 'completeVehicleFirstWeight('),

    'regular weighing uses completePendingWeighing' =>
        str_contains($src, 'completePendingWeighing($weight)'),

    'preflight exits before any weighing mutation' => (
        ($checkPos = strpos($src, 'if ($checkOnly)')) !== false &&
        ($exitPos = strpos($src, 'exit(0);', $checkPos)) !== false &&
        ($firstPassPos = strpos($src, 'capturePendingFirstPass($weight)')) !== false &&
        ($firstWeightPos = strpos($src, 'completeVehicleFirstWeight(')) !== false &&
        ($regularPos = strpos($src, 'completePendingWeighing($weight)')) !== false &&
        $checkPos < $exitPos &&
        $exitPos < $firstPassPos &&
        $exitPos < $firstWeightPos &&
        $exitPos < $regularPos
    ),
];

$failed = 0;

foreach ($checks as $name => $ok) {
    if ($ok) {
        echo "PASS: {$name}\n";
    } else {
        echo "FAIL: {$name}\n";
        $failed++;
    }
}

if ($failed > 0) {
    echo "RESULT: {$failed} check(s) failed\n";
    exit(1);
}

echo "RESULT: " . count($checks) . " checks passed\n";
