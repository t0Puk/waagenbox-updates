<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$worker = $root . '/cli/dini_weighing_worker.php';

if (!is_file($worker)) {
    fwrite(STDERR, "FAIL: DINI Worker nicht gefunden.\n");
    exit(1);
}

$tmp = sys_get_temp_dir() . '/waagebox_dini_two_pass_' . getmypid();

if (!mkdir($tmp, 0700, true) && !is_dir($tmp)) {
    fwrite(STDERR, "FAIL: Temporäres Verzeichnis konnte nicht erstellt werden.\n");
    exit(1);
}

$serverScript = $tmp . '/server.py';
$completeScript = $tmp . '/complete.php';
$serverLog = $tmp . '/server.log';
$completeLog = $tmp . '/complete.log';
$stateFile = $tmp . '/state';

$port = random_int(20000, 40000);

$server = <<<'PY'
import socket
import sys

HOST = "127.0.0.1"
PORT = __PORT__

results = [
    "05/10/26;21:00;      101;;;    1200;;;;Erstes Wiegung;;       0;       0",
    "05/10/26;21:01;      102;;;    3200;;;;Erstes Wiegung;;       0;       0",
]

def recv_line(conn):
    data = b""
    while not data.endswith(b"\n"):
        chunk = conn.recv(1)
        if not chunk:
            raise RuntimeError("Client closed connection")
        data += chunk
    return data.decode("ascii").strip("\r\n")

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen(1)

    print("READY", flush=True)

    for n, result in enumerate(results, start=1):
        conn, _ = s.accept()

        with conn:
            cmd = recv_line(conn)
            print(f"PASS{n}:RX:{cmd}", flush=True)

            if cmd != "KEYP37":
                sys.exit(10)

            conn.sendall(b"OK\r\n")

            cmd = recv_line(conn)
            print(f"PASS{n}:RX:{cmd}", flush=True)

            if cmd != "KEYR":
                sys.exit(11)

            conn.sendall(b"OK\r\n")
            conn.sendall((result + "\r\n").encode("ascii"))

print("DONE", flush=True)
PY;

$server = str_replace('__PORT__', (string)$port, $server);

$complete = <<<'PHP2'
<?php
declare(strict_types=1);

$args = $argv;
array_shift($args);

$check = false;

if (($args[0] ?? '') === '--check') {
    $check = true;
    array_shift($args);
}

if (count($args) !== 5) {
    exit(20);
}

[$owner, $vehicle, $trigger, $started, $weight] = $args;

file_put_contents(
    '__COMPLETE_LOG__',
    sprintf(
        "%s|owner=%s|vehicle=%s|trigger=%s|started=%s|weight=%s\n",
        $check ? 'CHECK' : 'COMPLETE',
        $owner,
        $vehicle,
        $trigger,
        $started,
        $weight
    ),
    FILE_APPEND
);

if ($check) {
    echo "FAKE Preflight OK\n";
    exit(0);
}

$stateFile = '__STATE_FILE__';
$count = is_file($stateFile)
    ? (int)trim((string)file_get_contents($stateFile))
    : 0;

$count++;
file_put_contents($stateFile, (string)$count);

echo "FAKE Abschluss {$count}\n";

if ($count === 1) {
    echo 'DINI_NEXT_PASS:' . json_encode([
        'vehicle_id' => 0,
        'trigger' => 'manual',
        'started_at' => '2026-10-05 21:00:30',
    ]) . PHP_EOL;
}
PHP2;

$complete = str_replace(
    ['__COMPLETE_LOG__', '__STATE_FILE__'],
    [addslashes($completeLog), addslashes($stateFile)],
    $complete
);

file_put_contents($serverScript, $server);
file_put_contents($completeScript, $complete);

$serverCmd = sprintf(
    'python3 %s > %s 2>&1 & echo $!',
    escapeshellarg($serverScript),
    escapeshellarg($serverLog)
);

$serverPid = (int)trim((string)shell_exec($serverCmd));

$ready = false;

for ($i = 0; $i < 50; $i++) {
    usleep(100000);

    if (
        is_file($serverLog) &&
        str_contains((string)file_get_contents($serverLog), 'READY')
    ) {
        $ready = true;
        break;
    }
}

if (!$ready) {
    fwrite(STDERR, "FAIL: Fake-DINI wurde nicht bereit.\n");
    exit(1);
}

$cmd = [
    PHP_BINARY,
    $worker,
    '--host', '127.0.0.1',
    '--port', (string)$port,
    '--timeout', '5',
    '--owner-id', '1',
    '--vehicle-id', '0',
    '--trigger', 'manual_first_pass',
    '--started-at', '2026-10-05 21:00:00',
    '--complete-script', $completeScript,
];

$spec = [
    0 => ['file', '/dev/null', 'r'],
    1 => ['pipe', 'w'],
    2 => ['pipe', 'w'],
];

$proc = proc_open($cmd, $spec, $pipes, $root);

if (!is_resource($proc)) {
    fwrite(STDERR, "FAIL: Worker konnte nicht gestartet werden.\n");
    exit(1);
}

$out = stream_get_contents($pipes[1]);
$err = stream_get_contents($pipes[2]);

fclose($pipes[1]);
fclose($pipes[2]);

$rc = proc_close($proc);

for ($i = 0; $i < 30 && posix_kill($serverPid, 0); $i++) {
    usleep(100000);
}

$serverOutput = is_file($serverLog)
    ? (string)file_get_contents($serverLog)
    : '';

$completionOutput = is_file($completeLog)
    ? (string)file_get_contents($completeLog)
    : '';

$checks = [
    'worker exits successfully' =>
        $rc === 0,

    'first pass uses KEYP37' =>
        str_contains($serverOutput, 'PASS1:RX:KEYP37'),

    'first pass releases key' =>
        str_contains($serverOutput, 'PASS1:RX:KEYR'),

    'second pass uses KEYP37' =>
        str_contains($serverOutput, 'PASS2:RX:KEYP37'),

    'second pass releases key' =>
        str_contains($serverOutput, 'PASS2:RX:KEYR'),

    'no KEYP38 used' =>
        !str_contains($serverOutput, 'KEYP38'),

    'first result parsed' =>
        str_contains($out, '"dini_id":101') &&
        str_contains($out, '"total_weight":1200'),

    'second result parsed' =>
        str_contains($out, '"dini_id":102') &&
        str_contains($out, '"total_weight":3200'),

    'first completion identity correct' =>
        str_contains(
            $completionOutput,
            'COMPLETE|owner=1|vehicle=0|trigger=manual_first_pass'
        ),

    'second preflight uses updated identity' =>
        str_contains(
            $completionOutput,
            'CHECK|owner=1|vehicle=0|trigger=manual|started=2026-10-05 21:00:30'
        ),

    'exactly two completions' =>
        substr_count($completionOutput, 'COMPLETE|') === 2,

    'worker reports final completion' =>
        str_contains($out, 'Auftrag erfolgreich abgeschlossen.'),
];

$failed = 0;

foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS: ' : 'FAIL: ') . $name . PHP_EOL;
    if (!$ok) {
        $failed++;
    }
}

if ($failed > 0) {
    echo PHP_EOL . "=== Worker STDOUT ===" . PHP_EOL . $out;
    echo PHP_EOL . "=== Worker STDERR ===" . PHP_EOL . $err;
    echo PHP_EOL . "=== Fake-DINI ===" . PHP_EOL . $serverOutput;
    echo PHP_EOL . "=== Completion ===" . PHP_EOL . $completionOutput;
}

foreach (glob($tmp . '/*') ?: [] as $file) {
    @unlink($file);
}
@rmdir($tmp);

exit($failed === 0 ? 0 : 1);
