#!/usr/bin/env python3

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]

service = (ROOT / "systemd/waagenbox-eldat-rx09.service").read_text()
installer = (ROOT / "install_eldat_rx09_systemd.sh").read_text()

checks = {
    "production service exists":
        (ROOT / "systemd/waagenbox-eldat-rx09.service").is_file(),

    "production listener path":
        "/var/www/waage/hardware/eldat_rx09_listener.py" in service,

    "production trigger path":
        "/var/www/waage/cli/eldat_remote_trigger.php" in service,

    "production worker path":
        "/var/www/waage/hardware/eldat_remote_worker.py" in service,

    "production completion path":
        "/var/www/waage/cli/eldat_remote_complete.php" in service,

    "shared RF learn request":
        "/run/waagenbox-rf/learn-request.json" in service,

    "shared RF learn result":
        "/run/waagenbox-rf/learn-result.json" in service,

    "dialout access":
        "SupplementaryGroups=dialout" in service,

    "DINI state writable":
        "ReadWritePaths=/var/lib/waagebox/dini" in service,

    "production filesystem protected":
        "ProtectSystem=strict" in service,

    "no test checkout path":
        "/home/pi/Waagenbox-test" not in service,

    "installer requires root":
        'if [ "$(id -u)" -ne 0 ]' in installer,

    "stable RX09 by-id path":
        "usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0"
        in installer,

    "installer creates DINI state directory":
        '"$STATE_DIR"' in installer and "install -d" in installer,

    "installer verifies systemd unit":
        'systemd-analyze verify "$SERVICE_SRC"' in installer
        and 'systemd-analyze verify "$SERVICE_DST"' in installer,

    "installer supports test mode":
        '${TEST_MODE:-0}' in installer and "TEST_MODE_OK" in installer,

    "installer reloads systemd":
        "systemctl daemon-reload" in installer,

    "installer enables production service":
        'systemctl enable --now "$SERVICE_NAME"' in installer,

    "installer does not stop test service":
        "waagenbox-eldat-rx09-test.service" not in installer,
}

failed = 0

for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
    if not ok:
        failed += 1

print()
print(f"Ergebnis: {len(checks) - failed}/{len(checks)} PASS")

sys.exit(1 if failed else 0)
