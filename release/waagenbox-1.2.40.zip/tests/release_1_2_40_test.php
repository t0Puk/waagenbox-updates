<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$checks=0;

function ok140(bool $condition,string $label):void{
    global $checks;
    if(!$condition){fwrite(STDERR,"FAIL $label\n");exit(1);}
    $checks++;
    echo "PASS $label\n";
}

function read140(string $path):string{
    $v=file_get_contents($path);
    if($v===false){fwrite(STDERR,"FAIL Datei nicht lesbar: $path\n");exit(1);}
    return $v;
}

$version=read140($root.'/version.php');
$migration=read140($root.'/migration_v1_2_40_eldat_rx09.sql');
$remotes=read140($root.'/remotes.php');
$learn=read140($root.'/api/rf_learn.php');
$listener=read140($root.'/hardware/eldat_rx09_listener.py');
$worker=read140($root.'/hardware/eldat_remote_worker.py');
$trigger=read140($root.'/cli/eldat_remote_trigger.php');
$complete=read140($root.'/cli/eldat_remote_complete.php');
$diniWorker=read140($root.'/cli/dini_weighing_worker.php');
$diniComplete=read140($root.'/cli/dini_weighing_complete.php');
$service=read140($root.'/systemd/waagenbox-eldat-rx09.service');
$installer=read140($root.'/install_eldat_rx09_systemd.sh');
$telegram=read140($root.'/telegram_support.php');

ok140(str_contains($version,"APP_VERSION = '1.2.40'"),'Version ist 1.2.40');

ok140(str_contains($migration,'eldat_sender'),'ELDAT-Sender-Migration vorhanden');
ok140(str_contains($migration,'eldat_weigh_button'),'ELDAT-Wiegetaste wird gespeichert');
ok140(str_contains($migration,'eldat_tare_button'),'ELDAT-Erstgewichtstaste wird gespeichert');
ok140(str_contains($migration,'uq_remote_owner_eldat_sender'),'ELDAT-Sender ist je Benutzer eindeutig');

ok140(str_contains($remotes,'eldat_sender'),'Fernbedienungsverwaltung unterstützt ELDAT');
ok140(str_contains($learn,"'eldat_rx09'"),'Einlern-API unterstützt ELDAT RX09');
ok140(str_contains($learn,"'/run/waagenbox-rf'"),'Einlern-API verwendet gemeinsamen RF-Runtimepfad');

ok140(str_contains($listener,'usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0'),'RX09 verwendet stabilen USB-by-id-Pfad');
ok140(str_contains($listener,'BAUDRATE = 57600'),'RX09 verwendet 57600 Baud');
ok140(str_contains($listener,'receiver != "eldat_rx09"'),'ELDAT-Listener konsumiert nur eigene Lernanforderungen');

ok140(str_contains($trigger,'eldat_sender'),'ELDAT-Trigger ordnet Sender der Fernbedienung zu');
ok140(
    str_contains($worker,'--complete-script') &&
    str_contains($worker,'args.complete_script') &&
    str_contains($listener,'args.complete_script'),
    'Listener übergibt Abschluss-Script an ELDAT-Worker'
);
ok140(
    substr_count($trigger,'startDiniPendingWorker();') >= 2,
    'ELDAT startet DINI-Worker für Wiegung und Erstgewicht'
);

ok140(str_contains($diniWorker,'360'),'DINI-Worker unterstützt verlängertes Überfahrt-Zeitfenster');
ok140(str_contains($diniComplete,'complete'),'DINI-Abschlusskomponente vorhanden');

ok140(str_contains($service,'/var/www/waage/hardware/eldat_rx09_listener.py'),'Produktivdienst verwendet Produktiv-Webroot');
ok140(str_contains($service,'SupplementaryGroups=dialout'),'Produktivdienst besitzt seriellen Zugriff');
ok140(str_contains($service,'ReadWritePaths=/var/lib/waagebox/dini'),'Produktivdienst darf DINI-State schreiben');
ok140(!str_contains($service,'/home/pi/Waagenbox-test'),'Produktivdienst enthält keinen Testpfad');

ok140(str_contains($installer,'systemd-analyze verify'),'ELDAT-Systeminstaller prüft Unit');
ok140(str_contains($installer,'TEST_MODE_OK'),'ELDAT-Systeminstaller besitzt Testmodus');
ok140(str_contains($installer,'systemctl enable --now'),'ELDAT-Systeminstaller aktiviert Produktivdienst');

ok140(str_contains($telegram,'feldmanagerTelegramOutboundDecision'),'Telegram-Verbindungsentprellung vorhanden');
ok140(str_contains($telegram,'feldmanager_outbound_failure_since'),'Telegram-Ausfallbeginn wird gespeichert');

echo "RESULT $checks checks passed\n";
