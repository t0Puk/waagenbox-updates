<?php
declare(strict_types=1);

require_once dirname(__DIR__).'/telegram_support.php';

$checks=0;

function okTelegram(bool $condition,string $label):void{
    global $checks;
    if(!$condition){
        fwrite(STDERR,"FAIL $label\n");
        exit(1);
    }
    $checks++;
    echo "PASS $label\n";
}

function decision(
    bool $connected,
    string $notifyState,
    int $failureSince,
    int $now
): array {
    return feldmanagerTelegramOutboundDecision(
        $connected,
        $notifyState,
        $failureSince,
        $now
    );
}

$base=1000;

// Erststart bei funktionierender Verbindung.
$r=decision(true,'',0,$base);
okTelegram($r['action']==='initialize','Initialisierung sendet keine Nachricht');
okTelegram($r['notify_state']==='connected','Initialisierung setzt connected');
okTelegram($r['failure_since']===0,'Initialisierung hat keinen Fehlerzeitpunkt');

// Erster Ausfall startet nur die Karenz.
$r=decision(false,'connected',0,$base);
okTelegram($r['action']==='wait','Erster Fehler wartet');
okTelegram($r['failure_since']===$base,'Erster Fehler speichert Startzeit');

// Nach 60 Sekunden weiterhin keine Meldung.
$r=decision(false,'connected',$base,$base+60);
okTelegram($r['action']==='wait','60 Sekunden Ausfall bleiben still');

// Auch nach 119 Sekunden noch keine Meldung.
$r=decision(false,'connected',$base,$base+119);
okTelegram($r['action']==='wait','119 Sekunden Ausfall bleiben still');

// Exakt ab 120 Sekunden Störungsmeldung.
$r=decision(false,'connected',$base,$base+120);
okTelegram($r['action']==='outage','120 Sekunden Ausfall lösen Störungsmeldung aus');

// Nach erfolgreicher Störungsmeldung keine Wiederholung.
$r=decision(false,'error',$base,$base+180);
okTelegram($r['action']==='none','Gemeldete Störung wird nicht erneut gemeldet');

// Wiederherstellung nach gemeldeter Störung.
$r=decision(true,'error',$base,$base+181);
okTelegram($r['action']==='recovery','Wiederherstellung nach Alarm wird gemeldet');
okTelegram($r['failure_since']===0,'Wiederherstellung löscht Fehlerzeitpunkt');

// Kurzer Ausfall mit Wiederherstellung innerhalb der Karenz.
$r=decision(true,'connected',$base,$base+60);
okTelegram($r['action']==='none','Kurzer Ausfall erzeugt keine Wiederherstellungsmeldung');
okTelegram($r['failure_since']===0,'Kurzer Ausfall wird bei Wiederherstellung zurückgesetzt');

// Systemzeit liegt vor gespeichertem Fehlerzeitpunkt.
$r=decision(false,'connected',$base+500,$base+100);
okTelegram($r['action']==='wait','Rückwärts gesprungene Systemzeit erzeugt keinen Alarm');
okTelegram($r['failure_since']===$base+100,'Karenz startet bei rückwärts gesprungener Zeit neu');

// System startet bereits während einer Störung.
$r=decision(false,'',0,$base);
okTelegram($r['action']==='initialize','Start während Störung alarmiert nicht sofort');
okTelegram($r['notify_state']==='connected','Start während Störung gilt noch nicht als gemeldeter Alarm');
okTelegram($r['failure_since']===$base,'Start während Störung beginnt Karenzzeit');

echo "OK: $checks Telegram-Debounce-Prüfungen erfolgreich.\n";
