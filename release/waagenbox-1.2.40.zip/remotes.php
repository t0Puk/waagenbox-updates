<?php
require_once __DIR__.'/functions.php';
requireLogin();
if($_SERVER['REQUEST_METHOD']==='POST'){
    try {
        if (isset($_POST['toggle_id'])) {
            $id=(int)$_POST['toggle_id'];
            if ($id<=0) throw new RuntimeException('Ungültige Fernbedienung.');
            $pdo=db();
            $q=$pdo->prepare('SELECT active FROM remotes WHERE owner_user_id=? AND id=?');
            $q->execute([currentOwnerId(),$id]);
            $remote=$q->fetch();
            if (!$remote) throw new RuntimeException('Fernbedienung wurde nicht gefunden.');
            $newActive=((int)$remote['active']===1)?0:1;
            $s=$pdo->prepare('UPDATE remotes SET active=? WHERE owner_user_id=? AND id=?');
            $s->execute([$newActive,currentOwnerId(),$id]);
            flash('Fernbedienung '.($newActive?'wurde aktiviert.':'wurde deaktiviert.'));
            redirect('remotes.php');
        }
        if (isset($_POST['regenerate_token_id'])) {
            $id=(int)$_POST['regenerate_token_id'];
            if($id<=0) throw new RuntimeException('Ungültige Fernbedienung.');
            $token=bin2hex(random_bytes(32));
            $q=db()->prepare('UPDATE remotes SET mobile_token=? WHERE owner_user_id=? AND id=?');
            $q->execute([$token,currentOwnerId(),$id]);
            redirect('remote_qr.php?id='.$id);
        }
        if (isset($_POST['delete_id'])) {
            $id=(int)$_POST['delete_id'];
            $s=db()->prepare('DELETE FROM remotes WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$id]);
            flash($s->rowCount() ? 'Fernbedienung wurde gelöscht.' : 'Fernbedienung wurde nicht gefunden.');
            redirect('remotes.php');
        }
        if (!isset($_POST['create_remote'])) {
            throw new RuntimeException('Unbekannte Fernbedienungsaktion.');
        }

        $remoteType=trim((string)($_POST['remote_type'] ?? ''));
        $eldatSender=strtolower(trim((string)($_POST['eldat_sender'] ?? '')));
        $eldatWeighButton=strtoupper(trim((string)($_POST['eldat_weigh_button'] ?? '')));
        $eldatTareButton=strtoupper(trim((string)($_POST['eldat_tare_button'] ?? '')));
        $name=trim((string)($_POST['name'] ?? ''));
        $vehicleId=(int)($_POST['vehicle_id'] ?? 0);

        if(!in_array($remoteType,['eldat_1','eldat_2'],true)) {
            throw new RuntimeException('Ungültiger ELDAT-Handsendertyp.');
        }
        if($name==='') {
            throw new RuntimeException('Bitte eine Bezeichnung eingeben.');
        }
        if($vehicleId<=0) {
            throw new RuntimeException('Bitte ein Fahrzeug auswählen.');
        }

        $q=db()->prepare('SELECT id FROM vehicles WHERE owner_user_id=? AND id=? AND active=1');
        $q->execute([currentOwnerId(),$vehicleId]);
        if(!$q->fetchColumn()) {
            throw new RuntimeException('Das ausgewählte Fahrzeug ist nicht aktiv oder wurde nicht gefunden.');
        }

        if(!preg_match('/^[0-9a-f]{1,32}$/',$eldatSender)) {
            throw new RuntimeException('Bitte den ELDAT-Handsender zuerst einlernen.');
        }
        if(!preg_match('/^[A-D]$/',$eldatWeighButton)) {
            throw new RuntimeException('Bitte die Taste für die Wiegung einlernen.');
        }

        if($remoteType==='eldat_2') {
            if(!preg_match('/^[A-D]$/',$eldatTareButton)) {
                throw new RuntimeException('Bitte die Taste für das Erstgewicht einlernen.');
            }
            if($eldatTareButton===$eldatWeighButton) {
                throw new RuntimeException('Wiegung und Erstgewicht müssen unterschiedliche Tasten verwenden.');
            }
        } else {
            $eldatTareButton=null;
        }

        $q=db()->prepare('SELECT id,name FROM remotes WHERE owner_user_id=? AND eldat_sender=? LIMIT 1');
        $q->execute([currentOwnerId(),$eldatSender]);
        if($existing=$q->fetch()) {
            throw new RuntimeException(
                'Dieser ELDAT-Handsender ist bereits der Fernbedienung „'.
                ($existing['name'] ?: '#'.$existing['id']).'“ zugeordnet.'
            );
        }

        $code=null;

        $token=bin2hex(random_bytes(32));
        $s=db()->prepare('INSERT INTO remotes (owner_user_id,code,eldat_sender,eldat_weigh_button,eldat_tare_button,mobile_token,name,vehicle_id,active,created_at) VALUES (?,?,?,?,?,?,?,?,1,NOW())');
        $s->execute([currentOwnerId(),$code,$eldatSender,$eldatWeighButton,$eldatTareButton,$token,$name,$vehicleId]);
        flash('Fernbedienung wurde angelegt.');
        redirect('remotes.php');
    } catch(Throwable $e){ $error=$e->getMessage(); }
}
layoutStart('Fernbedienungen','remotes');
if(!empty($error)) echo '<div class="flash error"><strong>Fernbedienung konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$rows=db()->query('SELECT r.*,v.plate,v.name AS vehicle_name FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id='.(int)currentOwnerId().' ORDER BY r.name')->fetchAll();
$vehicles=db()->query('SELECT id,plate,name FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY plate')->fetchAll();

$feldmanagerRemoteTeams=feldmanagerRemoteTeamMap();
$feldmanagerTeamNames=[];
if(feldmanagerEnabled() && feldmanagerBaseUrl()!=='' && trim(appSetting('feldmanager_api_token',''))!==''){
    $teamResponse=feldmanagerTeams();
    if(!empty($teamResponse['ok'])){
        foreach((array)($teamResponse['teams']??[]) as $team){
            $tid=(int)($team['id']??0);
            if($tid>0) $feldmanagerTeamNames[$tid]=(string)($team['name']??('Team #'.$tid));
        }
    }
}
?>
<div class="toolbar"><h1>Fernbedienungen</h1></div>
<div class="card table-wrap"><table><tr><th>Status</th><th>Code</th><th>Name</th><th>Fahrzeug</th><th>Feldmanager-Team</th><th></th></tr>
<?php foreach($rows as $r): ?><tr>
<td><?=(int)$r['active']===1?'<strong>Aktiv</strong>':'<span class="muted">Deaktiviert</span>'?></td>
<td><?php if(!empty($r['eldat_sender'])): ?><strong>ELDAT</strong><br><span class="muted"><?=h($r['eldat_sender'])?> · Wiegung <?=h($r['eldat_weigh_button'] ?: '–')?><?php if(!empty($r['eldat_tare_button'])): ?> · Erstgewicht <?=h($r['eldat_tare_button'])?><?php endif; ?></span><?php else: ?><?=h($r['code'] ?? '–')?><?php endif; ?></td>
<td><?=h($r['name'])?></td>
<td><?=h(trim(($r['plate'] ?? '').' – '.($r['vehicle_name'] ?? ''), ' –'))?></td>
<?php $teamId=(int)($feldmanagerRemoteTeams[(int)$r['id']]??0); ?>
<td><?=$teamId>0?h($feldmanagerTeamNames[$teamId]??('Team #'.$teamId)):'–'?></td>
<td class="row-actions">
<form method="post" style="display:inline"><input type="hidden" name="regenerate_token_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button">📱 QR-Code</button></form>
<a class="button" href="remote_edit.php?id=<?= (int)$r['id'] ?>">Zuordnungen</a>
<form method="post" style="display:inline"><input type="hidden" name="toggle_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button"><?=(int)$r['active']===1?'Deaktivieren':'Aktivieren'?></button></form>
<form method="post" class="delete-form" onsubmit="return confirm(<?=json_encode('Fernbedienung '.($r['name'] ?? '').' wirklich endgültig löschen?\n\nDieser Vorgang kann nicht rückgängig gemacht werden.', JSON_UNESCAPED_UNICODE)?>);"><input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button-danger">Löschen</button></form>
</td></tr><?php endforeach; ?></table></div>
<div class="card"><h2>Fernbedienung anlegen</h2>
<form method="post" id="remoteForm">
<div class="form-grid">

<div class="full">
<label>Handsender</label>
<select name="remote_type" id="remoteType">
<option value="eldat_1">ELDAT RX09 – 1 Taste</option>
<option value="eldat_2">ELDAT RX09 – 2 Tasten</option>
</select>
</div>

<div class="full">
<input type="hidden" name="eldat_sender" id="eldatSender">
<input type="hidden" name="eldat_weigh_button" id="eldatWeighButton">
<input type="hidden" name="eldat_tare_button" id="eldatTareButton">

<label>Handsender einlernen</label>

<div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap">
<button type="button" class="button" id="eldatWeighLearnButton">
📡 Taste für Wiegung einlernen
</button>

<button type="button" class="button" id="eldatTareLearnButton" style="display:none">
📡 Taste für Erstgewicht einlernen
</button>
</div>

<div id="eldatLearnStatus" class="muted" style="margin-top:.45rem">
Bitte zuerst die Taste für die Wiegung einlernen.
</div>
</div>

<div>
<label>Bezeichnung</label>
<input name="name" required>
</div>

<div class="full">
<label>Fahrzeug</label>
<select name="vehicle_id" required>
<option value="">Bitte wählen</option>
<?php foreach($vehicles as $v): ?>
<option value="<?=$v['id']?>"><?=h($v['plate'].' – '.$v['name'])?></option>
<?php endforeach; ?>
</select>
</div>

</div>

<p>
<button type="submit" name="create_remote" value="1">
Fernbedienung speichern
</button>
</p>
</form>
</div>

<script>
(() => {
  const form = document.getElementById('remoteForm');
  const remoteType = document.getElementById('remoteType');

  const weighLearnButton =
    document.getElementById('eldatWeighLearnButton');
  const tareLearnButton =
    document.getElementById('eldatTareLearnButton');
  const status =
    document.getElementById('eldatLearnStatus');

  const senderInput =
    document.getElementById('eldatSender');
  const weighInput =
    document.getElementById('eldatWeighButton');
  const tareInput =
    document.getElementById('eldatTareButton');

  let token = null;
  let timer = null;
  let learnTarget = null;

  function csrf() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }

  function stopPolling() {
    if (timer) clearTimeout(timer);
    timer = null;
  }

  function enableButtons() {
    weighLearnButton.disabled = false;
    tareLearnButton.disabled = false;
  }

  function finishLearn() {
    stopPolling();
    token = null;
    learnTarget = null;
    enableButtons();
  }

  async function cancelLearn() {
    stopPolling();

    if (!token) return;

    const oldToken = token;
    token = null;

    const data = new FormData();
    data.append('action', 'cancel');
    data.append('token', oldToken);
    data.append('csrf_token', csrf());

    try {
      await fetch('api/rf_learn.php', {
        method: 'POST',
        body: data,
        cache: 'no-store'
      });
    } catch (_) {
    }
  }

  function resetLearnedRemote() {
    senderInput.value = '';
    weighInput.value = '';
    tareInput.value = '';
    status.textContent =
      'Bitte zuerst die Taste für die Wiegung einlernen.';
  }

  function updateTypeUi() {
    const twoButtons = remoteType.value === 'eldat_2';

    tareLearnButton.style.display = twoButtons ? '' : 'none';

    if (!twoButtons) {
      tareInput.value = '';

      if (senderInput.value && weighInput.value) {
        status.textContent =
          '✓ Wiegungstaste erkannt. Handsender ist bereit.';
      }
    } else if (senderInput.value && weighInput.value && !tareInput.value) {
      status.textContent =
        '✓ Wiegungstaste erkannt. Bitte jetzt die Taste für das Erstgewicht einlernen.';
    }
  }

  async function startLearn(target) {
    if (token) return;

    learnTarget = target;
    weighLearnButton.disabled = true;
    tareLearnButton.disabled = true;
    status.textContent = 'Einlernmodus wird gestartet …';

    try {
      const data = new FormData();
      data.append('receiver', 'eldat_rx09');

      const r = await fetch('api/rf_learn.php?action=start', {
        method: 'POST',
        headers: {'X-CSRF-Token': csrf()},
        body: data,
        cache: 'no-store'
      });

      const d = await r.json();

      if (!r.ok || !d.ok) {
        throw new Error(
          d.message || 'Einlernmodus konnte nicht gestartet werden.'
        );
      }

      token = d.token;

      if (target === 'weigh') {
        status.textContent =
          'Bitte jetzt die Taste für die Wiegung kurz drücken.';
      } else {
        status.textContent =
          'Bitte jetzt die Taste für das Erstgewicht kurz drücken.';
      }

      timer = setTimeout(poll, 250);
    } catch (e) {
      finishLearn();
      status.textContent =
        'Einlernen nicht möglich: ' + e.message;
    }
  }

  async function poll() {
    if (!token) return;

    try {
      const r = await fetch(
        'api/rf_learn.php?action=status&token=' +
        encodeURIComponent(token),
        {cache: 'no-store'}
      );

      const d = await r.json();

      if (!r.ok || !d.ok) {
        throw new Error(
          d.message || 'Status konnte nicht gelesen werden.'
        );
      }

      if (d.state === 'captured') {
        if (
          d.receiver !== 'eldat_rx09' ||
          !d.sender ||
          !d.button
        ) {
          throw new Error(
            'Unerwartetes ELDAT-Lernergebnis.'
          );
        }

        if (d.duplicate && d.duplicate_remote) {
          finishLearn();
          status.textContent =
            'Dieser ELDAT-Handsender ist bereits „' +
            (d.duplicate_remote.name ||
              ('#' + d.duplicate_remote.id)) +
            '“ zugeordnet.';
          return;
        }

        if (learnTarget === 'weigh') {
          senderInput.value = d.sender;
          weighInput.value = d.button;
          tareInput.value = '';

          finishLearn();

          if (remoteType.value === 'eldat_2') {
            status.textContent =
              '✓ Wiegungstaste erkannt. Bitte jetzt die Taste für das Erstgewicht einlernen.';
          } else {
            status.textContent =
              '✓ Wiegungstaste erkannt. Handsender ist bereit.';
          }
          return;
        }

        if (learnTarget === 'tare') {
          if (!senderInput.value || !weighInput.value) {
            finishLearn();
            status.textContent =
              'Bitte zuerst die Taste für die Wiegung einlernen.';
            return;
          }

          if (d.sender !== senderInput.value) {
            finishLearn();
            status.textContent =
              'Andere Fernbedienung erkannt. Bitte die zweite Taste desselben Handsenders drücken.';
            return;
          }

          if (d.button === weighInput.value) {
            finishLearn();
            status.textContent =
              'Das ist bereits die Wiegungstaste. Bitte eine andere Taste für das Erstgewicht verwenden.';
            return;
          }

          tareInput.value = d.button;
          finishLearn();

          status.textContent =
            '✓ Wiegungstaste und Erstgewichtstaste erkannt. Handsender ist bereit.';
          return;
        }
      }

      if (d.state === 'expired') {
        finishLearn();
        status.textContent =
          'Kein Funksignal erkannt. Bitte Einlernen erneut starten.';
        return;
      }

      const seconds = d.seconds_left ?? '';

      if (learnTarget === 'weigh') {
        status.textContent =
          'Warte auf Wiegungstaste … noch ' +
          seconds + ' s.';
      } else {
        status.textContent =
          'Warte auf Erstgewichtstaste … noch ' +
          seconds + ' s.';
      }

      timer = setTimeout(poll, 500);
    } catch (e) {
      finishLearn();
      status.textContent =
        'Einlernen fehlgeschlagen: ' + e.message;
    }
  }

  remoteType.addEventListener('change', async () => {
    await cancelLearn();
    resetLearnedRemote();
    enableButtons();
    updateTypeUi();
  });

  weighLearnButton.addEventListener('click', () => {
    startLearn('weigh');
  });

  tareLearnButton.addEventListener('click', () => {
    if (!senderInput.value || !weighInput.value) {
      status.textContent =
        'Bitte zuerst die Taste für die Wiegung einlernen.';
      return;
    }

    startLearn('tare');
  });

  form.addEventListener('submit', (event) => {
    if (!senderInput.value || !weighInput.value) {
      event.preventDefault();
      status.textContent =
        'Bitte zuerst die Taste für die Wiegung einlernen.';
      return;
    }

    if (
      remoteType.value === 'eldat_2' &&
      !tareInput.value
    ) {
      event.preventDefault();
      status.textContent =
        'Bitte auch die Taste für das Erstgewicht einlernen.';
    }
  });

  window.addEventListener('beforeunload', () => {
    if (!token) return;

    const data = new FormData();
    data.append('action', 'cancel');
    data.append('token', token);
    data.append('csrf_token', csrf());

    navigator.sendBeacon('api/rf_learn.php', data);
  });

  updateTypeUi();
})();
</script>

<?php layoutEnd(); ?>
