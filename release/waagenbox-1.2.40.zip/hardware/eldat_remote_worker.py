#!/usr/bin/env python3

import argparse
import subprocess
import sys
import time


POLL_SECONDS = 0.20
TIMEOUT_SECONDS = 120.0


def parse_args():
    parser = argparse.ArgumentParser(
        description="AJP Waagenbox – ELDAT Abschluss-Worker"
    )
    parser.add_argument("--owner-id", type=int, required=True)
    parser.add_argument("--remote-id", type=int, required=True)
    parser.add_argument("--vehicle-id", type=int, required=True)
    parser.add_argument(
        "--trigger",
        choices=[
            "eldat",
            "eldat_first_pass",
            "eldat_first_weight",
        ],
        required=True,
    )
    parser.add_argument("--started-at", required=True)
    parser.add_argument(
        "--php",
        default="/usr/bin/php",
        help="PHP-CLI-Binary",
    )
    parser.add_argument(
        "--complete-script",
        required=True,
        help="Pfad zum ELDAT-Abschluss-Script",
    )
    return parser.parse_args()


def run_complete(args):
    return subprocess.run(
        [
            args.php,
            args.complete_script,
            str(args.owner_id),
            str(args.remote_id),
            str(args.vehicle_id),
            args.trigger,
            args.started_at,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=10,
        check=False,
    )


def main():
    args = parse_args()

    if (
        args.owner_id <= 0
        or args.remote_id <= 0
        or args.vehicle_id <= 0
        or not args.started_at.strip()
    ):
        print(
            "ELDAT Worker: ungültiger Auftrag.",
            file=sys.stderr,
            flush=True,
        )
        return 2

    print(
        "ELDAT Abschluss-Worker gestartet: "
        f"Owner {args.owner_id} / "
        f"Remote {args.remote_id} / "
        f"Fahrzeug {args.vehicle_id} / "
        f"{args.trigger} / "
        f"{args.started_at}",
        flush=True,
    )

    deadline = time.monotonic() + TIMEOUT_SECONDS

    while time.monotonic() < deadline:
        try:
            result = run_complete(args)
        except (OSError, subprocess.SubprocessError) as exc:
            print(
                f"ELDAT Abschluss konnte nicht ausgeführt werden: {exc}",
                file=sys.stderr,
                flush=True,
            )
            return 3

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()

        if stdout:
            print(stdout, flush=True)

        if stderr:
            print(stderr, file=sys.stderr, flush=True)

        if result.returncode == 0:
            print(
                "ELDAT Abschluss erfolgreich.",
                flush=True,
            )
            return 0

        if result.returncode != 2:
            print(
                f"ELDAT Abschluss beendet mit RC={result.returncode}.",
                file=sys.stderr,
                flush=True,
            )
            return result.returncode

        # RC 2 bedeutet aktuell noch kein Abschluss.
        # Das kann insbesondere bedeuten, dass noch kein gültiges
        # Gewicht vorhanden ist. Deshalb kurz warten und erneut prüfen.
        time.sleep(POLL_SECONDS)

    print(
        f"ELDAT Abschluss nach {TIMEOUT_SECONDS:.0f} s ohne gültiges "
        "Ergebnis abgebrochen.",
        file=sys.stderr,
        flush=True,
    )
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
