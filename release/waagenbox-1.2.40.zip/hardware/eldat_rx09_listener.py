#!/usr/bin/env python3

import argparse
import json
import os
from pathlib import Path
import re
import sys
import time
import subprocess

import serial


DEFAULT_DEVICE = (
    "/dev/serial/by-id/"
    "usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0"
)
BAUDRATE = 57600
RELEASE_QUIET_SECONDS = 1.000

REC_RE = re.compile(
    r"^REC,\s*([0-9A-Fa-f]+)\s*,\s*([A-Da-d])\s*$"
)


def safe_unlink(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def capture_learn_event(
    sender: str,
    button: str,
    request_file: str,
    result_file: str,
    now: float | None = None,
) -> bool:
    """
    Consume one RX09 event when a valid learn request is active.

    Returns True only when the event was consumed by learn mode. In that case
    normal processing of this physical button press must be suppressed.
    """
    request_path = Path(request_file)
    result_path = Path(result_file)

    if not request_path.is_file():
        return False

    try:
        request = json.loads(request_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        safe_unlink(request_path)
        return False

    receiver = str(request.get("receiver", "legacy_433"))
    if receiver != "eldat_rx09":
        return False

    token = str(request.get("token", ""))
    owner_id = int(request.get("owner_id", 0) or 0)
    expires_at = float(request.get("expires_at", 0) or 0)
    wall_now = time.time() if now is None else now

    if (
        not re.fullmatch(r"[0-9a-f]{32}", token)
        or owner_id <= 0
        or expires_at <= wall_now
    ):
        safe_unlink(request_path)
        return False

    result = {
        "token": token,
        "owner_id": owner_id,
        "receiver": "eldat_rx09",
        "sender": sender.lower(),
        "button": button.upper(),
        "captured_at": int(wall_now),
    }

    try:
        result_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = result_path.with_name(
            result_path.name + f".{os.getpid()}.tmp"
        )
        tmp_path.write_text(
            json.dumps(result, separators=(",", ":")),
            encoding="utf-8",
        )
        os.replace(tmp_path, result_path)
        safe_unlink(request_path)
    except OSError as exc:
        print(
            f"RX09 learn result write failed: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return False

    print(
        f"RX09 learn captured: Sender {sender} / Taste {button}",
        flush=True,
    )
    return True


def trigger_remote(
    sender: str,
    button: str,
    php_binary: str,
    trigger_script: str,
):
    """
    Übergibt genau einen physischen Tastendruck an die Waagenbox-Logik.

    Bei einem gestarteten ELDAT-Vorgang wird dessen eindeutiger
    Pending-Fingerabdruck als Dictionary zurückgegeben.
    """
    try:
        result = subprocess.run(
            [
                php_binary,
                trigger_script,
                sender,
                button,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        print(
            f"ELDAT Trigger konnte nicht ausgeführt werden: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return None

    stdout = result.stdout.strip()
    stderr = result.stderr.strip()

    if stdout:
        print(stdout, flush=True)

    if stderr:
        print(stderr, file=sys.stderr, flush=True)

    if result.returncode == 2:
        return None

    if result.returncode != 0:
        print(
            f"ELDAT Trigger beendet mit RC={result.returncode}",
            file=sys.stderr,
            flush=True,
        )
        return None

    job = None

    for line in stdout.splitlines():
        if not line.startswith("ELDAT_JOB:"):
            continue

        payload = line[len("ELDAT_JOB:"):].strip()

        try:
            candidate = json.loads(payload)
        except json.JSONDecodeError as exc:
            print(
                f"ELDAT_JOB JSON ungültig: {exc}",
                file=sys.stderr,
                flush=True,
            )
            return None

        if not isinstance(candidate, dict):
            print(
                "ELDAT_JOB ist kein JSON-Objekt.",
                file=sys.stderr,
                flush=True,
            )
            return None

        job = candidate

    if job is None:
        # Ein erfolgreich ignorierter B-Tastendruck bei bereits
        # vorhandenem Erstgewicht erzeugt absichtlich keinen Job.
        return None

    required = {
        "owner_id",
        "remote_id",
        "vehicle_id",
        "trigger",
        "started_at",
    }

    if not required.issubset(job):
        print(
            "ELDAT_JOB ist unvollständig.",
            file=sys.stderr,
            flush=True,
        )
        return None

    if (
        not isinstance(job["owner_id"], int)
        or job["owner_id"] <= 0
        or not isinstance(job["remote_id"], int)
        or job["remote_id"] <= 0
        or not isinstance(job["vehicle_id"], int)
        or job["vehicle_id"] <= 0
        or job["trigger"] not in {
            "eldat",
            "eldat_first_pass",
            "eldat_first_weight",
        }
        or not isinstance(job["started_at"], str)
        or not job["started_at"]
    ):
        print(
            "ELDAT_JOB enthält ungültige Werte.",
            file=sys.stderr,
            flush=True,
        )
        return None

    print(
        "ELDAT Auftrag übernommen: "
        f"Owner {job['owner_id']} / "
        f"Remote {job['remote_id']} / "
        f"Fahrzeug {job['vehicle_id']} / "
        f"{job['trigger']} / "
        f"{job['started_at']}",
        flush=True,
    )

    return job


def start_completion_worker(
    job: dict,
    python_binary: str,
    worker_script: str,
    php_binary: str,
    complete_script: str,
) -> bool:
    """
    Startet den ELDAT-Abschluss-Worker unabhängig vom RX09-Listener.
    """
    try:
        subprocess.Popen(
            [
                python_binary,
                worker_script,
                "--owner-id",
                str(job["owner_id"]),
                "--remote-id",
                str(job["remote_id"]),
                "--vehicle-id",
                str(job["vehicle_id"]),
                "--trigger",
                str(job["trigger"]),
                "--started-at",
                str(job["started_at"]),
                "--php",
                php_binary,
                "--complete-script",
                complete_script,
            ],
            stdin=subprocess.DEVNULL,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        print(
            f"ELDAT Worker konnte nicht gestartet werden: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return False

    print(
        "ELDAT Abschluss-Worker gestartet.",
        flush=True,
    )
    return True


def parse_args():
    parser = argparse.ArgumentParser(
        description="AJP Waagenbox ELDAT RX09 listener"
    )
    parser.add_argument(
        "--device",
        default=DEFAULT_DEVICE,
        help="Serielle Schnittstelle des ELDAT RX09",
    )
    parser.add_argument(
        "--learn-request",
        default="/run/waagenbox-rf/learn-request.json",
        help="Pfad zur Learn-Request-Datei",
    )
    parser.add_argument(
        "--learn-result",
        default="/run/waagenbox-rf/learn-result.json",
        help="Pfad zur Learn-Result-Datei",
    )
    parser.add_argument(
        "--php",
        default="/usr/bin/php",
        help="PHP-CLI-Binary",
    )
    parser.add_argument(
        "--trigger-script",
        default="/var/www/waage/cli/eldat_remote_trigger.php",
        help="Pfad zum ELDAT-Trigger-Script",
    )
    parser.add_argument(
        "--python",
        default=sys.executable,
        help="Python-Binary für den Abschluss-Worker",
    )
    parser.add_argument(
        "--worker-script",
        default="/var/www/waage/hardware/eldat_remote_worker.py",
        help="Pfad zum ELDAT-Abschluss-Worker",
    )
    parser.add_argument(
        "--worker-php",
        default="/usr/bin/php",
        help="PHP-CLI-Binary für den ELDAT-Abschluss-Worker",
    )
    parser.add_argument(
        "--complete-script",
        default="/var/www/waage/cli/eldat_remote_complete.php",
        help="Pfad zum ELDAT-Abschluss-Script",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print("AJP Waagenbox – ELDAT RX09 Diagnosetest")
    print(f"Gerät: {args.device}")
    print(f"Baudrate: {BAUDRATE}")
    print(
        f"Freigabe nach {RELEASE_QUIET_SECONDS:.3f} s Funkstille"
    )
    print("Warte auf Easywave-Telegramme ...")
    print("Beenden mit Strg+C")
    print()

    try:
        with serial.Serial(
            port=args.device,
            baudrate=BAUDRATE,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0.05,
            xonxoff=False,
            rtscts=False,
            dsrdtr=False,
        ) as ser:

            buffer = b""

            # sender -> {
            #     "pressed": bool,
            #     "button": str | None,
            #     "last_seen": float
            # }
            sender_state = {}

            while True:
                now = time.monotonic()

                # Sender nach ausreichender Funkstille wieder freigeben.
                for sender, state in sender_state.items():
                    if (
                        state["pressed"]
                        and now - state["last_seen"]
                        >= RELEASE_QUIET_SECONDS
                    ):
                        state["pressed"] = False
                        state["button"] = None

                chunk = ser.read(64)

                if not chunk:
                    continue

                buffer += chunk

                while b"\r" in buffer:
                    raw, buffer = buffer.split(b"\r", 1)
                    text = raw.decode(
                        "ascii",
                        errors="replace",
                    ).strip()

                    if not text:
                        continue

                    match = REC_RE.match(text)

                    if not match:
                        print(
                            f"Unbekanntes RX09-Telegramm: {text!r}",
                            flush=True,
                        )
                        continue

                    sender = match.group(1).lower()
                    button = match.group(2).upper()
                    now = time.monotonic()

                    state = sender_state.setdefault(
                        sender,
                        {
                            "pressed": False,
                            "button": None,
                            "last_seen": 0.0,
                        },
                    )

                    # Während ein Sender noch als gedrückt gilt,
                    # werden sämtliche Wiederholtelegramme ignoriert.
                    if state["pressed"]:
                        state["last_seen"] = now
                        continue

                    # Neuer physischer Tastendruck.
                    state["pressed"] = True
                    state["button"] = button
                    state["last_seen"] = now

                    print(
                        f"RX09 Ereignis: "
                        f"Sender {sender} / Taste {button}",
                        flush=True,
                    )

                    if capture_learn_event(
                        sender,
                        button,
                        args.learn_request,
                        args.learn_result,
                    ):
                        continue

                    job = trigger_remote(
                        sender,
                        button,
                        args.php,
                        args.trigger_script,
                    )

                    if job is not None:
                        start_completion_worker(
                            job,
                            args.python,
                            args.worker_script,
                            args.worker_php,
                            args.complete_script,
                        )

    except KeyboardInterrupt:
        print("\nRX09-Diagnosetest beendet.")
        return 0

    except serial.SerialException as exc:
        print(
            f"RX09 konnte nicht geöffnet/gelesen werden: {exc}",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
