#!/usr/bin/python3
"""Check paths and Linux text files that would actually be exported into a release archive."""
import io
import json
from pathlib import PurePosixPath
import re
import subprocess
import tarfile


def allowed(name):
    if not name or "\\" in name or ":" in name or name.startswith("/"):
        return False

    parts = PurePosixPath(name).parts

    if any(part in (".", "..") for part in name.split("/")):
        return False

    lower = name.lower()
    base = parts[-1].lower()

    if any(
        part.lower()
        in (
            ".git",
            ".ssh",
            "__pycache__",
            "backups",
            "rollback",
            "tmp",
            "temp",
            "cache",
        )
        for part in parts
    ):
        return False

    if parts[0].lower() == "uploads":
        return False

    if (
        base == "config.php"
        or base.startswith(".env")
        or re.fullmatch(r"id_(rsa|dsa|ecdsa|ed25519)", base)
    ):
        return False

    if lower.endswith(
        (
            ".key",
            ".pem",
            ".ppk",
            ".p12",
            ".pfx",
            ".sql.gz",
            ".bak",
            ".backup",
            ".dump",
            ".old",
            ".orig",
            ".pyc",
        )
    ):
        return False

    if lower.endswith(".sql") and not (
        name == "schema.sql"
        or re.fullmatch(r"migration_[A-Za-z0-9_]+\.sql", name)
    ):
        return False

    return True


def release_archive():
    return subprocess.check_output(
        ["git", "archive", "--format=tar", "HEAD"]
    )


def exported_names(archive=None):
    if archive is None:
        archive = release_archive()

    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as tar:
        return [
            member.name.rstrip("/")
            for member in tar.getmembers()
            if member.name.rstrip("/")
        ]


def has_invalid_shell_line_endings(data):
    """Shell scripts shipped to Linux must not contain carriage returns."""
    return b"\r" in data


def shell_scripts_with_invalid_line_endings(archive=None):
    if archive is None:
        archive = release_archive()

    invalid = []
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as tar:
        for member in tar.getmembers():
            name = member.name.rstrip("/")
            if not name.lower().endswith(".sh") or not member.isfile():
                continue
            handle = tar.extractfile(member)
            data = handle.read() if handle is not None else b""
            if has_invalid_shell_line_endings(data):
                invalid.append(name)
    return invalid


if __name__ == "__main__":
    archive = release_archive()
    names = exported_names(archive)

    rejected = [
        name
        for name in names
        if not allowed(name)
    ]
    invalid_shell_line_endings = shell_scripts_with_invalid_line_endings(archive)
    ok = not rejected and not invalid_shell_line_endings

    print(
        json.dumps(
            {
                "ok": ok,
                "rejected": rejected,
                "invalid_shell_line_endings": invalid_shell_line_endings,
                "checked_exported_paths": len(names),
                "zip_created": False,
            }
        )
    )

    raise SystemExit(0 if ok else 1)
