#!/bin/sh
set -eu

APP_DIR="${APP_DIR:-/var/www/waage}"
SYSTEMD_DIR="${SYSTEMD_DIR:-/etc/systemd/system}"
STATE_DIR="${STATE_DIR:-/var/lib/waagebox/dini}"
RF_RUNTIME_DIR="${RF_RUNTIME_DIR:-/run/waagenbox-rf}"

SERVICE_NAME="waagenbox-eldat-rx09.service"
SERVICE_SRC="$APP_DIR/systemd/$SERVICE_NAME"
SERVICE_DST="$SYSTEMD_DIR/$SERVICE_NAME"

DEVICE="/dev/serial/by-id/usb-Silicon_Labs_USB_Transceiver_Easywave_00021695-if00-port0"

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: Dieses Script muss als root ausgeführt werden." >&2
    exit 1
fi

for file in \
    "$SERVICE_SRC" \
    "$APP_DIR/hardware/eldat_rx09_listener.py" \
    "$APP_DIR/hardware/eldat_remote_worker.py" \
    "$APP_DIR/cli/eldat_remote_trigger.php" \
    "$APP_DIR/cli/eldat_remote_complete.php"
do
    if [ ! -f "$file" ]; then
        echo "FEHLER: Benötigte Datei fehlt: $file" >&2
        exit 1
    fi
done

if [ ! -e "$DEVICE" ]; then
    echo "FEHLER: ELDAT RX09 wurde nicht gefunden: $DEVICE" >&2
    exit 1
fi

if ! getent group dialout >/dev/null 2>&1; then
    echo "FEHLER: Gruppe dialout ist nicht vorhanden." >&2
    exit 1
fi

systemd-analyze verify "$SERVICE_SRC"

install -d \
    -o www-data \
    -g www-data \
    -m 0750 \
    "$STATE_DIR"

if [ ! -d "$RF_RUNTIME_DIR" ]; then
    echo "FEHLER: RF-Runtime-Verzeichnis fehlt: $RF_RUNTIME_DIR" >&2
    echo "Der bestehende RF-Dienst muss aktiv sein." >&2
    exit 1
fi

install -o root -g root -m 0644 \
    "$SERVICE_SRC" \
    "$SERVICE_DST"

systemd-analyze verify "$SERVICE_DST"

if [ "${TEST_MODE:-0}" = "1" ]; then
    echo
    echo "TEST_MODE_OK"
    echo "SERVICE=$SERVICE_DST"
    echo "DEVICE=$DEVICE"
    echo "STATE_DIR=$STATE_DIR"
    echo "RF_RUNTIME_DIR=$RF_RUNTIME_DIR"
    echo "TEST_MODE: systemctl wurde nicht ausgeführt."
    exit 0
fi

systemctl daemon-reload
systemctl enable --now "$SERVICE_NAME"

echo
echo "ELDAT RX09 Produktivdienst wurde installiert."
echo
systemctl status "$SERVICE_NAME" --no-pager -l
