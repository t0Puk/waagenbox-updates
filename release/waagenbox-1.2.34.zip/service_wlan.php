<?php
require_once __DIR__.'/functions.php';
requireAdmin();
require_once __DIR__.'/service_wlan_support.php';
header('Cache-Control: no-store');
$ssid = 'Waagenbox-Service';
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        requireCsrfToken();
        $ssid = (string)($_POST['ssid'] ?? $ssid);
        $result = serviceWlanRequest((string)($_POST['action'] ?? ''), $ssid, (string)($_POST['password'] ?? ''));
    } else {
        $result = serviceWlanRequest('status');
    }
} catch (Throwable $e) {
    $result = ['ok'=>false, 'message'=>$e instanceof InvalidArgumentException ? $e->getMessage() : 'Service-WLAN derzeit nicht verfügbar.'];
}
layoutStart('Service-WLAN', 'settings');
?>
<div class="card"><h1>Service-WLAN</h1>
<p><?=h($result['message'])?></p>
<p>Lokale Waagenbox-Adresse: <strong>http://10.42.0.1</strong></p>
<p>Benötigt die separate Systeminstallation für wlan0. Eine bestehende WLAN-Verbindung wird nicht übernommen. Eingeschaltetes Service-WLAN startet nach einem Neustart automatisch. Das Passwort wird nicht im Klartext gespeichert.</p>
<form method="post" autocomplete="off"><input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
<label>SSID (höchstens 32 UTF-8-Bytes)</label><input name="ssid" value="<?=h($ssid)?>" required>
<label>WLAN-Passwort (8 bis 63 druckbare ASCII-Zeichen)</label><input type="password" name="password" minlength="8" maxlength="63" autocomplete="new-password" required>
<p><button class="button primary" name="action" value="enable">WLAN einschalten</button></p></form>
<form method="post"><input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>"><button class="button" name="action" value="disable">WLAN ausschalten</button></form>
<p><a class="button" href="service_wlan.php">Status aktualisieren</a> <a class="button" href="settings.php">Zurück</a></p></div>
<?php layoutEnd(); ?>
