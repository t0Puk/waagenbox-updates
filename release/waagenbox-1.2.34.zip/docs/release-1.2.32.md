# Release-Vorbereitung 1.2.32

Basis: vollständig abgenommene Version 1.2.31 auf `release/1.2.31` / `8b749cad33803c6156265ee3aeb2c87afe6adbc9`.
Entwicklungsbranch: `feature/1.2.32-rf-remote`.

Die Anwendungsversion stammt ausschließlich aus `version.php`. Nach vollständig bestandener Regression wurde sie auf `1.2.32` angehoben.

## Ziel von 1.2.32

Version 1.2.32 ergänzt die vorhandene QR-/Mobile-Fernbedienung um eine physische 433-MHz-Funkfernbedienung mit Einlernmodus in der Weboberfläche.

Die Änderung verwendet bewusst das vorhandene Datenmodell. Es ist keine Datenbankmigration erforderlich; der feste 24-Bit-Funkcode wird im bestehenden Feld `remotes.code` gespeichert.

## Neue Komponenten

- `hardware/rf_remote_listener.py`
  - liest GPIO17 über `gpiomon`,
  - dekodiert 24-Bit-OOK-Telegramme,
  - verlangt zwei gleiche gültige Frames,
  - verriegelt gehaltene Tastendrücke,
  - übergibt bestätigte Codes an die PHP-CLI-Brücke,
  - fängt Codes im Einlernmodus ab, ohne eine Wiegung auszulösen.
- `rf_remote_support.php`
  - validiert Remote, Fahrzeug, Erstgewicht sowie bestehende Wäge-/Processing-Zustände,
  - übernimmt Schlag/Kunde/Produkt aus der vorhandenen Remote-Zuordnung,
  - startet über die bestehende `setPendingWeighing()`-Logik mit `trigger_type='radio'`,
  - unterstützt einen nebenwirkungsfreien Dry-Run.
- `cli/rf_remote_trigger.php`
  - CLI-only Brücke zwischen Listener und PHP-Anwendungslogik,
  - unterstützt `--dry-run`.
- `api/rf_learn.php`
  - admin- und CSRF-geschützter Einlern-Endpunkt,
  - 20-Sekunden-Lernfenster,
  - Token-/Owner-Bindung,
  - Duplikaterkennung vorhandener Remote-Codes.
- `remotes.php`
  - Button `Handsender einlernen`,
  - übernimmt den erkannten Code in das Formular,
  - zeigt vorhandene Zuordnungen an.
- `systemd/waagenbox-rf-remote.service`
  - Betrieb als `www-data` mit Zusatzgruppe `gpio`,
  - eigener Runtime-Pfad `/run/waagenbox-rf`,
  - systemd-Hardening und automatischer Wiederanlauf.

## Hardware und Protokoll

Getesteter Empfänger: 433-MHz-RF-5V-Modul an GPIO17 mit Pegelanpassung auf maximal 3,3 V.

Getesteter Handsender:

- Dezimal: `4719265`
- Hex: `0x4802A1`
- 24 Bit: `010010000000001010100001`

Typische Pulse:

- kurz ca. 0,4 ms,
- lang ca. 1,1 ms,
- Synchronpause ca. 11,5 ms.

Feste 433-MHz-Codes sind nicht kryptographisch geschützt. Die Funkfunktion ist daher als Komfortauslösung zu behandeln, nicht als starke Authentifizierung.

## Erfolgreich ausgeführte RF-Spezialtests am 15.09.2026

- PHP-Syntax der RF-PHP-Komponenten erfolgreich.
- Python-Syntax des Listeners erfolgreich.
- `tests/rf_remote_decoder_test.py`: 8/8 Tests erfolgreich.
- `tests/rf_remote_dry_run_test.php`: erfolgreich.
- physische Decoder-/Dry-Run-Tests erfolgreich.
- echter RF-End-to-End-Test in isolierter `waagebox_test` erfolgreich.
- systemd-/GPIO-Test erfolgreich.
- realer Einlernmodus erfolgreich; während des Lernens keine Wiegung ausgelöst.
- produktiver UI-Einlernmodus erfolgreich; vorhandene Fernbedienung `FB3` erkannt.
- produktiver RF-Dry-Run erfolgreich.
- produktiver echter Funk-End-to-End-Test erfolgreich:
  - `first_weight=11500.000`,
  - `vehicle_id=1`,
  - `remote_id=3`,
  - `customer_id=1`,
  - `trigger_type=radio`.
- produktiver Testzustand danach kontrolliert entfernt; `weighing_state=0`.
- `waagenbox-rf-remote.service` anschließend dauerhaft `enabled` und `active`.

Details: `docs/rf-remote.md`.

## Vollständige Regression vor Versionsanhebung

Auf dem Raspberry-Testworktree wurde auf Commit `22ea7ac71e89b055640963f695f41ef76a6dd7c8` die vollständige bestehende Release-/Security-/Update-Suite erfolgreich ausgeführt.

Bestanden wurden:

- PHP-Syntax aller versionierten PHP-Dateien,
- Python-Syntax aller 11 versionierten Python-Dateien,
- RF Decoder: 8 Tests,
- RF Dry-Run / Domainlogik,
- `update_safety_test.php`: 76 Checks,
- `update_access_control_test.php`: 6 gezählte Suite-Checks plus alle ausgegebenen Schutzprüfungen PASS,
- `updater_v2_static_test.php`: 22 Checks,
- `updater_v2_phase4_test.php`: 17 Checks,
- `updater_v2_phase5_test.php`: 14 Checks,
- `deploy_bridge_test.php`: 8 Checks,
- `release_1_2_30_test.php`: 63 Regressionchecks,
- `session_http_test.py`: 22 HTTP-/Sessionchecks,
- `service_wlan_test.py`: 13 Tests,
- `service_components_installer_test.py`: 5 Tests,
- `kiosk_test.py`: 4 Tests,
- `release_preflight_test.py`: 2 Tests,
- `tools/release_preflight.py`: erfolgreich, keine abgelehnten Pfade, kein ZIP erzeugt,
- `systemd-analyze verify systemd/waagenbox-rf-remote.service`,
- `bash -n deploy/waagenbox-kiosk`,
- `git diff --check`.

`node` war auf dem Raspberry-Testsystem nicht installiert; die beiden optionalen JavaScript-Syntaxprüfungen wurden deshalb in diesem Lauf übersprungen. Die vollständige Suite meldete `GESAMTERGEBNIS: ALLE TESTS BESTANDEN`.

Danach wurde `version.php` auf `1.2.32` angehoben. Auf dem finalen Versions-Commit ist noch eine kurze Abschlussregression auszuführen, bevor der Source-Commit für das Release festgeschrieben wird.

## Unveränderte Sicherheitsprinzipien

- keine produktiven Daten werden durch das Release zurückgesetzt oder neu initialisiert,
- keine DB-Migration für die Funkfunktion,
- Update-/Rollback-Sicherheitsmechanismen werden nicht abgeschwächt,
- private Release-Schlüssel bleiben ausschließlich auf dem lokalen Windows-Rechner,
- keine produktive `config.php`, Secrets, Backups oder Dumps in Git oder Release,
- signiertes inneres Manifest und SHA256-Prüfung bleiben unverändert erforderlich,
- ZIP-Eintragsnamen müssen POSIX-Pfade mit `/` verwenden.

## Noch ausstehend vor Release-Freigabe

1. kurze Abschlussregression auf dem finalen Versions-Commit,
2. finalen Source-Commit festhalten,
3. Release-Branch `release/1.2.32` erst nach erfolgreicher Abschlussregression und Abnahme erzeugen,
4. Release-ZIP auf dem Windows-Rechner bauen,
5. ZIP-Inhalte/ZIP-Pfade prüfen,
6. SHA256 berechnen,
7. inneres Manifest exakt als UTF-8 ohne BOM mit abschließendem LF erzeugen und signieren,
8. Signatur verifizieren,
9. öffentliches Update-Manifest vorbereiten,
10. Veröffentlichung und Installation erst nach gemeinsamer Prüfung und ausdrücklicher Freigabe.

## Abnahmestatus

Stand dieses Dokuments: Release-Kandidat nach vollständig bestandener Regression und Versionsanhebung auf 1.2.32. Die 433-MHz-Funktion selbst ist praktisch bis in die produktive Wägeauslösung getestet. Signiertes Updatepaket, Release-Branch und Updateinstallation stehen noch aus.
