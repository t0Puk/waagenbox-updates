# Service-WLAN und Kiosk: separate Systeminstallation

## Freigegebener Installationsschritt nach dem App-Update

Ein PHP-Dateiupdate installiert keine Root-Systemkomponenten. Der bestehende signierte
Deploy-/Updatepfad wird nicht erweitert, um beliebige Paketskripte als root auszuführen.
Die folgende Systeminstallation muss separat ausdrücklich freigegeben werden und aus
der geprüften Git-Arbeitskopie erfolgen. Diese Anleitung ist keine Produktionsfreigabe.

```sh
cd /home/pi/Waagenbox
sudo /usr/bin/python3 install_service_components.py --check
# Erst nach ausdrücklicher Freigabe:
sudo /usr/bin/python3 install_service_components.py --install
sudo /usr/bin/python3 install_service_components.py --check
```

`--check` verändert nichts, liefert JSON mit `ok`, `missing`, `required_step` und
Exit-Code 0 bei vollständiger Installation, sonst 1. Es vergleicht die installierten
Systemdateien bytegenau mit dieser Arbeitskopie, prüft Modi, Root-Besitz, Symlinks,
Programme, geladene Units, sudoers, wlan0-Unmanaged-Zustand und den Autostart-Eintrag.
Die sensitive hostapd-Datei wird bei dieser Prüfung nicht gelesen. Prüfung als root,
da die Systemkonfiguration absichtlich nicht für den Webserver lesbar ist.

Voraussetzungen: Debian 13, systemd, NetworkManager/nmcli, Python 3, iproute2,
util-linux; Benutzer pi mit bereits eingerichtetem LightDM-Autologin und rpd-labwc (/usr/bin/labwc-pi).
Der Installer installiert fehlende Pakete hostapd, dnsmasq-base, rfkill, iw, curl,
sudo und Chromium aus den konfigurierten Debian-Paketquellen. Paketlisten müssen
aktuell und die Paketquellen erreichbar sein; nur die Installation benötigt ggf.
Netzwerkzugriff, der spätere Kioskstart nicht. dnsmasq-base liefert den DHCP-Prozess
ohne neuen globalen dnsmasq-Dienst. Eine temporäre policy-rc.d unterbindet Dienststarts
während der Paketinstallation und wird im finally-Block entfernt. Eine vorhandene
policy-rc.d wird niemals ersetzt; in diesem Fall fehlende Pakete separat unter der
bestehenden Richtlinie bereitstellen und Installation wiederholen.

Vor der Umstellung einen unabhängigen Ethernet-/SSH-Zugang sicherstellen. Belegte
NetworkManager-Verbindungen auf wlan0 werden abgelehnt, auch das alte Serviceprofil.
Diese müssen nach separater Prüfung bewusst ausgeschaltet werden. Es werden keine
Profile oder gespeicherten Passwörter gelöscht. Fremde APs und verbundene WLAN-Clients
werden ebenfalls abgelehnt. Andere bestehende unmanaged-devices-Regeln erfordern
manuelle Integration; der Installer ersetzt diese nicht stillschweigend.

Installiert werden ausschließlich Waagenbox-eigene Dateien aus der Zuordnung `FILES`
im Installer. NetworkManager erhält die separate Datei
`/etc/NetworkManager/conf.d/90-waagenbox-service-wlan.conf`:

```ini
[keyfile]
unmanaged-devices=interface-name:wlan0
```

Es erfolgt nur `nmcli general reload conf`, kein NetworkManager-Neustart und keine
Änderung an eth0-Profilen, Routing/NAT, SSH, Apache, MariaDB, Tailscale oder Cloudflare.
Nach `systemctl daemon-reload` bleiben bestehende Enabled-/Disabled-Zustände erhalten.
Der Installer startet weder WLAN noch Chromium; auf frischer Installation ist WLAN aus.

## WLAN-Betrieb

Die Adminseite Einstellungen → Service-WLAN bleibt erhalten, inklusive CSRF-Schutz.
SSID: 1–32 UTF-8-Bytes ohne Steuerzeichen. Passwort: 8–63 druckbare ASCII-Zeichen.
Der feste sudo-Aufruf erlaubt nur den Root-Helper ohne Argumente:

```sudoers
www-data ALL=(root) NOPASSWD: /usr/local/sbin/waagenbox-service-wlan ""
```

Begrenztes JSON über stdin, keine Shell, keine Passwörter in Argumenten, Logs oder DB.
Der Helper leitet PBKDF2-HMAC-SHA1 mit 4096 Iterationen und 32 Bytes ab; gespeichert
wird nur der WPA-PSK. Dieser Schlüssel bleibt sensitiv. SSIDs werden über `ssid2` als
Hex-Bytes kodiert; Sonderzeichen können keine Konfigurationszeilen einschleusen.
`/etc/waagenbox/service-wlan` ist root:root 0700, hostapd.conf atomar geschrieben 0600.

Dienste:

- `waagenbox-service-wlan-prepare.service`: `/usr/sbin/rfkill unblock wlan`, wlan0
  hochfahren, ausschließlich `10.42.0.1/24` setzen. Stop entfernt nur diese Adresse,
  fährt wlan0 herunter und setzt dessen Typ nach dem AP-Stopp wieder auf managed.
  NetworkManager verwaltet wlan0 dadurch weiterhin nicht.
- `waagenbox-service-hostapd.service`: eigene hostapd.conf, wlan0/nl80211,
  2,4 GHz, Kanal 6, DE, WPA2-PSK und CCMP.
- `waagenbox-service-dnsmasq.service`: eigener Vordergrundprozess und feste
  Konfigurationsdatei, port=0, wlan0/bind-interfaces, DHCP .20–.100/24, keine DNS-
  oder Default-Gateway-Ankündigung, eigene flüchtige Lease-/PID-Dateien unter /run.
  Dieser begrenzte Prozess läuft als root; bestehende dnsmasq-Dienste bleiben unberührt.

Einschalten prüft Unmanaged-Zustand, fremde IPv4-Adressen, überlappende Routen und
fremde WLAN-Nutzung, schreibt die Konfiguration, aktiviert alle drei Units und startet
sie. Fehler beim Aktivieren/Starten führen zum Deaktivieren und Stoppen aller drei
Units. Bei fehlgeschlagener Bereinigung meldet der Helper den unvollständigen Zustand.
Ausschalten deaktiviert und stoppt DHCP, hostapd und Prepare in dieser Reihenfolge.
Die eigene PSK-Datei bleibt root-only erhalten, keine fremden Daten werden gelöscht.
SSID-/Passwortwechsel erfordert vorheriges Ausschalten. Status zeigt Laufzustand und
Autostart getrennt an. systemd-Enablement überlebt Strom-Aus/Ein und Reboot.

Kein Internet-Sharing. HTTP unter http://10.42.0.1 bleibt durch den bestehenden
App-Login geschützt. Ein separates DHCP auf wlan0 darf nicht parallel laufen.

## Kiosk unter labwc/Wayland

`/usr/local/bin/waagenbox-kiosk` wird im grafischen Benutzerkontext pi aufgerufen.
Der Installer führt den Autostart-Editor mit runuser als pi aus; root schreibt nicht
in benutzerkontrollierte Desktop-Pfade. Vorhandene `~/.config/labwc/autostart`-Inhalte
bleiben erhalten; genau eine markierte Startzeile wird ergänzt. Die rpd-labwc-Sitzung startet labwc über labwc-pi mit `-m` und führt System- und
Benutzer-Autostart gemeinsam aus. Die neue Datei bindet den System-Autostart deshalb
nicht nochmals ein; Desktop-Programme werden nicht doppelt gestartet. Symlink-Autostartdateien werden
zur manuellen Prüfung abgelehnt. LightDM- und Session-Konfigurationen bleiben erhalten.

Der Starter verlangt pi und WAYLAND_DISPLAY, verhindert Doppelstarts mit flock,
wartet ohne endgültiges Zeitlimit per curl auf http://127.0.0.1/ und startet
`/usr/bin/chromium --ozone-platform=wayland --kiosk` mit eigener Profildirectory,
No-First-Run, ohne Standardbrowserabfrage, ohne Keyring-Passwortdialog und mit
unterdrückter Session-Crash-Bubble. Nach Browserende wird erneut gestartet.
Ein Profil anderer Browserinstanzen wird nicht verwendet. Der Chromium-Sandbox bleibt
aktiv. Ein erneuter grafischer Login aktiviert den installierten Autostart.

## Vor einer Produktionsfreigabe: Raspberry-Laufzeittests

1. `--check`, Installer zweimal und erneut `--check` ausführen. Fremde Verbindungen
   und fremde unmanaged-Regeln müssen vor Änderungen abgelehnt werden.
2. `systemd-analyze verify` für die drei installierten Units ausführen; dnsmasq mit
   `--test --conf-file=/etc/waagenbox/service-wlan/dnsmasq.conf` prüfen.
3. SSID mit Umlauten/Sonderzeichen, Passwortgrenzen, Ein/Aus und Status prüfen.
   WLAN-Adresse/AP-Modus/Channel, Smartphone-DHCP und http://10.42.0.1 kontrollieren.
4. Eingeschaltet rebooten und stromlos neu starten: alle drei Units aktiv/enabled,
   Smartphone verbindet erneut. Ausgeschaltet rebooten: alle drei Units aus/disabled.
5. Ethernet/SSH, Tailscale, Cloudflare, Apache und MariaDB währenddessen kontrollieren.
   Keine anderen DHCP/DNS-Bindings dürfen übernommen werden.
6. Langsamen Apache-Start simulieren: Chromium startet nach Erreichbarkeit. Browser
   beenden: Wiederanlauf. Reboot/Autologin: pi/Wayland/Kiosk/lokale URL, keine Dialoge.
   Bestehende Desktop-Autostarts und LightDM-Einstellungen bleiben funktional.
7. Linux-Symlink-/Dateirechteprüfungen sowie Paketinstallation ausführen. Vorhandene
   individuell getestete manuelle WLAN-Units/Konfigurationspfade vorher abgleichen.

Die Windows-Tests verwenden Attrappen. Sie ersetzen weder Funkhardware- noch echte
systemd-, Paketinstallations-, DHCP-, Chromium- oder Reboot-Prüfungen.

Referenzen: [NetworkManager nmcli reload conf](https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html),
[labwc Autostart](https://github.com/labwc/labwc/blob/master/docs/labwc-config.5.scd),
[Raspberry Pi labwc-pi mit Merge-Modus](https://github.com/raspberrypi-ui/raspberrypi-ui-mods/blob/master/usr/bin/labwc-pi),
[hostapd-Konfiguration](https://chromium.googlesource.com/external/w1.fi/cgit/hostap/+/refs/tags/hostap_2_1/hostapd/hostapd.conf),
[dnsmasq-Optionen](https://thekelleys.org.uk/dnsmasq/docs/dnsmasq-man.html).
