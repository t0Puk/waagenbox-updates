# Updater-v2 Bootstrap für bestehende Waagenbox v1.2.26

Dieser Bootstrap ist der einmalige Übergang von der bestehenden
v1.2.26 auf die root-geschützte Updater-v2-Architektur.

Er verändert die Anwendungsversionsnummer nicht.

## Sicherheitsprinzipien

Vor jeder Bootstrap-Mutation wird eine vollständige,
verifizierte Anwendung-/Datenbanksicherung außerhalb des
Webroots erstellt.

Der Anwendungscode wird anschließend root-owned. Apache/www-data
erhält keine allgemeinen Schreibrechte auf den Codebaum.

Ausnahmen:

- `config.php`: `root:www-data`, Modus `0640`
- `uploads`: `www-data:www-data`
- `uploads/camera`: für Laufzeitbilder schreibbar

Der privilegierte Deployment-Helfer darf ausschließlich über
die fest definierte sudoers-Regel gestartet werden.

Der private Release-Signaturschlüssel gehört niemals auf die
Waagenbox. Auf dem Raspberry liegt ausschließlich der Public Key.

## Legacy-config.php

Die alte APP_VERSION-Deklaration wird mit
`updateSafetyLegacyConfig()` eindeutig analysiert und entfernt bzw.
auf die zentrale `version.php` umgestellt.

Unklare oder dynamische Deklarationen werden abgelehnt.

## Altes recovery_failed-Journal

Das alte Journal wird niemals einfach gelöscht.

Vorher wird:

1. eine frische vollständige Bootstrap-Sicherung erstellt,
2. das alte Journal in das Bootstrap-Verzeichnis kopiert,
3. nur der bekannte Zustand `recovery_failed` ohne aktive Mutation
   auf `recovered` versöhnt.

Unbekannte Journalzustände führen zum Abbruch.

## Produktionsaktivierung

Die Produktionsaktivierung erfolgt erst nach erfolgreichem
isoliertem Phase-5-Test und gesonderter ausdrücklicher Freigabe.

Während des echten Bootstrap:

- keine Wägungen,
- keine mobilen Auslösungen,
- keine parallelen Browser-Schreibzugriffe,
- kein Update oder Restore,
- Apache wird kontrolliert für das Wartungsfenster behandelt.

Nach Bootstrap bleibt die Anwendung auf v1.2.26.

Das erste reguläre Update danach muss ein neues, signiertes Release
größer als 1.2.26 sein und im Manifest zusätzlich eine
`signature_url` besitzen.
