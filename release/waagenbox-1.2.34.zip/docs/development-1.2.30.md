# Entwicklung 1.2.30

Basis: `release/1.2.29`, Umsetzung ausschließlich auf `feature/1.2.30`.

## Änderungen

1. Kunden: Beim INSERT fehlte `owner_user_id`; jetzt wird `currentOwnerId()`
   mitgespeichert. Keine Migration. Statuswechsel und Löschen unverändert.
2. QR: `mobileRemoteBaseUrl()` definiert den endgültigen Endpunkt
   `https://waage-ajp.de`. Alte gespeicherte Basisadressen werden nicht mehr
   ausgewertet oder verändert. Lokale URLs und mobile Tokens bleiben unverändert.
3. Manuelle Backups: Gzip-Download mit `AJP-Waagenbox_v<APP_VERSION>_<Zeit>.sql.gz`.
4. Automatisches Backup: Admin-Download ausschließlich aus `/var/backups/waagenbox`,
   sortiert nach dem Erstellungszeitstempel im Dateinamen. Alte automatische
   Namensformate werden erkannt. Dateityp, Pfadauflösung, Symlinks, Inode und
   Gzip-Integrität werden geprüft; der geprüfte Deskriptor wird gestreamt.
5. Navigation: sichtbarer Abmelden-Link mit bestehendem Design.
6. Auth: serverseitiger 900-Sekunden-Timeout, Session-ID-Wechsel beim Login und
   Timeout, strikter Session-Modus. Hintergrund-Polling verlängert keine Sitzung.
   CSRF-geschützte Aktivitätsmeldung berücksichtigt tatsächliche Browserbedienung.
   Direkter Loopback-/Entwicklungs-Bypass bleibt; Proxy-Header können den Bypass
   ausschließlich einschränken. Mobile Token-Endpunkte erhalten keine Loginpflicht.
   Bestehende normale Sitzungen ohne Aktivitätszeitstempel benötigen eine neue Anmeldung.
7. Cloudflare: ausschließlich Anwendungscode geändert. Kein Netzwerktest gegen
   die öffentliche Installation erforderlich; keine Infrastrukturänderung.
8. Service-WLAN: Adminseite, doppelte Eingabevalidierung und separat installierbarer
   Root-Helper mit festem NetworkManager-Profil. Passwort über stdin und nur in
   root-eigener NetworkManager-Datei, nicht in der App-Datenbank.
   Einrichtung und Grenzen: [service-wlan.md](service-wlan.md).
9. Dini: vorhandene API war ungeschützt und bot schreibende Wiegeaktionen an.
   Jetzt Adminschutz und ausschließlich R, VER, STAT, REXT, RALL über die bestehende
   Klasse. Deaktivierung/Demo-Modus und Nichterreichbarkeit werden sauber behandelt.
10. `version.php` bleibt alleinige Versionsquelle: `1.2.30`.

## Lokale Prüfungen

PHP 8.4.25 unter Windows, mit `-n` ohne lokale PHP-Konfiguration.

- PHP-Lint aller geänderten/neuen PHP-Dateien und `git diff --check`.
- `php -n tests/release_1_2_30_test.php`: 62 Prüfungen erfolgreich.
  Windows erlaubt hier keine Symlink-Erstellung; die beiden Symlink-Lauftests
  sind deshalb als SKIP ausgewiesen und auf Linux erneut auszuführen.
- `python tests/session_http_test.py <php.exe>`: 22 HTTP-Prüfungen erfolgreich,
  mit synthetischem App-Bootstrap, isolierten Sessions und Backup-Verzeichnis.
  Prüft Login, Fixation, Timeout, CSRF, Loopback, Dini-Zustände und Download-Header.
- `python tests/service_wlan_test.py`: 8 Tests erfolgreich. Alle NetworkManager-
  und Dateisystemoperationen sind Attrappen; kein echtes Netzwerk wird verändert.
- `node --check assets/session.js`: erfolgreich.
- Vorhandene PHP-Suiten: deploy_bridge (8), updater_v2_phase4 (17),
  updater_v2_phase5 (14), updater_v2_static (22), update_access_control (alle
  Prüfungen erfolgreich; dessen vorhandener Ergebniszähler meldet 6),
  update_safety (76) erfolgreich.
- Der Bridge-Test benötigt die synthetischen Umgebungswerte
  `WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE=/tmp/waagenbox_deploy_bridge_test_1230/storage`
  und `WAAGEBOX_DEPLOY_CLIENT_TEST_HELPER=/tmp/waagenbox_deploy_bridge_test_1230/helper`.
- Der Sicherheitstest benötigt die ZIP-Erweiterung (`-d extension=zip` mit passendem
  `extension_dir`). Innerhalb der Windows-Sandbox konnte `cp.exe` nicht starten;
  außerhalb der Sandbox bestand die Suite vollständig mit synthetischen Fixtures.

## Grenzen vor produktivem Einsatz

Keine Freigabe für eine Produktionsinstallation. Keine Änderungen an produktiver
Datenbank, Waagenhardware, Netzwerk, Cloudflare, IONOS, Tailscale, Updates oder
Rollback-Beständen durchgeführt. Die echte lokale `config.php` wurde weder gelesen
noch verändert und ist nicht versioniert. Keine Schlüssel oder echten Tokens ergänzt.

Service-WLAN muss separat installiert/freigegeben und an einer dedizierten
Schnittstelle getestet werden. Reale Dini-Kommunikation wurde nicht ausgelöst.
Der Backup-Download benötigt Leserechte des Webserver-Benutzers; der vorhandene
Backup-Dienst arbeitet bereits als `www-data`. Bestehende abweichende Dateirechte
werden nicht automatisch geändert. Browserdarstellung und Tunnel-/Hardwarebetrieb
bleiben auf einem ausdrücklich freigegebenen Testsystem zu prüfen.
