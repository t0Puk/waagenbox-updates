# Erster Umstieg von v1.2.26 auf den abgesicherten Updater

Diese Anleitung beschreibt einen später ausdrücklich freizugebenden Produktiveinsatz.
Bei der Entwicklung wurden weder diese Schritte ausgeführt noch Produktivdaten gelesen.
Vorher ist ein kompletter Test mit einer isolierten Kopie unter Linux/PHP 8.4/MariaDB 11.8 erforderlich.

## Warum der alte Updateweg nicht geeignet ist

Geprüfte Grundlage: lokales `main`, Commit `0e1feff3965f4e3a7c8d428cbaad3a6876cb24af`,
`api/update_install.php` und dessen aufrufende Oberfläche.

Der alte Installer verlangt `config.php` und `functions.php` im ZIP. Beim Kopieren
überspringt er zwar die Paket-`config.php`, schreibt anschließend aber selbst die
Legacy-Versionskonstante in der lokalen Datei um. Auch nach dem Kopieren eines neuen
Installers läuft der bereits gestartete Request mit dem alten Installationscode weiter.
Seine unvollständigen Fehlerpfade werden dadurch nicht repariert.

Ein Dummy-`config.php` im Paket ist deshalb KEIN sicherer Bootstrap. Ein reguläres
Paket ohne diese Datei wird vom alten Installer abgelehnt. Die Datei
`update_install.php` im Anwendungshauptverzeichnis ist ebenfalls kein Bootstrap;
sie besitzt andere/falsche relative Pfade und wird von der Oberfläche nicht verwendet.

## Phase A: Ausschließlich den Installationsmechanismus austauschen

1. Wartungsfenster freigeben: keine Wägungen, mobilen Auslösungen, schreibenden
   Browseranfragen, Cron-Backups oder anderen Update-/Restore-Prozesse während des
   gesamten Vorgangs. Die neue Sperre schützt nur kooperierende Update-/Rollback-Aufrufe.
2. Den vollständig geprüften Quellstand separat unter
   `/home/pi/Waagenbox-bootstrap-reviewed` bereitstellen. Dort dürfen keine echten
   Zugangsdaten liegen. Nur die unten genannten drei Dateien werden installiert.
   Insbesondere keine pauschale Verzeichniskopie und kein alter `.patch`-Export.
3. Voraussetzungen für den ausführenden Dienstbenutzer prüfen: PHP-CLI 8.4,
   PDO-MySQL, cURL, ZIP, `proc_open`, `cp`, `mariadb-dump` (alternativ `mysqldump`)
   und `mariadb` (alternativ `mysql`). Anwendung muss lesbar sein; Zielverzeichnisse
   und `/var/lib/waagebox` müssen die erforderlichen Schreibrechte besitzen.
   Auch Dump-/Restore-Rechte für Tabellen, Views, Trigger, Routinen und Events
   müssen vorher in der isolierten Umgebung nachgewiesen sein.
4. Vor dem ersten Dateiaustausch eine **eigene vollständige Bootstrap-Sicherung**
   der unveränderten v1.2.26 erstellen und prüfen. Vorhandenes
   `/var/lib/waagebox/rollback` dabei weder umbenennen noch löschen.
   Dafür kann die neue Hilfsdatei aus dem separaten Prüfverzeichnis benutzt werden:

   ```php
   // Nur als kontrollierter CLI-Vorgang im später freigegebenen Wartungsfenster.
   $app = '/var/www/waage';
   $storage = '/var/lib/waagebox';
   require '/home/pi/Waagenbox-bootstrap-reviewed/update_safety.php';
   require $app.'/config.php';
   require_once $app.'/version.php'; // Hier ausdrücklich die ALTE, bedingte Definition.
   $lock = updateSafetyLock($storage); // Bis Ende von Austausch/Prüfung offen halten.
   $work = $storage.'/bootstrap_'.date('Ymd_His').'_'.bin2hex(random_bytes(8));
   updateSafetyDirectory($work);
   $snapshot = $work.'/snapshot';
   updateSafetySnapshot($app, $snapshot, [
       'previous_version'=>APP_VERSION, 'new_version'=>APP_VERSION,
   ]);
   updateSafetyValidateSnapshot($snapshot);
   // Erst nach erfolgreicher Rückkehr Dateiaustausch fortsetzen.
   ```

   Der CLI-Vorgang darf keine Konfigurationsinhalte ausgeben. Die Sicherung muss
   außerhalb des Webroots bleiben; ihre Eigentümer-/Gruppenrechte kontrolliert
   passend zum ausführenden Dienstbenutzer setzen. Keinen Schutz pauschal lockern.

5. Unter weiter gehaltenem Lock ausschließlich in dieser Reihenfolge austauschen:

   | Quelle im Prüfverzeichnis | Ziel relativ zu `/var/www/waage` |
   |---|---|
   | `update_safety.php` | `update_safety.php` |
   | `api/update_rollback.php` | `api/update_rollback.php` |
   | `api/update_install.php` | `api/update_install.php` |

   Für jede Datei: zuerst in eine eindeutige temporäre `.php`-Datei im jeweiligen
   Zielverzeichnis kopieren, Exitcode prüfen, PHP-Syntax und SHA-256 gegen die
   geprüfte Quelle vergleichen, passende Dateirechte setzen und erst dann per
   `rename` auf den endgültigen Namen aktivieren. Keine Shell-Globs verwenden.
   Der Installer kommt zuletzt, damit er niemals ohne seine Hilfsdatei startet.
6. Die drei endgültigen Dateien erneut per SHA-256/Syntax prüfen. Zusätzlich die
   SHA-256 von **config.php und version.php** gegen die Bootstrap-Sicherung prüfen:
   beide müssen noch bytegenau unverändert sein. In Phase A NICHT austauschen:
   `config.php`, `config.example.php`, `version.php`, `functions.php` oder SQL-Dateien.
   Einen gegebenenfalls aktiven OPcache kontrolliert invalidieren; das CLI allein
   leert nicht den OPcache von Apache/mod_php. Erst danach den Lock freigeben.
7. Bei irgendeinem Fehler abbrechen. Mit der extern bereitgehaltenen Hilfsdatei
   `updateSafetyRecover($snapshot, $app, $work)` ausführen und das Ergebnis prüfen:
   nur ein leeres Fehlerarray bestätigt beide Wiederherstellungsschritte. Bei
   Fehlern bleibt der Betrieb gesperrt und die Bootstrap-Sicherung erhalten.
   Nach einem Prozessabbruch zuerst den Zustand anhand dieser Sicherung prüfen,
   keinesfalls blind erneut kopieren. Die Bootstrap-Sicherung bleibt dauerhaft
   von der automatischen Aufbewahrung ausgenommen.

Nach Phase A lautet die Anwendungsversion weiterhin **1.2.26**. Die lokale
Konfiguration darf weiterhin ihre Legacy-Konstante enthalten. Der neue Installer
kann damit starten, weil `version.php` noch die alte bedingte Definition verwendet.

## Phase B: Erstes reguläres Update mit Legacy-Migration

1. Einen freigegebenen vollständigen Release mit einer Version **größer als
   1.2.26** vorbereiten, beispielsweise 1.2.27. Manifest-Version und der tatsächliche
   Literalwert in Paket-`version.php` müssen identisch sein. Diese Reparatur erhöht
   die Versionsnummer noch nicht: ein unverändertes Paket mit Version 1.2.26 ist
   daher kein installierbarer Folgerelease. Niemals nur das Manifest höher setzen.
2. Das Paket enthält `version.php` als alleinige Versionsdefinition und die
   aktualisierte `config.example.php` ohne Versionskonstante. Pflichtdateien sind
   außerdem `functions.php`, `db.php`, `index.php`, `api/update_install.php`,
   `api/update_rollback.php` und `update_safety.php`. Die **lokale config.php gehört
   nicht ins Paket**; ebenso keine `.git`, `.env`, Laufzeitbilder oder Sicherungen.
3. SHA-256 des fertigen ZIP ins HTTPS-Manifest übernehmen und das Paket zuerst in
   der isolierten v1.2.26-Testkopie mit Legacy-Konfiguration installieren.
4. Erst nach Freigabe im Wartungsfenster über den nun neuen API-Installer installieren.
   Dieser erstellt und prüft Anwendungssicherung plus Datenbankdump, aktiviert die
   neue Rollback-Generation und protokolliert den Mutationsbeginn. Erst danach
   ersetzt er genau die einfache Legacy-Versionsdeklaration in der lokalen
   Konfiguration durch `require_once __DIR__ . '/version.php';`.
   Alle Bytes außerhalb dieser Deklaration bleiben erhalten. Die ursprüngliche
   Datei liegt unverändert im Snapshot. Ungewöhnliche/dynamische Deklarationen
   werden ohne erratene Änderungen abgewiesen.
5. Anschließend installiert er die Paketdateien und prüft Kopien, Migrationen und
   Konfigurationshash. Ein Fehler führt zum Restore von Anwendung **und** Datenbank;
   damit kommen auch die ursprüngliche Legacy-`config.php` und die passende alte
   `version.php` zurück. Der sichere Updater aus Phase A ist Teil dieses Snapshots.
6. Nach Erfolg in einem neuen Request Versionsanzeige, Datenbankzugriff und
   Rückkehrmöglichkeit prüfen. Erst nach Ende des Wartungsfensters wieder wiegen.

## Aufbewahrung und verbleibende Grenzen

- Erfolgreiche Updates entfernen ihr ZIP, Staging-Verzeichnis und den geschützten
  Konfigurationsentwurf. Kleine Protokoll-/Arbeitsverzeichnisse bleiben erhalten.
- Die aktuelle Rollback-Sicherung bleibt immer erhalten. Zusätzlich bleibt die
  neueste weitere ausdrücklich erfolgreiche Generation erhalten; dazu zählen
  auch Sicherheitskopien erfolgreicher manueller Rollbacks.
- Nur gebunden markierte, erneut verifizierte Generationen werden automatisch
  gelöscht. Fehler-/Abbruchdaten, beschädigte oder unbekannte Altbestände,
  Bootstrap-Sicherungen und durch einen Fehler geschützte Generationen nie.
- Fehlgeschlagene Bereinigung ist ein Hinweis zu einem erfolgreichen Update,
  kein Anlass, die bereits erfolgreiche Installation zurückzurollen.
- Fehlerdaten können weiterhin viel Speicher belegen und benötigen eine spätere
  bewusste manuelle Prüfung. Keine automatische Löschung bei Speicherknappheit.
- Ein harter Prozessabbruch/Stromausfall ist nicht durch PHP garantiert reparierbar.
  Journal und Rettungsdateien müssen danach geprüft werden. Fehlende Rechte oder
  defekte Datenträger können auch einen Restore verhindern.
- `rename` übernimmt den Dateimodus, erzeugt aber eine neue Datei unter dem
  ausführenden Benutzer. Eigentümer/Gruppe, ACLs und Apache-/OPcache-Verhalten
  müssen im Linux-Test geprüft werden. Der Installer ändert keine DB-Zugangsdaten.
- Die Windows-Dateitests ersetzen keinen echten MariaDB-Roundtrip mit Datenvergleich.
