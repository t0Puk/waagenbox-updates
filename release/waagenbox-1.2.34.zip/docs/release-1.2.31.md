# Release-Vorbereitung

Basis: `925110927f35a2e998646f87a50c6c3e04743e96`, Branch `feature/1.2.31`.
Die Anwendungsversion stammt ausschließlich aus `version.php`: `1.2.31`.

## Umsetzung

Der reale NetworkManager-Hotspot erwies sich auf BCM43430/Debian 13 als unzuverlässig.
Der Ersatz verwendet die drei eigenen systemd-Dienste für Adresse, hostapd und DHCP.
Details, Systemdateien, sichere Migration, Ein-/Aus-Persistenz und Raspberry-Prüfplan:
[Service-WLAN und Kiosk](service-wlan.md).

`deploy/system-installation.json` beschreibt maschinenlesbar den separat freizugebenden
Systemschritt. `install_service_components.py --check` prüft dessen Ergebnis mit JSON
und Exit-Code. Ein normales App-Update führt diesen Root-Installer nicht aus.

Das Dashboard verwendet weiterhin APP_VERSION. Die Copyright-Zeile steht mit einem
einfachen Zeilenumbruch im selben Footer und erbt dessen Schrift, Größe und Farbe.
`dashboard.php` ist bereits ein Alias für `index.php`; die Änderung liegt daher in
`index.php` und dem bestehenden Layout in `functions.php`.

Kiosk: ein eigener Launcher und eine ergänzte labwc-Autostartzeile unter pi,
Chromium/Wayland/Kiosk mit lokaler URL, HTTP-Warteschleife und Wiederanlauf.
Keine Änderungen an Datenbankschema, Wägeabläufen oder Update-/Rollback-Code.

## Lokale Prüfungen unter Windows

Erfolgreich ausgeführt:

- PHP 8.4.25 `-n -l`: functions.php, index.php, service_wlan.php,
  service_wlan_support.php, tests/release_1_2_30_test.php, version.php.
- `update_safety_test.php`: 76 Prüfungen. Erster Lauf in der Windows-Sandbox
  scheiterte beim Start von Git-cp.exe; vollständiger Wiederholungslauf außerhalb
  der Sandbox mit ausschließlich synthetischen temporären Daten bestanden.
- `update_access_control_test.php`: alle 12 ausgegebenen PASS-Prüfungen bestanden;
  der bestehende Ergebniszähler der Suite meldet 6.
- `updater_v2_static_test.php`: 22, `updater_v2_phase4_test.php`: 17,
  `updater_v2_phase5_test.php`: 14 Prüfungen bestanden.
- `deploy_bridge_test.php`: 8 Prüfungen mit den synthetischen Umgebungsvariablen
  `WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE=/tmp/waagenbox_deploy_bridge_test_1231/storage`
  und `WAAGEBOX_DEPLOY_CLIENT_TEST_HELPER=/tmp/waagenbox_deploy_bridge_test_1231/helper`.
- `release_1_2_30_test.php`: 62 Prüfungen; bestehende Linux-Symlinkprüfungen unter
  Windows übersprungen. Erwarteter Backupname bezieht APP_VERSION dynamisch.
- `session_http_test.py`: 22 HTTP-Prüfungen mit synthetischem Bootstrap bestanden.
- `service_wlan_test.py`: 13 Tests für PSK-Testvektor, SSID-/Passwortgrenzen,
  atomisches Schreiben, Fremdverbindungen/Routen, Ein-/Aus-Persistenz, Startfehler,
  Cleanup, Status, Root-Verzeichnis sowie systemd-/rfkill-/IP-/WPA2-/DHCP-Vorgaben.
- `service_components_installer_test.py`: 5 Tests zu Abbruchbedingungen,
  Wiederholungsinstallation mit Zustandserhalt und Linux-Zeilenenden.
- `kiosk_test.py`: 4 Tests zu bestehendem/frischem Autostart, Idempotenz,
  Benutzerkontext und lokalem Chromium-Kioskstart.
- `release_preflight_test.py`: 2 Tests für erlaubte Programmdateien sowie
  ausgeschlossene Secrets, Dumps, Laufzeitdaten und unsichere ZIP-Pfade.
- Python-Syntaxprüfung der acht neuen/geänderten Python-Dateien bestanden.
- `bash -n deploy/waagenbox-kiosk` bestanden (Git-Bash benötigt auf diesem Rechner
  ebenfalls Ausführung außerhalb der Windows-Sandbox).
- `node --check assets/session.js` und `node --check assets/app.js` bestanden.
- `git diff --check` und Release-Pfadprüfung bestanden.

Die Python-Systemtests verwenden Attrappen, keine echte Paketinstallation oder
Netzwerkänderung. Raspberry-spezifische systemd-Validierung, DHCP/AP-Funktion,
Dateirechte, Kiosk/Wayland, langsamer Boot, Strom-Aus/Ein, Reboot und Erhalt aller
parallelen Dienste sind vor Produktionsfreigabe anhand der verlinkten Anleitung
auf dem Zielgerät zu prüfen. Lokale Browserdarstellung nicht visuell geprüft.

## Separater späterer Release-Schritt

`python -B tools/release_preflight.py` prüft die versionierten Kandidatenpfade, liest
keine Dateiinhalte und baut kein Archiv. Unversionierte Dateien niemals pauschal
in das Release aufnehmen. Der spätere Paketbau muss dieselbe Pfadprüfung auf seine
tatsächliche Dateiliste anwenden und ausschließlich POSIX-Pfade mit `/` verwenden.
Die Prüfung ersetzt keine Inhaltskontrolle einer ausdrücklich freigegebenen
Release-Stagingkopie auf versehentlich in Quelldateien eingetragene Zugangsdaten.

Erlaubt bleiben schema.sql, migration_*.sql und Backup-Programmdateien. Verboten sind
lokale Konfiguration/.env*, private Schlüssel, fremde SQL-Dateien/Dumps/sql.gz,
bak/dump/old/orig sowie Laufzeit-Uploads/-Backups. Keine pauschale Sperre auf den
String `backup`. Der bestehende Updater lehnt ZIP-Einträge mit Backslashes ab.

Keine Produktionsinstallation, kein Zugriff auf den produktiven Anwendungspfad,
keine Produktionsdatenbankänderung, keine Hardwarebefehle, keine Verwendung privater
Schlüssel und keine Veröffentlichung. Kein Release-ZIP erstellt; lediglich vorhandene
isolierte Sicherheitstests erzeugten ihre eigenen synthetischen Archiv-Fixtures.
