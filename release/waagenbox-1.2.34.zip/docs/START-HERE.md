# START HERE – AJP Waagenbox

Für jede zukünftige Änderung an der Waagenbox zuerst lesen:

1. `AGENTS.md`
2. `docs/PROJECT-STATE.md`
3. `docs/release-1.2.31.md`
4. bei Service-WLAN-Änderungen zusätzlich `docs/service-wlan.md`

## Bekannter guter Referenzstand

- Produktiv abgenommene Version: `1.2.31`
- Getesteter Source-Commit: `8b749cad33803c6156265ee3aeb2c87afe6adbc9`
- Unveränderlicher Referenz-Branch: `release/1.2.31`
- Dokumentationsstand auf `feature/1.2.31`: enthält nachträglich nur Dokumentation, keine Änderung an der getesteten Anwendung.

## Regel für die nächste Version

Neue Entwicklung nicht direkt auf dem produktiven Pfad und nicht auf `release/1.2.31` durchführen. Für die nächste Version einen neuen Feature-/Fix-Branch vom bekannten guten Stand erzeugen, Änderungen testen, anschließend auf dem Raspberry-Testworktree prüfen und erst nach erfolgreicher Abnahme ein neues Release bauen.

`release/1.2.31` ist die technische Rückfall- und Vergleichsbasis.
