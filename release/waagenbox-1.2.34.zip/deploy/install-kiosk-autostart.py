#!/usr/bin/python3
"""Runs as pi, never writes user-owned paths as root. Preserve existing autostart."""
import os
from pathlib import Path
import sys

LINE = '/usr/local/bin/waagenbox-kiosk & # AJP Waagenbox kiosk'


def install(home):
    directory = home / '.config/labwc'
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / 'autostart'
    if target.is_symlink():
        raise ValueError('Symlink autostart: manual review required')
    if not target.exists():
        # rpd-labwc uses labwc-pi -> labwc -m. System autostart is already merged.
        target.write_text('#!/bin/sh\n# rpd-labwc merges the system autostart automatically.\n', encoding='utf-8')
    text = target.read_text(encoding='utf-8')
    if LINE not in text.splitlines():
        with target.open('a', encoding='utf-8') as output:
            output.write('\n' + LINE + '\n')


if __name__ == '__main__':
    import pwd
    if os.getuid() != pwd.getpwnam('pi').pw_uid or os.getuid() == 0:
        sys.exit('Must run as pi')
    install(Path(pwd.getpwnam('pi').pw_dir))
