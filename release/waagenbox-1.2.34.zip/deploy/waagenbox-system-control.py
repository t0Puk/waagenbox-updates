#!/usr/bin/python3
"""Privilegierter Waagenbox-Systemhelper mit fester Aktions-Whitelist."""
import json
import os
from pathlib import Path
import pwd
import shlex
import signal
import subprocess
import sys
import time

ALLOWED_ACTIONS = {'kiosk_exit', 'reboot', 'poweroff'}
KIOSK_SCRIPT = '/usr/local/bin/waagenbox-kiosk'
SYSTEMCTL = '/usr/bin/systemctl'
KIOSK_PROFILE = '/home/pi/.local/share/waagenbox-kiosk'
KIOSK_URL = 'http://127.0.0.1/'


def validate(request):
    if not isinstance(request, dict) or request.get('action') not in ALLOWED_ACTIONS:
        raise ValueError('Ungültige Systemaktion.')
    if set(request) != {'action'}:
        raise ValueError('Unerwartete Systemparameter.')
    return request['action']


def pi_account():
    try:
        return pwd.getpwnam('pi')
    except KeyError:
        raise ValueError('Benutzer pi wurde nicht gefunden.') from None


def kiosk_pid_file():
    account = pi_account()
    return Path('/run/user') / str(account.pw_uid) / 'waagenbox-kiosk.pid'


def decode_cmdline(data):
    """Decode /proc/<pid>/cmdline, including Chromium's rewritten single-string argv."""
    parts = [part.decode('utf-8', 'replace') for part in data.split(b'\0') if part]
    if len(parts) == 1 and ' ' in parts[0]:
        try:
            expanded = shlex.split(parts[0], posix=True)
        except ValueError:
            return parts
        if expanded:
            return expanded
    return parts


def process_args(pid):
    try:
        return decode_cmdline(Path(f'/proc/{pid}/cmdline').read_bytes())
    except OSError:
        return []


def process_uid(pid):
    try:
        status = Path(f'/proc/{pid}/status').read_text(encoding='utf-8', errors='replace')
    except OSError:
        return None
    uid_line = next((line for line in status.splitlines() if line.startswith('Uid:')), '')
    fields = uid_line.split()
    try:
        return int(fields[1]) if len(fields) >= 2 else None
    except ValueError:
        return None


def process_ppid(pid):
    try:
        text = Path(f'/proc/{pid}/stat').read_text(encoding='ascii', errors='replace')
        close = text.rfind(')')
        if close < 0:
            return None
        fields = text[close + 2:].split()
        return int(fields[1]) if len(fields) > 1 else None
    except (OSError, ValueError):
        return None


def process_identity(pid, uid):
    if process_uid(pid) != uid:
        return False
    args = process_args(pid)
    return len(args) >= 2 and args[0] in ('/bin/sh', '/usr/bin/sh') and args[1] == KIOSK_SCRIPT


def matching_kiosk_wrappers(uid):
    matches = []
    try:
        entries = list(Path('/proc').iterdir())
    except OSError:
        return matches
    for entry in entries:
        if entry.name.isdigit():
            pid = int(entry.name)
            if pid > 1 and process_identity(pid, uid):
                matches.append(pid)
    return sorted(matches)


def kiosk_pid():
    account = pi_account()
    path = kiosk_pid_file()
    try:
        info = path.lstat()
        if path.is_file() and info.st_uid == account.pw_uid and not (info.st_mode & 0o022):
            pid = int(path.read_text(encoding='ascii').strip())
            if pid > 1 and process_identity(pid, account.pw_uid):
                return pid
    except (OSError, ValueError):
        pass

    # Übergang von Versionen vor 1.2.34: Der bereits laufende Launcher hat
    # noch keine PID-Datei. Nur genau einen Wrapper mit exakt passender
    # Prozessidentität akzeptieren; kein unscharfes Prozess-Matching verwenden.
    matches = matching_kiosk_wrappers(account.pw_uid)
    return matches[0] if len(matches) == 1 else None


def legacy_chromium_child(wrapper_pid, uid):
    matches = []
    try:
        entries = list(Path('/proc').iterdir())
    except OSError:
        return None
    for entry in entries:
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        if process_ppid(pid) != wrapper_pid or process_uid(pid) != uid:
            continue
        args = process_args(pid)
        if not args:
            continue
        exe = args[0]
        if exe not in ('/usr/bin/chromium', '/usr/lib/chromium/chromium'):
            continue
        if '--kiosk' not in args or KIOSK_URL not in args:
            continue
        if '--user-data-dir=' + KIOSK_PROFILE not in args:
            continue
        matches.append(pid)
    return matches[0] if len(matches) == 1 else None


def wait_gone(pid, timeout):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not Path(f'/proc/{pid}').exists():
            return True
        time.sleep(0.1)
    return not Path(f'/proc/{pid}').exists()


def stop_kiosk():
    account = pi_account()
    pid = kiosk_pid()
    if pid is None:
        return {'ok': True, 'message': 'Kiosk-Modus ist bereits beendet.', 'kiosk_running': False}

    pid_file_present = kiosk_pid_file().exists()
    if not pid_file_present:
        # Alter, bereits vor 1.2.34 gestarteter Launcher: zuerst ausschließlich
        # den exakt validierten Chromium-Hauptprozess beenden. Der alte Wrapper
        # kehrt danach in seine Schleife zurück; anschließend wird nur der exakt
        # validierte Wrapper beendet. Keine Prozessgruppe wird signalisiert.
        child = legacy_chromium_child(pid, account.pw_uid)
        if child is None:
            raise ValueError('Laufender alter Kiosk konnte nicht eindeutig erkannt werden.')
        os.kill(child, signal.SIGTERM)
        if not wait_gone(child, 6):
            raise ValueError('Alter Kiosk-Browser konnte nicht sauber beendet werden.')
        if not process_identity(pid, account.pw_uid):
            return {'ok': True, 'message': 'Kiosk-Modus wurde beendet. Der Desktop bleibt geöffnet.', 'kiosk_running': False}

    os.kill(pid, signal.SIGTERM)
    if wait_gone(pid, 6):
        return {'ok': True, 'message': 'Kiosk-Modus wurde beendet. Der Desktop bleibt geöffnet.', 'kiosk_running': False}
    raise ValueError('Kiosk-Modus konnte nicht sauber beendet werden.')


def power_action(action):
    command = 'reboot' if action == 'reboot' else 'poweroff'
    try:
        result = subprocess.run(
            [SYSTEMCTL, '--no-block', command],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C'},
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        raise ValueError('Systemaktion konnte nicht gestartet werden.') from None
    if result.returncode != 0:
        raise ValueError('Systemaktion wurde vom Betriebssystem abgelehnt.')
    return {
        'ok': True,
        'message': 'Raspberry Pi wird neu gestartet.' if action == 'reboot' else 'Raspberry Pi wird heruntergefahren.',
    }


def handle(request):
    action = validate(request)
    if action == 'kiosk_exit':
        return stop_kiosk()
    return power_action(action)


def main():
    try:
        if len(sys.argv) != 1 or os.geteuid() != 0:
            raise ValueError('Systemhelper benötigt die separate Root-Freigabe.')
        data = sys.stdin.buffer.read(1025)
        if len(data) > 1024:
            raise ValueError('Anfrage zu groß.')
        result = handle(json.loads(data))
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except json.JSONDecodeError:
        print(json.dumps({'ok': False, 'message': 'Ungültige Anfrage.'}, ensure_ascii=False))
    except ValueError as error:
        print(json.dumps({'ok': False, 'message': str(error)}, ensure_ascii=False))
    except Exception:
        print(json.dumps({'ok': False, 'message': 'Systemsteuerung nicht verfügbar.'}, ensure_ascii=False))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
