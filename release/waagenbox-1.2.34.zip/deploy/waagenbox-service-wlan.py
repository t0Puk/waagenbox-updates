#!/usr/bin/python3
"""Separat freizugebender Root-Helper. Keine Installation beim App-Update."""
import json
import os
import re
import stat
import subprocess
import sys
import tempfile
import time

import hashlib
import ipaddress

CONFIG = '/etc/waagenbox/service-wlan/hostapd.conf'
UNITS = ['waagenbox-service-wlan-prepare.service', 'waagenbox-service-hostapd.service', 'waagenbox-service-dnsmasq.service']
DEADLINE = None


def validate(request):
    if not isinstance(request, dict) or request.get('action') not in ('status', 'enable', 'disable'):
        raise ValueError('Ungültige WLAN-Aktion.')
    if request['action'] == 'enable':
        ssid, password = request.get('ssid'), request.get('password')
        if not isinstance(ssid, str) or not 1 <= len(ssid.encode('utf-8')) <= 32 or re.search(r'[\x00-\x1f\x7f]', ssid):
            raise ValueError('SSID ungültig (1 bis 32 UTF-8-Bytes ohne Steuerzeichen).')
        if not isinstance(password, str) or not re.fullmatch(r'[\x20-\x7e]{8,63}', password):
            raise ValueError('Passwort ungültig (8 bis 63 druckbare ASCII-Zeichen).')


def run(args):
    # Kein Shell-Aufruf; Ausgaben und Fehler niemals mit Passwörtern zurückgeben.
    remaining = 12 if DEADLINE is None else min(12, DEADLINE - time.monotonic())
    if remaining <= 0:
        raise ValueError('Zeitlimit überschritten. WLAN-Status erneut prüfen.')
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=remaining,
                                env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C'})
    except subprocess.TimeoutExpired:
        raise ValueError('Zeitlimit der Systemaktion überschritten. Status erneut prüfen.') from None
    if result.returncode:
        raise ValueError('Service-WLAN-Systemaktion fehlgeschlagen. Status erneut prüfen.')
    return result.stdout.strip()


def systemctl(*args):
    return run(['/usr/bin/systemctl', *args])


def state(unit, property):
    return systemctl('show', unit, '--property=' + property, '--value')


def check_installation():
    parent = os.lstat('/etc/waagenbox')
    if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != 0 or parent.st_mode & 0o022:
        raise ValueError('Unsicheres Systemverzeichnis.')
    info = os.lstat(os.path.dirname(CONFIG))
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077:
        raise ValueError('Systeminstallation fehlt oder Konfigurationsverzeichnis ist nicht root-only.')
    if run(['/usr/bin/nmcli', '-g', 'GENERAL.STATE', 'device', 'show', 'wlan0']) != '10 (unmanaged)':
        raise ValueError('wlan0 muss separat freigegeben und von NetworkManager unverwaltet sein. Keine Verbindung wurde übernommen.')
    for unit in UNITS:
        if state(unit, 'LoadState') != 'loaded':
            raise ValueError('Service-WLAN-Systeminstallation fehlt. Installationsprüfung ausführen.')


def hostapd_config(ssid, password):
    psk = hashlib.pbkdf2_hmac('sha1', password.encode('ascii'), ssid.encode('utf-8'), 4096, 32).hex()
    return ('interface=wlan0\ndriver=nl80211\ncountry_code=DE\nieee80211d=1\n'
            'hw_mode=g\nchannel=6\nwmm_enabled=1\nauth_algs=1\nwpa=2\n'
            'wpa_key_mgmt=WPA-PSK\nrsn_pairwise=CCMP\n'
            + 'ssid2=' + ssid.encode('utf-8').hex() + '\nwpa_psk=' + psk + '\n')


def write_config(content):
    fd, path = tempfile.mkstemp(prefix='.hostapd-', dir=os.path.dirname(CONFIG))
    try:
        with os.fdopen(fd, 'w', encoding='ascii') as target:
            os.fchmod(target.fileno(), 0o600)
            target.write(content)
            target.flush()
            os.fsync(target.fileno())
        os.replace(path, CONFIG)
    finally:
        if os.path.exists(path):
            os.unlink(path)


def check_routes():
    network = ipaddress.ip_network('10.42.0.0/24')
    for route in json.loads(run(['/usr/sbin/ip', '-j', '-4', 'route', 'show', 'table', 'all'])):
        destination = route.get('dst', 'default')
        if destination != 'default' and route.get('dev') != 'wlan0' and network.overlaps(ipaddress.ip_network(destination, strict=False)):
            raise ValueError('10.42.0.0/24 überschneidet sich mit einer vorhandenen Route.')
    for iface in json.loads(run(['/usr/sbin/ip', '-j', 'address', 'show', 'dev', 'wlan0'])):
        for addr in iface.get('addr_info', []):
            if addr.get('family') == 'inet' and (addr.get('local'), addr.get('prefixlen')) != ('10.42.0.1', 24):
                raise ValueError('wlan0 ist bereits belegt. Keine Adresse wurde übernommen.')
    if 'Connected to ' in run(['/usr/sbin/iw', 'dev', 'wlan0', 'link']):
        raise ValueError('wlan0 ist bereits mit einem WLAN verbunden.')
    if 'type AP' in run(['/usr/sbin/iw', 'dev', 'wlan0', 'info']):
        raise ValueError('wlan0 wird bereits als Access Point verwendet.')


def stop():
    # Alle Schritte versuchen, auch wenn ein einzelner Dienst fehlschlägt.
    errors = []
    for unit in reversed(UNITS):
        for action in ('disable', 'stop'):
            try:
                systemctl(action, unit)
            except ValueError as error:
                errors.append(error)
    if errors:
        raise ValueError('Ausschalten unvollständig; Dienstzustand und Autostart prüfen.')


def handle(request):
    validate(request)
    action = request['action']
    if action == 'disable':
        stop()
        return 'Service-WLAN ist ausgeschaltet; Autostart deaktiviert.'
    check_installation()
    service_states = [state(unit, 'ActiveState') for unit in UNITS]
    active = [value == 'active' for value in service_states]
    enabled = [state(unit, 'UnitFileState') == 'enabled' for unit in UNITS]
    if action == 'status':
        return ('Service-WLAN ist gestört; Systemdienste prüfen.' if 'failed' in service_states else
                'Service-WLAN ist eingeschaltet.' if all(active) else
                'Service-WLAN ist ausgeschaltet.' if not any(active) else 'Service-WLAN ist nur teilweise aktiv.') + (
                ' Autostart aktiviert.' if all(enabled) else ' Autostart deaktiviert.' if not any(enabled) else ' Autostart unvollständig.')
    if any(active):
        raise ValueError('Service-WLAN zuerst ausschalten, bevor SSID oder Passwort geändert werden.')
    check_routes()
    write_config(hostapd_config(request['ssid'], request['password']))
    check_installation()
    check_routes()
    try:
        systemctl('enable', *UNITS)
        systemctl('start', *UNITS)
        if not all(state(unit, 'ActiveState') == 'active' for unit in UNITS):
            raise ValueError('Service-WLAN nicht vollständig gestartet.')
    except Exception:
        global DEADLINE
        DEADLINE = time.monotonic() + 20
        stop()
        raise
    return 'Service-WLAN ist eingeschaltet. Autostart aktiviert. Adresse: http://10.42.0.1'


def main():
    global DEADLINE
    DEADLINE = time.monotonic() + 35
    try:
        if len(sys.argv) != 1 or os.geteuid() != 0:
            raise ValueError('Service-WLAN-Helper benötigt eine separate Freigabe.')
        import fcntl
        lock = os.open('/run/waagenbox-service-wlan.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(lock, 'w') as guard:
            fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
            data = sys.stdin.buffer.read(4097)
            if len(data) > 4096:
                raise ValueError('Anfrage zu groß.')
            message = handle(json.loads(data))
        print(json.dumps({'ok': True, 'message': message}))
    except ValueError as error:
        print(json.dumps({'ok': False, 'message': str(error) if not isinstance(error, json.JSONDecodeError) else 'Ungültige Anfrage.'}))
    except Exception:
        print(json.dumps({'ok': False, 'message': 'Service-WLAN nicht verfügbar. Installation, Berechtigungen und Systemdienste prüfen.'}))


if __name__ == '__main__':
    main()
