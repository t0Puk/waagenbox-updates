<?php
declare(strict_types=1);

if (!function_exists('db')) {
    require_once __DIR__ . '/functions.php';
}

/**
 * Resolve the automatic default assignment for one remote.
 *
 * This intentionally mirrors the established mobile remote behaviour:
 * - no assignment => null
 * - one active assignment => use it
 * - multiple active assignments => only an explicit default is accepted
 */
function rfRemoteAssignment(PDO $pdo, string $table, string $column, int $remoteId, int $ownerId): ?int {
    $allowed = [
        'remote_fields' => 'field_id',
        'remote_customers' => 'customer_id',
        'remote_products' => 'product_id',
    ];
    if (!isset($allowed[$table]) || $allowed[$table] !== $column) {
        throw new InvalidArgumentException('Ungültige Fernbedienungszuordnung.');
    }

    $q = $pdo->prepare(
        "SELECT {$column} FROM {$table}
         WHERE owner_user_id=? AND remote_id=? AND active=1
         ORDER BY is_default DESC, {$column}
         LIMIT 1"
    );
    $q->execute([$ownerId, $remoteId]);
    $first = $q->fetchColumn();
    if ($first === false) {
        return null;
    }

    $count = $pdo->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE owner_user_id=? AND remote_id=? AND active=1"
    );
    $count->execute([$ownerId, $remoteId]);
    if ((int)$count->fetchColumn() <= 1) {
        return (int)$first;
    }

    $default = $pdo->prepare(
        "SELECT {$column} FROM {$table}
         WHERE owner_user_id=? AND remote_id=? AND active=1 AND is_default=1
         LIMIT 1"
    );
    $default->execute([$ownerId, $remoteId]);
    $value = $default->fetchColumn();

    return $value === false ? null : (int)$value;
}

function rfRemoteUseOwnerContext(PDO $pdo, int $ownerId): void {
    if ($ownerId <= 0) {
        throw new RuntimeException('Ungültiger Besitzerkontext.');
    }

    global $mobileContextUserId;
    $mobileContextUserId = $ownerId;
    $pdo->exec('SET @ajp_user_id = ' . $ownerId);
}

function rfRemotePendingExists(PDO $pdo, int $ownerId): bool {
    $s = $pdo->prepare('SELECT 1 FROM weighing_state WHERE owner_user_id=? AND id=1 LIMIT 1');
    $s->execute([$ownerId]);
    return $s->fetchColumn() !== false;
}

function rfRemoteProcessingActiveForOwner(PDO $pdo, int $ownerId): bool {
    $s = $pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
    $s->execute([$ownerId, 'scale_processing_until']);
    $value = $s->fetchColumn();
    return $value !== false && (int)$value > time();
}

/**
 * Apply a validated RF weighing plan, or return it without side effects.
 *
 * @param array{owner_id:int,remote_id:int,vehicle_id:int,first_weight:float,field_id:?int,customer_id:?int,product_id:?int} $plan
 * @return array{ok:bool,status:string,message:string,remote_id:int,vehicle_id:int,field_id:?int,customer_id:?int,product_id:?int}
 */
function rfRemoteExecutePlan(PDO $pdo, array $plan, bool $dryRun = false): array {
    $result = [
        'ok'=>true,
        'status'=>$dryRun ? 'dry_run' : 'started',
        'message'=>$dryRun
            ? 'Dry-Run erfolgreich: Funkwiegung würde gestartet.'
            : 'Funkwiegung gestartet.',
        'remote_id'=>(int)$plan['remote_id'],
        'vehicle_id'=>(int)$plan['vehicle_id'],
        'field_id'=>$plan['field_id'] === null ? null : (int)$plan['field_id'],
        'customer_id'=>$plan['customer_id'] === null ? null : (int)$plan['customer_id'],
        'product_id'=>$plan['product_id'] === null ? null : (int)$plan['product_id'],
    ];

    if ($dryRun) {
        return $result;
    }

    rfRemoteUseOwnerContext($pdo, (int)$plan['owner_id']);
    setPendingWeighing(
        (float)$plan['first_weight'],
        (int)$plan['vehicle_id'],
        (int)$plan['remote_id'],
        'radio',
        $plan['field_id'],
        $plan['customer_id'],
        $plan['product_id']
    );

    return $result;
}

/**
 * Validate and optionally start a weighing from a decoded numeric 433 MHz code.
 *
 * Dry-run performs the complete lookup and readiness validation, but it does
 * not set application owner context, write weighing_state, or start the scale.
 *
 * @return array{ok:bool,status:string,message:string,remote_id?:int,vehicle_id?:int,field_id?:?int,customer_id?:?int,product_id?:?int}
 */
function triggerRfRemoteCode(string $code, bool $dryRun = false): array {
    $code = trim($code);
    if ($code === '' || !ctype_digit($code)) {
        return ['ok'=>false, 'status'=>'invalid_code', 'message'=>'Ungültiger Funkcode.'];
    }

    $numericCode = (int)$code;
    if ($numericCode < 0 || $numericCode > 0xFFFFFF) {
        return ['ok'=>false, 'status'=>'invalid_code', 'message'=>'Ungültiger 24-Bit-Funkcode.'];
    }

    $pdo = db();
    $s = $pdo->prepare(
        'SELECT r.id,r.owner_user_id,r.code,r.active,r.vehicle_id,
                v.first_weight,v.active AS vehicle_active
         FROM remotes r
         LEFT JOIN vehicles v
           ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id
         WHERE r.code=?
         LIMIT 2'
    );
    $s->execute([(string)$numericCode]);
    $matches = $s->fetchAll();

    if (count($matches) === 0) {
        return ['ok'=>false, 'status'=>'unknown', 'message'=>'Funkcode ist keiner Fernbedienung zugeordnet.'];
    }
    if (count($matches) > 1) {
        return ['ok'=>false, 'status'=>'ambiguous', 'message'=>'Funkcode ist nicht eindeutig zugeordnet.'];
    }

    $remote = $matches[0];
    if ((int)$remote['active'] !== 1 || (int)($remote['vehicle_active'] ?? 0) !== 1) {
        return ['ok'=>false, 'status'=>'inactive', 'message'=>'Fernbedienung oder Fahrzeug ist nicht aktiv.'];
    }
    if ((int)($remote['vehicle_id'] ?? 0) <= 0) {
        return ['ok'=>false, 'status'=>'no_vehicle', 'message'=>'Der Fernbedienung ist kein Fahrzeug zugeordnet.'];
    }
    if ((float)($remote['first_weight'] ?? 0) <= 0) {
        return ['ok'=>false, 'status'=>'no_first_weight', 'message'=>'Für das Fahrzeug ist noch kein Erstgewicht hinterlegt.'];
    }

    $ownerId = (int)$remote['owner_user_id'];
    $remoteId = (int)$remote['id'];

    // Read-only readiness checks: dry-run must not change session/DB context.
    if (rfRemotePendingExists($pdo, $ownerId)) {
        return ['ok'=>false, 'status'=>'busy', 'message'=>'Es läuft bereits eine Wiegung.'];
    }
    if (rfRemoteProcessingActiveForOwner($pdo, $ownerId)) {
        return ['ok'=>false, 'status'=>'processing', 'message'=>'Die vorherige Wiegung wird noch verarbeitet.'];
    }

    $fieldId = rfRemoteAssignment($pdo, 'remote_fields', 'field_id', $remoteId, $ownerId);
    $customerId = rfRemoteAssignment($pdo, 'remote_customers', 'customer_id', $remoteId, $ownerId);
    $productId = rfRemoteAssignment($pdo, 'remote_products', 'product_id', $remoteId, $ownerId);

    return rfRemoteExecutePlan($pdo, [
        'owner_id'=>$ownerId,
        'remote_id'=>$remoteId,
        'vehicle_id'=>(int)$remote['vehicle_id'],
        'first_weight'=>(float)$remote['first_weight'],
        'field_id'=>$fieldId,
        'customer_id'=>$customerId,
        'product_id'=>$productId,
    ], $dryRun);
}
