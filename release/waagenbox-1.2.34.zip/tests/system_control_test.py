"""Portable static/unit tests for 1.2.34 system controls."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('system_control', ROOT / 'deploy/waagenbox-system-control.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SystemControlTest(unittest.TestCase):
    def test_action_allowlist(self):
        for action in ('kiosk_exit', 'reboot', 'poweroff'):
            self.assertEqual(module.validate({'action': action}), action)
        for action in ('status', 'shell', 'restart apache2', '', None):
            with self.assertRaises(ValueError):
                module.validate({'action': action})
        with self.assertRaises(ValueError):
            module.validate({'action': 'reboot', 'command': 'id'})

    def test_helper_has_no_shell_execution(self):
        text = (ROOT / 'deploy/waagenbox-system-control.py').read_text()
        self.assertIn("[SYSTEMCTL, '--no-block', command]", text)
        self.assertNotIn('shell=True', text)
        self.assertNotIn('os.system(', text)
        self.assertNotIn('subprocess.Popen(', text)

    def test_installer_uses_separate_exact_sudo_rule(self):
        text = (ROOT / 'install_system_controls.py').read_text()
        self.assertIn('/etc/sudoers.d/waagenbox-system-control', text)
        self.assertIn('NOPASSWD: /usr/local/sbin/waagenbox-system-control ""', text)
        self.assertIn("'/usr/sbin/visudo', '-cf'", text)
        self.assertNotIn('/var/www/waage', text)

    def test_web_bridge_uses_fixed_helper(self):
        text = (ROOT / 'system_control_support.php').read_text()
        self.assertIn("$helper = '/usr/local/sbin/waagenbox-system-control';", text)
        self.assertIn("['/usr/bin/sudo', '-n', $helper]", text)
        self.assertNotIn('shell_exec(', text)
        self.assertNotIn('exec(', text)
        self.assertNotIn('system(', text)

    def test_status_is_read_only_without_privileged_helper(self):
        support = (ROOT / 'system_control_support.php').read_text()
        page = (ROOT / 'system.php').read_text()
        self.assertIn('function systemControlStatus(): array', support)
        self.assertIn("$status = systemControlStatus();", page)
        self.assertNotIn("systemControlRequest('status')", support)
        self.assertNotIn("systemControlRequest('status')", page)
        self.assertNotIn("'status','kiosk_exit'", support)

    def test_dashboard_kiosk_exit_is_local_and_csrf_protected(self):
        text = (ROOT / 'index.php').read_text()
        self.assertIn('$localDashboard = isLocalAccess();', text)
        self.assertIn('requireCsrfToken();', text)
        self.assertIn("systemControlRequest('kiosk_exit')", text)
        self.assertIn('Kiosk beenden', text)
        self.assertIn("if (!$localDashboard)", text)

    def test_legacy_kiosk_transition_is_exact_and_never_group_kills(self):
        text = (ROOT / 'deploy/waagenbox-system-control.py').read_text()
        self.assertIn('matching_kiosk_wrappers', text)
        self.assertIn('legacy_chromium_child', text)
        self.assertIn("args[1] == KIOSK_SCRIPT", text)
        self.assertIn("'--kiosk' not in args", text)
        self.assertIn("KIOSK_URL not in args", text)
        self.assertIn("'--user-data-dir=' + KIOSK_PROFILE", text)
        self.assertNotIn("subprocess.run(['pgrep'", text)
        self.assertNotIn("subprocess.check_output(['pgrep'", text)
        self.assertNotIn('os.killpg(', text)
        self.assertNotIn('os.getpgid(', text)

    def test_chromium_rewritten_single_string_cmdline_is_normalized(self):
        raw = (
            b'/usr/lib/chromium/chromium --kiosk '
            b'--user-data-dir=/home/pi/.local/share/waagenbox-kiosk '
            b'http://127.0.0.1/\0'
        )
        args = module.decode_cmdline(raw)
        self.assertEqual(args[0], '/usr/lib/chromium/chromium')
        self.assertIn('--kiosk', args)
        self.assertIn('--user-data-dir=/home/pi/.local/share/waagenbox-kiosk', args)
        self.assertIn('http://127.0.0.1/', args)

    def test_normal_nul_separated_cmdline_is_preserved(self):
        raw = b'/bin/sh\0/usr/local/bin/waagenbox-kiosk\0'
        self.assertEqual(module.decode_cmdline(raw), ['/bin/sh', '/usr/local/bin/waagenbox-kiosk'])


if __name__ == '__main__':
    unittest.main()
