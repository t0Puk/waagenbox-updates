<?php
// Statischer CLI-Test: keine Anwendung, Datenbank oder Produktivpfade laden.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Nur CLI.'); }
$root = dirname(__DIR__);
require $root.'/auth.php';
$protected = [
    'api/update_install.php',
    'api/update_rollback.php',
    'api/update_check.php',
    'api/update_ignore.php',
    'api/update_snooze.php',
];
$passed = 0;
foreach ($protected as $relative) {
    $source = file_get_contents($root.'/'.$relative);
    if ($source === false || !preg_match('/requireAdmin\s*\(\s*\)\s*;/', $source)) {
        throw new RuntimeException($relative.' muss requireAdmin() verwenden.');
    }
    if ($relative !== 'api/update_check.php' && !preg_match('/requireCsrfToken\s*\(\s*\)\s*;/', $source)) {
        throw new RuntimeException($relative.' muss requireCsrfToken() verwenden.');
    }
    $passed++;
    echo "PASS {$relative} access control\n";
}
$_SERVER['REMOTE_ADDR'] = '10.0.0.5';
$_SERVER['HTTP_HOST'] = 'localhost';
if (isLocalAccess()) throw new RuntimeException('HTTP_HOST=localhost darf keinen lokalen Zugriff vortäuschen.');
echo "PASS HTTP_HOST localhost does not bypass local check\n";
foreach (['127.0.0.1', '::1'] as $remote) {
    $_SERVER['REMOTE_ADDR'] = $remote;
    if (!isLocalAccess()) throw new RuntimeException($remote.' muss als lokaler Zugriff erkannt werden.');
    echo "PASS REMOTE_ADDR {$remote} local check\n";
}
if (file_exists($root.'/update_install.php')) {
    throw new RuntimeException('Der veraltete Root-Installer darf nicht mehr vorhanden sein.');
}
$auth = file_get_contents($root.'/auth.php');
if ($auth === false || !preg_match('/random_bytes\s*\(\s*32\s*\)/', $auth) || !preg_match('/hash_equals\s*\(/', $auth)) {
    throw new RuntimeException('CSRF-Helfer muss random_bytes() und hash_equals() verwenden.');
}
echo "PASS auth.php CSRF helper uses random_bytes/hash_equals\n";
$_SESSION['waage_csrf_token'] = 'expected-token';
foreach (['missing'=>'', 'wrong'=>'wrong-token', 'valid'=>'expected-token'] as $case=>$token) {
    if (($case === 'valid') !== isValidCsrfToken($token)) throw new RuntimeException("{$case} CSRF-Token Prüfung fehlgeschlagen.");
    echo "PASS {$case} CSRF token\n";
}
echo 'RESULT '.($passed + 1)." access-control/CSRF checks passed\n";
