"""Keine echten Systemaufrufe oder Systemdateien: ausschließlich Attrappen."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

spec = importlib.util.spec_from_file_location('service_wlan', Path(__file__).resolve().parents[1] / 'deploy/waagenbox-service-wlan.py')
wlan = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wlan)


class ServiceWlanTest(unittest.TestCase):
    def test_validation(self):
        for size in (8, 63):
            wlan.validate(dict(action='enable', ssid='Waagenbox-Service', password='x' * size))
        for value in ('x' * 7, 'x' * 64, '1234567\n', 'pässwort'):
            with self.assertRaises(ValueError):
                wlan.validate(dict(action='enable', ssid='Test', password=value))
        for value in ('', 'x' * 33, 'ä' * 17, 'bad\nssid'):
            with self.assertRaises(ValueError):
                wlan.validate(dict(action='enable', ssid=value, password='12345678'))
        with self.assertRaises(ValueError):
            wlan.validate(dict(action='shell'))

    def test_config(self):
        text = wlan.hostapd_config('IEEE', 'password')
        self.assertIn('wpa_psk=f42c6fc52df0ebef9ebb4b90b38a5f902e83fe1b135a70e23aed762e9710a12e', text)
        self.assertNotIn('password', text)
        self.assertNotIn('wpa_passphrase', text)
        self.assertIn('ssid2=413b22c39f', wlan.hostapd_config('A;"ß', ' a\\;#123 '))
        for setting in ('interface=wlan0', 'driver=nl80211', 'hw_mode=g', 'channel=6', 'country_code=DE', 'wpa=2', 'wpa_key_mgmt=WPA-PSK', 'rsn_pairwise=CCMP'):
            self.assertIn(setting + '\n', text)

    def scenario(self, action, active=False, enabled=False, failure=False):
        states = {unit: {'ActiveState': 'active' if active else 'inactive', 'UnitFileState': 'enabled' if enabled else 'disabled'} for unit in wlan.UNITS}
        calls = []
        def ctl(action, *units):
            calls.append((action, *units))
            if action == 'start' and failure:
                states[units[0]]['ActiveState'] = 'active'
                raise ValueError('synthetic failure')
            for unit in units:
                prop, value = {'enable': ('UnitFileState', 'enabled'), 'disable': ('UnitFileState', 'disabled'), 'start': ('ActiveState', 'active'), 'stop': ('ActiveState', 'inactive')}[action]
                states[unit][prop] = value
        with patch.object(wlan, 'check_installation'), patch.object(wlan, 'check_routes'), patch.object(wlan, 'write_config') as write, patch.object(wlan, 'systemctl', side_effect=ctl), patch.object(wlan, 'state', side_effect=lambda unit, prop: states[unit][prop]):
            try:
                result = wlan.handle(dict(action=action, ssid='Test', password='synthetic-test'))
            except ValueError as error:
                result = str(error)
        return result, calls, states, write

    def test_enable_persistence(self):
        result, calls, states, write = self.scenario('enable')
        self.assertIn('eingeschaltet', result)
        self.assertEqual(calls, [('enable', *wlan.UNITS), ('start', *wlan.UNITS)])
        self.assertTrue(all(s['UnitFileState'] == 'enabled' and s['ActiveState'] == 'active' for s in states.values()))
        self.assertNotIn('synthetic-test', write.call_args.args[0])

    def test_disable_persistence_and_order(self):
        result, calls, states, _ = self.scenario('disable', active=True, enabled=True)
        self.assertIn('ausgeschaltet', result)
        self.assertEqual(calls, [(action, unit) for unit in reversed(wlan.UNITS) for action in ('disable', 'stop')])
        self.assertTrue(all(s['UnitFileState'] == 'disabled' and s['ActiveState'] == 'inactive' for s in states.values()))

    def test_start_failure_cleanup(self):
        result, calls, states, _ = self.scenario('enable', failure=True)
        self.assertIn('failure', result)
        self.assertTrue(all(s['UnitFileState'] == 'disabled' and s['ActiveState'] == 'inactive' for s in states.values()))

    def test_active_ap_not_overwritten(self):
        _, calls, _, write = self.scenario('enable', active=True, enabled=True)
        self.assertEqual(calls, [])
        write.assert_not_called()

    def test_status_read_only(self):
        for enabled, label in ((True, 'aktiviert'), (False, 'deaktiviert')):
            result, calls, _, write = self.scenario('status', enabled=enabled)
            self.assertIn('Autostart ' + label, result)
            self.assertEqual(calls, [])
            write.assert_not_called()

    def test_managed_interface_blocked(self):
        with patch.object(wlan.os, 'lstat', return_value=SimpleNamespace(st_mode=0o40700, st_uid=0)), patch.object(wlan, 'run', return_value='100 (connected)'), patch.object(wlan, 'systemctl') as ctl:
            with self.assertRaises(ValueError):
                wlan.check_installation()
            ctl.assert_not_called()

    def test_root_only_required(self):
        for mode, uid in ((0o40777, 0), (0o40700, 33), (0o120777, 0)):
            with patch.object(wlan.os, 'lstat', return_value=SimpleNamespace(st_mode=mode, st_uid=uid)):
                with self.assertRaises(ValueError):
                    wlan.check_installation()

    def test_routes_addresses_and_foreign_wifi(self):
        cases = [('[{"dst":"10.42.0.0/16","dev":"eth0"}]', '[]', '', '', True), ('[{"dst":"10.42.0.0/24","dev":"wlan0"}]', '[]', '', '', False), ('[]', '[{"addr_info":[{"family":"inet","local":"192.168.1.2","prefixlen":24}]}]', '', '', True), ('[]', '[]', 'Connected to synthetic', '', True), ('[]', '[]', '', 'type AP', True)]
        for routes, addresses, link, info, fails in cases:
            with patch.object(wlan, 'run', side_effect=[routes, addresses, link, info]):
                if fails:
                    with self.assertRaises(ValueError): wlan.check_routes()
                else: wlan.check_routes()

    def test_atomic_write(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / 'hostapd.conf'
            target.write_text('synthetic old')
            with patch.object(wlan, 'CONFIG', str(target)), patch.object(wlan.os, 'fchmod', create=True) as chmod:
                wlan.write_config('synthetic new')
            self.assertEqual(target.read_text(), 'synthetic new')
            self.assertEqual(list(Path(directory).iterdir()), [target])
            self.assertEqual(chmod.call_args.args[1], 0o600)

    def test_stop_continues_after_failure(self):
        with patch.object(wlan, 'systemctl', side_effect=[ValueError('test'), '', '', '', '', '']) as ctl:
            with self.assertRaises(ValueError): wlan.stop()
            self.assertEqual(ctl.call_count, 6)

    def test_units_and_dhcp(self):
        root = Path(__file__).resolve().parents[1]
        units = [(root / 'systemd' / unit).read_text() for unit in wlan.UNITS]
        self.assertIn('ExecStart=/usr/sbin/rfkill unblock wlan', units[0])
        self.assertNotIn('/usr/bin/rfkill', ''.join(units))
        self.assertIn('/usr/sbin/ip address replace 10.42.0.1/24 dev wlan0', units[0])
        self.assertIn('ExecStop=-/usr/sbin/ip address del 10.42.0.1/24 dev wlan0', units[0])
        for unit in units:
            self.assertIn('WantedBy=multi-user.target', unit)
            self.assertNotIn('eth0', unit)
        for unit in units[1:]: self.assertIn('Requires=' + wlan.UNITS[0], unit)
        self.assertIn('--conf-file=/etc/waagenbox/service-wlan/dnsmasq.conf', units[2])
        conf = (root / 'deploy/service-wlan-dnsmasq.conf').read_text()
        for line in ('port=0', 'interface=wlan0', 'bind-interfaces', 'dhcp-option=3', 'dhcp-option=6', 'dhcp-range=10.42.0.20,10.42.0.100,255.255.255.0,12h'):
            self.assertIn(line + '\n', conf)
        self.assertNotIn('conf-dir', conf)


if __name__ == '__main__':
    unittest.main()
