<?php
declare(strict_types=1);

$testRoot = '/tmp/waagenbox_deploy_bridge_test_'.getmypid();
putenv('WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE='.$testRoot);
putenv('WAAGEBOX_DEPLOY_CLIENT_TEST_HELPER='.$testRoot.'/helper');

require dirname(__DIR__).'/deploy/deploy_client.php';

$checks = 0;

function bridgeOk(bool $condition, string $message): void
{
    global $checks;

    if (!$condition) {
        fwrite(STDERR, "FAIL {$message}\n");
        exit(1);
    }

    $checks++;
    echo "PASS {$message}\n";
}

$root = getenv('WAAGEBOX_DEPLOY_CLIENT_TEST_STORAGE');

bridgeOk(
    is_string($root) &&
    str_starts_with(
        $root,
        '/tmp/waagenbox_deploy_bridge_test_'
    ),
    'test storage restricted to temporary bridge root'
);

bridgeOk(
    waagenboxDeployStorageRoot() === rtrim($root, '/'),
    'test storage override accepted'
);

$command = waagenboxDeployHelperCommand();

bridgeOk(
    count($command) === 3 &&
    $command[0] === '/usr/bin/sudo' &&
    $command[1] === '-n' &&
    str_starts_with(
        $command[2],
        '/tmp/waagenbox_deploy_bridge_test_'
    ),
    'test helper override uses sudo -n with exact test wrapper'
);

$badIds = [
    '',
    '../snapshot',
    '../../etc/passwd',
    'abc',
    str_repeat('g', 32),
];

foreach ($badIds as $bad) {
    try {
        waagenboxDeployRestore($bad);
        bridgeOk(false, 'invalid snapshot rejected: '.$bad);
    } catch (RuntimeException $e) {
        bridgeOk(
            str_contains(
                $e->getMessage(),
                'Ungültige Deployment-Snapshot-ID'
            ),
            'invalid snapshot rejected: '.$bad
        );
    }
}

echo "RESULT {$checks} deploy-bridge static checks passed\n";
