"""Static regression tests for RF-only demo auto-completion."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DemoAutoCompleteScopeTest(unittest.TestCase):
    def test_server_rejects_non_radio_pending_weighings(self):
        text = (ROOT / 'api/demo_auto_complete.php').read_text(encoding='utf-8')
        self.assertIn("$triggerType = (string)($pending['trigger_type'] ?? 'manual');", text)
        self.assertIn("if ($triggerType !== 'radio')", text)
        self.assertIn("'status'=>'ignored_non_radio'", text)
        self.assertIn('completePendingWeighing($weight)', text)
        self.assertLess(text.index("if ($triggerType !== 'radio')"), text.index('completePendingWeighing($weight)'))

    def test_client_only_arms_for_radio_pending_weighings(self):
        text = (ROOT / 'assets/demo_auto_complete.js').read_text(encoding='utf-8')
        self.assertIn("pending.trigger_type!=='radio'", text)
        self.assertIn("fetch('api/status.php'", text)
        self.assertLess(text.index("pending.trigger_type!=='radio'"), text.index("fetch('api/status.php'"))

    def test_pending_api_exposes_trigger_type(self):
        text = (ROOT / 'api/pending.php').read_text(encoding='utf-8')
        self.assertIn("'trigger_type'=>$p?(string)($p['trigger_type']??'manual'):null", text)


if __name__ == '__main__':
    unittest.main()
