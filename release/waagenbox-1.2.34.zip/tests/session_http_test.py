"""Isolierter PHP-HTTP-Test: synthetischer App-Bootstrap, keine config.php/DB/Hardware."""
import http.cookiejar
import gzip
import json
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
PHP = sys.argv[1] if len(sys.argv) > 1 else 'php'


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


with tempfile.TemporaryDirectory(prefix='waagenbox_http_test_') as temp:
    fixture = Path(temp)
    (fixture / 'api').mkdir()
    (fixture / 'hardware').mkdir()
    (fixture / 'sessions').mkdir()
    (fixture / 'backups').mkdir()
    for name in ('auth.php', 'version.php', 'login.php', 'logout.php', 'api/session_activity.php',
                 'api/dini_test.php', 'api/backup_latest.php', 'backup_download.php', 'hardware/dini_diagnostics.php'):
        shutil.copyfile(ROOT / name, fixture / name)
    # Nur in der Kopie: festes Backup-Verzeichnis auf synthetische Fixtures setzen.
    endpoint = fixture / 'api/backup_latest.php'
    source = endpoint.read_text(encoding='utf-8')
    assert source.count("'/var/backups/waagenbox'") == 1
    endpoint.write_text(source.replace("'/var/backups/waagenbox'", "'" + (fixture / 'backups').as_posix() + "'"), encoding='utf-8')
    backup_name = 'waagenbox_2026-09-14_19-30-00_abcdef123456.sql.gz'
    (fixture / 'backups' / backup_name).write_bytes(gzip.compress(b'-- synthetic SQL'))
    (fixture / 'functions.php').write_text("""<?php
require_once __DIR__.'/version.php';
require_once __DIR__.'/auth.php';
function appSetting($key, $default='') { return $key === 'access_password_hash' ? password_hash('synthetic-password', PASSWORD_DEFAULT) : $default; }
function redirect($url): never { header('Location: '.$url); exit; }
function h($value) { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function db() { throw new RuntimeException('Test must never use a database'); }
function dini() { if (!empty($_GET['offline'])) throw new RuntimeException('synthetic offline'); return null; }
""", encoding='utf-8')
    (fixture / 'index.php').write_text("<?php require __DIR__.'/functions.php'; requireLogin(); echo 'protected';")
    (fixture / 'api/status.php').write_text("<?php require __DIR__.'/../functions.php'; requireLogin(); echo 'status';")
    (fixture / 'fixture.php').write_text("""<?php
require __DIR__.'/functions.php';
if (isset($_GET['age'])) $_SESSION['waage_last_activity']=time()-(int)$_GET['age'];
if (isset($_GET['user'])) $_SESSION['user_id']=123;
csrfToken();
header('Content-Type: application/json');
echo json_encode($_SESSION);
""")
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    process = subprocess.Popen([PHP, '-n', '-d', 'session.save_path=' + str(fixture / 'sessions'),
                                '-S', f'127.0.0.1:{port}', '-t', str(fixture)],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    jar = http.cookiejar.CookieJar()
    client = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect())
    url = f'http://127.0.0.1:{port}/'

    def request(path, data=None, external=True, csrf=None, binary=False):
        headers = {'X-Forwarded-For': '203.0.113.20'} if external else {}
        if csrf is not None:
            headers['X-CSRF-Token'] = csrf
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        try:
            response = client.open(urllib.request.Request(url + path, data=body, headers=headers), timeout=3)
        except urllib.error.HTTPError as error:
            response = error
        content = response.read()
        return response.code, response.headers, content if binary else content.decode()

    def state():
        return json.loads(request('fixture.php')[2])

    checks = 0

    def check(condition, message):
        global checks
        if not condition:
            raise AssertionError(message)
        checks += 1
        print('PASS ' + message)

    try:
        for attempt in range(50):
            try:
                request('fixture.php')
                break
            except OSError:
                time.sleep(0.05)
        check(request('index.php')[0] == 302, 'External session requires login')
        old_id = next(c.value for c in jar if c.name == 'PHPSESSID')
        check(request('login.php', {'password': 'synthetic-password'})[0] == 302, 'Login succeeds')
        new_id = next(c.value for c in jar if c.name == 'PHPSESSID')
        check(old_id != new_id, 'Login regenerates session ID')
        check(request('index.php')[0] == 200, 'Authenticated page accessible')
        status, headers, data = request('api/backup_latest.php?file=../../etc/passwd', binary=True)
        check(status == 200 and gzip.decompress(data) == b'-- synthetic SQL', 'Authenticated backup downloads only fixed fixture directory')
        check(headers['Content-Type'] == 'application/gzip' and headers['Content-Disposition'] == 'attachment; filename="' + backup_name + '"' and int(headers['Content-Length']) == len(data) and headers['Cache-Control'] == 'no-store', 'Backup download headers and length correct')
        (fixture / 'backups' / backup_name).unlink()
        check(request('api/backup_latest.php')[0] == 404, 'Missing backup returns a clear 404')
        check(request('api/dini_test.php?action=first')[0] == 400, 'Dini first rejected before hardware access')
        check(json.loads(request('api/dini_test.php?action=weight')[2])['state'] == 'disabled', 'Disabled Dini is a clean diagnostic state')
        check(request('api/dini_test.php?action=weight&offline=1')[0] == 502, 'Offline Dini handled without PHP failure')
        request('fixture.php?age=100')
        before = state()['waage_last_activity']
        check(request('api/status.php')[0] == 200 and state()['waage_last_activity'] == before, 'Polling does not extend session')
        csrf = state()['waage_csrf_token']
        check(request('api/session_activity.php', {'active': '0'}, csrf=csrf)[0] == 204 and state()['waage_last_activity'] == before, 'Idle heartbeat does not extend session')
        check(request('api/session_activity.php', {'active': '1'}, csrf='invalid')[0] == 403, 'Activity requires CSRF')
        check(request('api/session_activity.php', {'active': '1'}, csrf=csrf)[0] == 204 and state()['waage_last_activity'] > before, 'User activity extends session')
        request('fixture.php?age=900&user=1')
        check(request('api/session_activity.php', {'active': '1'}, csrf=csrf)[0] == 401, 'Expired session cannot be revived by activity')
        check('user_id' not in state(), 'Expired identity cleared')
        check(request('index.php')[0] == 302, 'Timeout requires a new login')
        check(request('api/dini_test.php')[0] == 302, 'Dini anonymous access denied')
        check(request('api/backup_latest.php?file=../../etc/passwd')[0] == 302, 'Backup anonymous access denied before file access')
        check(request('index.php', external=False)[0] == 200, 'Direct localhost stays passwordless')
        check(request('logout.php', external=False)[0] == 302, 'Local logout causes no PHP error')
        check(request('index.php', external=False)[0] == 200, 'Local page works after logout')
        print(f'RESULT {checks} HTTP checks passed')
    finally:
        process.terminate()
        process.wait(timeout=5)
