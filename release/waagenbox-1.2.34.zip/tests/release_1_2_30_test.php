<?php
// CLI, synthetische Fixtures. Keine config.php, Datenbank oder Hardware laden.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$root = dirname(__DIR__);
require $root.'/backup_download.php';
require $root.'/service_wlan_support.php';
require $root.'/hardware/dini_diagnostics.php';
require $root.'/hardware/Dini3590.php';
require $root.'/auth.php';
$checks = 0;
function ok(bool $condition, string $message): void {
    global $checks;
    if (!$condition) throw new RuntimeException('FAIL '.$message);
    $checks++;
    echo "PASS $message\n";
}
function rejected(callable $call, string $message): void {
    try { $call(); } catch (Throwable $e) { ok(true, $message); return; }
    ok(false, $message);
}
// Ausgewählte unveränderte Funktionen aus functions.php, ohne dessen DB-Bootstrap.
function loadFunction(string $name): void {
    global $root;
    $tokens = token_get_all(file_get_contents($root.'/functions.php'));
    for ($i=0; $i<count($tokens); $i++) {
        if (!is_array($tokens[$i]) || $tokens[$i][0] !== T_FUNCTION) continue;
        $start = $i;
        while (isset($tokens[++$i]) && is_array($tokens[$i]) && $tokens[$i][0] === T_WHITESPACE) {}
        if (!is_array($tokens[$i]) || $tokens[$i][1] !== $name) continue;
        $source = ''; $depth = 0; $body = false;
        for ($j=$start; $j<count($tokens); $j++) {
            $t = $tokens[$j]; $source .= is_array($t) ? $t[1] : $t;
            if ($t === '{') { $depth++; $body = true; }
            if ($t === '}' && --$depth === 0 && $body) { eval($source); return; }
        }
    }
    throw new RuntimeException('Funktion fehlt: '.$name);
}
loadFunction('mobileRemoteBaseUrl');
loadFunction('mobileRemoteUrl');
$_SERVER['HTTP_HOST'] = 'attacker.invalid';
$_SERVER['SCRIPT_NAME'] = '/local/subdir/remote_qr.php';
ok(mobileRemoteUrl('TESTTOKEN') === 'https://waage-ajp.de/mobile_remote.php?t=TESTTOKEN', 'QR URL unabhängig von Host und Installationspfad');
ok(str_ends_with(mobileRemoteUrl('a&b'), 't=a%26b'), 'Token URL-encoding');
ok(manualBackupFilename(new DateTimeImmutable('2026-09-14 19:30:00')) === 'AJP-Waagenbox_v'.APP_VERSION.'_2026-09-14_19-30-00.sql.gz', 'Backupname mit zentraler Version und sicherem Zeitstempel');

$_SERVER['REMOTE_ADDR'] = '203.0.113.5';
$now = time();
foreach ([899=>true, 900=>false, 901=>false] as $idle=>$valid) {
    $_SESSION = ['waage_access_authenticated'=>1, 'user_id'=>42, 'waage_last_activity'=>$now-$idle, 'waage_csrf_token'=>'synthetic'];
    enforceSessionIdleTimeout($now);
    ok(!empty($_SESSION['waage_access_authenticated']) === $valid, 'Timeout nach '.$idle.' Sekunden');
    if (!$valid) ok($_SESSION === [], 'Timeout entfernt Benutzer und CSRF');
}
$_SESSION = ['waage_access_authenticated'=>1];
enforceSessionIdleTimeout($now);
ok($_SESSION === [], 'Alte Sitzung ohne Zeitstempel wird beendet');
$_SESSION = ['waage_access_authenticated'=>1, 'waage_last_activity'=>$now+1];
enforceSessionIdleTimeout($now);
ok($_SESSION === [], 'Zeitstempel aus Zukunft wird abgelehnt');
foreach (['127.0.0.1','::1'] as $remote) {
    $_SERVER['REMOTE_ADDR'] = $remote;
    $_SESSION = ['waage_access_authenticated'=>1, 'waage_last_activity'=>1];
    enforceSessionIdleTimeout($now);
    ok(isLocalAccess() && !empty($_SESSION), 'Lokaler Bypass '.$remote);
}
$_SERVER['HTTP_X_FORWARDED_FOR'] = '203.0.113.5';
ok(!isLocalAccess(), 'Tunnel über Loopback erhält keinen Bypass');
unset($_SERVER['HTTP_X_FORWARDED_FOR']);
$_SERVER['REMOTE_ADDR'] = '203.0.113.5';
$_SERVER['HTTP_HOST'] = 'localhost';
ok(!isLocalAccess(), 'Host-Header kann Bypass nicht freischalten');
$_SERVER['SCRIPT_NAME'] = '/api/status.php';
$_SESSION = ['waage_access_authenticated'=>1, 'waage_last_activity'=>$now-100];
requireLogin();
ok($_SESSION['waage_last_activity'] === $now-100, 'Hintergrund-Polling verlängert Sitzung nicht');
$_SERVER['SCRIPT_NAME'] = '/index.php';
requireLogin();
ok($_SESSION['waage_last_activity'] >= $now, 'Seitenbedienung verlängert Sitzung');

$base = sys_get_temp_dir().DIRECTORY_SEPARATOR.'waagenbox_1230_'.bin2hex(random_bytes(6));
mkdir($base, 0700);
$backupDir = $base.DIRECTORY_SEPARATOR.'backups'; mkdir($backupDir);
rejected(fn()=>openLatestAutomaticBackup($backupDir), 'Fehlendes Backup verständlich abgelehnt');
$old = 'waagenbox_2026-09-13_19-30-00.sql.gz';
$new = 'waagenbox_2026-09-14_19-30-00_abcdef123456.sql.gz';
file_put_contents($backupDir.DIRECTORY_SEPARATOR.$old, gzencode('-- synthetic old SQL'));
file_put_contents($backupDir.DIRECTORY_SEPARATOR.$new, gzencode('-- synthetic new SQL'));
file_put_contents($backupDir.DIRECTORY_SEPARATOR.'waagenbox_2099-01-01_00-00-00.sql.gz', "\x1f\x8bbroken");
file_put_contents($backupDir.DIRECTORY_SEPARATOR.'foreign.sql.gz', gzencode('foreign'));
$backup = openLatestAutomaticBackup($backupDir);
ok($backup['name'] === $new && gzdecode(stream_get_contents($backup['stream'])) === '-- synthetic new SQL', 'Neuestes gültiges Backup; beschädigtes und fremdes ignoriert');
fclose($backup['stream']);
foreach (['../'.$new, '..\\'.$new, '/etc/passwd', $new.'.php', 'waagenbox_2026-99-99_19-30-00.sql.gz', 'AJP-Waagenbox_v1.2.30_2026-09-14_19-30-00.sql.gz'] as $bad) {
    ok(!automaticBackupNameValid($bad), 'Traversal/Fremdname/manuelles Backup abgelehnt');
}
ok(automaticBackupNameValid($old), 'Altes automatisches Format weiterhin erkannt');
$outside = $base.DIRECTORY_SEPARATOR.'outside.sql.gz';
file_put_contents($outside, gzencode('synthetic outside backup root'));
$link = $backupDir.DIRECTORY_SEPARATOR.'waagenbox_2099-12-31_00-00-00.sql.gz';
if (@symlink($outside, $link)) {
    $backup = openLatestAutomaticBackup($backupDir);
    ok($backup['name'] === $new, 'Symlink wird nicht heruntergeladen'); fclose($backup['stream']); unlink($link);
    $dirLink = $base.DIRECTORY_SEPARATOR.'link';
    symlink($backupDir, $dirLink);
    rejected(fn()=>openLatestAutomaticBackup($dirLink), 'Symlink-Verzeichnis abgelehnt'); unlink($dirLink);
} else { echo "SKIP Symlink-Erstellung benötigt lokale Berechtigung; Linux-Test erforderlich\n"; }

class FakeDini extends Dini3590 {
    public array $commands = [];
    public function __construct() {}
    public function command(string $command, bool $waitForAnswer = true): string {
        $this->commands[] = $command;
        return 'ST,GS,123,kg';
    }
}
$dini = new FakeDini();
foreach (array_keys(diniDiagnosticActions()) as $action) ok(isset(diniDiagnosticRead($dini, $action)['raw']), 'Dini '.$action.' liefert Rohantwort');
ok($dini->commands === ['R','VER','STAT','REXT','RALL'], 'Nur fünf freigegebene Dini-Lesebefehle');
foreach (['first','second','tare','zero','KEYP37'] as $action) rejected(fn()=>diniDiagnosticRead($dini, $action), 'Schreibende Dini-Aktion abgelehnt');
ok(count($dini->commands) === 5, 'Abgelehnte Aktionen senden keinen Befehl');
foreach ([8,63] as $length) { validateServiceWlan('enable', 'Waagenbox-Service', str_repeat('x',$length)); ok(true, 'WLAN Passwort-Grenze '.$length); }
foreach (['short',str_repeat('x',64), "1234567\n", 'pässwort'] as $password) rejected(fn()=>validateServiceWlan('enable','Test',$password), 'Ungültiges WLAN-Passwort abgelehnt');
foreach (['',str_repeat('x',33), "bad\nssid", str_repeat('ä',17)] as $ssid) rejected(fn()=>validateServiceWlan('enable',$ssid,'12345678'), 'Ungültige SSID abgelehnt');
validateServiceWlan('enable',str_repeat('ä',16),'12345678'); ok(true, 'UTF-8-SSID mit 32 Bytes akzeptiert');
rejected(fn()=>validateServiceWlan('shell','',''), 'WLAN Aktions-Allowlist');
if (PHP_OS_FAMILY === 'Windows') ok(serviceWlanRequest('status')['ok'] === false, 'Windows ohne nmcli sauber behandelt');

// Tatsächlicher Kunden-POST in separatem Prozess mit DB-Attrappe.
copy($root.'/customers.php', $base.'/customers.php');
file_put_contents($base.'/functions.php', <<<'PHP'
<?php
function requireLogin() {}
function currentOwnerId() { return 42; }
function flash($x) {}
function redirect($x) { echo json_encode($GLOBALS['record']); exit; }
function db() { return new FakeDb(); }
class FakeDb {
 function prepare($sql) { $GLOBALS['record']['sql']=$sql; return $this; }
 function execute($params) { $GLOBALS['record']['params']=$params; }
}
PHP);
file_put_contents($base.'/customer_test.php', "<?php \$_SERVER['REQUEST_METHOD']='POST'; \$_POST=['name'=>'Testkunde','address'=>'Testadresse','notes'=>'Testnotiz']; require __DIR__.'/customers.php';");
$p=proc_open([PHP_BINARY,'-n',$base.'/customer_test.php'], [1=>['pipe','w'],2=>['pipe','w']],$pipes);
$record=json_decode(stream_get_contents($pipes[1]),true); $errors=stream_get_contents($pipes[2]); fclose($pipes[1]); fclose($pipes[2]);
ok(proc_close($p) === 0 && $errors === '' && $record['sql'] === 'INSERT INTO customers(owner_user_id,name,address,notes) VALUES(?,?,?,?)' && $record['params'] === [42,'Testkunde','Testadresse','Testnotiz'], 'Echter Kunden-POST speichert Owner und Daten');
foreach (['api/backup_latest.php','api/dini_test.php','dini_diagnostics.php','service_wlan.php'] as $file) {
    ok(str_contains(file_get_contents($root.'/'.$file), 'requireAdmin();'), $file.' Adminschutz');
}
ok(!str_contains(file_get_contents($root.'/api/backup_latest.php'), '$_GET'), 'Download übernimmt keinen Browserpfad');
foreach (array_merge([$root.'/mobile_remote.php'],glob($root.'/api/mobile_*.php')) as $file) {
    ok(!preg_match('/require(?:Login|Admin)\s*\(/',file_get_contents($file)), basename($file).' bleibt tokenbasiert');
}
foreach (glob($backupDir.DIRECTORY_SEPARATOR.'*') as $file) unlink($file);
rmdir($backupDir);
foreach (glob($base.DIRECTORY_SEPARATOR.'*') as $file) unlink($file);
rmdir($base);
echo "RESULT $checks checks passed\n";
