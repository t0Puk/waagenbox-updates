import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('preflight', Path(__file__).resolve().parents[1] / 'tools/release_preflight.py')
preflight = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preflight)


class ReleasePreflightTest(unittest.TestCase):
    def test_allowed_source_files(self):
        for path in ('schema.sql', 'migration_v1_2_3_web.sql', 'backup.php', 'api/backup_create.php',
                     'api/backup_restore.php', 'systemd/waagenbox-backup.service'):
            self.assertTrue(preflight.allowed(path), path)

    def test_secrets_runtime_and_bad_zip_names(self):
        for path in ('config.php', 'nested/config.php', '.env', '.env.production', '.envsecret', 'id_rsa',
                     '.ssh/id_ed25519', 'private.pem', 'key.key', 'dbs123.sql', 'database.sql', 'a.sql.gz',
                     'old.bak', 'old.dump', 'old.old', 'old.orig', 'uploads/a.jpg', 'uploads/camera/.htaccess',
                     'backups/archive.zip', 'api\\backup_create.php', '../outside', '/absolute', 'C:/absolute', 'a/../b'):
            self.assertFalse(preflight.allowed(path), path)


if __name__ == '__main__':
    unittest.main()
