<?php
// Ausschließlich synthetische Daten im eigenen temporären Verzeichnis.
// Keine lokale config.php laden, keine Datenbankverbindung, keine Hardware.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Nur CLI.'); }
require dirname(__DIR__).'/update_safety.php';
set_error_handler(static function ($s, $m, $f, $l) { if (!(error_reporting() & $s)) return false; throw new ErrorException($m, 0, $s, $f, $l); });
if (PHP_OS_FAMILY === 'Windows') putenv('PATH=C:/Program Files/Git/usr/bin'.PATH_SEPARATOR.getenv('PATH'));
$base = str_replace('\\', '/', sys_get_temp_dir()).'/waagenbox_safety_test_'.bin2hex(random_bytes(6));
mkdir($base, 0700);
$passed = 0;
function check(bool $ok, string $message): void { global $passed; if (!$ok) throw new RuntimeException('FAIL '.$message); $passed++; echo "PASS $message\n"; }
function rejects(callable $fn, string $message): void { try { $fn(); } catch (Throwable $e) { check(true, $message); return; } check(false, $message); }
function rollbackRootInSubprocess(string $base, ?string $override): string {
    $runtime = $base.'/rollback-root-runtime';
    if (!is_dir($runtime)) mkdir($runtime, 0700, true);
    foreach (['functions.php','db.php','version.php','auth.php'] as $file) copy(dirname(__DIR__).'/'.$file, $runtime.'/'.$file);
    file_put_contents($runtime.'/config.php', "<?php\nconst DB_HOST='127.0.0.1'; const DB_PORT=3306; const DB_NAME='test'; const DB_USER='test'; const DB_PASS='test';\n");
    $script = $runtime.'/check.php';
    file_put_contents($script, "<?php\nif (\$argv[1] !== '__DEFAULT__') define('ROLLBACK_BACKUP_ROOT', \$argv[1]);\nrequire \$argv[2].'/functions.php';\necho rollbackBackupRoot();\n");
    $output = $runtime.'/output.txt';
    try {
        updateSafetyRun([PHP_BINARY, '-n', $script, $override ?? '__DEFAULT__', $runtime], $runtime.'/process.log', null, $output);
        return (string)file_get_contents($output);
    } finally { @unlink($script); @unlink($output); }
}
function rollbackRootRejectsInSubprocess(string $base, string $override): void {
    try { rollbackRootInSubprocess($base, $override); }
    catch (Throwable $e) { check(true, 'invalid rollback override rejected: '.$override); return; }
    check(false, 'invalid rollback override rejected: '.$override);
}
check(rollbackRootInSubprocess($base, null) === '/var/lib/waagebox/rollback', 'default rollback root without override');
check(rollbackRootInSubprocess($base, '/tmp/waagenbox-test-rollback') === '/tmp/waagenbox-test-rollback', 'valid absolute test rollback root accepted');
rollbackRootRejectsInSubprocess($base, 'relative/rollback');
rollbackRootRejectsInSubprocess($base, '/');
rollbackRootRejectsInSubprocess($base, '');
rollbackRootRejectsInSubprocess($base, '/tmp/../rollback');
rollbackRootRejectsInSubprocess($base, '/tmp/./waagenbox-test');
function fixture(string $root): void {
    mkdir($root, 0700, true);
    mkdir($root.'/app');
    foreach (['config.php','functions.php','version.php','db.php'] as $f) file_put_contents($root.'/app/'.$f, "<?php // synthetic fixture\n");
    mkdir($root.'/app/assets');
    file_put_contents($root.'/app/assets/file.txt', 'original');
    $sql = "-- Synthetic dump, never executed\nCREATE TABLE `test` (`id` int NOT NULL);\nINSERT INTO `test` VALUES (1);\n-- Dump completed on 2026-09-13\n";
    file_put_contents($root.'/database.sql', $sql);
    updateSafetyWriteJson($root.'/metadata.json', ['format'=>1,'previous_version'=>'1.2.26','application_files'=>updateSafetyInventory($root.'/app'),'database_sha256'=>hash_file('sha256',$root.'/database.sql'),'database_objects'=>['tables'=>['test'],'views'=>[],'procedures'=>[],'functions'=>[],'events'=>[],'triggers'=>[]]]);
}
fixture($base.'/snapshot');
check(updateSafetyValidateSnapshot($base.'/snapshot')['format'] === 1, 'complete snapshot validates');
file_put_contents($base.'/snapshot/app/assets/file.txt', 'corrupt');
rejects(fn()=>updateSafetyValidateSnapshot($base.'/snapshot'), 'changed application file rejected');
file_put_contents($base.'/snapshot/app/assets/file.txt', 'original');
file_put_contents($base.'/bad.sql', "CREATE TABLE `test` (`id` int);\n".str_repeat(' ',200));
rejects(fn()=>updateSafetyDumpCheck($base.'/bad.sql'), 'truncated dump rejected');
file_put_contents($base.'/empty.sql', '');
rejects(fn()=>updateSafetyDumpCheck($base.'/empty.sql'), 'empty dump rejected');
updateSafetyRun([PHP_BINARY,'-n','-r','exit(0);'], $base.'/process.log');
rejects(fn()=>updateSafetyRun([PHP_BINARY,'-n','-r','exit(7);'], $base.'/process.log'), 'nonzero subprocess exit rejected');
rejects(fn()=>updateSafetyCopy($base.'/missing',$base.'/target',$base.'/copy-fail.log'), 'single copy failure rejected');
updateSafetyCopy($base.'/snapshot/app',$base.'/live',$base.'/copy.log');
check(updateSafetyInventory($base.'/live') === updateSafetyInventory($base.'/snapshot/app'), 'application copy has matching hashes');
$definerDump = $base.'/definer.sql';
file_put_contents($definerDump, "CREATE TABLE `test` (`id` int);\n/*!50017 DEFINER=`root`@`localhost`*/ CREATE TRIGGER `trg` AFTER INSERT ON `test` FOR EACH ROW SET @x=1;\n-- Dump completed on 2026-09-13\n");
updateSafetyNormalizeDump($definerDump);
$normalizedDefiner = file_get_contents($definerDump);
check($normalizedDefiner !== false && !str_contains($normalizedDefiner, 'DEFINER=') && updateSafetyDumpCheck($definerDump) !== '', 'MariaDB DEFINER comment normalized safely');
$dataDump = $base.'/definer-data.sql';
$dataSql = "CREATE TABLE `test` (`note` varchar(100));\nINSERT INTO `test` VALUES ('DEFINER=not_a_clause');\n-- Dump completed on 2026-09-13\n";
file_put_contents($dataDump, $dataSql);
updateSafetyNormalizeDump($dataDump);
check(file_get_contents($dataDump) === $dataSql, 'DEFINER text in SQL data remains unchanged');
$unsupportedDump = $base.'/unsupported-definer.sql';
 $unsupportedSql = "CREATE TABLE `test` (`id` int);\n/*!50017 DEFINER 'root'@'localhost' */\n-- Dump completed on 2026-09-13\n";
file_put_contents($unsupportedDump, $unsupportedSql);
rejects(fn()=>updateSafetyNormalizeDump($unsupportedDump), 'unsupported DEFINER construct rejected');
check(file_get_contents($unsupportedDump) === $unsupportedSql, 'unsupported DEFINER leaves original dump unchanged');
$restoreSource = file_get_contents(dirname(__DIR__).'/update_safety.php');
check($restoreSource !== false && strpos($restoreSource, 'updateSafetyDumpCheck($normalized)') < strpos($restoreSource, '$pdo = updateSafetyDb();'), 'restore dump preparation precedes DB mutation');
$protected = $base.'/live/protected.php';
file_put_contents($protected, 'protected');
chmod($protected, 0440);
if (!is_writable($protected)) {
    rejects(fn()=>updateSafetyRequireWritableApplication($base.'/live', ['protected.php'=>['type'=>'file']]), 'basis-test: non-writable application file rejected before mutation');
    chmod($protected, 0640);
} else {
    echo "SKIP basis-test: filesystem ignores chmod; root:www-data 0640 regression requires Linux\n";
}
file_put_contents($base.'/live/functions.php', '<?php // changed');
mkdir($base.'/live/extra'); file_put_contents($base.'/live/extra/new.php','<?php');
file_put_contents($base.'/live/.new-hidden','extra');
updateSafetyRestoreApplication($base.'/snapshot',$base.'/live',$base.'/restore.log');
check(updateSafetyInventory($base.'/live') === updateSafetyInventory($base.'/snapshot/app'), 'restore removes added nested and hidden files and restores changed files');
check(is_file($base.'/snapshot/database.sql'), 'snapshot survives successful restore');
rejects(fn()=>updateSafetyRestoreApplication($base.'/snapshot',$base.'/snapshot/app',$base.'/restore.log'), 'overlapping restore paths rejected');
fixture($base.'/candidate'); fixture($base.'/rollback');
$oldHash=hash_file('sha256',$base.'/rollback/metadata.json');
updateSafetyActivate($base.'/candidate',$base.'/rollback');
$archived=glob($base.'/rollback_previous_*');
check(count($archived)===1 && hash_file('sha256',$archived[0].'/metadata.json')===$oldHash, 'old rollback generation retained after activation');
fixture($base.'/bad-candidate'); file_put_contents($base.'/bad-candidate/database.sql','broken');
rejects(fn()=>updateSafetyActivate($base.'/bad-candidate',$base.'/rollback'), 'corrupt candidate cannot replace rollback');
check(is_file($base.'/rollback/database.sql') && is_file($base.'/bad-candidate/database.sql'), 'both generations survive failed activation');
$lock=updateSafetyLock($base.'/locking');
rejects(fn()=>updateSafetyLock($base.'/locking'), 'concurrent maintenance lock rejected');
fclose($lock);
updateSafetyWriteJson($base.'/locking/operation.json',['state'=>'applying']);
rejects(fn()=>updateSafetyLock($base.'/locking'), 'interrupted operation blocks next maintenance');
updateSafetyWriteJson($base.'/locking/operation.json',['state'=>'recovered']);
$lock=updateSafetyLock($base.'/locking'); check(is_resource($lock),'verified recovery allows maintenance'); fclose($lock);
$newWork = $base.'/recover-new-work';
check(!file_exists($newWork), 'recovery work directory does not exist before call');
$errors = updateSafetyRecover($base.'/snapshot', $base.'/live', $newWork,
    fn()=>updateSafetyRun([PHP_BINARY, '-n', '-r', 'exit(0);'], $newWork.'/restore_database.log'));
check($errors === [] && is_dir($newWork) && is_file($newWork.'/restore_database.log') && is_file($newWork.'/restore_application.log'),
    'recovery creates work directory before opening restore logs');
$calls=[];
$errors=updateSafetyRecover('unused','unused',$base,function()use(&$calls){$calls[]='db';throw new RuntimeException('injected DB failure');},function()use(&$calls){$calls[]='app';});
check($calls===['db','app'] && count($errors)===1 && str_contains($errors[0],'Datenbank'), 'DB restore failure still attempts application restore and is reported');
$errors=updateSafetyRecover('unused','unused',$base,fn()=>null,fn()=>throw new RuntimeException('injected app failure'));
check(count($errors)===1 && str_contains($errors[0],'Anwendung'),'application restore failure reported');
$errors=updateSafetyRecover('unused','unused',$base,fn()=>throw new RuntimeException('db'),fn()=>throw new RuntimeException('app'));
check(count($errors)===2,'both recovery failures retained');
check(updateSafetyRecover('unused','unused',$base,fn()=>null,fn()=>null)===[],'successful two-part recovery confirmed');
$package=$base.'/package'; mkdir($package); mkdir($package.'/api');
foreach(['functions.php','db.php','index.php','api/update_install.php','api/update_rollback.php','update_safety.php']as$f)file_put_contents($package.'/'.$f,"<?php // fixture\n");
file_put_contents($package.'/version.php',"<?php define('APP_VERSION', '1.2.27');\n");
check(count(updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'))>0,'package without config.php accepted');
rejects(fn()=>updateSafetyPackage($package,'1.2.28',PHP_BINARY,$base.'/lint.log'),'manifest version mismatch rejected');
file_put_contents($package.'/config.php','<?php // forbidden');
rejects(fn()=>updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'),'package containing local config rejected');
unlink($package.'/config.php');
file_put_contents($package.'/index.php','<?php syntax error!!!');
rejects(fn()=>updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'),'invalid package PHP rejected');
file_put_contents($package.'/index.php','<?php // fixture');
unlink($package.'/version.php');
rejects(fn()=>updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'),'missing version.php rejected');
$zip=new ZipArchive(); $zip->open($base.'/bad.zip',ZipArchive::CREATE); $zip->addFromString('../escape.php','bad'); $zip->close();
rejects(fn()=>updateSafetyUnpack($base.'/bad.zip',$base.'/unpack'),'ZIP traversal rejected before extraction');
check(!file_exists($base.'/escape.php'),'ZIP traversal wrote no external file');
$zip=new ZipArchive();$zip->open($base.'/link.zip',ZipArchive::CREATE);$zip->addFromString('link','target');$zip->setExternalAttributesName('link',ZipArchive::OPSYS_UNIX,0120777<<16);$zip->close();
rejects(fn()=>updateSafetyUnpack($base.'/link.zip',$base.'/unpack-link'),'ZIP symlink rejected before extraction');
$zip=new ZipArchive();$zip->open($base.'/valid.zip',ZipArchive::CREATE);$zip->addFromString('release/file.txt','content');$zip->close();
check(updateSafetyUnpack($base.'/valid.zip',$base.'/unpack-valid')===$base.'/unpack-valid/release','single package wrapper handled');
fixture($base.'/activate-same');
rejects(fn()=>updateSafetyActivate($base.'/activate-same',$base.'/activate-same'),'rename failure restores archived generation');
check(is_file($base.'/activate-same/database.sql'),'previous generation remains at original path after activation failure');
file_put_contents($package.'/version.php',"<?php define('APP_VERSION', '1.2.27');\n");
mkdir($package.'/uploads');mkdir($package.'/uploads/camera');file_put_contents($package.'/uploads/camera/.htaccess','Options -Indexes');
check(count(updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'))>0,'upload control files accepted');
file_put_contents($package.'/uploads/camera/private.jpg','synthetic');
rejects(fn()=>updateSafetyPackage($package,'1.2.27',PHP_BINARY,$base.'/lint.log'),'runtime camera image rejected');
$state=['state'=>'preparing','mutating'=>false,'work'=>$base,'snapshot'=>$base.'/snapshot'];
$message=updateSafetyFailure($state,$base.'/failed-operation.json','Injected preflight failure.');
check($state['state']==='aborted' && str_contains($message,'noch nicht verändert') && is_file($base.'/snapshot/database.sql'),'preflight failure records clear state and retains rescue files');

// Legacy-Migration: Kommentare, andere Konstanten, CRLF und Beispielwerte erhalten.
$legacy = "<?php\r\n// const APP_VERSION = '0.0.0'; bleibt ein Kommentar\r\nconst DB_PASS = 'TEST_ONLY_APP_VERSION';\r\nconst APP_VERSION = '1.2.26';\r\nconst APP_TIMEZONE = 'Europe/Berlin';\r\n";
$migrated = str_replace("const APP_VERSION = '1.2.26';", "require_once __DIR__ . '/version.php';", $legacy);
check(updateSafetyLegacyConfig($legacy) === $migrated, 'only actual legacy const replaced, all other bytes preserved');
check(updateSafetyLegacyConfig($migrated) === $migrated, 'legacy transformation is idempotent');
$legacyDefine = "<?php\nif (!defined('APP_VERSION')) { define('APP_VERSION', '1.2.26'); }\n";
check(updateSafetyLegacyConfig($legacyDefine) === str_replace("define('APP_VERSION', '1.2.26');", "require_once __DIR__ . '/version.php';", $legacyDefine), 'guarded legacy define migrates');
rejects(fn()=>updateSafetyLegacyConfig("<?php define('APP_VERSION', getenv('VERSION'));"), 'dynamic version expression rejected without guessing');
rejects(fn()=>updateSafetyLegacyConfig("<?php const APP_VERSION='1.2.26'; define('APP_VERSION','1.2.26');"), 'ambiguous duplicate declarations rejected');
rejects(fn()=>updateSafetyLegacyConfig("<?php const OTHER='x', APP_VERSION='1.2.26';"), 'combined const declaration rejected safely');
$onlyString = '<?php $note = "const APP_VERSION = '."'1.2.26'".';";';
check(updateSafetyLegacyConfig($onlyString) === $onlyString, 'version-like text inside other setting is untouched');
fixture($base.'/legacy-snapshot');
file_put_contents($base.'/legacy-snapshot/app/config.php', $legacy);
file_put_contents($base.'/legacy-snapshot/app/version.php', "<?php if (!defined('APP_VERSION')) define('APP_VERSION','1.2.26');");
$meta = updateSafetyReadJson($base.'/legacy-snapshot/metadata.json');
$meta['application_files'] = updateSafetyInventory($base.'/legacy-snapshot/app');
updateSafetyWriteJson($base.'/legacy-snapshot/metadata.json',$meta);
updateSafetyCopy($base.'/legacy-snapshot/app',$base.'/legacy-live',$base.'/legacy-copy.log');
mkdir($base.'/legacy-work');
$expectedHash = updateSafetyMigrateConfig($base.'/legacy-snapshot',$base.'/legacy-live',$base.'/legacy-work',PHP_BINARY);
check(file_get_contents($base.'/legacy-live/config.php') === $migrated && hash_file('sha256',$base.'/legacy-live/config.php') === $expectedHash, 'atomic migration after verified snapshot');
check(file_get_contents($base.'/legacy-snapshot/app/config.php') === $legacy, 'original legacy configuration retained in snapshot');
check((glob($base.'/legacy-live/.config-migration-*.php') ?: []) === [], 'atomic rename leaves no adjacent temporary file on success');
file_put_contents($base.'/legacy-live/version.php', "<?php const APP_VERSION='1.2.27';");
updateSafetyRun([PHP_BINARY,'-n','-r','require $argv[1]; require_once $argv[2]; echo APP_VERSION;', $base.'/legacy-live/config.php', $base.'/legacy-live/version.php'], $base.'/legacy-runtime.log', null, $base.'/legacy-version.txt');
check(file_get_contents($base.'/legacy-version.txt') === '1.2.27', 'fresh bootstrap reads new version without duplicate definition');
$recovery = updateSafetyRecover($base.'/legacy-snapshot',$base.'/legacy-live',$base.'/legacy-work',fn()=>null);
check($recovery === [] && file_get_contents($base.'/legacy-live/config.php') === $legacy, 'later update failure restores original legacy config byte for byte');
fixture($base.'/invalid-legacy-snapshot');
file_put_contents($base.'/invalid-legacy-snapshot/database.sql','broken');
rejects(fn()=>updateSafetyMigrateConfig($base.'/invalid-legacy-snapshot',$base.'/legacy-live',$base.'/legacy-work',PHP_BINARY), 'migration blocked without verified database snapshot');
check(file_get_contents($base.'/legacy-live/config.php') === $legacy, 'failed snapshot validation leaves local config untouched');

// Aufbewahrung nur bei Erfolg. Alles liegt unter dem Testverzeichnis.
$retention = $base.'/retention'; mkdir($retention);
fixture($retention.'/rollback');
foreach (['a','b','c'] as $n) {
    fixture($retention.'/rollback_previous_'.$n);
    updateSafetyMarkSuccessfulSnapshot($retention.'/rollback_previous_'.$n);
}
fixture($retention.'/rollback_previous_error');
fixture($retention.'/rollback_previous_pinned');
updateSafetyMarkSuccessfulSnapshot($retention.'/rollback_previous_pinned');
$pin = updateSafetyPinSnapshot($retention.'/rollback_previous_pinned');
fixture($retention.'/rollback_previous_corrupt');
updateSafetyMarkSuccessfulSnapshot($retention.'/rollback_previous_corrupt');
file_put_contents($retention.'/rollback_previous_corrupt/database.sql','broken');
mkdir($retention.'/update_success'); mkdir($retention.'/update_success/stage');
file_put_contents($retention.'/update_success/stage/package.php','<?php // synthetic');
file_put_contents($retention.'/update_success/package.zip','synthetic');
file_put_contents($retention.'/update_success/config_migration.php','<?php // synthetic');
mkdir($retention.'/update_error'); mkdir($retention.'/update_error/stage');
file_put_contents($retention.'/update_error/package.zip','error evidence');
$failedState=['state'=>'recovered','mutating'=>false,'work'=>$retention.'/update_error'];
updateSafetyCleanupSuccess($failedState,$retention.'/rollback');
check(is_file($retention.'/update_error/package.zip') && is_dir($retention.'/update_error/stage'), 'even recovered errors never trigger cleanup');
$success=['state'=>'complete','mutating'=>false,'work'=>$retention.'/update_success'];
check(updateSafetyCleanupSuccess($success,$retention.'/rollback') === [], 'successful cleanup completes');
check(!file_exists($retention.'/update_success/package.zip') && !file_exists($retention.'/update_success/stage') && !file_exists($retention.'/update_success/config_migration.php'), 'successful ZIP, stage and migration draft removed');
check(is_dir($retention.'/rollback') && !is_dir($retention.'/rollback_previous_a') && !is_dir($retention.'/rollback_previous_b') && is_dir($retention.'/rollback_previous_c'), 'current plus latest successful historical generation retained');
check(is_dir($retention.'/rollback_previous_error') && is_dir($retention.'/rollback_previous_pinned') && is_dir($retention.'/rollback_previous_corrupt'), 'unmarked, pinned and corrupt rescue generations survive retention');
check(is_file($retention.'/update_error/package.zip'), 'successful later update never removes earlier error workspace');
check(updateSafetyPinSnapshot($retention.'/rollback_previous_pinned') === null, 'existing error pin not replaced');
updateSafetyUnpinSuccessfulSnapshot($retention.'/rollback_previous_pinned',null);
check(is_file($retention.'/rollback_previous_pinned/rescue-pin.json'), 'earlier error pin remains after another successful attempt');
$sourcePin = updateSafetyPinSnapshot($retention.'/rollback');
updateSafetyUnpinSuccessfulSnapshot($retention.'/rollback',$sourcePin);
check(!file_exists($retention.'/rollback/rescue-pin.json'), 'successful rollback releases only its own new pin');
fixture($retention.'/rollback_attempt_success/snapshot');
updateSafetyMarkSuccessfulSnapshot($retention.'/rollback_attempt_success/snapshot');
updateSafetyPruneSuccessfulSnapshots($retention.'/rollback');
check(is_dir($retention.'/rollback_attempt_success/snapshot') && !is_dir($retention.'/rollback_previous_c'), 'successful rollback safety snapshots share bounded retention');
rejects(fn()=>updateSafetyRemoveTree($retention,$retention), 'cleanup cannot delete its allowed parent');
rejects(fn()=>updateSafetyRemoveTree($base.'/snapshot',$retention), 'cleanup cannot escape allowed parent');
check(is_file($base.'/snapshot/database.sql'), 'out-of-scope snapshot untouched');
echo "RESULT $passed checks passed\nFixtures retained: $base\n";



