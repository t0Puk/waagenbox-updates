<?php
require_once __DIR__.'/functions.php';
require_once __DIR__.'/system_control_support.php';
requireLogin();

$local = isLocalAccess();
$admin = isAdmin();
$error = null;
$result = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        requireCsrfToken();
        $action = (string)($_POST['action'] ?? '');
        validateSystemControlAction($action);

        if ($action === 'kiosk_exit') {
            if (!$local) {
                throw new RuntimeException('Der Kiosk-Modus kann nur direkt am Raspberry-Bildschirm beendet werden.');
            }
        } else {
            // Neustart und Herunterfahren sind gefährliche Systemaktionen und
            // benötigen zusätzlich zur CSRF-Prüfung eine echte Admin-Sitzung.
            requireAdmin();
        }

        $result = systemControlRequest($action);
        if (empty($result['ok'])) throw new RuntimeException((string)($result['message'] ?? 'Systemaktion fehlgeschlagen.'));
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$status = systemControlStatus();
layoutStart('System','settings');
?>
<div class="toolbar"><h1>System</h1><a class="button" href="settings.php">Zurück zu Einstellungen</a></div>
<?php if($error): ?><div class="flash error"><strong>Systemaktion fehlgeschlagen.</strong><br><?=h($error)?></div><?php endif; ?>
<?php if($result && !empty($result['ok'])): ?><div class="flash success"><?=h((string)$result['message'])?></div><?php endif; ?>

<div class="card">
  <h2>Systemstatus</h2>
  <p><?=h((string)($status['message'] ?? 'Systemstatus nicht verfügbar.'))?></p>
  <?php if(!empty($status['installed'])): ?>
    <p class="muted">Gerät: <strong><?=h((string)($status['model'] ?? 'Linux-System'))?></strong></p>
    <p class="muted">Kiosk-Modus: <strong><?=!empty($status['kiosk_running'])?'aktiv':'nicht aktiv'?></strong></p>
  <?php else: ?>
    <p class="muted">Die Systemfunktionen werden erst nach der separat freizugebenden Raspberry-Systeminstallation aktiviert.</p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Kiosk-Modus</h2>
  <p>Der Kiosk-Browser wird beendet, der Raspberry und die Waagenbox laufen weiter. Beim nächsten Neustart startet der Kiosk wieder automatisch.</p>
  <?php if($local): ?>
    <form method="post" onsubmit="return confirm('Kiosk-Modus wirklich beenden und zum Raspberry-Desktop zurückkehren?');">
      <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
      <button class="button" name="action" value="kiosk_exit" <?=empty($status['installed'])?'disabled':''?>>Kiosk-Modus beenden</button>
    </form>
  <?php else: ?>
    <p class="muted">Diese Funktion ist nur direkt am Raspberry-Bildschirm verfügbar.</p>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Raspberry neu starten oder herunterfahren</h2>
  <p class="muted">Laufende Wiegungen sollten vorher abgeschlossen werden. Beim Herunterfahren bleibt die Waagenbox ausgeschaltet, bis die Stromversorgung erneut eingeschaltet wird.</p>
  <?php if($admin): ?>
    <div class="button-row">
      <form method="post" onsubmit="return confirm('Raspberry wirklich neu starten? Die Waagenbox ist während des Neustarts vorübergehend nicht erreichbar.');">
        <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
        <button class="button" name="action" value="reboot" <?=empty($status['installed'])?'disabled':''?>>Raspberry neu starten</button>
      </form>
      <form method="post" onsubmit="return confirm('Raspberry wirklich herunterfahren? Die Waagenbox bleibt ausgeschaltet, bis die Stromversorgung erneut eingeschaltet wird.');">
        <input type="hidden" name="csrf_token" value="<?=h(csrfToken())?>">
        <button class="button" name="action" value="poweroff" <?=empty($status['installed'])?'disabled':''?>>Raspberry herunterfahren</button>
      </form>
    </div>
  <?php else: ?>
    <p class="muted">Neustart und Herunterfahren sind nur in einer angemeldeten Admin-Sitzung verfügbar.</p>
  <?php endif; ?>
</div>
<?php layoutEnd(); ?>
