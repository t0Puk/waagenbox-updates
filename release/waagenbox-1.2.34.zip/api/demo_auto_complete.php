<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'status'=>'method_not_allowed','message'=>'Nur POST ist erlaubt.'], JSON_UNESCAPED_UNICODE);
    exit;
}

requireCsrfToken();

if (!demoMode()) {
    http_response_code(409);
    echo json_encode(['ok'=>false,'status'=>'not_demo','message'=>'Automatischer Testabschluss ist nur im Demo-Modus verfügbar.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$pdo = db();
$ownerId = currentOwnerId();
$lockName = 'waagenbox_demo_complete_'.$ownerId;
$lockHeld = false;

try {
    $lockStmt = $pdo->prepare('SELECT GET_LOCK(?,0)');
    $lockStmt->execute([$lockName]);
    $lockHeld = (int)$lockStmt->fetchColumn() === 1;
    if (!$lockHeld) {
        echo json_encode(['ok'=>true,'status'=>'busy','message'=>'Eine Wiegung wird bereits verarbeitet.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pending = pendingWeighing();
    if (!$pending) {
        echo json_encode(['ok'=>true,'status'=>'idle','message'=>'Keine laufende Wiegung vorhanden.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $triggerType = (string)($pending['trigger_type'] ?? 'manual');
    if ($triggerType !== 'radio') {
        echo json_encode([
            'ok'=>true,
            'status'=>'ignored_non_radio',
            'message'=>'Automatischer Testabschluss ist nur für Funk-Wiegungen aktiv.',
            'trigger_type'=>$triggerType,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $weight = currentWeight();
    $firstWeight = (float)$pending['first_weight'];
    if ($weight <= 0 || abs($weight - $firstWeight) <= 0.05) {
        echo json_encode([
            'ok'=>true,
            'status'=>'waiting',
            'message'=>'Noch kein gültiges Zweitgewicht erkannt.',
            'weight'=>$weight,
            'first_weight'=>$firstWeight,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $id = completePendingWeighing($weight);
    echo json_encode([
        'ok'=>true,
        'status'=>'completed',
        'message'=>'Testwiegung automatisch abgeschlossen.',
        'weighing_id'=>$id,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'status'=>'error','message'=>'Automatischer Testabschluss fehlgeschlagen.'], JSON_UNESCAPED_UNICODE);
} finally {
    if ($lockHeld) {
        try {
            $release = $pdo->prepare('SELECT RELEASE_LOCK(?)');
            $release->execute([$lockName]);
        } catch (Throwable $e) {
        }
    }
}
