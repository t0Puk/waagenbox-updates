<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$p=pendingWeighing();
echo json_encode([
    'pending'=>$p?true:false,
    'key'=>$p?($p['started_at'].'|'.($p['remote_id']??0).'|'.($p['vehicle_id']??0)):null,
    'first_weight'=>$p?(float)$p['first_weight']:null,
    'trigger_type'=>$p?(string)($p['trigger_type']??'manual'):null,
    'demo_mode'=>demoMode(),
],JSON_UNESCAPED_UNICODE);
