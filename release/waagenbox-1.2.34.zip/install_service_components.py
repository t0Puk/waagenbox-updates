#!/usr/bin/python3
"""Explicitly approved root installation only; --check is read-only, JSON, exit 0/1."""
import argparse
import configparser
import json
import os
from pathlib import Path
import pwd
import stat
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
UNITS = ['waagenbox-service-wlan-prepare.service', 'waagenbox-service-hostapd.service', 'waagenbox-service-dnsmasq.service']
FILES = {
    'deploy/waagenbox-service-wlan.py': ('/usr/local/sbin/waagenbox-service-wlan', 0o755),
    'deploy/service-wlan-dnsmasq.conf': ('/etc/waagenbox/service-wlan/dnsmasq.conf', 0o600),
    'deploy/service-wlan-networkmanager.conf': ('/etc/NetworkManager/conf.d/90-waagenbox-service-wlan.conf', 0o644),
    'deploy/waagenbox-kiosk': ('/usr/local/bin/waagenbox-kiosk', 0o755),
    'deploy/install-kiosk-autostart.py': ('/usr/local/lib/waagenbox/install-kiosk-autostart.py', 0o755),
    **{'systemd/' + unit: ('/etc/systemd/system/' + unit, 0o644) for unit in UNITS},
}
SUDOERS = '/etc/sudoers.d/waagenbox-service-wlan'
RULE = b'www-data ALL=(root) NOPASSWD: /usr/local/sbin/waagenbox-service-wlan ""\n'
BINARIES = ['/usr/sbin/hostapd', '/usr/sbin/dnsmasq', '/usr/sbin/rfkill', '/usr/sbin/ip',
            '/usr/sbin/iw', '/usr/sbin/visudo', '/usr/bin/nmcli', '/usr/bin/systemctl',
            '/usr/bin/chromium', '/usr/bin/curl', '/usr/bin/flock', '/usr/sbin/runuser', '/usr/bin/labwc-pi']


def run(*args):
    return subprocess.run(args, check=True, capture_output=True, text=True,
                          env={**os.environ, 'LC_ALL': 'C', 'PATH': '/usr/sbin:/usr/bin:/sbin:/bin'}).stdout.strip()


def safe_path(path):
    path = Path(path)
    for item in [path, *path.parents]:
        if item.is_symlink():
            raise ValueError('Unsafe symlink: ' + str(item))
        if item.exists():
            info = item.stat()
            if info.st_uid != 0 or info.st_mode & 0o022:
                raise ValueError('Root ownership/write protection required: ' + str(item))


def put(path, data, mode):
    path = Path(path)
    safe_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.waagenbox-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as target:
            os.fchmod(target.fileno(), mode)
            target.write(data)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def expected_files():
    return [(dst, (ROOT / src).read_bytes(), mode) for src, (dst, mode) in FILES.items()] + [(SUDOERS, RULE, 0o440)]


def check():
    missing = []
    try:
        if stat.S_IMODE(Path('/etc/waagenbox/service-wlan').stat().st_mode) != 0o700:
            missing.append('service-wlan directory must have mode 0700')
    except OSError:
        missing.append('service-wlan directory missing')
    for dst, data, mode in expected_files():
        try:
            safe_path(dst)
            if Path(dst).read_bytes() != data or stat.S_IMODE(Path(dst).stat().st_mode) != mode:
                missing.append(dst)
        except (OSError, ValueError):
            missing.append(dst)
    for binary in BINARIES:
        if not os.access(binary, os.X_OK):
            missing.append(binary)
    try:
        home = pwd.getpwnam('pi').pw_dir
        # User files are inspected in the user context, not through root-followed links.
        run('/usr/sbin/runuser', '-u', 'pi', '--', '/usr/bin/python3', '-c',
            'from pathlib import Path; import sys; sys.exit(0 if ' +
            repr('/usr/local/bin/waagenbox-kiosk & # AJP Waagenbox kiosk') +
            ' in Path(' + repr(home + '/.config/labwc/autostart') + ').read_text().splitlines() else 1)')
        if run('/usr/bin/nmcli', '-g', 'GENERAL.STATE', 'device', 'show', 'wlan0') != '10 (unmanaged)':
            missing.append('wlan0 must be unmanaged')
        run('/usr/sbin/visudo', '-cf', SUDOERS)
        for unit in UNITS:
            if run('/usr/bin/systemctl', 'show', unit, '--property=LoadState', '--value') != 'loaded':
                missing.append(unit)
    except (OSError, KeyError, subprocess.CalledProcessError):
        missing.append('runtime prerequisites/autostart')
    print(json.dumps({'ok': not missing, 'required_step': 'sudo /usr/bin/python3 install_service_components.py --install', 'missing': missing}))
    return 1 if missing else 0


def install():
    if os.geteuid() != 0:
        raise ValueError('Run the explicitly approved installation as root.')
    pwd.getpwnam('pi')
    # Abort before any change if wlan0 carries a connection; never disconnect it.
    active = run('/usr/bin/nmcli', '-g', 'GENERAL.CON-UUID', 'device', 'show', 'wlan0')
    if active not in ('', '--'):
        raise ValueError('wlan0 has an active NetworkManager connection. Release it separately after reviewing remote access.')
    config = configparser.ConfigParser(interpolation=None, strict=False)
    config.read_string(run('/usr/sbin/NetworkManager', '--print-config'))
    existing = config.get('keyfile', 'unmanaged-devices', fallback='')
    if existing not in ('', 'interface-name:wlan0'):
        raise ValueError('Existing unmanaged-devices rules require manual integration; nothing changed.')
    for dst, _, _ in expected_files():
        safe_path(dst)
    safe_path('/etc/waagenbox/service-wlan')
    # dnsmasq-base supplies the binary without introducing a global DHCP service.
    packages = {'/usr/sbin/hostapd': 'hostapd', '/usr/sbin/dnsmasq': 'dnsmasq-base',
                '/usr/sbin/rfkill': 'rfkill', '/usr/sbin/iw': 'iw', '/usr/bin/curl': 'curl',
                '/usr/sbin/visudo': 'sudo', '/usr/bin/chromium': 'chromium'}
    missing = [package for binary, package in packages.items() if not os.access(binary, os.X_OK)]
    if missing:
        # Never overwrite an existing policy. If present, ask administrator to install
        # packages under that policy; its permission to start services is unknown.
        policy = Path('/usr/sbin/policy-rc.d')
        if policy.exists() or policy.is_symlink():
            raise ValueError('Install missing packages under existing policy-rc.d first: ' + ' '.join(missing))
        with policy.open('xb') as target:
            target.write(b'#!/bin/sh\nexit 101\n')
        policy.chmod(0o755)
        try:
            run('/usr/bin/apt-get', 'install', '-y', '--no-install-recommends', *missing)
        finally:
            policy.unlink()
    if any(not os.access(binary, os.X_OK) for binary in BINARIES):
        raise ValueError('Missing system prerequisites; run --check.')
    # Independently managed clients/APs must not be taken over either.
    link = run('/usr/sbin/iw', 'dev', 'wlan0', 'link')
    own_ap = run('/usr/bin/systemctl', 'is-active', 'waagenbox-service-hostapd.service') if (
        run('/usr/bin/systemctl', 'show', 'waagenbox-service-hostapd.service', '--property=ActiveState', '--value') == 'active') else ''
    info = run('/usr/sbin/iw', 'dev', 'wlan0', 'info')
    if 'Connected to ' in link or ('type AP' in info and own_ap != 'active'):
        raise ValueError('wlan0 is in use by another connection/AP.')
    configured = os.path.isfile('/etc/waagenbox/service-wlan/hostapd.conf')
    enabled = any(run('/usr/bin/systemctl', 'show', unit, '--property=UnitFileState', '--value') == 'enabled' for unit in UNITS)
    if (own_ap == 'active' or enabled) and not configured:
        raise ValueError('Existing WLAN units use another configuration path. Review and disable them separately before migration; then enter credentials in the WebUI.')
    if run('/usr/bin/nmcli', '-g', 'GENERAL.CON-UUID', 'device', 'show', 'wlan0') not in ('', '--'):
        raise ValueError('wlan0 became occupied during preflight. No system configuration was replaced.')
    directory = Path('/etc/waagenbox/service-wlan')
    directory.mkdir(parents=True, exist_ok=True)
    directory.chmod(0o700)
    # Validate sudoers before installing any privileged command permission.
    with tempfile.NamedTemporaryFile() as candidate:
        candidate.write(RULE)
        candidate.flush()
        run('/usr/sbin/visudo', '-cf', candidate.name)
    for dst, data, mode in expected_files():
        put(dst, data, mode)
    run('/usr/bin/systemctl', 'daemon-reload')
    # Reload configuration only: never restart NetworkManager or touch eth0 profiles.
    run('/usr/bin/nmcli', 'general', 'reload', 'conf')
    run('/usr/sbin/runuser', '-u', 'pi', '--', '/usr/bin/python3', '/usr/local/lib/waagenbox/install-kiosk-autostart.py')
    # Preserve existing enabled/disabled state; no WLAN or browser is started here.
    return check()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true')
    group.add_argument('--install', action='store_true')
    args = parser.parse_args()
    try:
        if args.check:
            raise SystemExit(check())
        import fcntl
        lock = os.open('/run/waagenbox-service-wlan.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(lock, 'w') as guard:
            fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
            raise SystemExit(install())
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        # No subprocess output: never disclose local network configuration.
        print(json.dumps({'ok': False, 'error': str(error) if isinstance(error, ValueError) else 'System step failed; review prerequisites and run --check.'}))
        raise SystemExit(1)
