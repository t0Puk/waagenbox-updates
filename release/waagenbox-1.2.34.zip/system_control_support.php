<?php
function validateSystemControlAction(string $action): void {
    if (!in_array($action, ['kiosk_exit','reboot','poweroff'], true)) {
        throw new InvalidArgumentException('Ungültige Systemaktion.');
    }
}

function systemControlPiUid(): ?int {
    $uid = @fileowner('/home/pi');
    return $uid === false ? null : (int)$uid;
}

function systemControlProcessArgs(int $pid): array {
    if ($pid <= 1) return [];
    $raw = @file_get_contents('/proc/'.$pid.'/cmdline');
    if (!is_string($raw) || $raw === '') return [];
    return array_values(array_filter(explode("\0", $raw), static fn($part) => $part !== ''));
}

function systemControlProcessUid(int $pid): ?int {
    if ($pid <= 1) return null;
    $status = @file('/proc/'.$pid.'/status', FILE_IGNORE_NEW_LINES);
    if (!is_array($status)) return null;
    foreach ($status as $line) {
        if (str_starts_with($line, 'Uid:')) {
            $fields = preg_split('/\s+/', trim(substr($line, 4)));
            return isset($fields[0]) && ctype_digit((string)$fields[0]) ? (int)$fields[0] : null;
        }
    }
    return null;
}

function systemControlIsKioskWrapper(int $pid, int $uid): bool {
    if (systemControlProcessUid($pid) !== $uid) return false;
    $args = systemControlProcessArgs($pid);
    return count($args) >= 2
        && in_array($args[0], ['/bin/sh','/usr/bin/sh'], true)
        && $args[1] === '/usr/local/bin/waagenbox-kiosk';
}

function systemControlKioskRunning(): bool {
    $uid = systemControlPiUid();
    if ($uid === null) return false;

    $pidFile = '/run/user/'.$uid.'/waagenbox-kiosk.pid';
    $info = @lstat($pidFile);
    if (is_array($info) && (($info['mode'] ?? 0) & 0170000) === 0100000
        && (int)($info['uid'] ?? -1) === $uid && (((int)$info['mode']) & 0022) === 0) {
        $text = trim((string)@file_get_contents($pidFile));
        if (ctype_digit($text) && systemControlIsKioskWrapper((int)$text, $uid)) return true;
    }

    // Übergang von älteren Installationen ohne PID-Datei: nur exakt passende
    // Wrapper des Benutzers pi zählen. Es werden keinerlei Prozesse signalisiert.
    $matches = 0;
    foreach (glob('/proc/[0-9]*', GLOB_ONLYDIR) ?: [] as $path) {
        $name = basename($path);
        if (!ctype_digit($name)) continue;
        if (systemControlIsKioskWrapper((int)$name, $uid)) $matches++;
        if ($matches > 1) return false;
    }
    return $matches === 1;
}

function systemControlStatus(): array {
    $helper = '/usr/local/sbin/waagenbox-system-control';
    $installed = PHP_OS_FAMILY === 'Linux'
        && is_executable('/usr/bin/sudo')
        && is_executable($helper);

    $model = '';
    $rawModel = @file_get_contents('/proc/device-tree/model');
    if (is_string($rawModel)) $model = trim(rtrim($rawModel, "\0"));

    return [
        'ok'=>$installed,
        'message'=>$installed
            ? 'Systemsteuerung ist verfügbar.'
            : 'Systemsteuerung ist noch nicht installiert. Bitte die separate Systeminstallation ausführen.',
        'installed'=>$installed,
        'kiosk_running'=>$installed ? systemControlKioskRunning() : false,
        'model'=>$model,
        'raspberry_pi'=>stripos($model, 'raspberry pi') !== false,
    ];
}

function systemControlRequest(string $action): array {
    validateSystemControlAction($action);
    $helper = '/usr/local/sbin/waagenbox-system-control';
    if (PHP_OS_FAMILY !== 'Linux' || !is_executable('/usr/bin/sudo') || !is_executable($helper)) {
        return [
            'ok'=>false,
            'message'=>'Systemsteuerung ist noch nicht installiert. Bitte die separate Systeminstallation ausführen.',
            'installed'=>false,
        ];
    }
    $process = proc_open(
        ['/usr/bin/sudo', '-n', $helper],
        [0=>['pipe','r'], 1=>['pipe','w'], 2=>['file','/dev/null','a']],
        $pipes
    );
    if (!is_resource($process)) {
        return ['ok'=>false,'message'=>'Systemhelper konnte nicht gestartet werden.','installed'=>true];
    }
    fwrite($pipes[0], json_encode(['action'=>$action], JSON_THROW_ON_ERROR));
    fclose($pipes[0]);
    stream_set_blocking($pipes[1], false);
    $output = '';
    $running = true;
    $deadline = microtime(true) + 12;
    do {
        $output .= stream_get_contents($pipes[1], 8192);
        $status = proc_get_status($process);
        $running = (bool)$status['running'];
        if (!$running) break;
        usleep(50000);
    } while (microtime(true) < $deadline && strlen($output) < 16384);
    if ($running) proc_terminate($process);
    $output .= stream_get_contents($pipes[1], 8192);
    fclose($pipes[1]);
    proc_close($process);
    $result = json_decode($output, true);
    if (!is_array($result) || !array_key_exists('ok', $result) || !isset($result['message'])) {
        return ['ok'=>false,'message'=>'Systemhelper nicht erreichbar, nicht freigegeben oder Zeitlimit überschritten.','installed'=>true];
    }
    $result['installed'] = true;
    return $result;
}
