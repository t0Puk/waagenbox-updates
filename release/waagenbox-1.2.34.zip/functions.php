<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/version.php';
require_once __DIR__ . '/auth.php';

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function currentOwnerId(): int {
    global $mobileContextUserId;
    if(!empty($mobileContextUserId)) return (int)$mobileContextUserId;
    $u=currentUser();
    if($u) return (int)$u['id'];
    static $ownerId = null;
    if($ownerId !== null) return $ownerId;
    try {
        $ownerId = (int)(db()->query("SELECT id FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1")->fetchColumn() ?: 0);
    } catch(Throwable $e) { $ownerId = 0; }
    return $ownerId;
}

function useMobileContextByToken(string $token): ?int {
    global $mobileContextUserId;
    $pdo=db();
    $s=$pdo->prepare('SELECT owner_user_id FROM remotes WHERE mobile_token=? LIMIT 1');
    $s->execute([$token]);
    $uid=$s->fetchColumn();
    if($uid===false) return null;
    $mobileContextUserId=(int)$uid;
    $pdo->exec('SET @ajp_user_id = '.(int)$mobileContextUserId);
    return $mobileContextUserId;
}

function redirect(string $url): never { header('Location: ' . $url); exit; }
function flash(?string $message = null): ?string {
    if ($message !== null) { $_SESSION['flash'] = $message; return null; }
    $m = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $m;
}

function activeField(): ?array {
    $stmt = db()->query('SELECT * FROM `fields` WHERE owner_user_id = '.(int)currentOwnerId().' AND active = 1 ORDER BY id DESC LIMIT 1');
    return $stmt->fetch() ?: null;
}
function activeFields(): array {
    return db()->query('SELECT * FROM `fields` WHERE owner_user_id = '.(int)currentOwnerId().' AND active = 1 ORDER BY name ASC')->fetchAll();
}

function demoMode(): bool {
    $default = (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) ? '1' : '0';
    return appSetting('demo_mode', $default) === '1';
}
function diniConfig(): array {
    static $config = null;
    if ($config !== null) return $config;
    $defaults = require __DIR__ . '/config/dini.php';
    $enabled = !demoMode() && appSetting('dini_enabled', !empty($defaults['enabled']) ? '1' : '0') === '1';
    $host = appSetting('dini_host', (string)$defaults['host']);
    $port = (int)appSetting('dini_port', (string)$defaults['port']);
    $timeout = (float)appSetting('dini_timeout', (string)$defaults['timeout']);
    $config = ['enabled'=>$enabled,'host'=>$host,'port'=>$port,'timeout'=>$timeout];
    return $config;
}
function dini(): ?Dini3590 {
    static $instance = null;
    $cfg = diniConfig();
    if (empty($cfg['enabled'])) return null;
    if ($instance === null) {
        require_once __DIR__ . '/hardware/Dini3590.php';
        $instance = new Dini3590((string)$cfg['host'], (int)$cfg['port'], (float)$cfg['timeout']);
    }
    return $instance;
}
function testWeight(): float {
    try {
        $s=db()->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
        $s->execute([currentOwnerId(),'test_weight']);
        $v=$s->fetchColumn();
        return $v===false ? 0.0 : max(0.0,(float)$v);
    } catch(Throwable $e) { return 0.0; }
}
function setTestWeight(float $weight): void {
    $s=db()->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
    $s->execute([currentOwnerId(),'test_weight',number_format(max(0.0,$weight),3,'.','')]);
}
function scaleDisplayWeight(float $weight): float { return round(max(0.0,$weight) / 5.0) * 5.0; }
function formatScaleWeight(float $weight): string { return number_format(scaleDisplayWeight($weight),0,',','.'); }
function formatWeight(float $weight): string { return number_format(round($weight / 5.0) * 5.0, 0, ',', '.'); }
function currentWeight(): float {
    $scale = dini();
    if ($scale === null) return testWeight();
    try {
        $r = $scale->readWeight();
        $status = strtoupper((string)($r['status'] ?? ''));
        if (in_array($status, ['OL','UL','ER'], true)) return 0.0;
        return max(0.0, (float)($r['weight'] ?? 0));
    } catch (Throwable $e) {
        return 0.0;
    }
}
function weightStatus(): string {
    $scale = dini();
    if ($scale === null) return currentWeight() > 0 ? 'Gewicht erkannt' : 'Bereit';
    try {
        $r = $scale->readWeight();
        $status = strtoupper((string)($r['status'] ?? ''));
        return match ($status) {
            'OL' => 'Überlast',
            'UL' => 'Unterlast',
            'ER' => 'Waagenfehler',
            'ST' => 'Gewicht erkannt',
            default => ((float)($r['weight'] ?? 0) > 0 ? 'Gewicht erkannt' : 'Bereit'),
        };
    } catch (Throwable $e) {
        return 'Waage nicht erreichbar';
    }
}
function scaleProcessingActive(): bool {
    try {
        $v = appSetting('scale_processing_until', '0');
        return (int)$v > time();
    } catch(Throwable $e) { return false; }
}
function scaleStatusKey(): string {
    if (scaleProcessingActive()) return 'processing';
    return pendingWeighing() ? 'waiting' : 'ready';
}
function scaleStatusLabel(): string {
    if (scaleProcessingActive()) return 'Wiegung wird verarbeitet …';
    return pendingWeighing() ? 'Wiegung gestartet – wartet auf Überfahrt' : 'Bereit für nächste Wiegung';
}
function startSecondScaleWeighing(): void {
    $scale = dini();
    if ($scale !== null) $scale->startSecondWeighing();
}
function startFirstScaleWeighing(): void {
    $scale = dini();
    if ($scale !== null) $scale->startFirstWeighing();
}

function nav(string $active): void {
    $items = [
      'dashboard'=>'Dashboard','vehicles'=>'Fahrzeuge','customers'=>'Kunden','products'=>'Produkte','fields'=>'Schläge','remotes'=>'Fernbedienungen','weighings'=>'Wiegungen','settings'=>'Einstellungen'
    ];
    echo '<nav class="nav">';
    foreach ($items as $key=>$label) {
        echo '<a class="'.($active===$key?'active':'').'" href="'.($key==='dashboard'?'index.php':$key.'.php').'">'.h($label).'</a>';
    }
    echo '<a class="button" href="logout.php">Abmelden</a></nav>';
}
function layoutStart(string $title, string $active=''): void {
    $brand = appSetting('brand_name','AJP WAAGE');
    if ($brand === '') $brand = 'AJP WAAGE';
    echo '<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>'.h($title).' – '.h($brand).'</title><meta name="csrf-token" content="'.h(csrfToken()).'"><script>function csrfHeaders(){return {"X-CSRF-Token":document.querySelector("meta[name=csrf-token]")?.content||""};}</script><link rel="stylesheet" href="assets/style.css"></head><body class="page-'.h($active).'">';
    echo '<header class="top"><div class="brand-block"><div class="brand">'.h($brand).'</div><div class="sub">Waagensteuerung · Weboberfläche · Version '.h(APP_VERSION).'</div><div class="dashboard-clock-header"><span id="dashboardClock">–</span></div></div>';
    nav($active);
    echo '</header><main class="container">';
    if ($m = flash()) echo '<div class="flash">'.h($m).'</div>';
}
function layoutEnd(bool $dashboardCopyright = false): void {
    if (passwordProtectionRequired()) echo '<script src="assets/session.js"></script>';
    echo '</main><footer>AJP Waagensteuerung · Version '.h(APP_VERSION).($dashboardCopyright ? '<br>Copyright by Tobias Purk' : '').'</footer>';
    echo '<script>function updateDashboardClock(){const e=document.getElementById("dashboardClock");if(e)e.textContent=new Date().toLocaleString("de-DE",{dateStyle:"short",timeStyle:"medium"});}updateDashboardClock();setInterval(updateDashboardClock,1000);</script>';
    echo '</body></html>';
}

function appSetting(string $key, string $default=''): string {
    static $cache = [];
    $ownerId = currentOwnerId();
    $cacheKey = $ownerId.':'.$key;
    if (array_key_exists($cacheKey, $cache)) return $cache[$cacheKey];
    try {
        $s = db()->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');
        $s->execute([$ownerId,$key]);
        $v = $s->fetchColumn();
        return $cache[$cacheKey] = ($v===false ? $default : (string)$v);
    } catch(Throwable $e) { return $cache[$cacheKey] = $default; }
}
function saveAppSetting(string $key, string $value): void {
    $s = db()->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
    $s->execute([currentOwnerId(),$key,$value]);
}
function diniConnectionStatus(): array {
    $cfg = diniConfig();
    if (empty($cfg['enabled'])) return ['state'=>'disabled','label'=>'Nicht aktiviert','detail'=>'Die Verbindung zum Waagencomputer ist derzeit deaktiviert.'];
    try {
        $scale = dini();
        if ($scale === null) return ['state'=>'disabled','label'=>'Nicht aktiviert','detail'=>'Die Verbindung ist deaktiviert.'];
        $version = trim($scale->identify());
        return ['state'=>'connected','label'=>'Verbunden','detail'=>$version !== '' ? 'Antwort: '.$version : 'Waagencomputer antwortet.'];
    } catch(Throwable $e) {
        return ['state'=>'error','label'=>'Nicht erreichbar','detail'=>$e->getMessage()];
    }
}

function updateBaseUrl(): string {
    $saved = rtrim(trim(appSetting('update_server_url','')), '/');
    $channelDefault = (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) ? 'staging' : 'release';
    $channel = appSetting('update_channel', $channelDefault);
    if (!in_array($channel, ['release','staging'], true)) $channel = $channelDefault;

    // Die beiden offiziellen Kanäle werden zentral geschaltet. Eine ausdrücklich
    // abweichende Server-URL bleibt für Sonderinstallationen erhalten.
    $official = ['https://update.ajp-bg.de/release','https://update.ajp-bg.de/staging'];
    if ($saved === '' || in_array($saved, $official, true)) {
        return 'https://update.ajp-bg.de/'.$channel;
    }
    return $saved;
}
function updateCheckUrl(): string {
    return updateBaseUrl().'/manifest.json';
}
function updateIgnoredVersion(): string { return appSetting('update_ignored_version',''); }
function setUpdateIgnoredVersion(string $version): void { saveAppSetting('update_ignored_version',$version); }
function updateSnoozedUntil(): string { return appSetting('update_snoozed_until',''); }
function setUpdateSnoozedUntil(string $until): void { saveAppSetting('update_snoozed_until',$until); }
function compareAppVersions(string $a,string $b): int { return version_compare($a,$b); }

function rollbackBackupRoot(): string {
    $default = '/var/lib/waagebox/rollback';
    if (!defined('ROLLBACK_BACKUP_ROOT')) return $default;
    $override = ROLLBACK_BACKUP_ROOT;
    if (!is_string($override) || $override === '' || str_contains($override, "\0") || $override === '/' ||
        !preg_match('~^/(?:[^/\\0]+/)*[^/\\0]+$~D', $override) ||
        (in_array('..', explode('/', $override), true) || in_array('.', explode('/', $override), true))) {
        throw new RuntimeException('Ungültiger ROLLBACK_BACKUP_ROOT. Erwartet wird ein absoluter Linux-Pfad ohne relative Bestandteile.');
    }
    return $override;
}
function rollbackInfo(): ?array {
    $file=rollbackBackupRoot().'/metadata.json';
    if(!is_file($file)) return null;
    $data=json_decode((string)@file_get_contents($file),true);
    if(!is_array($data) || empty($data['previous_version']) || !is_dir(rollbackBackupRoot().'/app') || !is_file(rollbackBackupRoot().'/database.sql')) return null;
    return $data;
}
function numOrNull($v) {
    return ($v === '' || $v === null) ? null : (float)str_replace(',', '.', (string)$v);
}
function pendingWeighing(): ?array {
    try { $s=db()->prepare('SELECT * FROM weighing_state WHERE owner_user_id=? AND id=1'); $s->execute([currentOwnerId()]); return $s->fetch() ?: null; }
    catch(Throwable $e) { return $_SESSION['pending_weighing'] ?? null; }
}
function setPendingWeighing(float $first, ?int $vehicleId=null, ?int $remoteId=null, string $trigger='manual', ?int $fieldId=null, ?int $customerId=null, ?int $productId=null): void {
    try {
        $s=db()->prepare('INSERT INTO weighing_state (owner_user_id,id,first_weight,vehicle_id,remote_id,field_id,customer_id,product_id,trigger_type,started_at) VALUES (?,1,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE first_weight=VALUES(first_weight),vehicle_id=VALUES(vehicle_id),remote_id=VALUES(remote_id),field_id=VALUES(field_id),customer_id=VALUES(customer_id),product_id=VALUES(product_id),trigger_type=VALUES(trigger_type),started_at=VALUES(started_at)');
        $s->execute([currentOwnerId(),$first,$vehicleId,$remoteId,$fieldId,$customerId,$productId,$trigger]);
        if ($trigger !== 'manual') startSecondScaleWeighing();
    } catch(Throwable $e) {
        $_SESSION['pending_weighing'] = ['first_weight'=>$first,'vehicle_id'=>$vehicleId,'remote_id'=>$remoteId,'field_id'=>$fieldId,'customer_id'=>$customerId,'product_id'=>$productId,'trigger_type'=>$trigger,'started_at'=>date('Y-m-d H:i:s')];
        throw $e;
    }
}
function fieldName(int $fieldId): string {
    $stmt = db()->prepare('SELECT name FROM `fields` WHERE owner_user_id=? AND id=?'); $stmt->execute([currentOwnerId(),$fieldId]);
    return (string)($stmt->fetchColumn() ?: 'Unbekannter Schlag');
}
function vehicleLabel(int $vehicleId): string {
    $stmt = db()->prepare('SELECT CONCAT(plate, IF(name IS NULL OR name="", "", CONCAT(" – ", name))) FROM vehicles WHERE owner_user_id=? AND id=?');
    $stmt->execute([currentOwnerId(),$vehicleId]); return (string)($stmt->fetchColumn() ?: 'Unbekanntes Fahrzeug');
}
function customerName(int $id): string { $s=db()->prepare('SELECT name FROM customers WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$id]); return (string)($s->fetchColumn() ?: 'Unbekannter Kunde'); }
function productName(int $id): string { $s=db()->prepare('SELECT name FROM products WHERE owner_user_id=? AND id=?'); $s->execute([currentOwnerId(),$id]); return (string)($s->fetchColumn() ?: 'Unbekanntes Produkt'); }
function remoteAssignment(PDO $pdo, string $table, string $column, int $remoteId): ?int {
    $q=$pdo->prepare("SELECT $column FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 ORDER BY is_default DESC, $column LIMIT 1");
    $q->execute([currentOwnerId(),$remoteId]);
    $first=$q->fetchColumn();
    if($first===false) return null;
    $c=$pdo->prepare("SELECT COUNT(*) FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1");
    $c->execute([currentOwnerId(),$remoteId]);
    if((int)$c->fetchColumn()>1){
        $q=$pdo->prepare("SELECT $column FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 AND is_default=1 LIMIT 1");
        $q->execute([currentOwnerId(),$remoteId]);
        $v=$q->fetchColumn();
        return $v===false?null:(int)$v;
    }
    return (int)$first;
}
function mobileRemoteUrl(string $token): string {
    return mobileRemoteBaseUrl().'/mobile_remote.php?t='.rawurlencode($token);
}

function mobileRemoteBaseUrl(): string {
    // Fester öffentlicher Endpunkt dieser Installation; unabhängig von alten
    // Datenbankwerten, Host-Header und lokalem Installationspfad.
    return 'https://waage-ajp.de';
}


function cameraEnabled(): bool { return appSetting('camera_enabled','0') === '1'; }
function cameraStreamUrl(): string { return trim(appSetting('camera_stream_url','')); }
function cameraSnapshotEnabled(): bool { return appSetting('camera_snapshot_enabled','0') === '1'; }
function cameraSnapshotUrl(): string { return trim(appSetting('camera_snapshot_url','')); }
function cameraSnapshotRelativePath(int $weighingId): string { return 'uploads/camera/weighing_'.$weighingId.'.jpg'; }
function cameraSnapshotAbsolutePath(int $weighingId): string { return __DIR__ . '/' . cameraSnapshotRelativePath($weighingId); }
function deleteCameraSnapshot(int $weighingId): void { $p=cameraSnapshotAbsolutePath($weighingId); if(is_file($p)) @unlink($p); }
function captureCameraSnapshot(int $weighingId): bool {
    if (!cameraEnabled() || !cameraSnapshotEnabled()) return false;
    $url=cameraSnapshotUrl();
    if ($url==='') return false;
    if (!preg_match('~^https?://~i',$url)) return false;
    $dir=dirname(cameraSnapshotAbsolutePath($weighingId));
    if (!is_dir($dir)) @mkdir($dir,0775,true);
    if (!is_dir($dir) || !is_writable($dir)) return false;
    $data=false;
    if (function_exists('curl_init')) {
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>8,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_USERAGENT=>'AJP-Waagenbox-Kamera/1.0']);
        $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $type=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE); curl_close($ch);
        if ($body!==false && $code>=200 && $code<400 && strlen($body)>100) $data=$body;
    }
    if ($data===false) {
        $ctx=stream_context_create(['http'=>['timeout'=>8,'follow_location'=>1,'user_agent'=>'AJP-Waagenbox-Kamera/1.0'],'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $body=@file_get_contents($url,false,$ctx);
        if ($body!==false && strlen($body)>100) $data=$body;
    }
    if ($data===false) return false;
    $img=@imagecreatefromstring($data);
    if (!$img) return false;
    $path=cameraSnapshotAbsolutePath($weighingId);
    $ok=@imagejpeg($img,$path,88); imagedestroy($img);
    return $ok && is_file($path) && filesize($path)>0;
}

function completePendingWeighing(float $secondWeight, string $notes=''): int {
    $pending = pendingWeighing();
    if (!$pending) throw new RuntimeException('Es ist keine laufende Wiegung vorhanden.');
    if ($secondWeight <= 0) throw new RuntimeException('Auf der Waage steht noch kein gültiges Gewicht.');
    $pdo = db();
    $net = $secondWeight - (float)$pending['first_weight'];
    $stmt = $pdo->prepare('INSERT INTO weighings (owner_user_id,vehicle_id,field_id,customer_id,product_id,remote_id,first_weight,second_weight,net_weight,trigger_type,scale_status,notes,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())');
    $stmt->execute([currentOwnerId(),!empty($pending['vehicle_id']) ? (int)$pending['vehicle_id'] : null,!empty($pending['field_id']) ? (int)$pending['field_id'] : null,!empty($pending['customer_id']) ? (int)$pending['customer_id'] : null,!empty($pending['product_id']) ? (int)$pending['product_id'] : null,!empty($pending['remote_id']) ? (int)$pending['remote_id'] : null,$pending['first_weight'],$secondWeight,$net,$pending['trigger_type'] ?? 'manual','completed',trim($notes)]);
    $id = (int)$pdo->lastInsertId();
    // Ein Kameraschnappschuss gehört zur Wiegung, blockiert den Abschluss aber nicht,
    // falls die Kamera nicht erreichbar ist.
    captureCameraSnapshot($id);
    clearPendingWeighing();

    // Im Testbetrieb (kein Dini-Waagencomputer aktiv) wird die simulierte
    // Waage nach erfolgreichem Abschluss wieder auf 0 kg gesetzt.
    if (dini() === null) setTestWeight(0.0);
    // Die rote Verarbeitungsphase gilt für Web-Testbetrieb und Raspberry.
    setScaleProcessing(5);

    return $id;
}
function clearPendingWeighing(): void { try { $s=db()->prepare('DELETE FROM weighing_state WHERE owner_user_id=? AND id=1'); $s->execute([currentOwnerId()]); } catch(Throwable $e) {} unset($_SESSION['pending_weighing']); }

function setScaleProcessing(int $seconds = 5): void {
    try {
        $u = db()->prepare('INSERT INTO settings (owner_user_id,`key`,`value`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');
        $u->execute([currentOwnerId(),'scale_processing_until',(string)(time()+max(1,$seconds))]);
    } catch(Throwable $e) {}
}
