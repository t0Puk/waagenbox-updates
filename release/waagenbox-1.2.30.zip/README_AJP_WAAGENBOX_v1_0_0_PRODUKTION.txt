AJP Waagenbox v1.1.0 – Produktionsstand

Diese Version ist für den lokalen Betrieb auf dem Raspberry Pi vorgesehen.

Wichtige Punkte:
- Kein Demo-Modus und keine Demo-Benutzerverwaltung mehr.
- Anmeldung nur über den vorhandenen Administrator.
- Daten bleiben lokal in MariaDB.
- Dini-3590ETKR-Anbindung ist über config/dini.php vorbereitet.
- QR-Fernbedienungen erhalten beim Anlegen automatisch einen eigenen Token.
- Bestehende Fernbedienungen ohne Token werden beim Aufruf der QR-Seite automatisch repariert.
- GPS-Prüfung bleibt als Option in den Einstellungen erhalten.

Ersteinrichtung / Update:
1. Dateien nach /var/www/waage kopieren.
2. migration_v1_0_production.sql einmal gegen die Datenbank ausführen.
3. Apache-Konfiguration unverändert lassen.
4. Dini-IP und TCP-Port erst nach dem Hardware-Netzwerktest in config/dini.php eintragen.

Hinweis:
Die Dini-TCP-Portnummer ist absichtlich nicht vorgegeben, solange sie am konkreten 3590ETKR/ETHKR-1 nicht getestet wurde.


Version 1.1.0: Lokaler Wagenbetrieb ohne Login; Testgewicht kann bei deaktivierter Dini-Anbindung gesetzt werden.
