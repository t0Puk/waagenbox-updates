# AJP Waagenbox – Web-Entwicklungsstand v1.2.3

Diese Version basiert auf der bisher funktionierenden Web-Demo und enthält die Funktionen des aktuellen Raspberry-Pi-Stands v1.2.3.

Web-Entwicklungsbetrieb:
- IONOS-Datenbank der bisherigen Demo bleibt die Datenbasis.
- Dini ist deaktiviert; Testgewicht kann verwendet werden.
- Die aktuelle Pi-Oberfläche/Funktionen wurden übernommen.
- QR-Fernbedienungen, GPS, Einstellungen, Updates und Tabellen entsprechen dem aktuellen Stand.
- Die Datei config.php bleibt IONOS-spezifisch und darf nicht in ein Raspberry-Produktionspaket übernommen werden.

Vor dem ersten Aufruf auf der bisherigen IONOS-Datenbank einmal migration_v1_2_3_web.sql ausführen.
