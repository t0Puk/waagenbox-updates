#!/bin/sh
set -eu

APP_DIR="${APP_DIR:-/var/www/waage}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/waagenbox}"
SYSTEMD_DIR="${SYSTEMD_DIR:-/etc/systemd/system}"

SERVICE_SRC="$APP_DIR/systemd/waagenbox-backup.service"
TIMER_SRC="$APP_DIR/systemd/waagenbox-backup.timer"

SERVICE_DST="$SYSTEMD_DIR/waagenbox-backup.service"
TIMER_DST="$SYSTEMD_DIR/waagenbox-backup.timer"

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: Dieses Script muss als root ausgeführt werden." >&2
    exit 1
fi

if [ ! -f "$SERVICE_SRC" ]; then
    echo "FEHLER: Service-Datei fehlt: $SERVICE_SRC" >&2
    exit 1
fi

if [ ! -f "$TIMER_SRC" ]; then
    echo "FEHLER: Timer-Datei fehlt: $TIMER_SRC" >&2
    exit 1
fi

if [ ! -f "$APP_DIR/backup.php" ]; then
    echo "FEHLER: backup.php fehlt: $APP_DIR/backup.php" >&2
    exit 1
fi

systemd-analyze verify \
    "$SERVICE_SRC" \
    "$TIMER_SRC"

install -d \
    -o www-data \
    -g www-data \
    -m 0750 \
    "$BACKUP_DIR"

install -o root -g root -m 0644 \
    "$SERVICE_SRC" \
    "$SERVICE_DST"

install -o root -g root -m 0644 \
    "$TIMER_SRC" \
    "$TIMER_DST"

systemd-analyze verify \
    "$SERVICE_DST" \
    "$TIMER_DST"

if [ "${TEST_MODE:-0}" = "1" ]; then
    echo
    echo "TEST_MODE: Unit-Dateien wurden installiert und geprüft."
    echo "TEST_MODE: systemctl wurde nicht ausgeführt."
    exit 0
fi

systemctl daemon-reload

systemctl enable --now waagenbox-backup.timer

echo
echo "Waagenbox-Backup-Timer wurde installiert."
echo
systemctl status waagenbox-backup.timer --no-pager -l
