AJP Waage v0.6.3 – QR/Mobile Ablauf

Änderungen:
- Nach QR-Start gibt es nur noch einen einzigen Tastendruck: WIEGUNG STARTEN.
- Das Smartphone wartet anschließend auf ein positives aktuelles Waagengewicht.
- In der Demo gilt die Wiegung 1 Sekunde nach Erkennung des positiven Gewichts als beendet. Danach wird die Wiegung automatisch gespeichert und das Demo-Gewicht auf 0 kg zurückgesetzt.
- Die Erfolgsmeldung bleibt 5 Sekunden sichtbar; anschließend wird die mobile Wiegeoberfläche einfach neu geladen. Kein window.close() mehr.
- In der späteren echten Anlage beendet der Dini-Wiegecomputer die dynamische Achsverwiegung; die Weboberfläche verarbeitet nur das aktuelle Gewicht und erkennt den abgeschlossenen Zustand über die bereitgestellte Wiegelogik.

Upload:
1. ZIP-Inhalt nach /waage/software hochladen und vorhandene Dateien überschreiben.
2. config.php nicht verändern.
3. Keine neue SQL-Migration erforderlich.
