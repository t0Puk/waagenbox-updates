#!/bin/sh
set -eu

echo "Dieser Installer ist veraltet und wurde aus Sicherheitsgründen deaktiviert."
echo
echo "Waagenbox-Backups werden jetzt über systemd als Benutzer www-data ausgeführt."
echo
echo "Bitte verwenden:"
echo "  sudo /var/www/waage/install_backup_systemd.sh"
echo
exit 1
