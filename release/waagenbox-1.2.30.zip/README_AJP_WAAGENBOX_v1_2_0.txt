AJP Waagenbox v1.2.0 – Produktionsversion

Änderungen:
- Kein Login für den lokalen Wagenbetrieb.
- Dashboard: Datum/Uhrzeit, sichtbare Statusampel, Kamera-Platzhalter über die gesamte Breite.
- Einstellungen mit Unterreitern: Allgemein, Standort/GPS, Waagencomputer, Backup.
- Frei definierbarer Name der Waage im Kopfbereich.
- GPS-Prüfung kann vollständig deaktiviert werden; mobile Fernbedienung funktioniert dann ohne Standortfreigabe.
- Dini-3590-Verbindung: IP, TCP-Port und Timeout in der Weboberfläche einstellbar; Statusanzeige Verbunden/Nicht erreichbar/Nicht aktiviert.
- Automatische lokale Datenbank-Backups mit Aufbewahrung; optionaler Upload nach Google Drive über rclone.
- Wiegungstabelle erhält eine feste Mindestbreite, sodass Aktionsbuttons nicht abgeschnitten sind.
- Mobile QR-Fernbedienung bleibt mit ihrem Token aktiv, bis unter Fernbedienungen erneut „QR-Code“ gedrückt wird. Dann wird der alte Token sofort ungültig und ein neuer erzeugt.

Backup-Automatik:
- backup.php wird als Root-Cronjob alle 5 Minuten aufgerufen und entscheidet anhand der gespeicherten Einstellungen, ob ein Backup fällig ist.
- Einmalig auf dem Pi ausführen: sudo /var/www/waage/install_backup_cron.sh
- Für Google Drive zuerst rclone installieren und ein Google-Drive-Remote einrichten; danach Remote-Name und Zielordner unter Einstellungen > Backup eintragen.
