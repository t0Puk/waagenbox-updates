-- AJP Waagensteuerung v1.0.0 – Umstellung von Demo-/Mandantenbetrieb auf lokale Produktionsinstallation
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

SET @admin_id := (SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1);

-- Nicht-Administrator-Zugänge und deren Daten entfernen. Der vorhandene
-- Administrator-Datenbestand bleibt erhalten.
DELETE FROM weighing_state WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM remote_fields WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM remote_customers WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM remote_products WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM weighings WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM remotes WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM vehicles WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM fields WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM customers WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM products WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM settings WHERE owner_user_id IN (SELECT id FROM users WHERE role <> 'admin');
DELETE FROM users WHERE role <> 'admin';

-- Alle vorhandenen Produktionsdaten gehören dem Administrator.
UPDATE settings SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE vehicles SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE fields SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE remotes SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE customers SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE products SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE weighings SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE weighing_state SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE remote_fields SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE remote_customers SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;
UPDATE remote_products SET owner_user_id=@admin_id WHERE owner_user_id<>@admin_id;

-- Bereits vorhandene Fernbedienungen bekommen einen sicheren QR-Token, falls
-- dieser noch fehlt (z. B. Fernbedienungen, die vor v0.6 angelegt wurden).
UPDATE remotes
SET mobile_token = SHA2(CONCAT(UUID(), '-', RAND(), '-', id, '-', code), 256)
WHERE mobile_token IS NULL OR mobile_token='';

-- Authentifizierung bleibt auf einen lokalen Administrator beschränkt.
UPDATE users SET role='admin', expires_at=NULL WHERE role='admin';

-- Trigger auf den produktiven DB-Kontext umstellen.
DROP TRIGGER IF EXISTS trg_settings_owner;
DROP TRIGGER IF EXISTS trg_vehicles_owner;
DROP TRIGGER IF EXISTS trg_fields_owner;
DROP TRIGGER IF EXISTS trg_remotes_owner;
DROP TRIGGER IF EXISTS trg_customers_owner;
DROP TRIGGER IF EXISTS trg_products_owner;
DROP TRIGGER IF EXISTS trg_weighings_owner;
DROP TRIGGER IF EXISTS trg_weighing_state_owner;
DROP TRIGGER IF EXISTS trg_remote_fields_owner;
DROP TRIGGER IF EXISTS trg_remote_customers_owner;
DROP TRIGGER IF EXISTS trg_remote_products_owner;

DELIMITER $$
CREATE TRIGGER trg_settings_owner BEFORE INSERT ON settings FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_vehicles_owner BEFORE INSERT ON vehicles FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_fields_owner BEFORE INSERT ON fields FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remotes_owner BEFORE INSERT ON remotes FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_customers_owner BEFORE INSERT ON customers FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_products_owner BEFORE INSERT ON products FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_weighings_owner BEFORE INSERT ON weighings FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_weighing_state_owner BEFORE INSERT ON weighing_state FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_fields_owner BEFORE INSERT ON remote_fields FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_customers_owner BEFORE INSERT ON remote_customers FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
CREATE TRIGGER trg_remote_products_owner BEFORE INSERT ON remote_products FOR EACH ROW BEGIN IF NEW.owner_user_id IS NULL OR NEW.owner_user_id=0 THEN SET NEW.owner_user_id=COALESCE(@ajp_user_id,0); END IF; IF NEW.owner_user_id=0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Kein Benutzerkontext'; END IF; END$$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=1;
