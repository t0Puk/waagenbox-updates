<?php
require_once __DIR__.'/functions.php';
requireLogin();
$pdo=db(); $id=(int)($_GET['id']??$_POST['id']??0); $error=null;
if($id<=0) { http_response_code(404); exit('Wiegung nicht gefunden'); }
if($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    $fid=(int)($_POST['field_id']??0); $cid=(int)($_POST['customer_id']??0); $pid=(int)($_POST['product_id']??0);
    if($fid>0){$s=$pdo->prepare('SELECT id FROM fields WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$fid]);if(!$s->fetchColumn())throw new RuntimeException('Schlag nicht gefunden.');}
    if($cid>0){$s=$pdo->prepare('SELECT id FROM customers WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$cid]);if(!$s->fetchColumn())throw new RuntimeException('Kunde nicht gefunden.');}
    if($pid>0){$s=$pdo->prepare('SELECT id FROM products WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$pid]);if(!$s->fetchColumn())throw new RuntimeException('Produkt nicht gefunden.');}
    $s=$pdo->prepare('UPDATE weighings SET field_id=?,customer_id=?,product_id=?,notes=? WHERE owner_user_id=? AND id=?');
    $s->execute([$fid?:null,$cid?:null,$pid?:null,trim((string)($_POST['notes']??'')),currentOwnerId(),$id]);
    flash('Wiegung wurde geändert.'); redirect('weighings.php');
  } catch(Throwable $e){$error=$e->getMessage();}
}
$s=$pdo->prepare('SELECT * FROM weighings WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$id]);$w=$s->fetch();if(!$w){http_response_code(404);exit('Wiegung nicht gefunden');}
$fields=$pdo->query('SELECT id,name,crop,year FROM fields WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();
$customers=$pdo->query('SELECT id,name FROM customers WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();
$products=$pdo->query('SELECT id,name FROM products WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();
layoutStart('Wiegung bearbeiten','weighings');
if($error)echo '<div class="flash error"><strong>Wiegung konnte nicht geändert werden.</strong><br>'.h($error).'</div>';
?>
<div class="toolbar"><h1>Wiegung bearbeiten</h1><a class="button" href="weighings.php">← Zurück</a></div>
<div class="card"><p><strong>Datum:</strong> <?=h($w['created_at'])?></p><p><strong>Gewichte:</strong> <?=formatWeight((float)$w['first_weight'])?> kg → <?=formatWeight((float)$w['second_weight'])?> kg = <strong><?=formatWeight((float)$w['net_weight'])?> kg</strong></p>
<form method="post"><input type="hidden" name="id" value="<?=$id?>"><div class="form-grid">
<div><label>Kunde (optional)</label><select name="customer_id"><option value="0">Kein Kunde</option><?php foreach($customers as $x):?><option value="<?=$x['id']?>" <?=$w['customer_id']==$x['id']?'selected':''?>><?=h($x['name'])?></option><?php endforeach;?></select></div>
<div><label>Produkt (optional)</label><select name="product_id"><option value="0">Kein Produkt</option><?php foreach($products as $x):?><option value="<?=$x['id']?>" <?=$w['product_id']==$x['id']?'selected':''?>><?=h($x['name'])?></option><?php endforeach;?></select></div>
<div><label>Schlag (optional)</label><select name="field_id"><option value="0">Kein Schlag</option><?php foreach($fields as $x):?><option value="<?=$x['id']?>" <?=$w['field_id']==$x['id']?'selected':''?>><?=h($x['name'])?></option><?php endforeach;?></select></div>
<div class="full"><label>Notizen</label><textarea name="notes"><?=h($w['notes']??'')?></textarea></div></div><p><button class="button primary">Änderungen speichern</button></p></form></div>
<?php layoutEnd(); ?>
