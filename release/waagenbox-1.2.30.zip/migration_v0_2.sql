-- WägeSoftware v0.2
-- Macht Wiegungen ohne Fahrzeug möglich. Bestehende Daten bleiben erhalten.
ALTER TABLE `weighings` MODIFY `vehicle_id` INT UNSIGNED NULL;
