<?php
require_once __DIR__.'/functions.php';
requireLogin();
if(isset($_GET['update']) && $_GET['update']==='success'){
    $v=trim((string)($_GET['v']??''));
    flash($v!=='' ? 'Update erfolgreich installiert. Neue Version: v'.$v.'.' : 'Update erfolgreich installiert.');
}
layoutStart('Dashboard','dashboard');
$activeFields = activeFields();
$activeVehicleCount = (int)db()->query('SELECT COUNT(*) FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1')->fetchColumn();
$activeFieldCount = (int)db()->query('SELECT COUNT(*) FROM `fields` WHERE owner_user_id='.(int)currentOwnerId().' AND active=1')->fetchColumn();
?>
<div class="dashboard-top-grid">
  <section class="card weight-card">
    <div class="eyebrow">AKTUELLES GEWICHT</div>
    <div id="weight" class="weight"><?=formatScaleWeight(currentWeight())?> <span>kg</span></div>
    <div id="weightStatus" class="status"><?=h(weightStatus())?></div>
    <div class="actions"><a class="button primary" href="weighing.php">Manuelle Wiegung</a><a class="button" href="vehicles.php">Fahrzeug wählen</a></div>
  </section>

  <section class="card scale-light-card" aria-live="polite">
    <div class="eyebrow">WAAGENSTATUS</div>
    <div id="scaleLight" class="scale-light dashboard-scale-light <?=h(scaleStatusKey())?>" data-status="<?=h(scaleStatusKey())?>">
      <span class="scale-bulb red"></span>
      <span class="scale-bulb yellow"></span>
      <span class="scale-bulb green"></span>
    </div>
    <div id="scaleLightLabel" class="scale-light-label"><?=h(scaleStatusLabel())?></div>
  </section>

  <section class="card camera camera-full">
    <div class="eyebrow">IP-KAMERA</div>
    <?php $cameraStream=cameraStreamUrl(); ?>
    <?php if(cameraEnabled() && $cameraStream!==''): ?>
      <div class="camera-image"><img src="<?=h($cameraStream)?>" alt="IP-Kamera"></div>
    <?php else: ?>
      <div class="camera-placeholder">IP-Kamera noch nicht konfiguriert</div>
    <?php endif; ?>
  </section>
</div>
<div class="grid2">
  <section class="card"><h3>Aktive Schläge</h3><div class="bigtext"><?=$activeFieldCount?></div><p>aktiv</p><?php if($activeFields): ?><small><?=h(implode(' · ', array_map(fn($f)=>(string)$f['name'],$activeFields)))?></small><?php endif; ?><br><a class="text-link" href="fields.php">Schläge verwalten →</a></section>
  <section class="card"><h3>Aktive Fahrzeuge</h3><div class="bigtext"><?=$activeVehicleCount?></div><p>aktiv</p><a class="text-link" href="vehicles.php">Fahrzeuge verwalten →</a></section>
</div>
<?php if (demoMode()): ?>
<section class="card test-weight-card">
  <h2>Testgewicht</h2>
  <p class="muted">Testbetrieb ohne aktiven Waagencomputer: Dieses Gewicht wird als aktuelles Waagenggewicht verwendet.</p>
  <form method="post" action="api/demo_weight.php" class="test-weight-form">
    <div><label>Testgewicht (kg)</label><input type="number" name="weight" min="0" step="0.1" value="<?=h(testWeight())?>"></div>
    <button class="button primary">Testgewicht setzen</button>
  </form>
  <p class="muted">Aktuell simuliert: <strong><?=formatScaleWeight(testWeight())?> kg</strong></p>
</section>
<?php endif; ?>
<script src="assets/app.js"></script>
<?php layoutEnd(); ?>
