<?php
// AJP Waage – Authentifizierung der Raspberry-Produktionsinstallation
if (PHP_SAPI !== 'cli' && session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function currentUser(): ?array {
    static $loaded = false;
    static $user = null;
    if ($loaded) return $user;
    $loaded = true;
    $id = (int)($_SESSION['user_id'] ?? 0);
    if ($id <= 0) return null;
    try {
        $s = db()->prepare('SELECT id,username,display_name,role,active,expires_at,force_password_change,last_login_at FROM users WHERE id=? LIMIT 1');
        $s->execute([$id]);
        $user = $s->fetch() ?: null;
    } catch (Throwable $e) {
        $user = null;
    }
    return $user;
}

function isLocalAccess(): bool {
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    // Tunnel-Anfragen können ebenfalls von Loopback kommen. Proxy-Header
    // dürfen den Bypass nur einschränken, niemals freischalten.
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_FORWARDED', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED_PROTO'] as $header) {
        if (!empty($_SERVER[$header])) return false;
    }
    return in_array($remote, ['127.0.0.1', '::1'], true);
}

function passwordProtectionRequired(): bool {
    return !(defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) && !isLocalAccess();
}

function accessPasswordHash(): string {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT && !empty($_SESSION['web_test_access_password_hash'])) {
        return trim((string)$_SESSION['web_test_access_password_hash']);
    }
    return trim(appSetting('access_password_hash', ''));
}

function accessPasswordConfigured(): bool {
    return accessPasswordHash() !== '';
}

function saveAccessPasswordHash(string $hash): void {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) {
        $_SESSION['web_test_access_password_hash'] = $hash;
        return;
    }
    saveAppSetting('access_password_hash', $hash);
}

function isAccessAuthenticated(): bool {
    enforceSessionIdleTimeout();
    return !empty($_SESSION['waage_access_authenticated']);
}

function enforceSessionIdleTimeout(?int $now = null): void {
    if (!passwordProtectionRequired()) return;
    if (empty($_SESSION['waage_access_authenticated']) && empty($_SESSION['user_id'])) return;
    $now ??= time();
    $last = (int)($_SESSION['waage_last_activity'] ?? 0);
    // Bereits bestehende Sitzungen ohne Zeitstempel müssen sich neu anmelden.
    if ($last <= 0 || $now - $last >= 900 || $last > $now) {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) session_regenerate_id(true);
    }
}

function isLoggedIn(): bool { return currentUser() !== null || isAccessAuthenticated(); }
function isAdmin(): bool { $u=currentUser(); return ($u && $u['role']==='admin') || isAccessAuthenticated(); }

function csrfToken(): string {
    if (empty($_SESSION['waage_csrf_token'])) {
        $_SESSION['waage_csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['waage_csrf_token'];
}

function requireCsrfToken(): void {
    $provided = (string)($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string)($_SESSION['waage_csrf_token'] ?? '');
    if (!isValidCsrfToken($provided)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false, 'message'=>'Ungültiger CSRF-Token.']);
        exit;
    }
}

function isValidCsrfToken(string $provided): bool {
    $expected = (string)($_SESSION['waage_csrf_token'] ?? '');
    return $expected !== '' && $provided !== '' && hash_equals($expected, $provided);
}

function logoutUser(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}

function requireLogin(bool $allowPasswordChange=false): void {
    // Entwicklungs-Webversion bleibt ohne Login erreichbar.
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) return;
    // Direkter lokaler Zugriff am Raspberry (localhost / 127.0.0.1) bleibt ohne Passwort erreichbar.
    if (isLocalAccess()) return;
    if (isAccessAuthenticated()) {
        // Hintergrundabfragen zählen nicht als Benutzeraktivität.
        if (!str_contains(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/api/')) {
            $_SESSION['waage_last_activity'] = time();
        }
        return;
    }
    $base = str_contains(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/api/') ? '../' : '';
    if (!accessPasswordConfigured()) redirect($base.'setup_access_password.php');
    redirect($base.'login.php');
}

// Auch direkte currentUser()/isAdmin()-Aufrufe sehen keine abgelaufene Sitzung.
enforceSessionIdleTimeout();

function requireAdmin(): void {
    if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) return;
    requireLogin();
    if (!isAdmin()) {
        http_response_code(403);
        exit('Zugriff verweigert.');
    }
}
