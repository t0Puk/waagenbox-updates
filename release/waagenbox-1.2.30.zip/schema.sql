-- WägeSoftware 0.1
-- Für MariaDB 11.8
-- Datenbank: dbs16101150
-- Das Skript legt nur die Tabellen an, nicht die Datenbank selbst.

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS settings (
  `key` VARCHAR(100) NOT NULL,
  `value` TEXT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vehicles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  plate VARCHAR(50) NOT NULL,
  name VARCHAR(150) NULL,
  first_weight DECIMAL(12,3) NOT NULL DEFAULT 0,
  max_weight DECIMAL(12,3) NULL,
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_vehicle_plate (plate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fields (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  crop VARCHAR(100) NULL,
  year SMALLINT NULL,
  area DECIMAL(10,2) NULL,
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_field_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS remotes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(100) NOT NULL,
  name VARCHAR(150) NULL,
  vehicle_id INT UNSIGNED NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_remote_code (code),
  KEY idx_remote_vehicle (vehicle_id),
  CONSTRAINT fk_remote_vehicle FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  address TEXT NULL,
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_customer_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  unit VARCHAR(30) NOT NULL DEFAULT 'kg',
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_product_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS weighings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  vehicle_id INT UNSIGNED NULL,
  field_id INT UNSIGNED NULL,
  customer_id INT UNSIGNED NULL,
  product_id INT UNSIGNED NULL,
  remote_id INT UNSIGNED NULL,
  first_weight DECIMAL(12,3) NOT NULL,
  second_weight DECIMAL(12,3) NOT NULL,
  net_weight DECIMAL(12,3) NOT NULL,
  trigger_type VARCHAR(30) NOT NULL,
  scale_status VARCHAR(50) NULL,
  notes TEXT NULL,
  PRIMARY KEY (id),
  KEY idx_weigh_vehicle (vehicle_id),
  KEY idx_weigh_field (field_id),
  KEY idx_weigh_customer (customer_id),
  KEY idx_weigh_product (product_id),
  KEY idx_weigh_remote (remote_id),
  KEY idx_weigh_created (created_at),
  CONSTRAINT fk_weigh_vehicle FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id) ON DELETE SET NULL,
  CONSTRAINT fk_weigh_customer FOREIGN KEY (customer_id)
    REFERENCES customers(id) ON DELETE SET NULL,
  CONSTRAINT fk_weigh_product FOREIGN KEY (product_id)
    REFERENCES products(id) ON DELETE SET NULL,
  CONSTRAINT fk_weigh_field FOREIGN KEY (field_id)
    REFERENCES fields(id) ON DELETE SET NULL,
  CONSTRAINT fk_weigh_remote FOREIGN KEY (remote_id)
    REFERENCES remotes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
