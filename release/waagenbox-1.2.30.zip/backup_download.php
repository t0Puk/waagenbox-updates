<?php
require_once __DIR__.'/version.php';

function manualBackupFilename(?DateTimeImmutable $date = null): string {
    $version = preg_replace('/[^A-Za-z0-9._-]/', '_', APP_VERSION);
    return 'AJP-Waagenbox_v'.$version.'_'.($date ?? new DateTimeImmutable())->format('Y-m-d_H-i-s').'.sql.gz';
}

function automaticBackupNameValid(string $name): bool {
    if (preg_match('/\Awaagenbox_(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})(?:_[a-f0-9]{12})?\.sql\.gz\z/D', $name, $match) !== 1) return false;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d_H-i-s', $match[1]);
    return $date !== false && $date->format('Y-m-d_H-i-s') === $match[1];
}

/** Der Aufrufer setzt das Verzeichnis fest; niemals Browserparameter verwenden. */
function openLatestAutomaticBackup(string $directory): array {
    $root = realpath($directory);
    if ($root === false || is_link($directory) || !is_dir($root) ||
        str_replace('\\', '/', $root) !== rtrim(str_replace('\\', '/', $directory), '/')) {
        throw new RuntimeException('Das automatische Backup-Verzeichnis ist nicht verfügbar.');
    }
    $candidates = [];
    foreach (new DirectoryIterator($root) as $entry) {
        if (!automaticBackupNameValid($entry->getFilename()) || $entry->isLink() || !$entry->isFile()) continue;
        $candidates[] = $entry->getFilename();
    }
    // Zeitstempel im Namen: unabhängig von Kopierzeitpunkten und altem Format.
    rsort($candidates, SORT_STRING);
    foreach ($candidates as $name) {
        $path = $root.DIRECTORY_SEPARATOR.$name;
        clearstatcache(true, $path);
        $before = @lstat($path);
        if (!$before || ($before['mode'] & 0170000) !== 0100000 || realpath($path) !== $path) continue;
        $stream = @fopen($path, 'rb');
        if ($stream === false) continue;
        $after = fstat($stream);
        // Geöffneten Deskriptor prüfen und genau diesen streamen (kein erneutes Öffnen).
        if (!$after || $before['dev'] !== $after['dev'] || $before['ino'] !== $after['ino'] ||
            ($after['mode'] & 0170000) !== 0100000 || !backupGzipValid($stream)) {
            fclose($stream);
            continue;
        }
        rewind($stream);
        return ['stream'=>$stream, 'name'=>$name, 'size'=>$after['size']];
    }
    throw new RuntimeException('Kein lesbares automatisches Waagenbox-Backup vorhanden.');
}

function backupGzipValid($stream): bool {
    $inflate = inflate_init(ZLIB_ENCODING_GZIP);
    if ($inflate === false) return false;
    while (!feof($stream)) {
        $chunk = fread($stream, 8192);
        if ($chunk === false) return false;
        if (@inflate_add($inflate, $chunk, ZLIB_SYNC_FLUSH) === false) return false;
        if (inflate_get_status($inflate) === ZLIB_STREAM_END) {
            return inflate_get_read_len($inflate) === fstat($stream)['size'];
        }
    }
    return false;
}
