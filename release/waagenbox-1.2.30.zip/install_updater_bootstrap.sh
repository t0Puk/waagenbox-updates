#!/bin/bash
set -euo pipefail

ROOT_DIR="$(
    CDPATH= cd -- "$(dirname -- "$0")" && pwd
)"

TEST_MODE="${TEST_MODE:-0}"
APP_ROOT="${APP_ROOT:-/var/www/waage}"
STORAGE_ROOT="${STORAGE_ROOT:-/var/lib/waagebox}"
PUBLIC_KEY_SOURCE="${PUBLIC_KEY_SOURCE:-}"
SKIP_HELPER_INSTALL="${SKIP_HELPER_INSTALL:-0}"

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: Bootstrap muss als root laufen." >&2
    exit 1
fi

if [ -z "$PUBLIC_KEY_SOURCE" ] || [ ! -f "$PUBLIC_KEY_SOURCE" ]; then
    echo "FEHLER: PUBLIC_KEY_SOURCE fehlt." >&2
    exit 1
fi

if [ "$TEST_MODE" = "1" ]; then
    case "$APP_ROOT" in
        /tmp/waagenbox_bootstrap_test_*/app)
            ;;
        *)
            echo "FEHLER: TEST_MODE APP_ROOT außerhalb des Testbereichs." >&2
            exit 1
            ;;
    esac

    case "$STORAGE_ROOT" in
        /tmp/waagenbox_bootstrap_test_*/storage)
            ;;
        *)
            echo "FEHLER: TEST_MODE STORAGE_ROOT außerhalb des Testbereichs." >&2
            exit 1
            ;;
    esac
fi

SOURCE_FILES=(
    "auth.php"
    "version.php"
    "update_safety.php"
    "api/update_install.php"
    "api/update_rollback.php"
    "deploy/deploy_client.php"
    "deploy/update_transaction.php"
    "deploy/waagenbox-deploy-helper.php"
)

for file in "${SOURCE_FILES[@]}"; do
    if [ ! -f "$ROOT_DIR/$file" ]; then
        echo "FEHLER: Quelldatei fehlt: $file" >&2
        exit 1
    fi

    if [[ "$file" == *.php ]]; then
        php -l "$ROOT_DIR/$file" >/dev/null
    fi
done

openssl pkey \
    -pubin \
    -in "$PUBLIC_KEY_SOURCE" \
    -noout \
    >/dev/null

for binary in php mariadb-dump mariadb cp install flock; do
    if ! command -v "$binary" >/dev/null 2>&1; then
        echo "FEHLER: Programm fehlt: $binary" >&2
        exit 1
    fi
done

if [ ! -d "$APP_ROOT" ]; then
    echo "FEHLER: Anwendung fehlt: $APP_ROOT" >&2
    exit 1
fi

for file in \
    config.php \
    version.php \
    functions.php \
    db.php
do
    if [ ! -f "$APP_ROOT/$file" ]; then
        echo "FEHLER: Produktionsdatei fehlt: $file" >&2
        exit 1
    fi
done

CURRENT_VERSION="$(
    php -r '
require $argv[1];
require $argv[2];

echo defined("APP_VERSION") ? APP_VERSION : "";
' "$APP_ROOT/config.php" "$APP_ROOT/version.php"
)"

if [ "$CURRENT_VERSION" != "1.2.26" ]; then
    echo "FEHLER: Bootstrap unterstützt ausschließlich v1.2.26." >&2
    exit 1
fi

mkdir -p "$STORAGE_ROOT"

chmod 0750 "$STORAGE_ROOT" || true

LOCK_FILE="$STORAGE_ROOT/bootstrap-v2.lock"

exec 9>"$LOCK_FILE"

if ! flock -n 9; then
    echo "FEHLER: Ein Bootstrap läuft bereits." >&2
    exit 1
fi

BOOTSTRAP_DIR="$STORAGE_ROOT/bootstrap_v2_$(date +%Y%m%d_%H%M%S)_$(openssl rand -hex 8)"

mkdir -p "$BOOTSTRAP_DIR"
chmod 0700 "$BOOTSTRAP_DIR"

echo "BOOTSTRAP_DIR=$BOOTSTRAP_DIR"

CONFIG_HASH_BEFORE="$(
    sha256sum "$APP_ROOT/config.php" |
    awk '{print $1}'
)"

VERSION_HASH_BEFORE="$(
    sha256sum "$APP_ROOT/version.php" |
    awk '{print $1}'
)"

echo "CONFIG_HASH_BEFORE=$CONFIG_HASH_BEFORE"
echo "VERSION_HASH_BEFORE=$VERSION_HASH_BEFORE"


echo
echo "--- vollständiger Bootstrap-Snapshot ---"

APP="$APP_ROOT"
STORAGE="$STORAGE_ROOT"
SNAPSHOT="$BOOTSTRAP_DIR/snapshot"

APP="$APP" \
STORAGE="$STORAGE" \
SNAPSHOT="$SNAPSHOT" \
SOURCE_UPDATE_SAFETY="$ROOT_DIR/update_safety.php" \
php <<'PHP'
<?php
declare(strict_types=1);

$app=getenv('APP');
$storage=getenv('STORAGE');
$snapshot=getenv('SNAPSHOT');

require getenv('SOURCE_UPDATE_SAFETY');
require $app.'/config.php';
require_once $app.'/version.php';

updateSafetyDirectory($snapshot);

$info=updateSafetySnapshot(
    $app,
    $snapshot,
    [
        'previous_version'=>APP_VERSION,
        'new_version'=>APP_VERSION,
        'bootstrap_v2'=>true,
    ]
);

updateSafetyValidateSnapshot($snapshot);

echo "BOOTSTRAP_SNAPSHOT_OK\n";
echo "snapshot_id=".$info['snapshot_id']."\n";
PHP


echo
echo "--- operation journal sichern ---"

JOURNAL="$STORAGE_ROOT/operation.json"

if [ -f "$JOURNAL" ]; then
    cp -a \
        "$JOURNAL" \
        "$BOOTSTRAP_DIR/operation_before_bootstrap.json"

    chmod 0600 \
        "$BOOTSTRAP_DIR/operation_before_bootstrap.json"

    php -r '
$d=json_decode(file_get_contents($argv[1]),true);

if (!is_array($d)) exit(2);

echo "OLD_OPERATION_STATE=".
    ($d["state"] ?? "UNKNOWN").
    PHP_EOL;

echo "OLD_OPERATION_MUTATING=".
    (!empty($d["mutating"]) ? "true" : "false").
    PHP_EOL;
' "$JOURNAL"
else
    echo "OLD_OPERATION_STATE=NONE"
fi


echo
echo "--- Legacy-config.php analysieren ---"

MIGRATED_CONFIG="$BOOTSTRAP_DIR/config.php.migrated"

APP_ROOT="$APP_ROOT" \
SOURCE_UPDATE_SAFETY="$ROOT_DIR/update_safety.php" \
MIGRATED_CONFIG="$MIGRATED_CONFIG" \
php <<'PHP'
<?php
declare(strict_types=1);

require getenv('SOURCE_UPDATE_SAFETY');

$file=getenv('APP_ROOT').'/config.php';

$source=file_get_contents($file);

if (!is_string($source)) {
    throw new RuntimeException(
        'config.php konnte nicht gelesen werden.'
    );
}

$migrated=updateSafetyLegacyConfig($source);

if ($migrated === $source) {
    /*
     * Bereits migriert ist erlaubt, sofern keine eigene
     * APP_VERSION-Deklaration mehr vorhanden ist.
     */
    $tokens=token_get_all($source);

    if (preg_match(
        '/\bAPP_VERSION\b/',
        $source
    )) {
        throw new RuntimeException(
            'config.php enthält APP_VERSION, konnte aber nicht eindeutig migriert werden.'
        );
    }
}

if (
    file_put_contents(
        getenv('MIGRATED_CONFIG'),
        $migrated
    ) !== strlen($migrated)
) {
    throw new RuntimeException(
        'Migrierte config.php konnte nicht geschrieben werden.'
    );
}

echo "CONFIG_MIGRATION_PREPARED_OK\n";
PHP

chmod 0600 "$MIGRATED_CONFIG"


echo
echo "--- neue version.php prüfen ---"

NEW_VERSION="$(
php -r '
require $argv[1];
echo APP_VERSION;
' "$ROOT_DIR/version.php"
)"

if [ "$NEW_VERSION" != "1.2.26" ]; then
    echo "FEHLER: Bootstrap-version.php ist nicht 1.2.26." >&2
    exit 1
fi


echo
echo "--- Dateien atomar installieren ---"

install_atomic() {
    SRC="$1"
    DST="$2"
    OWNER="$3"
    GROUP="$4"
    MODE="$5"

    DIR="$(dirname "$DST")"

    install -d \
        -o root \
        -g root \
        -m 0755 \
        "$DIR"

    TMP="$DIR/.bootstrap.$(basename "$DST").$(openssl rand -hex 6)"

    install \
        -o "$OWNER" \
        -g "$GROUP" \
        -m "$MODE" \
        "$SRC" \
        "$TMP"

    if [[ "$DST" == *.php ]]; then
        php -l "$TMP" >/dev/null
    fi

    if [ "$(
        sha256sum "$SRC" |
        awk '{print $1}'
    )" != "$(
        sha256sum "$TMP" |
        awk '{print $1}'
    )" ]; then
        rm -f "$TMP"
        echo "FEHLER: Hashprüfung fehlgeschlagen: $DST" >&2
        exit 1
    fi

    mv -f "$TMP" "$DST"
}

install_atomic \
    "$MIGRATED_CONFIG" \
    "$APP_ROOT/config.php" \
    root \
    www-data \
    0640

install_atomic \
    "$ROOT_DIR/version.php" \
    "$APP_ROOT/version.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/auth.php" \
    "$APP_ROOT/auth.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/update_safety.php" \
    "$APP_ROOT/update_safety.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/api/update_rollback.php" \
    "$APP_ROOT/api/update_rollback.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/api/update_install.php" \
    "$APP_ROOT/api/update_install.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/deploy/deploy_client.php" \
    "$APP_ROOT/deploy/deploy_client.php" \
    root \
    root \
    0644

install_atomic \
    "$ROOT_DIR/deploy/update_transaction.php" \
    "$APP_ROOT/deploy/update_transaction.php" \
    root \
    root \
    0644


echo
echo "--- Codebaum auf root-owned Architektur setzen ---"

find "$APP_ROOT" \
    -path "$APP_ROOT/uploads" -prune \
    -o -path "$APP_ROOT/config.php" -prune \
    -o -type d \
    -exec chown root:root {} \; \
    -exec chmod 0755 {} \;

find "$APP_ROOT" \
    -path "$APP_ROOT/uploads" -prune \
    -o -path "$APP_ROOT/config.php" -prune \
    -o -type f \
    -exec chown root:root {} \; \
    -exec chmod u=rw,go=r {} \;

chown root:www-data "$APP_ROOT/config.php"
chmod 0640 "$APP_ROOT/config.php"

if [ -d "$APP_ROOT/uploads" ]; then
    chown -R www-data:www-data "$APP_ROOT/uploads"
    chmod 0750 "$APP_ROOT/uploads"

    if [ -d "$APP_ROOT/uploads/camera" ]; then
        chmod 0770 "$APP_ROOT/uploads/camera"

        find "$APP_ROOT/uploads/camera" \
            -type f \
            -exec chmod 0660 {} \;
    fi
fi


echo
echo "--- Journal nach geprüftem Snapshot versöhnen ---"

if [ -f "$JOURNAL" ]; then
    JOURNAL_STATE="$(
        php -r '
$d=json_decode(file_get_contents($argv[1]),true);

echo $d["state"] ?? "";
' "$JOURNAL"
    )"

    JOURNAL_MUTATING="$(
        php -r '
$d=json_decode(file_get_contents($argv[1]),true);

echo !empty($d["mutating"]) ? "1" : "0";
' "$JOURNAL"
    )"

    if [ "$JOURNAL_MUTATING" = "1" ]; then
        echo "FEHLER: Altes Journal meldet noch aktive Mutation." >&2
        exit 1
    fi

    case "$JOURNAL_STATE" in
        complete|recovered|aborted)
            echo "Journal bereits freigegeben."
            ;;

        recovery_failed)
            JOURNAL="$JOURNAL" \
            BOOTSTRAP_DIR="$BOOTSTRAP_DIR" \
            php <<'PHP'
<?php
declare(strict_types=1);

$file=getenv('JOURNAL');

$data=[
    'state'=>'recovered',
    'mutating'=>false,
    'reconciled_by'=>'bootstrap_v2',
    'reconciled_at'=>date('c'),
    'previous_journal'=>
        getenv('BOOTSTRAP_DIR').
        '/operation_before_bootstrap.json',
];

$json=json_encode(
    $data,
    JSON_PRETTY_PRINT |
    JSON_UNESCAPED_UNICODE |
    JSON_UNESCAPED_SLASHES |
    JSON_THROW_ON_ERROR
)."\n";

$tmp=$file.'.bootstrap-new';

if (
    file_put_contents(
        $tmp,
        $json,
        LOCK_EX
    ) !== strlen($json)
) {
    throw new RuntimeException(
        'Neues Journal konnte nicht geschrieben werden.'
    );
}

chmod($tmp,0600);

if (!rename($tmp,$file)) {
    throw new RuntimeException(
        'Neues Journal konnte nicht aktiviert werden.'
    );
}

echo "RECOVERY_JOURNAL_RECONCILED_OK\n";
PHP
            ;;

        *)
            echo "FEHLER: Unbekannter Journalzustand: $JOURNAL_STATE" >&2
            exit 1
            ;;
    esac
fi


echo
echo "--- Deployment-Helper ---"

if [ "$SKIP_HELPER_INSTALL" = "1" ]; then
    echo "HELPER_INSTALL_SKIPPED"
else
    if [ "$TEST_MODE" = "1" ]; then
        TEST_MODE=1 \
        PUBLIC_KEY_SOURCE="$PUBLIC_KEY_SOURCE" \
        "$ROOT_DIR/install_deploy_helper.sh"
    else
        PUBLIC_KEY_SOURCE="$PUBLIC_KEY_SOURCE" \
        "$ROOT_DIR/install_deploy_helper.sh"
    fi
fi


echo
echo "--- Abschlussprüfung ---"

php -l "$APP_ROOT/version.php" >/dev/null
php -l "$APP_ROOT/auth.php" >/dev/null
php -l "$APP_ROOT/update_safety.php" >/dev/null
php -l "$APP_ROOT/api/update_install.php" >/dev/null
php -l "$APP_ROOT/api/update_rollback.php" >/dev/null
php -l "$APP_ROOT/deploy/deploy_client.php" >/dev/null
php -l "$APP_ROOT/deploy/update_transaction.php" >/dev/null

FINAL_VERSION="$(
php -r '
require $argv[1];
require_once $argv[2];

echo APP_VERSION;
' "$APP_ROOT/config.php" "$APP_ROOT/version.php"
)"

if [ "$FINAL_VERSION" != "1.2.26" ]; then
    echo "FEHLER: Finalversion ist nicht 1.2.26." >&2
    exit 1
fi

CONFIG_HASH_AFTER="$(
sha256sum "$APP_ROOT/config.php" |
awk '{print $1}'
)"

if [ "$CONFIG_HASH_AFTER" = "$CONFIG_HASH_BEFORE" ]; then
    echo "CONFIG_ALREADY_MIGRATED_OR_UNCHANGED"
else
    echo "CONFIG_LEGACY_MIGRATED_OK"
fi

if grep -Eq \
    '(^|[^A-Za-z0-9_])(const[[:space:]]+APP_VERSION|define[[:space:]]*\([[:space:]]*["'"'"']APP_VERSION)' \
    "$APP_ROOT/config.php"
then
    echo "FEHLER: config.php enthält weiterhin eigene APP_VERSION-Deklaration." >&2
    exit 1
fi

if ! grep -q \
    "const APP_VERSION = '1.2.26'" \
    "$APP_ROOT/version.php"
then
    echo "FEHLER: Neue version.php nicht aktiv." >&2
    exit 1
fi

if ! grep -q \
    'function requireCsrfToken' \
    "$APP_ROOT/auth.php"
then
    echo "FEHLER: Neue CSRF-Auth nicht aktiv." >&2
    exit 1
fi

if ! grep -q \
    'waagenboxDeployInstall' \
    "$APP_ROOT/api/update_install.php"
then
    echo "FEHLER: Neuer Installer nicht aktiv." >&2
    exit 1
fi

if ! grep -q \
    'waagenboxDeployRestore' \
    "$APP_ROOT/api/update_rollback.php"
then
    echo "FEHLER: Neuer Rollback nicht aktiv." >&2
    exit 1
fi

echo
echo "BOOTSTRAP_V2_OK"
echo "VERSION=$FINAL_VERSION"
echo "SNAPSHOT=$SNAPSHOT"
echo "BOOTSTRAP_DIR=$BOOTSTRAP_DIR"
