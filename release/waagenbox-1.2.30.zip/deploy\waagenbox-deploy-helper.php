#!/usr/bin/php
<?php
declare(strict_types=1);

/*
 * AJP Waagenbox – privilegierter Dateideployment-Helfer.
 *
 * Der Helfer darf später ausschließlich als root über einen exakt
 * eingeschränkten sudo-Aufruf gestartet werden.
 *
 * Er übernimmt KEINE Datenbankmigrationen.
 * Er installiert ausschließlich kryptografisch signierte Anwendungspakete
 * und kann ausschließlich von ihm selbst erzeugte Root-Snapshots
 * zurückspielen.
 *
 * Produktionspfade sind fest verdrahtet.
 * Testpfade sind nur mit WAAGEBOX_DEPLOY_TEST_MODE=1 und ausschließlich
 * unter den fest definierten /tmp/waagenbox_deploy_*_Testbereichen zulässig.
 */

function fail(string $message, int $code = 1): never
{
    fwrite(STDERR, "DEPLOY_ERROR: ".$message.PHP_EOL);
    exit($code);
}

function out(array $data): never
{
    echo json_encode(
        $data,
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES |
        JSON_THROW_ON_ERROR
    ).PHP_EOL;
    exit(0);
}

function isRoot(): bool
{
    if (!function_exists('posix_geteuid')) {
        fail('POSIX-Unterstützung fehlt.');
    }

    return posix_geteuid() === 0;
}

function assertRegularDirectory(string $path, string $label): void
{
    if (!is_dir($path) || is_link($path)) {
        fail($label.' ist kein reguläres Verzeichnis: '.$path);
    }
}

function assertRegularFile(string $path, string $label): void
{
    if (!is_file($path) || is_link($path)) {
        fail($label.' ist keine reguläre Datei: '.$path);
    }
}

function canonicalExisting(string $path): string
{
    $real = realpath($path);

    if ($real === false) {
        fail('Pfad konnte nicht aufgelöst werden: '.$path);
    }

    return rtrim($real, '/');
}

function isInside(string $path, string $root): bool
{
    $path = rtrim($path, '/');
    $root = rtrim($root, '/');

    return $path === $root ||
        str_starts_with($path, $root.DIRECTORY_SEPARATOR);
}

function assertTestPath(string $path): void
{
    $real = canonicalExisting($path);

    if (!preg_match('~^/tmp/waagenbox_deploy_(?:test|bridge_test)_[A-Za-z0-9._-]+(?:/|$)~', $real)) {
        fail('Testpfad liegt außerhalb des erlaubten Testbereichs: '.$real);
    }
}

function ensureRootPrivateDirectory(string $path): void
{
    if (!is_dir($path)) {
        if (!mkdir($path, 0700, true)) {
            fail('Root-Verzeichnis konnte nicht angelegt werden: '.$path);
        }
    }

    assertRegularDirectory($path, 'Root-Verzeichnis');

    @chmod($path, 0700);

    $stat = stat($path);

    if ($stat === false) {
        fail('Dateirechte konnten nicht geprüft werden: '.$path);
    }

    if (($stat['uid'] ?? -1) !== 0) {
        fail('Privilegiertes Verzeichnis gehört nicht root: '.$path);
    }

    if (((int)$stat['mode'] & 0022) !== 0) {
        fail('Privilegiertes Verzeichnis ist für Gruppe/Andere beschreibbar: '.$path);
    }
}

function inventory(string $root): array
{
    assertRegularDirectory($root, 'Inventarwurzel');

    $root = canonicalExisting($root);
    $result = [];

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(
            $root,
            FilesystemIterator::SKIP_DOTS
        ),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        $path = $item->getPathname();

        if (is_link($path)) {
            fail('Symlink ist nicht erlaubt: '.$path);
        }

        $relative = ltrim(substr($path, strlen($root)), '/');

        if ($item->isDir()) {
            $result[$relative] = ['type' => 'directory'];
            continue;
        }

        if (!$item->isFile()) {
            fail('Nicht unterstützter Dateityp: '.$relative);
        }

        $hash = hash_file('sha256', $path);

        if ($hash === false) {
            fail('Datei konnte nicht gehasht werden: '.$relative);
        }

        $result[$relative] = [
            'type' => 'file',
            'sha256' => $hash,
        ];
    }

    ksort($result);

    return $result;
}

function run(array $command): void
{
    $null = '/dev/null';

    $process = proc_open(
        $command,
        [
            0 => ['file', $null, 'r'],
            1 => ['file', $null, 'a'],
            2 => ['pipe', 'w'],
        ],
        $pipes,
        null,
        null,
        ['bypass_shell' => true]
    );

    if (!is_resource($process)) {
        fail('Prozess konnte nicht gestartet werden: '.basename((string)$command[0]));
    }

    $error = stream_get_contents($pipes[2]);
    fclose($pipes[2]);

    $code = proc_close($process);

    if ($code !== 0) {
        fail(
            'Prozess '.basename((string)$command[0]).
            ' fehlgeschlagen ('.$code.'): '.trim((string)$error)
        );
    }
}

function copyTree(string $source, string $target): void
{
    assertRegularDirectory($source, 'Kopierquelle');

    if (file_exists($target)) {
        fail('Kopierziel existiert bereits: '.$target);
    }

    run(['/bin/cp', '-a', '--', $source, $target]);
}

function removeTree(string $path): void
{
    if (!file_exists($path) && !is_link($path)) {
        return;
    }

    if (is_link($path)) {
        fail('Symlink darf nicht rekursiv gelöscht werden: '.$path);
    }

    run(['/bin/rm', '-rf', '--one-file-system', '--', $path]);
}

function overlayTree(string $source, string $target): void
{
    assertRegularDirectory($source, 'Overlay-Quelle');
    assertRegularDirectory($target, 'Overlay-Ziel');

    /*
     * Nicht "cp -a source/. target/" verwenden:
     * GNU cp übernimmt dabei auch die Attribute des Quell-Wurzelverzeichnisses
     * auf das Zielverzeichnis. Unser Stage-Verzeichnis ist absichtlich 0700;
     * dadurch würde die aktivierte Webanwendung ebenfalls 0700 erhalten.
     *
     * Stattdessen nur die einzelnen Paket-Einträge kopieren. So bleiben
     * Besitzer/Modus des vorbereiteten Anwendungswurzelverzeichnisses erhalten.
     */
    $entries = scandir($source);

    if ($entries === false) {
        fail('Overlay-Quelle konnte nicht gelesen werden.');
    }

    foreach ($entries as $name) {
        if ($name === '.' || $name === '..') {
            continue;
        }

        run([
            '/bin/cp',
            '-a',
            '--',
            $source.'/'.$name,
            $target.'/',
        ]);
    }
}

function safeZipName(string $name): bool
{
    if ($name === '' || str_contains($name, "\0")) {
        return false;
    }

    $name = str_replace('\\', '/', $name);

    if (str_starts_with($name, '/')) {
        return false;
    }

    if (preg_match('~^[A-Za-z]:/~', $name)) {
        return false;
    }

    foreach (explode('/', $name) as $part) {
        if ($part === '..') {
            return false;
        }
    }

    return true;
}

function extractZipSafely(string $zipFile, string $destination): void
{
    assertRegularFile($zipFile, 'Updatepaket');

    if (!class_exists('ZipArchive')) {
        fail('PHP-ZIP-Erweiterung fehlt.');
    }

    if (!mkdir($destination, 0700, true)) {
        fail('Extraktionsverzeichnis konnte nicht angelegt werden.');
    }

    $zip = new ZipArchive();

    if ($zip->open($zipFile) !== true) {
        fail('Updatepaket konnte nicht geöffnet werden.');
    }

    try {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);

            if (!is_string($name) || !safeZipName($name)) {
                fail('Unsicherer ZIP-Pfad erkannt.');
            }

            $normalized = str_replace('\\', '/', $name);
            $isDirectory = str_ends_with($normalized, '/');

            if (
                strcasecmp($normalized, 'config.php') === 0 ||
                str_ends_with(strtolower($normalized), '/config.php')
            ) {
                fail('Updatepaket darf config.php nicht enthalten.');
            }

            $segments = array_values(
                array_filter(
                    explode('/', trim($normalized, '/')),
                    static fn(string $v): bool => $v !== '' && $v !== '.'
                )
            );

            if ($segments === []) {
                continue;
            }

            $target = $destination.'/'.implode('/', $segments);

            if (!isInside(dirname($target), $destination) && dirname($target) !== $destination) {
                fail('ZIP-Ziel liegt außerhalb des Arbeitsverzeichnisses.');
            }

            $opsys = 0;
            $attributes = 0;

            if ($zip->getExternalAttributesIndex($i, $opsys, $attributes)) {
                if ($opsys === ZipArchive::OPSYS_UNIX) {
                    $type = ($attributes >> 16) & 0170000;

                    if ($type === 0120000) {
                        fail('Symlink im ZIP-Paket ist nicht erlaubt: '.$normalized);
                    }
                }
            }

            if ($isDirectory) {
                if (!is_dir($target) && !mkdir($target, 0755, true)) {
                    fail('ZIP-Verzeichnis konnte nicht angelegt werden: '.$normalized);
                }

                continue;
            }

            $parent = dirname($target);

            if (!is_dir($parent) && !mkdir($parent, 0755, true)) {
                fail('ZIP-Zielverzeichnis konnte nicht angelegt werden.');
            }

            $stream = $zip->getStream($name);

            if (!is_resource($stream)) {
                fail('ZIP-Datei konnte nicht gelesen werden: '.$normalized);
            }

            $output = fopen($target, 'xb');

            if (!is_resource($output)) {
                fclose($stream);
                fail('ZIP-Datei konnte nicht geschrieben werden: '.$normalized);
            }

            try {
                while (!feof($stream)) {
                    $data = fread($stream, 1024 * 1024);

                    if ($data === false) {
                        fail('ZIP-Datei konnte nicht vollständig gelesen werden.');
                    }

                    if ($data !== '' && fwrite($output, $data) !== strlen($data)) {
                        fail('ZIP-Datei konnte nicht vollständig geschrieben werden.');
                    }
                }
            } finally {
                fclose($stream);
                fclose($output);
            }
        }
    } finally {
        $zip->close();
    }
}

function packageRoot(string $stage): string
{
    $entries = array_values(
        array_filter(
            scandir($stage) ?: [],
            static fn(string $name): bool => $name !== '.' && $name !== '..'
        )
    );

    if (
        count($entries) === 1 &&
        is_dir($stage.'/'.$entries[0]) &&
        !is_link($stage.'/'.$entries[0])
    ) {
        return canonicalExisting($stage.'/'.$entries[0]);
    }

    return canonicalExisting($stage);
}

function validatePackage(string $stage, string $expectedVersion): array
{
    $stage = canonicalExisting($stage);

    foreach (['version.php', 'functions.php', 'db.php'] as $required) {
        assertRegularFile($stage.'/'.$required, 'Erforderliche Paketdatei');
    }

    if (file_exists($stage.'/config.php')) {
        fail('Updatepaket enthält config.php.');
    }

    foreach (['uploads', 'backup', 'backups'] as $runtime) {
        if (file_exists($stage.'/'.$runtime)) {
            fail('Updatepaket enthält Laufzeitdaten: '.$runtime);
        }
    }

    $versionSource = file_get_contents($stage.'/version.php');

    if (!is_string($versionSource)) {
        fail('version.php konnte nicht gelesen werden.');
    }

    $version = null;

    if (
        preg_match(
            "/\\bconst\\s+APP_VERSION\\s*=\\s*['\"]([0-9]+\\.[0-9]+\\.[0-9]+)['\"]\\s*;/",
            $versionSource,
            $match
        ) === 1
    ) {
        $version = $match[1];
    } elseif (
        preg_match(
            "/define\\s*\\(\\s*['\"]APP_VERSION['\"]\\s*,\\s*['\"]([0-9]+\\.[0-9]+\\.[0-9]+)['\"]\\s*\\)/",
            $versionSource,
            $match
        ) === 1
    ) {
        $version = $match[1];
    }

    if ($version !== $expectedVersion) {
        fail(
            'Paketversion stimmt nicht mit signiertem Manifest überein. Paket='.
            ($version ?? 'unbekannt').
            ', Manifest='.$expectedVersion
        );
    }

    $files = inventory($stage);

    foreach ($files as $relative => $entry) {
        if (($entry['type'] ?? '') !== 'file') {
            continue;
        }

        if (!str_ends_with(strtolower($relative), '.php')) {
            continue;
        }

        run([PHP_BINARY, '-l', $stage.'/'.$relative]);
    }

    return $files;
}

function verifySignedManifest(
    string $manifestFile,
    string $signatureFile,
    string $publicKeyFile
): array {
    assertRegularFile($manifestFile, 'Manifest');
    assertRegularFile($signatureFile, 'Manifest-Signatur');
    assertRegularFile($publicKeyFile, 'Deployment-Public-Key');

    $manifestRaw = file_get_contents($manifestFile);
    $signature = file_get_contents($signatureFile);
    $publicKeyRaw = file_get_contents($publicKeyFile);

    if (
        !is_string($manifestRaw) ||
        !is_string($signature) ||
        !is_string($publicKeyRaw)
    ) {
        fail('Signaturdateien konnten nicht gelesen werden.');
    }

    $publicKey = openssl_pkey_get_public($publicKeyRaw);

    if ($publicKey === false) {
        fail('Deployment-Public-Key ist ungültig.');
    }

    $verified = openssl_verify(
        $manifestRaw,
        $signature,
        $publicKey,
        OPENSSL_ALGO_SHA256
    );

    if ($verified !== 1) {
        fail('Signatur des Update-Manifests ist ungültig.');
    }

    try {
        $manifest = json_decode(
            $manifestRaw,
            true,
            64,
            JSON_THROW_ON_ERROR
        );
    } catch (Throwable $e) {
        fail('Signiertes Manifest enthält kein gültiges JSON.');
    }

    if (!is_array($manifest)) {
        fail('Ungültiges Manifest.');
    }

    $version = $manifest['version'] ?? null;
    $sha256 = $manifest['package_sha256'] ?? null;

    if (
        !is_string($version) ||
        preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/', $version) !== 1
    ) {
        fail('Ungültige Version im signierten Manifest.');
    }

    if (
        !is_string($sha256) ||
        preg_match('/^[a-f0-9]{64}$/i', $sha256) !== 1
    ) {
        fail('Ungültige Paket-Prüfsumme im signierten Manifest.');
    }

    return [
        'version' => $version,
        'package_sha256' => strtolower($sha256),
    ];
}

function readRequest(string $file): array
{
    assertRegularFile($file, 'Deployment-Anforderung');

    try {
        $data = json_decode(
            (string)file_get_contents($file),
            true,
            32,
            JSON_THROW_ON_ERROR
        );
    } catch (Throwable $e) {
        fail('Deployment-Anforderung enthält kein gültiges JSON.');
    }

    if (!is_array($data)) {
        fail('Ungültige Deployment-Anforderung.');
    }

    return $data;
}

function writeJsonRoot(string $file, array $data): void
{
    $json = json_encode(
        $data,
        JSON_PRETTY_PRINT |
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES |
        JSON_THROW_ON_ERROR
    ).PHP_EOL;

    $tmp = $file.'.new.'.bin2hex(random_bytes(6));

    if (file_put_contents($tmp, $json, LOCK_EX) !== strlen($json)) {
        @unlink($tmp);
        fail('Root-Metadaten konnten nicht geschrieben werden.');
    }

    @chmod($tmp, 0600);

    if (!rename($tmp, $file)) {
        @unlink($tmp);
        fail('Root-Metadaten konnten nicht aktiviert werden.');
    }
}

function swapApplication(
    string $appRoot,
    string $nextRoot,
    string $expectedConfigHash
): void {
    $parent = dirname($appRoot);
    $name = basename($appRoot);
    $old = $parent.'/.'.$name.'.old.'.bin2hex(random_bytes(8));

    if (!rename($appRoot, $old)) {
        fail('Bestehende Anwendung konnte nicht in Sicherheitsposition verschoben werden.');
    }

    $activated = false;

    try {
        if (!rename($nextRoot, $appRoot)) {
            fail('Neue Anwendung konnte nicht aktiviert werden.');
        }

        $activated = true;

        assertRegularFile($appRoot.'/config.php', 'Lokale Konfiguration');

        $configHash = hash_file('sha256', $appRoot.'/config.php');

        if (
            !is_string($configHash) ||
            !hash_equals($expectedConfigHash, $configHash)
        ) {
            fail('config.php wurde während des Deployments verändert.');
        }

        removeTree($old);
    } catch (Throwable $e) {
        if ($activated && file_exists($appRoot)) {
            $broken = $parent.'/.'.$name.'.broken.'.bin2hex(random_bytes(6));
            @rename($appRoot, $broken);
        }

        if (!file_exists($appRoot) && file_exists($old)) {
            @rename($old, $appRoot);
        }

        throw $e;
    }
}

if (PHP_SAPI !== 'cli') {
    fail('Deployment-Helfer darf nur über CLI gestartet werden.');
}

if ($argc !== 1) {
    fail('Deployment-Helfer akzeptiert keine Kommandozeilenargumente.');
}

if (!isRoot()) {
    fail('Deployment-Helfer muss als root ausgeführt werden.');
}

$testMode = getenv('WAAGEBOX_DEPLOY_TEST_MODE') === '1';

if ($testMode) {
    $appRoot = getenv('WAAGEBOX_DEPLOY_APP_ROOT') ?: '';
    $storageRoot = getenv('WAAGEBOX_DEPLOY_STORAGE_ROOT') ?: '';
    $publicKeyFile = getenv('WAAGEBOX_DEPLOY_PUBLIC_KEY') ?: '';

    if ($appRoot === '' || $storageRoot === '' || $publicKeyFile === '') {
        fail('Testmodus benötigt APP_ROOT, STORAGE_ROOT und PUBLIC_KEY.');
    }

    assertTestPath($appRoot);
    assertTestPath($storageRoot);
    assertTestPath(dirname($publicKeyFile));
} else {
    $appRoot = '/var/www/waage';
    $storageRoot = '/var/lib/waagebox/deploy';
    $publicKeyFile = '/etc/waagenbox/deploy-public.pem';
}

$appRoot = canonicalExisting($appRoot);
$storageRoot = canonicalExisting($storageRoot);
$publicKeyFile = canonicalExisting($publicKeyFile);

assertRegularDirectory($appRoot, 'Anwendung');
assertRegularDirectory($storageRoot, 'Deployment-Speicher');
assertRegularFile($publicKeyFile, 'Deployment-Public-Key');

$publicStat = stat($publicKeyFile);

if ($publicStat === false) {
    fail('Public-Key-Rechte konnten nicht geprüft werden.');
}

if (($publicStat['uid'] ?? -1) !== 0) {
    fail('Deployment-Public-Key gehört nicht root.');
}

if (((int)$publicStat['mode'] & 0022) !== 0) {
    fail('Deployment-Public-Key ist für Gruppe/Andere beschreibbar.');
}

$rootWork = $storageRoot.'/root-work';
$rootSnapshots = $storageRoot.'/root-snapshots';

ensureRootPrivateDirectory($rootWork);
ensureRootPrivateDirectory($rootSnapshots);

$requestFile = $storageRoot.'/request.json';
$request = readRequest($requestFile);
$action = $request['action'] ?? null;

if ($action === 'snapshot') {
    assertRegularFile(
        $appRoot.'/config.php',
        'Lokale Konfiguration'
    );

    $configHash = hash_file(
        'sha256',
        $appRoot.'/config.php'
    );

    if (!is_string($configHash)) {
        fail('config.php konnte nicht geprüft werden.');
    }

    $operationId = bin2hex(random_bytes(16));
    $snapshot = $rootSnapshots.'/'.$operationId;

    ensureRootPrivateDirectory($snapshot);

    try {
        copyTree(
            $appRoot,
            $snapshot.'/app'
        );

        $snapshotInventory = inventory(
            $snapshot.'/app'
        );

        writeJsonRoot(
            $snapshot.'/metadata.json',
            [
                'format' => 1,
                'snapshot_id' => $operationId,
                'created_at' => date('c'),
                'application_files' => $snapshotInventory,
                'config_sha256' => $configHash,
            ]
        );

        @unlink($requestFile);

        out([
            'ok' => true,
            'action' => 'snapshot',
            'snapshot_id' => $operationId,
        ]);
    } catch (Throwable $e) {
        fail($e->getMessage());
    }
}

if ($action === 'install') {
    $pending = $storageRoot.'/pending';

    assertRegularDirectory($pending, 'Pending-Verzeichnis');

    $package = $pending.'/package.zip';
    $manifestFile = $pending.'/manifest.json';
    $signatureFile = $pending.'/manifest.sig';

    $manifest = verifySignedManifest(
        $manifestFile,
        $signatureFile,
        $publicKeyFile
    );

    assertRegularFile($package, 'Updatepaket');

    $packageHash = hash_file('sha256', $package);

    if (
        !is_string($packageHash) ||
        !hash_equals($manifest['package_sha256'], strtolower($packageHash))
    ) {
        fail('Updatepaket stimmt nicht mit signiertem Manifest überein.');
    }

    assertRegularFile($appRoot.'/config.php', 'Lokale Konfiguration');

    $configHash = hash_file('sha256', $appRoot.'/config.php');

    if (!is_string($configHash)) {
        fail('config.php konnte nicht geprüft werden.');
    }

    $operationId = bin2hex(random_bytes(16));
    $work = $rootWork.'/'.$operationId;
    $snapshot = $rootSnapshots.'/'.$operationId;

    ensureRootPrivateDirectory($work);
    ensureRootPrivateDirectory($snapshot);

    try {
        copyTree($appRoot, $snapshot.'/app');

        $snapshotInventory = inventory($snapshot.'/app');

        writeJsonRoot(
            $snapshot.'/metadata.json',
            [
                'format' => 1,
                'snapshot_id' => $operationId,
                'created_at' => date('c'),
                'application_files' => $snapshotInventory,
                'config_sha256' => $configHash,
            ]
        );

        $stage = $work.'/stage';
        extractZipSafely($package, $stage);
        $stage = packageRoot($stage);

        $packageInventory = validatePackage(
            $stage,
            $manifest['version']
        );

        $next = dirname($appRoot).
            '/.'.basename($appRoot).
            '.next.'.$operationId;

        copyTree($appRoot, $next);
        overlayTree($stage, $next);

        $nextConfigHash = hash_file('sha256', $next.'/config.php');

        if (
            !is_string($nextConfigHash) ||
            !hash_equals($configHash, $nextConfigHash)
        ) {
            fail('Lokale config.php wurde im vorbereiteten Deployment verändert.');
        }

        foreach ($packageInventory as $relative => $entry) {
            if (($entry['type'] ?? '') !== 'file') {
                continue;
            }

            $installed = $next.'/'.$relative;

            if (!is_file($installed) || is_link($installed)) {
                fail('Vorbereitete Paketdatei fehlt: '.$relative);
            }

            $hash = hash_file('sha256', $installed);

            if (
                !is_string($hash) ||
                !hash_equals((string)$entry['sha256'], $hash)
            ) {
                fail('Vorbereitete Paketdatei stimmt nicht: '.$relative);
            }
        }

        swapApplication(
            $appRoot,
            $next,
            $configHash
        );

        foreach ($packageInventory as $relative => $entry) {
            if (($entry['type'] ?? '') !== 'file') {
                continue;
            }

            $installed = $appRoot.'/'.$relative;

            if (!is_file($installed) || is_link($installed)) {
                fail('Installierte Paketdatei fehlt: '.$relative);
            }

            $hash = hash_file('sha256', $installed);

            if (
                !is_string($hash) ||
                !hash_equals((string)$entry['sha256'], $hash)
            ) {
                fail('Installierte Paketdatei stimmt nicht: '.$relative);
            }
        }

        @unlink($requestFile);
        removeTree($work);

        out([
            'ok' => true,
            'action' => 'install',
            'version' => $manifest['version'],
            'snapshot_id' => $operationId,
        ]);
    } catch (Throwable $e) {
        fail($e->getMessage());
    }
}

if ($action === 'restore') {
    $snapshotId = $request['snapshot_id'] ?? null;

    if (
        !is_string($snapshotId) ||
        preg_match('/^[a-f0-9]{32}$/', $snapshotId) !== 1
    ) {
        fail('Ungültige Snapshot-ID.');
    }

    $snapshot = $rootSnapshots.'/'.$snapshotId;

    assertRegularDirectory($snapshot, 'Root-Snapshot');
    assertRegularDirectory($snapshot.'/app', 'Snapshot-Anwendung');
    assertRegularFile($snapshot.'/metadata.json', 'Snapshot-Metadaten');

    try {
        $meta = json_decode(
            (string)file_get_contents($snapshot.'/metadata.json'),
            true,
            64,
            JSON_THROW_ON_ERROR
        );
    } catch (Throwable $e) {
        fail('Snapshot-Metadaten sind ungültig.');
    }

    if (
        !is_array($meta) ||
        ($meta['snapshot_id'] ?? null) !== $snapshotId ||
        !is_array($meta['application_files'] ?? null) ||
        !is_string($meta['config_sha256'] ?? null)
    ) {
        fail('Snapshot-Metadaten sind unvollständig.');
    }

    $actualInventory = inventory($snapshot.'/app');

    if ($actualInventory !== $meta['application_files']) {
        fail('Root-Snapshot wurde nachträglich verändert.');
    }

    $snapshotConfigHash = hash_file(
        'sha256',
        $snapshot.'/app/config.php'
    );

    if (
        !is_string($snapshotConfigHash) ||
        !hash_equals($meta['config_sha256'], $snapshotConfigHash)
    ) {
        fail('config.php im Root-Snapshot stimmt nicht.');
    }

    $operationId = bin2hex(random_bytes(16));
    $next = dirname($appRoot).
        '/.'.basename($appRoot).
        '.restore.'.$operationId;

    copyTree($snapshot.'/app', $next);

    swapApplication(
        $appRoot,
        $next,
        $meta['config_sha256']
    );

    if (inventory($appRoot) !== $meta['application_files']) {
        fail('Wiederhergestellte Anwendung stimmt nicht mit Snapshot überein.');
    }

    @unlink($requestFile);

    out([
        'ok' => true,
        'action' => 'restore',
        'snapshot_id' => $snapshotId,
    ]);
}

fail('Unbekannte oder fehlende Deployment-Aktion.');
