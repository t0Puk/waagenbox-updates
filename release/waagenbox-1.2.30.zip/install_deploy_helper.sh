#!/bin/sh
set -eu

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
HELPER_SRC="$ROOT_DIR/deploy/waagenbox-deploy-helper.php"

HELPER_DST="/usr/local/sbin/waagenbox-deploy-helper"
ETC_DIR="/etc/waagenbox"
PUBLIC_KEY_DST="$ETC_DIR/deploy-public.pem"
SUDOERS_DST="/etc/sudoers.d/waagenbox-deploy"
STORAGE="/var/lib/waagebox/deploy"
RUNTIME_STORAGE="/var/lib/waagebox"

TEST_MODE="${TEST_MODE:-0}"
PUBLIC_KEY_SOURCE="${PUBLIC_KEY_SOURCE:-}"

if [ ! -f "$HELPER_SRC" ]; then
    echo "FEHLER: Deployment-Helfer fehlt." >&2
    exit 1
fi

php -l "$HELPER_SRC" >/dev/null

if [ -z "$PUBLIC_KEY_SOURCE" ] || [ ! -f "$PUBLIC_KEY_SOURCE" ]; then
    echo "FEHLER: PUBLIC_KEY_SOURCE muss auf den Release-Public-Key zeigen." >&2
    exit 1
fi

openssl pkey \
    -pubin \
    -in "$PUBLIC_KEY_SOURCE" \
    -noout \
    >/dev/null

TMP_SUDOERS="$(mktemp)"

cat > "$TMP_SUDOERS" <<EOF
# AJP Waagenbox – ausschließlich fester Deployment-Helfer ohne Argumente.
www-data ALL=(root) NOPASSWD: $HELPER_DST
EOF

chmod 0440 "$TMP_SUDOERS"

if command -v visudo >/dev/null 2>&1; then
    visudo -cf "$TMP_SUDOERS" >/dev/null
else
    echo "FEHLER: visudo fehlt." >&2
    rm -f "$TMP_SUDOERS"
    exit 1
fi

if [ "$TEST_MODE" = "1" ]; then
    echo "TEST_MODE_OK"
    echo "HELPER=$HELPER_DST"
    echo "PUBLIC_KEY=$PUBLIC_KEY_DST"
    echo "SUDOERS=$SUDOERS_DST"
    echo "STORAGE=$STORAGE"
    echo "RUNTIME_STORAGE=$RUNTIME_STORAGE"
    rm -f "$TMP_SUDOERS"
    exit 0
fi

install -d -o root -g root -m 0755 /usr/local/sbin
install -d -o root -g root -m 0755 "$ETC_DIR"
install -d -o www-data -g www-data -m 0750 "$STORAGE"
install -d -o www-data -g www-data -m 0750 "$STORAGE/pending"

install \
    -o root \
    -g root \
    -m 0755 \
    "$HELPER_SRC" \
    "$HELPER_DST"

install \
    -o root \
    -g root \
    -m 0644 \
    "$PUBLIC_KEY_SOURCE" \
    "$PUBLIC_KEY_DST"

install \
    -o root \
    -g root \
    -m 0440 \
    "$TMP_SUDOERS" \
    "$SUDOERS_DST"

rm -f "$TMP_SUDOERS"

visudo -cf "$SUDOERS_DST" >/dev/null

# Bootstrap v2 kann operation.json als root neu anlegen bzw. versöhnen.
# Der Web-Updater liest und ersetzt dieses Journal anschließend selbst.
# Nur freigegebene, nicht mutierende Journale werden deshalb an www-data
# übergeben; aktive/ungeklärte Zustände bleiben unangetastet und führen zum
# sicheren Abbruch.
JOURNAL="$RUNTIME_STORAGE/operation.json"
if [ -f "$JOURNAL" ]; then
    JOURNAL_SAFE="$(
        php -r '
$d=json_decode(file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);
$state=(string)($d["state"] ?? "");
$mutating=!empty($d["mutating"]);
echo (!$mutating && in_array($state,["complete","recovered","aborted"],true)) ? "1" : "0";
' "$JOURNAL"
    )"

    if [ "$JOURNAL_SAFE" != "1" ]; then
        echo "FEHLER: operation.json ist nicht freigegeben; Besitzer wird nicht geändert." >&2
        exit 1
    fi

    chown www-data:www-data "$JOURNAL"
    chmod 0600 "$JOURNAL"
    echo "UPDATE_JOURNAL_PERMISSIONS_OK"
fi

echo "Deployment-Helfer installiert."
