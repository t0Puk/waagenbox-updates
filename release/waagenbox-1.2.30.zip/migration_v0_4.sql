-- WägeSoftware v0.4: Kunden und Produkte
-- Einmalig in phpMyAdmin in der bereits verwendeten Datenbank ausführen.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS customers (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  address TEXT NULL,
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_customer_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  unit VARCHAR(30) NOT NULL DEFAULT 'kg',
  notes TEXT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_product_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `weighings` MODIFY `vehicle_id` INT UNSIGNED NULL;
ALTER TABLE `weighings` ADD COLUMN IF NOT EXISTS `customer_id` INT UNSIGNED NULL AFTER `vehicle_id`;
ALTER TABLE `weighings` ADD COLUMN IF NOT EXISTS `product_id` INT UNSIGNED NULL AFTER `customer_id`;
ALTER TABLE `weighings` ADD KEY IF NOT EXISTS `idx_weigh_customer` (`customer_id`);
ALTER TABLE `weighings` ADD KEY IF NOT EXISTS `idx_weigh_product` (`product_id`);

-- Falls die beiden Fremdschlüssel noch nicht existieren, diese beiden Befehle ausführen.
ALTER TABLE `weighings`
  ADD CONSTRAINT `fk_weigh_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL;

ALTER TABLE `weighings`
  ADD CONSTRAINT `fk_weigh_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL;
