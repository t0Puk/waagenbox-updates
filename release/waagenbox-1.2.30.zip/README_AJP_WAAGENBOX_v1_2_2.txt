AJP Waagenbox v1.2.2 – Produktion

Änderungen:
- Waagenanzeige berücksichtigt 5-kg-Auflösung (Darstellung ohne Nachkommastellen).
- Dashboard-Uhrzeit steht oben links direkt unter dem Waagen-/Anlagennamen.
- Wiegungstabelle: Trigger-Spalte und Aktionsspalte verbreitert.
- Wiegeseite: größerer Gewichtsbereich und einheitlicher Testgewichtsbereich.
- Grundlage für zentrales Update-System über IONOS bleibt enthalten.

Hinweis:
Die lokale Datenbank wird bei diesem Update nicht verändert.
