<?php
require_once __DIR__.'/../functions.php';
require_once __DIR__.'/../update_safety.php';
require_once __DIR__.'/../deploy/update_transaction.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'message'=>'Nur POST ist erlaubt.']); exit; }

if (!function_exists('requireCsrfToken')) {
    http_response_code(503);
    echo json_encode([
        'ok'=>false,
        'message'=>'Update-Bootstrap ist unvollständig: auth.php muss vor dem ersten Update auf den aktuellen Sicherheitsstand gebracht werden.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

requireCsrfToken();
set_error_handler(static function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$state = null;
$lock = null;
try {
    if (PHP_OS_FAMILY !== 'Linux') throw new RuntimeException('Updateinstallation benötigt die Linux-Zielumgebung.');
    ignore_user_abort(true);
    set_time_limit(0);
    $root = rollbackBackupRoot();
    $storage = dirname($root);
    $lock = updateSafetyLock($storage);
    $journal = $storage.'/operation.json';
    $work = $storage.'/update_'.date('Ymd_His').'_'.bin2hex(random_bytes(8));
    updateSafetyDirectory($work);
    $state = ['state'=>'preparing', 'mutating'=>false, 'app'=>dirname(__DIR__), 'work'=>$work, 'snapshot'=>$work.'/snapshot'];
    updateSafetyWriteJson($journal, $state);
    waagenboxUpdateShutdown($state, $journal);
    foreach ([['cp'], ['mariadb-dump','mysqldump'], ['mariadb','mysql']] as $programs) updateSafetyBinary($programs);
    $php = updateSafetyBinary(['php']);
    if (!function_exists('curl_init') || !class_exists('ZipArchive')) throw new RuntimeException('PHP-Erweiterungen cURL und ZIP werden benötigt.');
    $url = updateCheckUrl();
    if (!preg_match('~^https://~i', $url)) throw new RuntimeException('Update-Manifest muss über HTTPS geladen werden.');
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_PROTOCOLS_STR=>'https', CURLOPT_REDIR_PROTOCOLS_STR=>'https', CURLOPT_CONNECTTIMEOUT=>4, CURLOPT_TIMEOUT=>15, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $code < 200 || $code >= 300) throw new RuntimeException('Update-Manifest konnte nicht geladen werden.');
    $manifest = json_decode($body, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($manifest) || !is_string($manifest['version'] ?? null) || !preg_match('/^\d+\.\d+\.\d+$/', $manifest['version']) ||
        !is_string($manifest['download_url'] ?? null) || !preg_match('~^https://~i', $manifest['download_url']) ||
        !is_string($manifest['signature_url'] ?? null) || !preg_match('~^https://~i', $manifest['signature_url']) ||
        !is_string($manifest['sha256'] ?? null) || !preg_match('/^[a-f0-9]{64}$/i', $manifest['sha256'])) throw new RuntimeException('Ungültiges Update-Manifest.');
    if (compareAppVersions($manifest['version'], APP_VERSION) <= 0) {
        $state['state'] = 'complete';
        updateSafetyWriteJson($journal, $state);
        echo json_encode(['ok'=>true, 'updated'=>false, 'message'=>'Die Waagenbox ist bereits aktuell.']);
        exit;
    }
    $zipFile = $work.'/package.zip';
    $fp = fopen($zipFile, 'xb');
    if (!$fp) throw new RuntimeException('Update-Datei konnte nicht angelegt werden.');
    $ch = curl_init($manifest['download_url']);
    curl_setopt_array($ch, [CURLOPT_FILE=>$fp, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_PROTOCOLS_STR=>'https', CURLOPT_REDIR_PROTOCOLS_STR=>'https', CURLOPT_CONNECTTIMEOUT=>6, CURLOPT_TIMEOUT=>120, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
        CURLOPT_NOPROGRESS=>false, CURLOPT_XFERINFOFUNCTION=>static fn($handle, $size, $downloaded, $uploadSize, $uploaded) => $downloaded > 256*1024*1024 ? 1 : 0]);
    try {
        $ok = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    } finally { curl_close($ch); fclose($fp); }
    if (!$ok || $code < 200 || $code >= 300) throw new RuntimeException('Update-Download fehlgeschlagen oder zu groß.');
    if (!hash_equals(strtolower($manifest['sha256']), (string)hash_file('sha256', $zipFile))) throw new RuntimeException('Prüfsumme des Updatepakets stimmt nicht überein.');

    $signatureFile = $work.'/manifest.sig';
    waagenboxUpdateDownloadHttps(
        $manifest['signature_url'],
        $signatureFile
    );

    $signature = file_get_contents($signatureFile);
    if (!is_string($signature) || $signature === '') throw new RuntimeException('Update-Signatur ist leer.');

    $stage = updateSafetyUnpack($zipFile, $work.'/stage');
    $packageFiles = updateSafetyPackage($stage, $manifest['version'], $php, $work.'/package_check.log');

    $configSource = file_get_contents($state['app'].'/config.php');
    if (!is_string($configSource)) throw new RuntimeException('Lokale config.php konnte nicht geprüft werden.');

    $legacyPreview = updateSafetyLegacyConfig($configSource);
    if ($legacyPreview !== $configSource) {
        throw new RuntimeException(
            'Update-Bootstrap ist noch nicht abgeschlossen: APP_VERSION muss vor dem ersten Root-Deployment aus config.php migriert werden.'
        );
    }

    $expectedConfigHash = hash_file('sha256', $state['app'].'/config.php');
    if (!is_string($expectedConfigHash)) throw new RuntimeException('Lokale config.php konnte nicht gehasht werden.');

    updateSafetySnapshot(
        $state['app'],
        $state['snapshot'],
        [
            'previous_version'=>APP_VERSION,
            'new_version'=>$manifest['version']
        ]
    );

    // DB-Snapshot zuerst vollständig aktivieren.
    updateSafetyActivate($state['snapshot'], $root);
    $state['snapshot'] = $root;

    // Root-Application-Snapshot wird VOR der ersten Mutation erzeugt.
    $deploySnapshot = waagenboxDeploySnapshot();
    $state['deploy_snapshot_id'] = $deploySnapshot['snapshot_id'];

    waagenboxUpdateAttachDeploySnapshot(
        $root,
        $state['deploy_snapshot_id']
    );

    $state['state'] = 'applying';
    $state['mutating'] = true;
    updateSafetyWriteJson($journal, $state);

    // Erste Application-Mutation ausschließlich durch den Root-Helper.
    waagenboxDeployInstall(
        $zipFile,
        $manifest['version'],
        $manifest['sha256'],
        $signature
    );
    $migrations = glob($stage.'/migration_v*.sql') ?: [];
    sort($migrations, SORT_NATURAL);
    foreach ($migrations as $migration) {
        if (!preg_match('/^migration_v(\d+(?:_\d+){1,2})(?:_[A-Za-z][A-Za-z0-9_-]*)?\.sql$/', basename($migration), $match)) continue;
        $parts = explode('_', $match[1]);
        while (count($parts) < 3) $parts[] = '0';
        $version = implode('.', $parts);
        if (compareAppVersions($version, APP_VERSION) <= 0 || compareAppVersions($version, $manifest['version']) > 0) continue;
        try {
            updateSafetyRun(array_merge(updateSafetyDbArgs(updateSafetyBinary(['mariadb','mysql'])), [DB_NAME]), $work.'/migration.log', $migration, null, updateSafetyDbEnv());
        } catch (Throwable $e) { throw new RuntimeException('Migration '.basename($migration).' fehlgeschlagen. '.$e->getMessage()); }
    }
    if (!hash_equals($expectedConfigHash, (string)hash_file('sha256', $state['app'].'/config.php'))) throw new RuntimeException('Lokale Konfiguration wurde unerwartet verändert.');
    // Eigene, frische DB-Verbindung: Import und PDO-Verbindung nicht verwechseln.
    $check = updateSafetyDb();
    foreach (['settings','vehicles','weighings','weighing_state'] as $table) $check->query('SELECT 1 FROM `'.$table.'` LIMIT 1');
    saveAppSetting('update_ignored_version','');
    saveAppSetting('update_snoozed_until','');
    saveAppSetting('update_manifest_cache','');
    saveAppSetting('update_last_check',date('Y-m-d H:i:s'));
    if (function_exists('opcache_reset')) opcache_reset();
    $state['state'] = 'complete';
    updateSafetyWriteJson($journal, array_replace($state, ['mutating'=>false]));
    $state['mutating'] = false;
    // Bereinigungsfehler dürfen einen erfolgreich abgeschlossenen Updatevorgang
    // nicht nachträglich zurückrollen oder als fehlgeschlagene Installation melden.
    $warnings = [];
    try { updateSafetyMarkSuccessfulSnapshot($root); }
    catch (Throwable $e) { $warnings[] = 'Sicherung bleibt geschützt; Erfolgsmarkierung konnte nicht gespeichert werden.'; }
    $warnings = array_merge($warnings, updateSafetyCleanupSuccess($state, $root));
    echo json_encode(['ok'=>true, 'updated'=>true, 'version'=>$manifest['version'], 'warnings'=>$warnings, 'message'=>'Update installiert und geprüft.'.($warnings ? ' Hinweise: '.implode(' ', $warnings) : ' Temporäre Paketdateien wurden bereinigt.')], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    $message = $state === null ? $e->getMessage() : waagenboxUpdateFailure($state, $journal, $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>$message], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
