<?php
function validateServiceWlan(string $action, string $ssid, string $password): void {
    if (!in_array($action, ['status', 'enable', 'disable'], true)) throw new InvalidArgumentException('Ungültige WLAN-Aktion.');
    if ($action !== 'enable') return;
    if ($ssid === '' || strlen($ssid) > 32 || preg_match('/[\x00-\x1f\x7f]/', $ssid) || !preg_match('//u', $ssid)) {
        throw new InvalidArgumentException('Die SSID muss 1 bis 32 UTF-8-Bytes ohne Steuerzeichen enthalten.');
    }
    if (!preg_match('/\A[\x20-\x7e]{8,63}\z/D', $password)) {
        throw new InvalidArgumentException('Das WLAN-Passwort muss 8 bis 63 druckbare ASCII-Zeichen enthalten.');
    }
}

function serviceWlanRequest(string $action, string $ssid = '', string $password = ''): array {
    validateServiceWlan($action, $ssid, $password);
    $helper = '/usr/local/sbin/waagenbox-service-wlan';
    if (PHP_OS_FAMILY !== 'Linux' || !is_executable($helper) || !is_executable('/usr/bin/nmcli')) {
        return ['ok'=>false, 'message'=>'Service-WLAN nicht verfügbar: NetworkManager oder der freigegebene Service-Helper ist nicht installiert.'];
    }
    // Fester Befehl; Passwort ausschließlich über stdin, niemals Argumente/Logs/DB.
    $process = proc_open(['/usr/bin/sudo', '-n', $helper], [0=>['pipe','r'], 1=>['pipe','w'], 2=>['file','/dev/null','a']], $pipes);
    if (!is_resource($process)) return ['ok'=>false, 'message'=>'Service-WLAN-Helper konnte nicht gestartet werden.'];
    fwrite($pipes[0], json_encode(['action'=>$action, 'ssid'=>$ssid, 'password'=>$password], JSON_THROW_ON_ERROR));
    fclose($pipes[0]);
    stream_set_blocking($pipes[1], false);
    $output = '';
    $deadline = microtime(true) + 45;
    do {
        $output .= stream_get_contents($pipes[1], 8192);
        $running = proc_get_status($process)['running'];
        if (!$running) break;
        usleep(50000);
    } while (microtime(true) < $deadline && strlen($output) < 16384);
    if ($running) proc_terminate($process);
    $output .= stream_get_contents($pipes[1], 8192);
    fclose($pipes[1]);
    proc_close($process);
    $result = json_decode($output, true);
    return is_array($result) && isset($result['ok'], $result['message']) ? $result :
        ['ok'=>false, 'message'=>'Service-WLAN-Helper nicht erreichbar, nicht freigegeben oder Zeitlimit überschritten. Status erneut prüfen.'];
}
