<?php
require_once __DIR__.'/../functions.php';
require_once __DIR__.'/../update_safety.php';
require_once __DIR__.'/../deploy/update_transaction.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'message'=>'Nur POST ist erlaubt.']); exit; }
requireCsrfToken();
if (defined('WEB_DEVELOPMENT') && WEB_DEVELOPMENT) { http_response_code(403); echo json_encode(['ok'=>false,'message'=>'Rollback ist nur auf dem Raspberry möglich.']); exit; }
set_error_handler(static function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$state = null;
$lock = null;
try {
    if (PHP_OS_FAMILY !== 'Linux') throw new RuntimeException('Rollback benötigt die Linux-Zielumgebung.');
    $reason = trim((string)($_POST['reason'] ?? ''));
    if ($reason === '' || mb_strlen($reason) > 5000) throw new RuntimeException('Bitte einen Rollback-Grund mit 1 bis 5000 Zeichen angeben.');
    ignore_user_abort(true);
    set_time_limit(0);
    $root = rollbackBackupRoot();
    $storage = dirname($root);
    $lock = updateSafetyLock($storage);
    $journal = $storage.'/operation.json';
    // Alte Sicherungen ohne Prüfnachweis bleiben unangetastet und werden nicht blind importiert.
    $info = updateSafetyValidateSnapshot($root);
    if (empty($info['previous_version'])) throw new RuntimeException('Die Zielversion fehlt in der Rollback-Sicherung.');

    $sourceDeploySnapshotId = waagenboxUpdateDeploySnapshotId(
        $root
    );
    foreach ([['cp'], ['mariadb-dump','mysqldump'], ['mariadb','mysql']] as $programs) updateSafetyBinary($programs);
    $recipient = trim(appSetting('rollback_email',''));
    $currentVersion = APP_VERSION;
    $previousVersion = (string)$info['previous_version'];
    $work = $storage.'/rollback_attempt_'.date('Ymd_His').'_'.bin2hex(random_bytes(8));
    updateSafetyDirectory($work);
    $state = ['state'=>'preparing', 'mutating'=>false, 'app'=>dirname(__DIR__), 'work'=>$work, 'snapshot'=>$work.'/snapshot'];
    updateSafetyWriteJson($journal, $state);
    waagenboxUpdateShutdown($state, $journal);
    updateSafetySnapshot(
        $state['app'],
        $state['snapshot'],
        [
            'previous_version'=>$currentVersion,
            'new_version'=>$previousVersion
        ]
    );

    // Root-Snapshot des aktuellen Zustands für einen Rollback-des-Rollbacks.
    $currentDeploySnapshot = waagenboxDeploySnapshot();
    $state['deploy_snapshot_id'] =
        $currentDeploySnapshot['snapshot_id'];

    waagenboxUpdateAttachDeploySnapshot(
        $state['snapshot'],
        $state['deploy_snapshot_id']
    );

    // Bei Fehler oder Prozessabbruch bleibt auch die verwendete Zielgeneration geschützt.
    $sourcePin = updateSafetyPinSnapshot($root);

    $state['state'] = 'rolling_back';
    $state['mutating'] = true;
    updateSafetyWriteJson($journal, $state);

    updateSafetyRestoreDatabase(
        $root,
        $work.'/rollback_database.log'
    );

    waagenboxDeployRestore(
        $sourceDeploySnapshotId
    );
    $state['state'] = 'complete';
    updateSafetyWriteJson($journal, array_replace($state, ['mutating'=>false]));
    $state['mutating'] = false;
    $warnings = [];
    try {
        updateSafetyMarkSuccessfulSnapshot($state['snapshot']);
        updateSafetyUnpinSuccessfulSnapshot($root, $sourcePin);
    } catch (Throwable $e) { $warnings[] = 'Sicherungen bleiben geschützt; Aufbewahrungsstatus konnte nicht vollständig aktualisiert werden.'; }
    $warnings = array_merge($warnings, updateSafetyCleanupSuccess($state, $root));
    // Eine fehlgeschlagene Benachrichtigung darf keinen erfolgreichen Rollback rückgängig machen.
    $emailSent = false;
    $emailError = '';
    if ($recipient !== '') {
        try {
            $subject = 'AJP Waagenbox – Rollback von v'.$currentVersion.' auf v'.$previousVersion;
            $body = "AJP Waagenbox – manueller Rollback\nVon Version: {$currentVersion}\nAuf Version: {$previousVersion}\nZeitpunkt: ".date('d.m.Y H:i:s')."\n\nGrund:\n{$reason}\n\nDer Rollback wurde erfolgreich ausgeführt.\n";
            $emailSent = mail($recipient, $subject, $body, "Content-Type: text/plain; charset=UTF-8\r\n");
            if (!$emailSent) $emailError = 'Rollback erfolgreich; E-Mail konnte nicht übergeben werden.';
        } catch (Throwable $e) { $emailError = 'Rollback erfolgreich; E-Mail konnte nicht übergeben werden.'; }
    }
    echo json_encode(['ok'=>true, 'version'=>$previousVersion, 'email_sent'=>$emailSent, 'email_error'=>$emailError, 'warnings'=>$warnings, 'message'=>'Rollback geprüft abgeschlossen. Die Sicherung des aktuellen Zustands bleibt unter '.$state['snapshot'].' erhalten.'.($warnings ? ' Hinweise: '.implode(' ', $warnings) : '')], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    $message = $state === null ? $e->getMessage() : waagenboxUpdateFailure($state, $journal, $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>$message], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
}
