<?php
require_once __DIR__.'/../functions.php';
requireAdmin();
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['ok'=>false]);exit;}
requireCsrfToken();
setUpdateSnoozedUntil(date('Y-m-d H:i:s',time()+86400)); echo json_encode(['ok'=>true]);
