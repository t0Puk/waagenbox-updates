<?php
declare(strict_types=1);

require_once __DIR__.'/deploy_client.php';

/**
 * Verknüpft einen DB-/Safety-Snapshot mit dem zugehörigen,
 * root-geschützten Application-Snapshot.
 */
function waagenboxUpdateAttachDeploySnapshot(
    string $snapshot,
    string $deploySnapshotId
): void {
    if (
        preg_match(
            '/^[a-f0-9]{32}$/',
            $deploySnapshotId
        ) !== 1
    ) {
        throw new RuntimeException(
            'Ungültige Root-Snapshot-ID.'
        );
    }

    $meta = updateSafetyValidateSnapshot($snapshot);

    $meta['deploy_snapshot_id'] = $deploySnapshotId;

    updateSafetyWriteJson(
        $snapshot.'/metadata.json',
        $meta
    );

    $verified = updateSafetyValidateSnapshot(
        $snapshot
    );

    if (
        ($verified['deploy_snapshot_id'] ?? null)
        !== $deploySnapshotId
    ) {
        throw new RuntimeException(
            'Root-Snapshot-ID konnte nicht sicher mit der '
            .'Datenbanksicherung verknüpft werden.'
        );
    }
}


function waagenboxUpdateDeploySnapshotId(
    string $snapshot
): string {
    $meta = updateSafetyValidateSnapshot($snapshot);

    $id = $meta['deploy_snapshot_id'] ?? null;

    if (
        !is_string($id) ||
        preg_match('/^[a-f0-9]{32}$/', $id) !== 1
    ) {
        throw new RuntimeException(
            'Sicherung besitzt keinen gültigen '
            .'Root-Application-Snapshot.'
        );
    }

    return $id;
}


/**
 * Gemeinsamer Recovery-Pfad.
 *
 * Datenbank und Anwendung werden bewusst unabhängig voneinander
 * versucht. Ein Fehler in einem Teil verhindert den zweiten
 * Restore nicht.
 */
function waagenboxUpdateRecover(
    array $state,
    ?callable $restoreDatabase = null,
    ?callable $restoreApplication = null
): array {
    $errors = [];

    $snapshot = (string)($state['snapshot'] ?? '');
    $work = (string)($state['work'] ?? '');
    $deploySnapshotId =
        (string)($state['deploy_snapshot_id'] ?? '');

    if ($snapshot === '' || $work === '') {
        return [
            'Recovery-Zustand ist unvollständig.'
        ];
    }

    updateSafetyDirectory($work);

    $restoreDatabase ??= static function () use (
        $snapshot,
        $work
    ): void {
        updateSafetyRestoreDatabase(
            $snapshot,
            $work.'/restore_database.log'
        );
    };

    $restoreApplication ??= static function () use (
        $deploySnapshotId
    ): void {
        if (
            preg_match(
                '/^[a-f0-9]{32}$/',
                $deploySnapshotId
            ) !== 1
        ) {
            throw new RuntimeException(
                'Root-Snapshot-ID fehlt.'
            );
        }

        waagenboxDeployRestore(
            $deploySnapshotId
        );
    };

    try {
        $restoreDatabase();
    } catch (Throwable $e) {
        $errors[] =
            'Datenbank: '.$e->getMessage();
    }

    try {
        $restoreApplication();
    } catch (Throwable $e) {
        $errors[] =
            'Anwendung: '.$e->getMessage();
    }

    return $errors;
}


function waagenboxUpdateFailure(
    array &$state,
    string $journal,
    string $message
): string {
    if (!empty($state['mutating'])) {
        $errors = waagenboxUpdateRecover(
            $state
        );

        $state['state'] =
            $errors
                ? 'recovery_failed'
                : 'recovered';

        if ($errors) {
            $message .=
                ' Automatische Wiederherstellung '
                .'unvollständig: '
                .implode(' | ', $errors);
        } else {
            $message .=
                ' Anwendung und Datenbank wurden '
                .'auf den gesicherten Zustand '
                .'zurückgesetzt.';
        }
    } else {
        $state['state'] = 'aborted';

        $message .=
            ' Die Installation hat Anwendung und '
            .'Datenbank noch nicht verändert.';
    }

    $state['mutating'] = false;
    $state['error'] = $message;

    try {
        updateSafetyWriteJson(
            $journal,
            $state
        );
    } catch (Throwable $e) {
        $message .=
            ' Ablaufstatus konnte nicht gespeichert '
            .'werden; manuelle Prüfung erforderlich.';
    }

    return $message.
        ' Rettungsdateien bleiben erhalten: '.
        ($state['work'] ?? '').
        (!empty($state['snapshot'])
            ? ' ; '.$state['snapshot']
            : '');
}


function waagenboxUpdateShutdown(
    array &$state,
    string $journal
): void {
    $reserve = str_repeat('x', 262144);

    register_shutdown_function(
        function () use (
            &$state,
            $journal,
            &$reserve
        ): void {
            $reserve = null;

            if (empty($state['mutating'])) {
                return;
            }

            $message = waagenboxUpdateFailure(
                $state,
                $journal,
                'Wartungsvorgang wurde '
                .'unerwartet abgebrochen.'
            );

            error_log($message);

            if (!headers_sent()) {
                http_response_code(500);
                header(
                    'Content-Type: '
                    .'application/json; charset=utf-8'
                );
            }

            echo json_encode(
                [
                    'ok' => false,
                    'message' => $message,
                ],
                JSON_UNESCAPED_UNICODE |
                JSON_INVALID_UTF8_SUBSTITUTE
            );
        }
    );
}


/**
 * Kleine HTTPS-Datei, z.B. Signatur.
 */
function waagenboxUpdateDownloadHttps(
    string $url,
    string $target,
    int $maxBytes = 131072,
    int $timeout = 20
): void {
    if (
        !preg_match('~^https://~i', $url)
    ) {
        throw new RuntimeException(
            'Download-URL muss HTTPS verwenden.'
        );
    }

    $fp = fopen($target, 'xb');

    if (!$fp) {
        throw new RuntimeException(
            'Download-Zieldatei konnte nicht '
            .'angelegt werden.'
        );
    }

    $ch = curl_init($url);

    curl_setopt_array(
        $ch,
        [
            CURLOPT_FILE => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_PROTOCOLS_STR => 'https',
            CURLOPT_REDIR_PROTOCOLS_STR => 'https',
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_NOPROGRESS => false,
            CURLOPT_XFERINFOFUNCTION =>
                static function (
                    $handle,
                    $size,
                    $downloaded,
                    $uploadSize,
                    $uploaded
                ) use ($maxBytes): int {
                    return $downloaded > $maxBytes
                        ? 1
                        : 0;
                },
        ]
    );

    try {
        $ok = curl_exec($ch);
        $code = (int)curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );
    } finally {
        curl_close($ch);
        fclose($fp);
    }

    if (
        !$ok ||
        $code < 200 ||
        $code >= 300 ||
        !is_file($target) ||
        filesize($target) < 1 ||
        filesize($target) > $maxBytes
    ) {
        @unlink($target);

        throw new RuntimeException(
            'Signatur konnte nicht sicher '
            .'geladen werden.'
        );
    }

    @chmod($target, 0600);
}
