<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
$id=(int)db()->query('SELECT COALESCE(MAX(id),0) FROM weighings WHERE owner_user_id='.(int)currentOwnerId())->fetchColumn();
echo json_encode(['latest_id'=>$id],JSON_UNESCAPED_UNICODE);
