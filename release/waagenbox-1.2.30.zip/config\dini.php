<?php
/**
 * AJP Waagenbox – Dini 3590ETKR connection
 *
 * Erst aktivieren, wenn IP-Adresse und TCP-Port der konkreten Dini getestet sind.
 */
return [
    'enabled' => false,
    'host' => '192.168.55.50',
    'port' => 4000, // Platzhalter – nach TCP-Port-Test anpassen
    'timeout' => 2.0,
];
