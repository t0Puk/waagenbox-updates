<?php
require_once __DIR__.'/../functions.php';
header('Content-Type: application/json; charset=utf-8');
function mi():array{$d=json_decode(file_get_contents('php://input'),true);return is_array($d)?$d:$_POST;}
function settingForOwner(PDO $pdo,int $ownerId,string $key,string $default=''):string{$s=$pdo->prepare('SELECT value FROM settings WHERE owner_user_id=? AND `key`=? LIMIT 1');$s->execute([$ownerId,$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v;}
function dm(float $a,float $b,float $c,float $d):float{$r=6371000;$p1=deg2rad($a);$p2=deg2rad($c);$dp=deg2rad($c-$a);$dl=deg2rad($d-$b);$x=sin($dp/2)**2+cos($p1)*cos($p2)*sin($dl/2)**2;return 2*$r*asin(min(1,sqrt($x)));}
$d=mi();$token=trim((string)($d['token']??''));$lat=(float)($d['latitude']??0);$lon=(float)($d['longitude']??0);$acc=(float)($d['accuracy']??99999);
if($token===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültiger Token.']);exit;}
$pdo=db();$s=$pdo->prepare('SELECT r.*,v.plate,v.name AS vehicle_name,v.first_weight,v.active AS vehicle_active FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id WHERE r.mobile_token=? LIMIT 1');$s->execute([$token]);$r=$s->fetch();
if(!$r||(int)$r['active']!==1||(int)($r['vehicle_active']??0)!==1){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Fernbedienung oder Fahrzeug ist nicht aktiv.']);exit;}
if((float)$r['first_weight']<=0){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Für das Fahrzeug ist noch kein Erstgewicht hinterlegt.']);exit;}
$ownerId=(int)$r['owner_user_id'];
$gpsEnabled=settingForOwner($pdo,$ownerId,'gps_enabled','0')==='1';
if($gpsEnabled){
 if($lat<-90||$lat>90||$lon<-180||$lon>180){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Ungültige Standortdaten.']);exit;}
 if(settingForOwner($pdo,$ownerId,'gps_lat','')===''||settingForOwner($pdo,$ownerId,'gps_lon','')===''){http_response_code(503);echo json_encode(['ok'=>false,'message'=>'Der Standort der Waage ist noch nicht konfiguriert.']);exit;}
 $dist=dm($lat,$lon,(float)settingForOwner($pdo,$ownerId,'gps_lat'),(float)settingForOwner($pdo,$ownerId,'gps_lon'));$radius=max(1,(float)settingForOwner($pdo,$ownerId,'gps_radius_m','50'));$maxAcc=max(1,(float)settingForOwner($pdo,$ownerId,'gps_accuracy_m','50'));
 if($acc>$maxAcc){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'GPS-Genauigkeit zu schlecht.']);exit;}
 if($dist>$radius){http_response_code(403);echo json_encode(['ok'=>false,'message'=>'Du bist zu weit von der Waage entfernt.']);exit;}
}
function assignment(PDO $pdo,string $table,string $col,int $rid,int $ownerId):?int{$q=$pdo->prepare("SELECT $col FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 ORDER BY is_default DESC,$col LIMIT 1");$q->execute([$ownerId,$rid]);$first=$q->fetchColumn();if($first===false)return null;$c=$pdo->prepare("SELECT COUNT(*) FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1");$c->execute([$ownerId,$rid]);if((int)$c->fetchColumn()>1){$q=$pdo->prepare("SELECT $col FROM $table WHERE owner_user_id=? AND remote_id=? AND active=1 AND is_default=1 LIMIT 1");$q->execute([$ownerId,$rid]);$v=$q->fetchColumn();return $v===false?null:(int)$v;}return (int)$first;}
$fid=assignment($pdo,'remote_fields','field_id',(int)$r['id'],$ownerId);$cid=assignment($pdo,'remote_customers','customer_id',(int)$r['id'],$ownerId);$pid=assignment($pdo,'remote_products','product_id',(int)$r['id'],$ownerId);
useMobileContextByToken($token);
setPendingWeighing((float)$r['first_weight'],(int)$r['vehicle_id'],(int)$r['id'],'mobile',$fid,$cid,$pid);
echo json_encode(['ok'=>true,'message'=>'Wiegung gestartet.']);
