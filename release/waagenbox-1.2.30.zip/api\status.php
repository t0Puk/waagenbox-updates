<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['weight'=>currentWeight(),'status'=>weightStatus(),'scale_status'=>scaleStatusKey(),'scale_label'=>scaleStatusLabel()], JSON_UNESCAPED_UNICODE);
