<?php
// Kompatibilitäts-URL für ältere Links/Lesezeichen.
require __DIR__ . '/index.php';
