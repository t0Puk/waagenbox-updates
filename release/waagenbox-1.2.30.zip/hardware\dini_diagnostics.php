<?php
function diniDiagnosticActions(): array {
    return ['weight'=>'Gewicht', 'identify'=>'Identify / Geräteidentifikation', 'state'=>'State / Status', 'extended'=>'Extended', 'all'=>'All'];
}

function diniDiagnosticRead(object $dini, string $action): array {
    return match ($action) {
        'weight' => $dini->readWeight(),
        'identify' => ['raw'=>$dini->identify()],
        'state' => $dini->readState(),
        'extended' => $dini->readExtendedWeight(),
        'all' => $dini->readAll(),
        default => throw new InvalidArgumentException('Unzulässige Diagnoseaktion.'),
    };
}
