AJP WAAGENBOX v1.2.1 – Produktion

Änderungen gegenüber v1.2.0:
- Wiegungstabelle: Aktionsspalte bleibt auf Desktop am rechten Rand sichtbar.
- Wiegeseite: Bereich für aktuelles Gewicht wurde für größere Gewichte verbreitert/angepasst.
- Testgewichtsbereich passt sich an die Wiegeseite an.
- Datum/Uhrzeit werden kompakt oben links im Dashboard angezeigt.
- Zentrale Update-Prüfung über einen HTTPS-Update-Server vorbereitet.
- Update-Hinweis mit Jetzt installieren / Später / Diese Version ausblenden.
- Update-Paket wird vor Installation per SHA-256 geprüft.
- Lokale config.php wird bei einem Software-Update nicht überschrieben.
- Neue Einstellungen > Updates zur Konfiguration des Update-Servers.

Update-Manifest:
Die Waagenbox erwartet unter <Update-Server>/manifest.json mindestens:
{
  "version": "1.2.2",
  "download_url": "https://example.invalid/AJP_Waagenbox_Pi_v1_2_2_PRODUKTION.zip",
  "sha256": "...",
  "mandatory": false,
  "release_date": "2026-09-10",
  "message": "Beschreibung des Updates"
}

Vor dem echten Rollout des Update-Systems sollte der IONOS-Update-Endpunkt eingerichtet und mit einem Testpaket geprüft werden.
