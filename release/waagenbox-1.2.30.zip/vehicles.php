<?php
require_once __DIR__.'/functions.php';
requireLogin();

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['toggle_id'])) {
            $id=(int)$_POST['toggle_id'];
            if ($id<=0) throw new RuntimeException('Ungültiges Fahrzeug.');
            $pdo=db();
            $q=$pdo->prepare('SELECT active,plate FROM vehicles WHERE owner_user_id=? AND id=?');
            $q->execute([currentOwnerId(),$id]);
            $vehicle=$q->fetch();
            if (!$vehicle) throw new RuntimeException('Fahrzeug wurde nicht gefunden.');
            $newActive=((int)$vehicle['active']===1)?0:1;
            $s=$pdo->prepare('UPDATE vehicles SET active=? WHERE owner_user_id=? AND id=?');
            $s->execute([$newActive,currentOwnerId(),$id]);
            flash('Fahrzeug '.($newActive?'wurde aktiviert.':'wurde deaktiviert.'));
            redirect('vehicles.php');
        }

        if (isset($_POST['delete_id'])) {
            $id=(int)$_POST['delete_id'];
            if ($id<=0) throw new RuntimeException('Ungültiges Fahrzeug.');
            $pdo=db();
            $q=$pdo->prepare('SELECT COUNT(*) FROM weighings WHERE owner_user_id=? AND vehicle_id=?');
            $q->execute([currentOwnerId(),$id]);
            $wc=(int)$q->fetchColumn();
            if ($wc>0) throw new RuntimeException('Fahrzeug kann nicht gelöscht werden, weil bereits '.$wc.' Wiegung(en) damit verknüpft sind.');
            $s=$pdo->prepare('DELETE FROM vehicles WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$id]);
            flash($s->rowCount() ? 'Fahrzeug wurde gelöscht.' : 'Fahrzeug wurde nicht gefunden.');
            redirect('vehicles.php');
        }

        $plate = trim((string)($_POST['plate'] ?? ''));
        $name = trim((string)($_POST['name'] ?? ''));
        $firstRaw = trim((string)($_POST['first_weight'] ?? ''));
        $maxRaw = trim((string)($_POST['max_weight'] ?? ''));
        $notes = trim((string)($_POST['notes'] ?? ''));

        if ($plate === '') throw new RuntimeException('Bitte ein Kennzeichen eingeben.');
        if ($name === '') throw new RuntimeException('Bitte eine Bezeichnung eingeben.');

        $first = ($firstRaw === '') ? 0.0 : (float)str_replace(',', '.', $firstRaw);
        $max = ($maxRaw === '') ? null : (float)str_replace(',', '.', $maxRaw);

        $pdo = db();
        $stmt = $pdo->prepare('INSERT INTO `vehicles` (`plate`,`name`,`first_weight`,`max_weight`,`notes`) VALUES (?,?,?,?,?)');
        $stmt->execute([$plate, $name, $first, $max, $notes]);

        flash('Fahrzeug wurde angelegt.');
        redirect('vehicles.php');
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

layoutStart('Fahrzeuge','vehicles');
if ($error !== null) {
    echo '<div class="flash error"><strong>Fahrzeug konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
}
$rows = db()->query('SELECT `id`,`plate`,`name`,`first_weight`,`max_weight`,`notes`,`active`,`created_at` FROM `vehicles` WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY `name`,`plate`')->fetchAll();
?>
<div class="toolbar"><h1>Fahrzeuge</h1><a class="button primary" href="#neu">+ Fahrzeug anlegen</a></div>
<div class="card table-wrap"><table><tr><th>Status</th><th>Kennzeichen</th><th>Name</th><th>1. Gewicht</th><th>Max.</th><th></th></tr>
<?php foreach ($rows as $r): ?>
<tr>
<td><?=(int)$r['active']===1?'<strong>Aktiv</strong>':'<span class="muted">Deaktiviert</span>'?></td>
<td><?=h($r['plate'])?></td>
<td><?=h($r['name'])?></td>
<td><?= (float)$r['first_weight'] > 0 ? h(number_format((float)$r['first_weight'],1,',','.')).' kg' : '<span class="muted">nicht gesetzt</span>' ?></td>
<td><?= $r['max_weight'] !== null ? h(number_format((float)$r['max_weight'],1,',','.')).' kg' : '–' ?></td>
<td class="row-actions">
<?php if((int)$r['active']===1): ?><a href="weighing.php?vehicle_id=<?=(int)$r['id']?>">Wiegung / Erstgewicht</a><?php endif; ?>
<form method="post" style="display:inline"><input type="hidden" name="toggle_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button"><?=(int)$r['active']===1?'Deaktivieren':'Aktivieren'?></button></form>
<form method="post" class="delete-form" onsubmit="return confirm(<?=json_encode('Fahrzeug '.($r['plate'] ?? '').' wirklich endgültig löschen?\n\nFalls bereits Wiegungen vorhanden sind, wird das Löschen verhindert.\n\nDieser Vorgang kann nicht rückgängig gemacht werden.', JSON_UNESCAPED_UNICODE)?>);"><input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button-danger">Löschen</button></form>
</td></tr>
<?php endforeach; ?></table></div>
<div class="card" id="neu"><h2>Fahrzeug anlegen</h2><form method="post"><div class="form-grid">
<div><label>Kennzeichen</label><input name="plate" required value="<?=h($_POST['plate'] ?? '')?>"></div>
<div><label>Name / Bezeichnung</label><input name="name" required value="<?=h($_POST['name'] ?? '')?>"></div>
<div><label>1. Gewicht (kg)</label><input type="number" step="0.1" min="0" name="first_weight" value="<?=h($_POST['first_weight'] ?? '')?>"><small>Wenn leer, wird 0 kg gespeichert.</small></div>
<div><label>Max. Gewicht (kg)</label><input type="number" step="0.1" min="0" name="max_weight" value="<?=h($_POST['max_weight'] ?? '')?>"></div>
<div class="full"><label>Notizen</label><textarea name="notes"><?=h($_POST['notes'] ?? '')?></textarea></div>
</div><p><button>Fahrzeug speichern</button></p></form></div>
<?php layoutEnd(); ?>
