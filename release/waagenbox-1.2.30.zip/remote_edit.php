<?php
require_once __DIR__.'/functions.php';
requireLogin();
$pdo=db(); $id=(int)($_GET['id']??$_POST['id']??0); $error=null;
$s=$pdo->prepare('SELECT r.*,v.plate,v.name AS vehicle_name FROM remotes r LEFT JOIN vehicles v ON v.id=r.vehicle_id AND v.owner_user_id=r.owner_user_id WHERE r.owner_user_id=? AND r.id=?');$s->execute([currentOwnerId(),$id]);$remote=$s->fetch();if(!$remote){http_response_code(404);exit('Fernbedienung nicht gefunden');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $action=(string)($_POST['action']??'');

  // Fahrzeug unabhängig von den übrigen Zuordnungen speichern.
  if($action==='save_vehicle'){
   $vehicleId=(int)($_POST['vehicle_id']??0);
   if($vehicleId<=0) throw new RuntimeException('Bitte ein Fahrzeug auswählen.');
   $vq=$pdo->prepare('SELECT id FROM vehicles WHERE owner_user_id=? AND id=? AND active=1');$vq->execute([currentOwnerId(),$vehicleId]);
   if(!$vq->fetchColumn()) throw new RuntimeException('Das ausgewählte Fahrzeug ist nicht aktiv oder wurde nicht gefunden.');
   $pdo->prepare('UPDATE remotes SET vehicle_id=? WHERE owner_user_id=? AND id=?')->execute([$vehicleId,currentOwnerId(),$id]);
   flash('Fahrzeugzuordnung wurde gespeichert.');
   redirect('remote_edit.php?id='.$id);
  }

  // Schläge/Kunden/Produkte können unabhängig vom Fahrzeug gespeichert werden.
  if($action==='save_assignments'){
   $fieldIds=array_map('intval',$_POST['fields']??[]);
   $customerIds=array_map('intval',$_POST['customers']??[]);
   $productIds=array_map('intval',$_POST['products']??[]);
   $defaultField=(int)($_POST['default_field']??0);
   $defaultCustomer=(int)($_POST['default_customer']??0);
   $defaultProduct=(int)($_POST['default_product']??0);

   // Ein Standard darf nur gesetzt werden, wenn der Eintrag auch zugeordnet ist.
   if($defaultField>0 && !in_array($defaultField,$fieldIds,true)) throw new RuntimeException('Der als Standard gewählte Schlag muss auch zugeordnet sein.');
   if($defaultCustomer>0 && !in_array($defaultCustomer,$customerIds,true)) throw new RuntimeException('Der als Standard gewählte Kunde muss auch zugeordnet sein.');
   if($defaultProduct>0 && !in_array($defaultProduct,$productIds,true)) throw new RuntimeException('Das als Standard gewählte Produkt muss auch zugeordnet sein.');

   $pdo->beginTransaction();
   $pdo->prepare('DELETE FROM remote_fields WHERE owner_user_id=? AND remote_id=?')->execute([currentOwnerId(),$id]);
   $pdo->prepare('DELETE FROM remote_customers WHERE owner_user_id=? AND remote_id=?')->execute([currentOwnerId(),$id]);
   $pdo->prepare('DELETE FROM remote_products WHERE owner_user_id=? AND remote_id=?')->execute([currentOwnerId(),$id]);
   $q=$pdo->prepare('INSERT INTO remote_fields(owner_user_id,remote_id,field_id,active,is_default) VALUES(?,?,?,1,?)');
   foreach($fieldIds as $x) if($x>0) $q->execute([currentOwnerId(),$id,$x,$x===$defaultField?1:0]);
   $q=$pdo->prepare('INSERT INTO remote_customers(owner_user_id,remote_id,customer_id,active,is_default) VALUES(?,?,?,1,?)');
   foreach($customerIds as $x) if($x>0) $q->execute([currentOwnerId(),$id,$x,$x===$defaultCustomer?1:0]);
   $q=$pdo->prepare('INSERT INTO remote_products(owner_user_id,remote_id,product_id,active,is_default) VALUES(?,?,?,1,?)');
   foreach($productIds as $x) if($x>0) $q->execute([currentOwnerId(),$id,$x,$x===$defaultProduct?1:0]);
   $pdo->commit();
   flash('Zuordnungen der Fernbedienung wurden gespeichert.');
   redirect('remote_edit.php?id='.$id);
  }

  throw new RuntimeException('Unbekannte Aktion.');
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
}
$fields=$pdo->query('SELECT id,name,crop,year FROM fields WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();$customers=$pdo->query('SELECT id,name FROM customers WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();$products=$pdo->query('SELECT id,name FROM products WHERE owner_user_id='.(int)currentOwnerId().' ORDER BY name')->fetchAll();
$assigned=[];foreach(['fields'=>'field_id','customers'=>'customer_id','products'=>'product_id'] as $table=>$col){$q=$pdo->prepare("SELECT $col,active,is_default FROM remote_{$table} WHERE owner_user_id=? AND remote_id=?");$q->execute([currentOwnerId(),$id]);$assigned[$table]=$q->fetchAll();}
function idsFor(array $rows,string $col): array { $a=[]; foreach($rows as $r) if((int)$r['active']) $a[]=(int)$r[$col]; return $a; }
function defFor(array $rows,string $col): int { foreach($rows as $r) if((int)$r['is_default']===1 && (int)$r['active']===1) return (int)$r[$col]; return 0; }
$af=idsFor($assigned['fields'],'field_id');$ac=idsFor($assigned['customers'],'customer_id');$ap=idsFor($assigned['products'],'product_id');$df=defFor($assigned['fields'],'field_id');$dc=defFor($assigned['customers'],'customer_id');$dp=defFor($assigned['products'],'product_id');
layoutStart('Fernbedienung bearbeiten','remotes');if($error)echo '<div class="flash error"><strong>Zuordnungen konnten nicht gespeichert werden.</strong><br>'.h($error).'</div>';
?>
<div class="toolbar"><h1>Fernbedienung: <?=h($remote['name'])?></h1><a class="button" href="remotes.php">← Zurück</a></div>
<div class="card"><h2>Fahrzeugzuordnung</h2><form method="post"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="action" value="save_vehicle"><div><label>Fahrzeug</label><select name="vehicle_id" required><?php $remoteVehicles=$pdo->query('SELECT id,plate,name FROM vehicles WHERE owner_user_id='.(int)currentOwnerId().' AND active=1 ORDER BY plate')->fetchAll(); foreach($remoteVehicles as $v): ?><option value="<?=$v['id']?>" <?=((int)$v['id']===(int)$remote['vehicle_id'])?'selected':''?>><?=h($v['plate'].' – '.$v['name'])?></option><?php endforeach; ?></select></div><p><button class="button primary">Fahrzeug speichern</button></p></form></div>
<div class="card"><p><strong>Aktuelles Fahrzeug:</strong> <?=h(trim(($remote['plate']??'').' – '.($remote['vehicle_name']??''),' –'))?></p><p>Du kannst mehrere Schläge, Kunden und Produkte zuordnen. Je Kategorie kann zusätzlich ein <strong>Standard</strong> festgelegt werden. Dieser Standard wird bei einer automatischen Fernbedienungswiegung verwendet.</p>
<form method="post"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="action" value="save_assignments"><h3>Schläge</h3><div class="check-grid"><?php foreach($fields as $x):?><label class="check-item"><input type="checkbox" name="fields[]" value="<?=$x['id']?>" <?=in_array((int)$x['id'],$af,true)?'checked':''?>><span><?=h($x['name'])?></span><input type="radio" name="default_field" value="<?=$x['id']?>" <?=($df===(int)$x['id'])?'checked':''?> title="Als Standard verwenden"><small>Standard</small></label><?php endforeach;?></div>
<h3>Kunden</h3><div class="check-grid"><?php foreach($customers as $x):?><label class="check-item"><input type="checkbox" name="customers[]" value="<?=$x['id']?>" <?=in_array((int)$x['id'],$ac,true)?'checked':''?>><span><?=h($x['name'])?></span><input type="radio" name="default_customer" value="<?=$x['id']?>" <?=($dc===(int)$x['id'])?'checked':''?> title="Als Standard verwenden"><small>Standard</small></label><?php endforeach;?></div>
<h3>Produkte</h3><div class="check-grid"><?php foreach($products as $x):?><label class="check-item"><input type="checkbox" name="products[]" value="<?=$x['id']?>" <?=in_array((int)$x['id'],$ap,true)?'checked':''?>><span><?=h($x['name'])?></span><input type="radio" name="default_product" value="<?=$x['id']?>" <?=($dp===(int)$x['id'])?'checked':''?> title="Als Standard verwenden"><small>Standard</small></label><?php endforeach;?></div>
<p><button class="button primary">Zuordnungen speichern</button></p></form></div>
<?php layoutEnd(); ?>
