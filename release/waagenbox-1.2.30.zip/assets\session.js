// Nur echte Bedienung verlängert die Sitzung, niemals das Dashboard-Polling.
(() => {
    let activity = false;
    for (const event of ['pointerdown', 'keydown', 'scroll', 'touchstart']) {
        document.addEventListener(event, e => { if (e.isTrusted) activity = true; }, {passive: true});
    }
    setInterval(async () => {
        try {
            const response = await fetch('api/session_activity.php', {
                method: 'POST', cache: 'no-store', headers: csrfHeaders(),
                body: new URLSearchParams({active: activity ? '1' : '0'})
            });
            activity = false;
            if (response.status === 401) location.assign('login.php');
        } catch (_) { /* Bei Verbindungsausfall prüft der Server beim nächsten Zugriff. */ }
    }, 15000);
})();
