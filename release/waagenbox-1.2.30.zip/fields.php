<?php
require_once __DIR__.'/functions.php';
requireLogin();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $pdo=db();
    try {
        $pdo->beginTransaction();
        if(isset($_POST['create'])) {
            $s=$pdo->prepare('INSERT INTO `fields` (owner_user_id,name,crop,year,area,notes,active) VALUES (?,?,?,?,?,?,1)');
            $s->execute([
                currentOwnerId(),
                trim($_POST['name'] ?? ''),
                trim($_POST['crop'] ?? ''),
                ($_POST['year'] ?? '') !== '' ? (int)$_POST['year'] : null,
                numOrNull($_POST['area'] ?? ''),
                trim($_POST['notes'] ?? '')
            ]);
            flash('Schlag wurde angelegt.');
        } elseif(isset($_POST['toggle_active'])) {
            $fid = (int)$_POST['toggle_active'];
            $s=$pdo->prepare('UPDATE `fields` SET active = CASE WHEN active=1 THEN 0 ELSE 1 END WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$fid]);
            flash('Status des Schlags wurde geändert.');
        }
        elseif(isset($_POST['delete_id'])) {
            $fid = (int)$_POST['delete_id'];
            if ($fid <= 0) throw new RuntimeException('Ungültiger Schlag.');
            $c=$pdo->prepare('SELECT COUNT(*) FROM weighings WHERE owner_user_id=? AND field_id=?');
            $c->execute([currentOwnerId(),$fid]);
            $count=(int)$c->fetchColumn();
            $s=$pdo->prepare('DELETE FROM `fields` WHERE owner_user_id=? AND id=?');
            $s->execute([currentOwnerId(),$fid]);
            $msg = $s->rowCount() ? 'Schlag wurde gelöscht.' : 'Schlag wurde nicht gefunden.';
            if ($count > 0 && $s->rowCount()) $msg .= ' Die zugehörigen Wiegungen bleiben erhalten, haben aber keinen Schlag mehr zugeordnet.';
            flash($msg);
        }
        $pdo->commit();
    } catch(Throwable $e) {
        if($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    redirect('fields.php');
}
layoutStart('Schläge','fields');
$stmt = db()->prepare("
    SELECT f.*, COALESCE(SUM(w.net_weight),0) AS total_net_weight, COUNT(w.id) AS weighing_count
    FROM `fields` f
    LEFT JOIN weighings w ON w.field_id = f.id AND w.owner_user_id = f.owner_user_id
    WHERE f.owner_user_id = ?
    GROUP BY f.id
    ORDER BY f.active DESC, f.name ASC
");
$stmt->execute([currentOwnerId()]);
$rows = $stmt->fetchAll();
?>
<div class="toolbar"><h1>Schläge</h1><a class="button primary" href="#neu">+ Schlag anlegen</a></div>
<div class="card table-wrap"><table><tr><th>Aktiv</th><th>Name</th><th>Kultur</th><th>Jahr</th><th>Fläche</th><th>Gewogene Gesamtmenge</th><th></th></tr>
<?php foreach($rows as $r): ?>
<tr>
<td><?=$r['active']?'✓':''?></td>
<td><strong><?=h($r['name'])?></strong><br><small><?=h($r['weighing_count'])?> Wiegung(en)</small></td>
<td><?=h($r['crop'])?></td>
<td><?=h($r['year'])?></td>
<td><?=h($r['area'])?> ha</td>
<td><strong><?=number_format((float)$r['total_net_weight'],1,',','.')?> kg</strong><br><small><?=number_format((float)$r['total_net_weight']/1000,2,',','.')?> t netto</small></td>
<td class="row-actions"><form method="post" style="display:inline"><button class="button primary" name="toggle_active" value="<?= (int)$r['id'] ?>"><?=$r['active']?'Deaktivieren':'Aktiv setzen'?></button></form> <a class="button" href="reports/field.php?id=<?= (int)$r['id'] ?>" target="_blank">PDF</a> <form method="post" class="delete-form" onsubmit="return confirm(<?=json_encode('Schlag '.($r['name'] ?? '').' wirklich endgültig löschen?\n\nZugehörige Wiegungen werden nicht gelöscht, verlieren aber ihre Schlag-Zuordnung.\n\nDieser Vorgang kann nicht rückgängig gemacht werden.', JSON_UNESCAPED_UNICODE)?>);"><input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>"><button type="submit" class="button-danger">Löschen</button></form></td>
</tr>
<?php endforeach; ?></table></div>
<div class="card" id="neu"><h2>Schlag anlegen</h2><form method="post"><div class="form-grid">
<div><label>Name</label><input name="name" required></div><div><label>Kultur</label><input name="crop"></div>
<div><label>Jahr</label><input type="number" name="year" value="<?=date('Y')?>"></div><div><label>Fläche (ha)</label><input type="number" step="0.01" name="area"></div>
<div class="full"><label>Notizen</label><textarea name="notes"></textarea></div></div><p><button class="button primary" name="create" value="1">Schlag speichern</button></p></form></div>
<?php layoutEnd(); ?>
