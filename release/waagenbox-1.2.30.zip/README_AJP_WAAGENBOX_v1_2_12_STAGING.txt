AJP Waagenbox Raspberry – v1.2.12 STAGING

Vollständiges Update-Paket für den Raspberry Pi.

Enthält den getesteten Web-Stand der Version 1.2.12 einschließlich:
- automatische Wiegungsabschlusserkennung im Testbetrieb
- 5-kg-Gewichtsdarstellung
- Kamera/Schnappschuss-Funktionen
- QR-/mobile Fernbedienung und GPS-Anpassungen
- Backup erstellen/wiederherstellen
- 5 Sekunden Verarbeitungs-/Rotphase nach Wiegungsabschluss
- Rücksprung zum Dashboard mit Meldung nach erfolgreichem Software-Update

Die lokale config.php wird durch den Update-Mechanismus bewusst nicht ersetzt.
