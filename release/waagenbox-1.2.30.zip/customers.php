<?php
require_once __DIR__.'/functions.php';
requireLogin();
$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $pdo=db();
  if(isset($_POST['toggle_id'])){ $id=(int)$_POST['toggle_id']; $q=$pdo->prepare('SELECT active FROM customers WHERE owner_user_id=? AND id=?');$q->execute([currentOwnerId(),$id]);$r=$q->fetch();if(!$r)throw new RuntimeException('Kunde wurde nicht gefunden.');$s=$pdo->prepare('UPDATE customers SET active=? WHERE owner_user_id=? AND id=?');$s->execute([(int)$r['active']?0:1,currentOwnerId(),$id]);flash('Kundenstatus wurde geändert.');redirect('customers.php'); }
  if(isset($_POST['delete_id'])){ $id=(int)$_POST['delete_id'];$s=$pdo->prepare('DELETE FROM customers WHERE owner_user_id=? AND id=?');$s->execute([currentOwnerId(),$id]);flash($s->rowCount()?'Kunde wurde gelöscht.':'Kunde wurde nicht gefunden.');redirect('customers.php'); }
  $name=trim((string)($_POST['name']??''));$address=trim((string)($_POST['address']??''));$notes=trim((string)($_POST['notes']??''));
  if($name==='')throw new RuntimeException('Bitte einen Kundennamen eingeben.');
  $s=$pdo->prepare('INSERT INTO customers(owner_user_id,name,address,notes) VALUES(?,?,?,?)');$s->execute([currentOwnerId(),$name,$address,$notes]);flash('Kunde wurde angelegt.');redirect('customers.php');
 }catch(Throwable $e){$error=$e->getMessage();}
}
layoutStart('Kunden','customers');if($error)echo '<div class="flash error"><strong>Kunde konnte nicht verarbeitet werden.</strong><br>'.h($error).'</div>';
$rows=db()->query('SELECT c.*,COUNT(w.id) AS weighing_count FROM customers c LEFT JOIN weighings w ON w.customer_id=c.id AND w.owner_user_id=c.owner_user_id WHERE c.owner_user_id='.(int)currentOwnerId().' GROUP BY c.id ORDER BY c.name')->fetchAll();
?>
<div class="toolbar"><h1>Kunden</h1><a class="button primary" href="#neu">+ Kunde anlegen</a></div>
<div class="card table-wrap"><table><tr><th>Status</th><th>Name</th><th>Adresse</th><th>Wiegungen</th><th></th></tr><?php foreach($rows as $r): ?><tr><td><?=((int)$r['active']?'Aktiv':'<span class="muted">Deaktiviert</span>')?></td><td><strong><?=h($r['name'])?></strong></td><td><?=nl2br(h($r['address']?:'–'))?></td><td><?=h($r['weighing_count'])?></td><td class="row-actions"><form method="post" style="display:inline"><button class="button" name="toggle_id" value="<?=h($r['id'])?>"><?=((int)$r['active']?'Deaktivieren':'Aktivieren')?></button></form><form method="post" style="display:inline" onsubmit="return confirm(<?=json_encode('Kunde '.($r['name']??'').' wirklich endgültig löschen?\n\nBestehende Wiegungen bleiben erhalten, verlieren aber die Kunden-Zuordnung.\n\nDieser Vorgang kann nicht rückgängig gemacht werden.',JSON_UNESCAPED_UNICODE)?>)"><button class="button-danger" name="delete_id" value="<?=h($r['id'])?>">Löschen</button></form></td></tr><?php endforeach; ?></table></div>
<div class="card" id="neu"><h2>Kunde anlegen</h2><form method="post"><div class="form-grid"><div><label>Name</label><input name="name" required></div><div><label>Adresse</label><input name="address"></div><div class="full"><label>Notizen</label><textarea name="notes"></textarea></div></div><p><button>Kunde speichern</button></p></form></div>
<?php layoutEnd(); ?>
