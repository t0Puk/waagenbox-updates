<?php
require_once __DIR__.'/../functions.php';
requireLogin();
header('Content-Type: application/json; charset=utf-8');
$p=pendingWeighing();
echo json_encode(['pending'=>$p?true:false,'key'=>$p?($p['started_at'].'|'.($p['remote_id']??0).'|'.($p['vehicle_id']??0)):null],JSON_UNESCAPED_UNICODE);
