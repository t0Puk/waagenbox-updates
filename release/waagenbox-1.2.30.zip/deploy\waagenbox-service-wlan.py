#!/usr/bin/python3
"""Separat freizugebender Root-Helper. Keine Installation beim App-Update."""
import json
import os
import re
import stat
import subprocess
import sys
import tempfile
import time

PROFILE = 'b712f0de-87d8-4ec4-930d-e22b2958b480'
NMCLI = '/usr/bin/nmcli'
CONFIG = '/etc/waagenbox/service-wlan-interface'
DEADLINE = None


def validate(request):
    if not isinstance(request, dict) or request.get('action') not in ('status', 'enable', 'disable'):
        raise ValueError('Ungültige WLAN-Aktion.')
    if request['action'] == 'enable':
        ssid, password = request.get('ssid'), request.get('password')
        if not isinstance(ssid, str) or not 1 <= len(ssid.encode('utf-8')) <= 32 or re.search(r'[\x00-\x1f\x7f]', ssid):
            raise ValueError('SSID ungültig (1 bis 32 UTF-8-Bytes ohne Steuerzeichen).')
        if not isinstance(password, str) or not re.fullmatch(r'[\x20-\x7e]{8,63}', password):
            raise ValueError('Passwort ungültig (8 bis 63 druckbare ASCII-Zeichen).')


def run(args):
    # Kein Shell-Aufruf; Ausgaben und Fehler niemals mit Passwörtern zurückgeben.
    remaining = 12 if DEADLINE is None else min(12, DEADLINE - time.monotonic())
    if remaining <= 0:
        raise ValueError('Zeitlimit überschritten. WLAN-Status erneut prüfen.')
    result = subprocess.run(args, capture_output=True, text=True, timeout=remaining,
                            env={'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LC_ALL': 'C'})
    if result.returncode:
        raise ValueError('NetworkManager-Abfrage oder WLAN-Aktion fehlgeschlagen. Bestehende Verbindungen bleiben geschützt.')
    return result.stdout.strip()


def nm(*args):
    return run([NMCLI, '--wait', '8', *args])


def interface():
    # Keine vom Webserver beschreibbare Konfiguration und keine Symlinks.
    for path in ('/etc/waagenbox', CONFIG):
        info = os.lstat(path)
        if stat.S_ISLNK(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('Service-Schnittstelle muss separat durch root freigegeben werden.')
    with open(CONFIG, encoding='ascii') as source:
        value = source.read(64).strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,15}', value):
        raise ValueError('Service-Schnittstelle ungültig.')
    return value


def keyfile(iface, ssid, password):
    # SSID als Byte-Liste; PSK gemäß GLib-Keyfile escapen, keine Zeileninjektion.
    encoded_ssid = ''.join(str(b) + ';' for b in ssid.encode('utf-8'))
    psk = password.replace('\\', '\\\\').replace(' ', '\\s')
    return (f'[connection]\nid=Waagenbox-Service\nuuid={PROFILE}\ntype=wifi\n'
            f'interface-name={iface}\nautoconnect=false\n\n[wifi]\nmode=ap\nssid={encoded_ssid}\n'
            f'\n[wifi-security]\nkey-mgmt=wpa-psk\npsk={psk}\n'
            '\n[ipv4]\nmethod=shared\naddress1=10.42.0.1/24\nnever-default=true\n'
            '\n[ipv6]\nmethod=disabled\n')


def handle(request):
    validate(request)
    iface = interface()
    if nm('-g', 'GENERAL.TYPE', 'device', 'show', iface) != 'wifi':
        raise ValueError('Freigegebene Schnittstelle ist kein WLAN-Gerät.')
    active = nm('-g', 'GENERAL.CON-UUID', 'device', 'show', iface)
    action = request['action']
    if action == 'status':
        return 'Service-WLAN ist eingeschaltet.' if active == PROFILE else 'Service-WLAN ist ausgeschaltet.'
    if action == 'disable':
        if active == PROFILE:
            nm('connection', 'down', 'uuid', PROFILE)
        return 'Service-WLAN ist ausgeschaltet.'
    if active not in ('', '--'):
        raise ValueError('WLAN-Schnittstelle ist bereits belegt. Keine Verbindung wurde getrennt; Service-WLAN gegebenenfalls zuerst ausschalten.')
    if nm('-g', 'WIFI-PROPERTIES.AP', 'device', 'show', iface) != 'yes':
        raise ValueError('Die WLAN-Schnittstelle unterstützt keinen Access Point.')
    if nm('radio', 'wifi') != 'enabled':
        raise ValueError('WLAN-Funk ist gesperrt. Der Helper ändert den globalen Funkzustand nicht.')
    # Keine Überschneidung mit vorhandenen Adressen/Routen.
    import ipaddress
    network = ipaddress.ip_network('10.42.0.0/24')
    for route in json.loads(run(['/usr/sbin/ip', '-j', '-4', 'route', 'show', 'table', 'all'])):
        destination = route.get('dst', 'default')
        if destination != 'default' and network.overlaps(ipaddress.ip_network(destination, strict=False)):
            raise ValueError('10.42.0.0/24 überschneidet sich mit einer vorhandenen Route.')
    # Feste UUID darf nur unser dediziertes AP-Profil bezeichnen.
    profiles = nm('-g', 'UUID', 'connection', 'show').splitlines()
    if PROFILE in profiles:
        if (nm('-g', 'connection.interface-name', 'connection', 'show', 'uuid', PROFILE) != iface or
                nm('-g', '802-11-wireless.mode', 'connection', 'show', 'uuid', PROFILE) != 'ap'):
            raise ValueError('Reserviertes Service-Profil passt nicht zur freigegebenen Schnittstelle.')
    directory = '/etc/NetworkManager/system-connections'
    info = os.lstat(directory)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise ValueError('NetworkManager-Profilverzeichnis ist nicht sicher.')
    profile_path = directory + '/waagenbox-service.nmconnection'
    if os.path.lexists(profile_path) and (os.path.islink(profile_path) or PROFILE not in profiles):
        raise ValueError('Vorhandene Profildatei kann nicht sicher zugeordnet werden.')
    fd, path = tempfile.mkstemp(prefix='.waagenbox-service-', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as target:
            target.write(keyfile(iface, request['ssid'], request['password']))
        os.replace(path, profile_path)
        nm('connection', 'load', profile_path)
        # Zustand unmittelbar vor Aktivierung nochmals prüfen.
        if nm('-g', 'GENERAL.CON-UUID', 'device', 'show', iface) not in ('', '--'):
            raise ValueError('Schnittstelle inzwischen belegt; Aktivierung abgebrochen.')
        nm('connection', 'up', 'uuid', PROFILE, 'ifname', iface)
    finally:
        if os.path.exists(path):
            os.unlink(path)
    return 'Service-WLAN ist eingeschaltet. Adresse: http://10.42.0.1'


def main():
    global DEADLINE
    DEADLINE = time.monotonic() + 35
    try:
        if os.geteuid() != 0:
            raise ValueError('Service-WLAN-Helper benötigt eine separate Freigabe.')
        import fcntl
        lock = os.open('/run/waagenbox-service-wlan.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(lock, 'w') as guard:
            fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
            data = sys.stdin.buffer.read(4097)
            if len(data) > 4096:
                raise ValueError('Anfrage zu groß.')
            message = handle(json.loads(data))
        print(json.dumps({'ok': True, 'message': message}))
    except ValueError as error:
        print(json.dumps({'ok': False, 'message': str(error) if not isinstance(error, json.JSONDecodeError) else 'Ungültige Anfrage.'}))
    except Exception:
        print(json.dumps({'ok': False, 'message': 'Service-WLAN nicht verfügbar. Installation, Berechtigungen und NetworkManager prüfen.'}))


if __name__ == '__main__':
    main()
