#!/usr/bin/python3
"""Check tracked release candidate paths only. Does not read secrets or build ZIPs."""
import json
from pathlib import PurePosixPath
import re
import subprocess


def allowed(name):
    if not name or '\\' in name or ':' in name or name.startswith('/'):
        return False
    parts = PurePosixPath(name).parts
    if any(part in ('.', '..') for part in name.split('/')):
        return False
    lower = name.lower()
    base = parts[-1].lower()
    if any(part.lower() in ('.git', '.ssh', '__pycache__', 'backups', 'rollback', 'tmp', 'temp', 'cache') for part in parts):
        return False
    if base == 'config.php' or base.startswith('.env') or re.fullmatch(r'id_(rsa|dsa|ecdsa|ed25519)', base):
        return False
    if lower.endswith(('.key', '.pem', '.ppk', '.p12', '.pfx', '.sql.gz', '.bak', '.backup', '.dump', '.old', '.orig', '.pyc')):
        return False
    if lower.endswith('.sql') and not (name == 'schema.sql' or re.fullmatch(r'migration_[A-Za-z0-9_]+\.sql', name)):
        return False
    if parts[0].lower() == 'uploads' and base != '.htaccess':
        return False
    return True


if __name__ == '__main__':
    names = subprocess.check_output(['git', 'ls-files', '-z']).decode('utf-8').split('\0')
    rejected = [name for name in names if name and not allowed(name)]
    print(json.dumps({'ok': not rejected, 'rejected': rejected, 'zip_created': False}))
    raise SystemExit(1 if rejected else 0)
